﻿/**
 * @fileoverview
 * Node에 대해 Map으로 wrapping 하기 위한 Interface
 */
/**
 * Node에 대해 Map으로 wrapping 하기 위한 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.Node
 */
eXria.data.MapNode = function(poNode) {
  /**
   * inherit
   */
  eXria.data.Node.call(this, poNode);
  /**
   * ChildNode의 Element 갯수를 리턴한다.
   * @return ChildNode중 Element 갯수
   * @type Number
   */
  this.size = null;
  /**
   * ChildNode중 넘겨받은 Tag명인 첫번째 노드의 TextNode값을 리턴한다.
   * @param {String} psKey 조회할 ElementNode의 Tag명
   * @return 조회된 TextNode의 값
   * @type String
   */
  this.get = null;
  /**
   * ChildNode에 넘겨받은 Key값이 존재할 경우 존재하는 ChildNode의 하위 TextNode로 값을 설정하고,
   * 존재하지 않는 경우 ChileNode에 Append한다.
   * @param {String} psKey 설정할 Element Tag Name
   * @param {String} psValue 설정할 Value
   * @return void
   * @type void
   */
  this.put = null;
  /**
   * 넘겨받은 값을 Tag Name으로 가지는 첫번째 Node를 삭제한다.
   * @param {String} psKey 삭제할 Tag명
   * @return void
   * @type void
   */
  this.remove = null;
  /**
   * 모든 하위 노드를 삭제한다.
   * @return void
   * @type void
   */
  this.clear = null;
  /**
   * 하위 Element의 존재 유무 리턴
   * @return 하위 ElementNode가 없을 경우 true, 아니라면 false
   * @type Boolean
   */
  this.isEmpty = null;
  /**
   * ChildNode의 Tag명 만으로 구성된 Collection 객체를 리턴한다.
   * @return Tag Name으로 구성된 Collection
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getKeyCollection = null;
  // deprecated ?
  /**
   * ChildNode의 Element 하위 TextNode 및 CDataNode의 값만으로 구성된 Collection 객체를 리턴한다.
   * @return TextNode 및 CDataNode의 값만으로 구성된 Collection 객체를 리턴한다.
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getValueCollection = null;
  /**
   * ChildNode의 Element, TextNode 및 CDataNode로 구성된 Object Collection 객체를 리턴한다.
   * @return Element, TextNode 및 CDataNode로 구성된 Collection 객체
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getEntryCollection = null;
  /**
   * JSON Format String 값으로 리턴한다.
   * @return JSON Format의 xml data
   * @type String
   */
  this.toString = null;
};
