/**
 * @fileoverview
 * Instance 클래스의 Interface
 */
/**
 * Instance 클래스의 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {String} Instance Id
 * @param {eXria.form.Model} eXria Model Object
 * @constructor
 */
eXria.data.Instance = function(psId, poModel) {
  /**
   * Instance Id
   * @type String
   */
  this.id = psId;
  /**
   * Model Object
   * @type eXria.form.Model
   */
  this.model = poModel;
  /**
   * document
   * @private
   */
  this.document = null;
  /**
   * loadXML, loadURL, loadTXT 메소드 사용시 이전의 DOM 삭제 후 새로운 데이터를 로딩
   * <br/>Plugin에서만 사용 가능한 플래그
   * @type Number
   */
  this.LOADREPLACE = null;
  /**
   * loadXML, loadURL, loadTXT 메소드 사용시 이전의 DOM 유지 후 새로운 데이터 로딩
   * <br/>Plugin에서만 사용 가능한 플래그
   * @type Number
   */
  this.LOADAPPEND = null;
  /**
   * Parameter로 넘어온 URL의 타겟에 해당하는 XML을 인스턴스에 바인딩 한다.
   * @param {String} psUrl 바인딩할 XML의 URL
   * @param {Number} pnMode XML 바인딩 시 [InstanceObj.LOADREPLACE | InstanceObj.LOADAPPEND] 설정(Plugin에서만 지정가능)
   * @return void
   * @type void
   */
  this.loadURL = null;
  /**
   * Parameter로 넘어온 XML Element를 인스턴스에 바인딩한다.
   * @param {XMLElement} poXML 바인딩할 XMLElement
   * @param {Number} pnMode XML 바인딩 시 [InstanceObj.LOADREPLACE | InstanceObj.LOADAPPEND] 설정(Plugin에서만 지정가능)
   * @return void
   * @type void
   */
  this.loadXML = null;
  /**
   * Parameter로 넘어온 XML Text를 파싱하여 인스턴스에 바인딩한다.
   * @param {String} psTxt 파싱할 XML Text
   * @param {Number} pnMode XML 바인딩 시 [InstanceObj.LOADREPLACE | InstanceObj.LOADAPPEND] 설정(Plugin에서만 지정가능)
   * @return void
   * @type void
   */
  this.loadTXT = null;
  /**
   * Node를 주어진 타입에 따라 생성하여 그 객체를 리턴한다. Type이 없을 경우 Default로 Element Node가 리턴 된다.
   * @param {String} psNodeName 두번째 파라미터로 넘어오는 Type에 따라 Node명 또는 그 Node의 Value가 된다.
   * @param {Number} pnType Type [eXria.data.NodeType]
   * @type eXria.data.Node
   * @return 생성된 XML Node
   */
  this.createNode = null;
  /**
   * 파라미터로 넘어온 이름의 Element를 생성하여 리턴한다.
   * @param {String} psElementName 생성될 엘리먼트 이름
   * @return 생성된 Element Node
   * @type eXria.data.Node
   * @see eXria.data.Node
   */
  this.createElement = null;
  /**
   * Parameter로 넘어온 Tag Name을 가지는 ElementNode를 Value Node 형태로 생성하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 value node
   * @type eXria.data.ValueNode
   * @see eXria.data.ValueNode
   */
  this.createValueNode = null;
  /**
   * Parameter로 넘어온 Tag Name을 가지는 ElementNode를 Map Node 형태로 생성하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 Map node
   * @type eXria.data.MapNode
   * @see eXria.data.MapNode
   */
  this.createMapNode = null;
  /**
   * Parameter로 넘어온 Tag Name을 가지는 ElementNode를 CollectionNode 형태로 생성하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 Collection Node
   * @type eXria.data.CollectionNode
   * @see eXria.data.CollectionNode
   */
  this.createCollectionNode = null;
  /**
   * Parameter로 넘어온 XPath에 해당 Node를 추가한다.
   * @param {String} psPath 추가할 위치에 해당하는 XPath
   * @param {XMLNode} poNode 추가할 XMLNode
   * @return void
   * @type void
   */
  this.appendNode = null;
  /**
   * 넘겨받은 XPath를 단순 Value형태로 처리하기 위한 ValueNode를 생성하여 리턴한다.
   * @param {String} psXpath psClassName 참조 대상 클래스명
   * @return 생성된 value node
   * @type eXria.data.ValueNode
   * @see eXria.data.ValueNode
   */
  this.getValueNode = null;
  /**
   * 파라미터로 넘어온 XPath의 Node Value를 리턴한다.
   * @param {String} psXpath 조회대상의 XPath 경로
   * @type String
   * @return 조회된 Value
   */
  this.getValue = null;
  /**
   * Instance의 dom객체의 XML 내용을 XPath를 이용하여 해당 위치에 데이터를 문자열로 얻는다.
   * @return dom 객체의 XML 문자열
   * @param {String} psXPath XPath 문자열
   * @type String
   */
  this.getXML = null;
  /**
   * Instnace의 주어진 XPath 경로에 Value를 설정한다.
   * @param {String} psXpath Value를 설정하기 위한 XPath 경로
   * @param {String} psValue 설정하고자 하는 Value
   * @return void
   * @type void
   */
  this.setValue = null;
  /**
   * 넘겨받은 XPath를 Map형태로 처리하기 위한 MapNode를 생성하여 리턴한다.
   * @param {String} psXpath psClassName 참조 대상 클래스명
   * @return 생성된 Map node
   * @type eXria.data.MapNode
   * @see eXria.data.MapNode
   */
  this.getMapNode = null;
  /**
   * 넘겨받은 XPath를 Collection형태로 처리하기 위한 CollectionNode를 생성하여 리턴한다.
   * @param {String} psXpath 처리할 기준 Node XPath
   * @return 생성된 Collection node
   * @type eXria.data.CollectionNode
   * @see eXria.data.CollectionNode
   */
  this.getCollectionNode = null;
  /**
   * 넘겨받은 Xpath의 Node를 삭제한다.
   * @param {String} psXpath 삭제할 Node의 XPath
   * @return 삭제된 노드
   * @type eXria.data.Node
   */
  this.removeNode = null;
  /**
   * 해당 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 node
   * @type eXria.data.Node
   */
  this.selectSingleNode = null;
  /**
   * Instance의 하위Node를 넘겨받은 XPath로 조회하여 리턴한다.
   * @param {String} psXpath 조회할 Xpath
   * @return 조회된 node list
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodes = null;
  /**
   * Instance의 하위 Node를 Collection 형태로 리턴하며, <br/>
   * 해당 Node에 자식 Node가 있을 경우 nodeName과 nodeValue가 각각 Key, Value로 셋팅된 Map으로 Wrapping 하여 Collection에 Set
   * @param {String} psXpath Collection으로 리턴 받고자 하는 Node의 부모의 XPath
   * @return Collection으로 Wrapping 된 Node
   * @type eXria.data.Collection
   */
  this.getCollection = null;
  /**
   * 모든 하위노드를 삭제한다.
   * @return void
   * @type void
   */
  this.clear = null;
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 alert으로 출력
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return void
   * @type void
   */
  this.print = null;
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 문자열로 반환
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return xml 노드를 문자열화한 객체
   * @type String
   */
  this.nodeToStr = null;
  /**
   * 넘겨 받은 XPath의 Node를 복사하여 리턴한다.
   * @param {String} psXPath 복사할 Node의 XPath
   * @param {String} pbDeep 깊은복사 유무 ( True : Deep Copy )
   * @return 복사된 노드
   * @type eXria.data.Node
   */
  this.cloneNode = null;
  /**
   * 해당 XPath 하위에 두번째 파라미터로 넘어온 XML Text Node구조를 생성한다.
   * @param {String} psXpath 생성할 Node의 Parent Node가 될 Node의 XPath
   * @param {String} psTxt 생성할 Node XML Text
   * @return void
   * @type void
   */
  this.appendNodeByTxt = null;
};
