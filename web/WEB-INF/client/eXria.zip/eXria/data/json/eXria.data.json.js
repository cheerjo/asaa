/**
 * @fileoverview
 * eXria.data.xhtml Package
 */
/**
 * eXria.data.xhtml package
 * @author Cho, Young Jin.
 */
eXria.data.json = {};