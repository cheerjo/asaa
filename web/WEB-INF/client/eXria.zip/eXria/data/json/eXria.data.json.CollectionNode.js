/**
 * @fileoverview
 * XHTML Mode 사용시 Document Node를 Collection으로 wrapping 해주는 클래스
 */
/**
 * XHTML Mode 사용시 Document Node를 Collection으로 wrapping 해주는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.xhtml.Node
 */
eXria.data.json.CollectionNode = function(paList) {
  this.node = paList;
  this.nodeList = paList;

  this.add = function(poNode) {
    if(this.size() == 0 && (page.metadata.useDomPath == true)){
      var vsRowName = (poNode.parentNode != null) ? poNode.parentNode.nodeName : poNode.name;
      
      var voArrayNode = this.node.createElement(vsRowName, []);
      if(this.nodeList.getLength() == 0) { // json object 선언은 되어있음
        this.node.appendChild(voArrayNode);
        this.nodeList.nodeList = voArrayNode.node;
      } else if(this.nodeList.nodeList[0] && (this.nodeList.nodeList[0].getNodeType() == 3)) { // json object 선언은 되어있음. text nodes
        var voNode = this.node.createElement(this.node.name, {});
        this.node.parentNode[this.node.name] = voNode;
        this.node.appendChild(voArrayNode);
        this.nodeList.nodeList = voArrayNode.node;
      }
    }
    if(this.nodeList instanceof eXria.data.json.NodeList || this.nodeList instanceof eXria.data.xhtml.NodeList) {
      this.nodeList.nodeList.push(poNode.node);
    }else {
      this.nodeList.push(poNode.node);
    }
  };
  /**
   * 현재 Collection의 Item 갯수를 리턴한다.
   * @return 하위 ElementNode의 갯수
   * @type Number
   */
  this.size = function() {
    if(this.nodeList == null) return 0;
    if(this.nodeList instanceof eXria.data.json.NodeList || this.nodeList instanceof eXria.data.xhtml.NodeList) {
      var voNodeList = this.nodeList;
      var vnSize = voNodeList.getLength();
      var vnCnt = 0;
      for (var i = 0; i < vnSize; i++){
        if(voNodeList.item(i).getNodeType() == 1){
          vnCnt++;
        }
      }
      return vnCnt;
    }
    return this.nodeList.length;
  };
  /**
   * Parameter로 넘어온 Index에 해당하는 위치의 Node를 리턴한다.
   * @param {Number} pnIndex 리턴받은 Node의 Index
   * @return 해당 Index의 Node. Index가 Node의 범위 밖인 경우 null을 리턴한다.
   * @type  XMLNode
   */
  this.get = function(pnIndex) {
    var voNodeList = this.nodeList;
    var vnLen = voNodeList.getLength();
    var voItem = null;
    for (var i = 0; i < vnLen; i++){
      if(voNodeList.item(i).getNodeType() == 3){
        pnIndex++;
      }
      if(i == pnIndex) voItem = this.nodeList.item(pnIndex);
    }
    return voItem;
  };
  /**
   * 주어진 값이 현재 Node 구성 요소의 인덱스 번호로서 적합한 지 여부를 검사하는 메소드
   * Collection의 Range안에 없을 경우 Error Throw.
   * @param {Number} pnIndex 체크할 Index
   * @return void
   * @type void
   * @private
   */
  this.rangeCheck = function(pnIndex) {
    if (pnIndex < 0 || pnIndex > this.size()) {
      throw new Error("Index out of range : " + pnIndex);
    }
  };
  /**
   * Collection에서 Parameter로 넘어온 Index에 해당되는 위치에 두번째 Parameter로 넘어온 Node를 추가한다. 만약 해당 Index에 기존 Node가 존재할 경우 기존 Node는 삭제 된다.
   * @param {Number} pnIndex 추가할 위치 Index
   * @param {XMLNode} poNode 추가할 Node
   * @return 넘겨받은 Index에 Node가 존재할 경우 기존 Node를 대체하고 기존 Node를 리턴한다.
   * @type XMLNode
   */
  this.set = function(pnIndex, poNode) {
    var vnSize = this.size();
    if (vnSize < pnIndex) {
      throw new Error("Index out of range : " + pnIndex);
    } else if (vnSize == pnIndex) {
      this.add(poNode);
      return null;
    } else {
      var voNodeList = this.nodeList;
      var vnLen = voNodeList.getLength();
      var voItem = null;
      for (var i = 0; i < vnLen; i++){
        if(voNodeList.item(i).getNodeType() == 3){
          pnIndex++;
        }
        if(i == pnIndex) {
          this.nodeList[pnIndex] = poNode;
        }
      }
//      this.nodeList[pnIndex] = poNode;
      return poNode;
    }
    
  };
  /**
   * 넘겨 받은 Index에 Node를 추가 한다. 해당 Index에 기존에 Node가 존재 할 경우 해당 Node 및 이후 Index의 Node들의 Index가 하나씩 밀린다.
   * @param {Number} pnIndex 추가할 위치 Index
   * @param {XMLNode} poNode 추가할 Node
   * @return 넘겨받은 Index에 Node가 존재할 경우 기존 Node를 대체하고 기존 Node를 리턴한다.
   * @type XMLNode
   */
  this.insert = function(pnIndex, poNode) {
    
    var vnSize = this.size();
    if(vnSize < pnIndex - 1) { // over
      throw new Error("Index out of range : " + pnIndex);
    } else if(vnSize == pnIndex - 1) { // last
      this.add(poNode);
      return null;
    } else {
      if(poNode instanceof eXria.data.json.Node || poNode instanceof eXria.data.xhtml.Node) poNode = poNode.node;
      var voNodeList = this.nodeList;
      var vnLen = voNodeList.getLength();
      var voItem = null;
      for (var i = 0; i < vnLen; i++){
        if(voNodeList.item(i).getNodeType() == 3){
          pnIndex++;
        }
        if(i == pnIndex) {
          this.nodeList.nodeList.splice(pnIndex, 0, poNode);
        }
      }
//      this.nodeList.nodeList.splice(pnIndex, 0, poNode);
      return poNode;
    }
  };
  /**
   * Parameter로 넘어온 Index에 해당하는 Node를 삭제한다.
   * @param {Number} pnIndex 삭제할 Node Index
   * @return 삭제된 Node 참조값
   * @type XMLNode
   */
  this.remove = function(pnIndex) {
    var voNode = this.get(pnIndex);
    if(voNode) {
      var voNodeList = this.nodeList;
      var vnLen = voNodeList.getLength();
      var voItem = null;
      for (var i = 0; i < vnLen; i++){
        if(voNodeList.item(i).getNodeType() == 3){
          pnIndex++;
        }
        if(i == pnIndex) {
          this.nodeList.nodeList.splice(pnIndex, 1);
        }
      }
//      this.nodeList.splice(pnIndex, 1);
    }
    return voNode;
  };
  /**
   * Collection의 모든 Node를 삭제 하고 Collection을 초기화 한다.
   * @return void
   * @type void
   */
  this.clear = function() {
    this.nodeList = [];
  };
  /**
   * 현재 Collection이 비어 있는지 체크하여 리턴한다.
   * @return 비어있는 노드일 경우 TRUE, 아닐 경우 FALSE
   * @type Boolean
   */
  this.isEmpty = function() {
    return (this.size() == 0);
  };
  /**
   * 현재 Collection의 모든 Node를 Iterator로 변환하여 리턴한다.
   * @return 내부객체를 조회하는 Iterator
   * @type eXria.data.ArrayIterator
   * @see eXria.data.ArrayIterator
   */
  this.iterator = function() {
    var voNodeList = this.nodeList;
    var vnLen = voNodeList.getLength();
    var vaList = [];
    for(var i = 0; i < vnLen; i++){
      if(voNodeList.item(i).getNodeType() == 1){
        vaList.push(voNodeList.item(i));
      }
    }
    this.elements = vaList;
    return new eXria.data.ArrayIterator(this);
  };
  /**
   * 현재 메소드 이름을 리턴한다.
   * @return 내부요소를 파싱한 String 값
   * @type String
   */
  this.toString = function() {
    return "CollectionNode";
  };
  /**
   * 반복되는 하위 노드의 tagName 저장 속성
   * @return void
   * @type void
   * @private
   */
  this.reset = function() {
    if(this.node instanceof eXria.data.json.Node || this.node instanceof eXria.data.xhtml.Node){
//      if(!(this.node.node instanceof Array))
      this.nodeList = this.node.getChildNodes();
//      if(this.nodeList == null) this.nodeList = this.node.createElement(this.node.name ,[]);
    } else {
      this.nodeList = this.node;
    }
//    if(this.node instanceof eXria.data.json.Node || this.node instanceof eXria.data.xhtml.Node){
//      var voNodeList = this.node.getChildNodes();
//      if(voNodeList == null) {
//        this.nodeList = [];
//        return;
//      }
//      var vnLen = voNodeList.getLength();
//      var vaList = [];
//      for(var i = 0; i < vnLen; i++){
//        if(voNodeList.item(i).getNodeType() == 1){
//          vaList.push(voNodeList.item(i));
//        }
//      }
//      this.nodeList = new eXria.data.json.NodeList(vaList, voNodeList.name, voNodeList.parentNode);
//    } else {
//      this.nodeList = this.node;
//    }
  };
  /**
   * 생성시 reset 메소드 호출
   * @private
   */
  this.reset();
};
