/**
 * @fileoverview
 * XHTML Mode 사용시 Document Node를 Map으로 wrapping 해주는 클래스
 */
/**
 * XHTML Mode 사용시 Document Node를 Map으로 wrapping 해주는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.xhtml.Node
 */
eXria.data.json.MapNode = function(poNode) {
  /**
   * inherit
   */
  this.node = poNode;
  if(!(poNode.toString && poNode.toString() == "eXria.data.json.Node")) this.node = new eXria.data.json.Node(poNode);

  /**
   * ChildNode의 Element 갯수를 리턴한다.
   * @return ChildNode중 Element 갯수
   * @type Number
   */
  this.size = function() {
    var voNodes = this.node.getChildNodes();
    var vnSize = 0;
    if(voNodes == null) return vnSize;
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        // Element
        vnSize++;
      }
    }
    return vnSize;
  };
  /**
   * ChildNode중 넘겨받은 Tag명인 첫번째 노드를 리턴한다.
   * @param {String} psName Tag Name
   * @return 조회된 XMLElementNode
   * @type XMLElementNode
   */
  this.getNode = function(psName) {
    var voNode = this.node.getElementByTagNameFromChildNodes(psName);
    return voNode;
  };
  /**
   * ChildNode중 넘겨받은 Tag명인 첫번째 노드의 TextNode값을 리턴한다.
   * @param {String} psKey 조회할 ElementNode의 Tag명
   * @return 조회된 TextNode의 값
   * @type String
   */
  this.get = function(psKey) {
    if (!psKey || psKey == "") {
      return null;
    }
    var voNode = this.node.node;
    var vsRet = voNode[psKey];
    return vsRet;
  };
  /**
   * ChildNode에 넘겨받은 Key값이 존재할 경우 존재하는 ChildNode의 하위 TextNode로 값을 설정하고,</br>
   * 존재하지 않는 경우 ChileNode에 Append한다.
   * @param {String} psKey 설정할 Element Tag Name
   * @param {String} psValue 설정할 Value
   * @return void
   * @type void
   */
  this.put = function(psKey, psValue) {
    psValue = (psValue != null ? psValue : "");
    var voNode = this.node.node;
    voNode[psKey] = psValue;
  };
  /**
   * 넘겨받은 값을 Tag Name으로 가지는 첫번째 Node를 삭제한다.
   * @param {String} psKey 삭제할 Tag명
   * @return void
   * @type void
   */
  this.remove = function(psKey) {
    var voNode = this.getNode(psKey);
    if (voNode != null) {
      this.node.removeChild(voNode);
    }
  };
  /**
   * 모든 하위 노드를 삭제한다.
   * @return void
   * @type void
   */
  this.clear = function() {
    var voNodes = this.node.getChildNodes();
    if(voNodes == null) return;
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        this.node.removeChild(voNode);
      }
    }
  };
  /**
   * 하위 Element의 존재 유무 리턴
   * @return 하위 ElementNode가 없을 경우 true, 아니라면 false
   * @type Boolean
   */
  this.isEmpty = function() {
    return (this.size() == 0);
  };
  /**
   * ChildNode의 Tag명 만으로 구성된 Collection 객체를 리턴한다.
   * @return Tag Name으로 구성된 Collection
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getKeyCollection = function() {
    var voCollection = new eXria.data.ArrayCollection();
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
//      if (voNode.getNodeType() == 1) {
//        // Element
        voCollection.add(voNode.getNodeName());
//      }
    }
    return voCollection;
  };
  /**
   * ChildNode의 Element 하위 TextNode 및 CDataNode의 값만으로 구성된 Collection 객체를 리턴한다.
   * @return TextNode 및 CDataNode의 값만으로 구성된 Collection 객체를 리턴한다.
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getValueCollection = function() {
    var voCollection = new eXria.data.ArrayCollection();
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
//      if (voNode.getNodeType() == 1) {
//        // Element
        voCollection.add(String(voNode.getNodeValue()));
//      }
    }
    return voCollection;
  };
  /**
   * ChildNode의 Element, TextNode 및 CDataNode로 구성된 Object Collection 객체를 리턴한다.
   * @return Element, TextNode 및 CDataNode로 구성된 Collection 객체
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getEntryCollection = function() {
    var voCollection = new eXria.data.ArrayCollection();
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    var vsKey = null, voValue = null, vsValue = null;

    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        voValue = voNode.getFirstChild();
        vsValue = String(voNode.getNodeValue())
        vsKey = voNode.getNodeName();

        if (voValue != null && voValue.getNodeType() == 1) {
          voCollection.add({
            key : vsKey, value : voValue.cloneNode(true)
          });
        } else if (vsValue != null) {
          voCollection.add({
            key : vsKey, value : vsValue
          });
        } else {
          voCollection.add({
            key : vsKey, value : null
          });
        }
      }
    }
    return voCollection;
  };
  /**
   * JSON Format String 값으로 리턴한다.
   * @return JSON Format의 xml data
   * @type String
   */
  this.toString = function() {
    return this.node.getJSON();
  };
};
