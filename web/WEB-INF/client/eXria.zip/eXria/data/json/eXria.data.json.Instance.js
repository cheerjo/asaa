/**
 * @fileoverview
 * XHTML Mode에서의 Instance 객체를 관리하는 클래스
 */
/**
 * XHTML Mode에서의 Instance 객체를 관리하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {String} psId Instance Id
 * @param {eXria.form.Model} poModel eXria Model Objecct
 * @constructor
 * @base eXria.data.Instance
 */
eXria.data.json.Instance = function(psId, poModel) {
  /**
   * inheritget
   */
  eXria.data.Instance.call(this, psId, poModel);

  /**
   * instObj
   * @type Object
   */
  this.instObj = {};
  //수정
  /**
   * copyInstObj
   * @type Object
   */
  this.copyInstObj = null;

  /**
   * XML Text를 파싱하여 인스턴스에 바인딩한다.
   * @param {String} psTxt 파싱할 XML Text
   * @return void
   * @type void
   */
  this.loadTXT = function(psTxt) {
    var voNode = eval("("+psTxt+")");
    this.instObj = voNode;
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 CollectionNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 CollectionNode
   * @type eXria.data.xhtml.CollectionNode
   * @see eXria.data.xhtml.CollectionNode
   */
  this.createCollectionNode = function(psName) {
    var voNode = this.document.createNode(psName)
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.CollectionNode(
        new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 넘겨 받은 XPath의 하위에 Node를 추가한다.
   * @param {String} psPath 추가할 위치에 해당하는 XPath
   * @param {XMLNode} poNode 추가할 XMLNode
   * @return void
   * @type void
   */
  this.appendNode = function(psPath, poNode) {
    var voNode = null;
    voNode = this.selectSingleNode(psPath);
    if (voNode == null) {
      throw new Error("Can not find the node : " + psPath);
    }
    voNode.appendChild(poNode);
  };
  /**
   * 넘겨받은 XPath를 단순 Value형태로 처리하기 위한 ValueNode를 생성하여 리턴한다.
   * @param {String} psXpath psClassName 참조 대상 클래스명
   * @return 생성된 ValueNode
   * @type eXria.data.xhtml.ValueNode
   * @see eXria.data.xhtml.ValueNode
   */
  this.getValueNode = function(psXpath) {
    var voNode = this.selectSingleNode(psXpath);
    if (voNode == null) {
      return null;
    }
    return new eXria.data.xhtml.ValueNode(voNode);
  };
  /**
   * 파라미터로 넘어온 XPath의 Node Value를 리턴한다.
   * @param {String} psXpath 조회대상의 XPath 경로
   * @type String
   * @return 조회된 Value
   */
  this.getValue = function(psXpath) {
    try {
      var voNode = this.selectSingleNode(psXpath);
      return voNode != null ? voNode.getNodeValue() : null;
    } catch (e) {
      return null;
    }
  };

  this.toJSONString = function(poNodeObj, pbEscape) {
    if(pbEscape == null) pbEscape = true;
    var voUtil = eXria.controls.xhtml.Util;
    var voNode = poNodeObj;
    if(poNodeObj instanceof eXria.data.json.Node || poNodeObj instanceof eXria.data.xhtml.Node) voNode = poNodeObj.node;

    if(voNode == null) {
      return "null";
    } else if(voNode.constructor == String) {
      if(pbEscape) return voUtil.escapeJSONString(voNode);
      else return "\"" + voNode.toString() + "\"";
    } else if(voNode.constructor == Number) {
      return voNode.toString();
    } else if(voNode.constructor == Boolean) {
      return voNode.toString();
    } else if(voNode.constructor == Date) {
      return '{javaClass: "java.util.Date", time: ' + voNode.valueOf() +'}';
    } else if(voNode.constructor == Array) {
      var v = [];
      for(var i = 0; i < voNode.length; i++) {
        v.push(this.toJSONString(voNode[i], pbEscape));
      }
      return "[" + v.join(", ") + "]";
    } else {
      var v = [];
      for (attr in voNode) {
        if (voNode [attr] == null) {
          v.push("\"" + attr + "\": null");
        }else if (typeof voNode [attr] == "function" || eXria.protocols.json.ReservedType[attr]) {
          // TODO function일 경우도 파싱
          // skip
        } else {
          v.push(voUtil.escapeJSONString(attr) + ": " + this.toJSONString(voNode[attr], pbEscape));
        }
      }
      var vsStr = v.join(", ");
      if (!vsStr) return "\"\"";
      else return "{" + v.join(", ") + "}";
    }
  };

  /**
   * Instance의 dom객체의 XML 내용을 XPath를 이용하여 해당 위치에 데이터를 문자열로 얻는다.
   * @return dom 객체의 XML 문자열
   * @param {String} psXPath XPath 문자열
   * @param {Boolean} pbEscape 노드 값을 escape 처리할지 여부. 미 지정 시 escape 처리됨
   * @type String
   */
  this.getJSON = function(psXPath, pbEscape) {
    if (!psXPath) {
      return;
    }

    var voObj = this.getInstObj(psXPath);

    if(!voObj) {
      return null;
    }
    //var vsName = voObj.name instanceof String ? voObj.name : "\""+voObj.name+"\"";
    var vsJson;
    if(voObj.name !=null) {
      if(voObj.node.parent instanceof Array) {
        vsJson = this.toJSONString(voObj, pbEscape);
      } else {
        vsJson = "{ " + voObj.name + " : " + this.toJSONString(voObj, pbEscape) + " }";
      }
    } else vsJson =  this.toJSONString(voObj, pbEscape);
    return vsJson;
  };
  /**
   * Instnace의 주어진 XPath 경로에 Value를 설정한다.
   * @param {String} psXpath Value를 설정하기 위한 XPath 경로
   * @param {String} psValue 설정하고자 하는 Value
   * @return void
   * @type void
   */
  this.setValue = function(psXpath, psValue) {
    var voNode = this.selectSingleNode(psXpath);
    if (voNode == null) { //!voNode
      return null;
    }
    psValue = (psValue ? psValue : "");
    var vsValue = voNode.setNodeValue(psValue);
  };
  /**
   * 넘겨받은 XPath를 Map형태로 처리하기 위한 MapNode를 생성하여 리턴한다.
   * @param {String} psXpath psClassName 참조 대상 클래스명
   * @return 생성된 MapNode
   * @type eXria.data.xhtml.MapNode
   * @see eXria.data.xhtml.MapNode
   */
  this.getMapNode = function(psXpath) {
    var voNode = this.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.MapNode(voNode);
  };
  /**
   * 넘겨받은 XPath를 Collection형태로 처리하기 위한 CollectionNode를 생성하여 리턴한다.
   * @param {String} psXpath 처리할 기준 Node XPath
   * @return 생성된 CollectionNode
   * @type eXria.data.xhtml.CollectionNode
   * @see eXria.data.xhtml.CollectionNode
   */
  this.getCollectionNode = function(psXpath) {
    var voNode = this.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    } else if(page.metadata.useDomPath) {
      var voFirst = voNode.getFirstChild();
      if(voFirst && voFirst.node instanceof Array) voNode = voFirst;
    }
    return new eXria.data.json.CollectionNode(voNode);
  };
  /**
   * 넘겨받은 Xpath의 Node를 삭제한다.
   * @param {String} psXpath 삭제할 Node의 XPath
   * @return 삭제된 노드
   * @type eXria.data.Node
   */
  this.removeNode = function(psXPath) {
    var voNode = null;
    var voPNodeObj = null;
    var voPNode = null;
    if (typeof (psXPath) == "string") {
      voNode = this.selectSingleNode(psXPath);
      if(!voNode) return null;
      voPNodeObj = voNode.parentNode;
      if (voPNodeObj instanceof Array) {
        voPNodeObj.splice(voNode.name, 1);
        if(page.metadata.useDomPath && voPNodeObj.length == 0) {
          var voGPNode = voPNodeObj.parent;
          delete voGPNode[voPNodeObj.nodeName];
        }
      } else {
        delete voPNodeObj [voNode.name];
      }
      voNode.parentNode = null;
      if (typeof (voNode.node) == "object") voNode.node.parent = null;
    } else {
      voNode = psXPath;
      voPNode = voNode.getParentNode();
      voPNode.removeChild(voNode);
    }
    return voNode;
  };
  /**
   * 해당 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 Node
   * @type XMLNode
   */
  this.selectSingleNode = function(psXpath) {
    var voBase = this;
    var voNode = null;
    if(this.isQueryPath(psXpath)) {
      var vsPath = this.convertToJsonPath(psXpath);
      var vaResPath = null;
      try {
        vaResPath = jsonPath(this.instObj, vsPath, {resultType:"PATH"});
      } catch(e) {}
      if(vaResPath) voNode = new eXria.data.json.Node(null, null, null, {
        instObj : voBase.instObj,
        path : vaResPath[0]
      });
    } else {
      voNode = this.getInstObj(psXpath);
    }
    return voNode;
  };
  /**
   * Instance의 하위Node를 넘겨받은 XPath로 조회하여 리턴한다.
   * @param {String} psXpath 조회할 Xpath
   * @return 생성된 NodeList
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodes = function(psXpath, pbNotTrim) {
    var voNode = null;
    var voNodeList = null;
//    if(page.metadata.useDomPath && !pbNotTrim && /.+\]$/.test(psXpath) == false) {
//      psXpath = psXpath.substring(0, psXpath.lastIndexOf("/"));
//    }

    if(this.isQueryPath(psXpath)) {
      voNodeList = [];
      var voInst = this.instObj;
      var vsPath = this.convertToJsonPath(psXpath);
      var vaResPath = null;
      try {
        vaResPath = jsonPath(voInst, vsPath, {resultType:"PATH"});
      } catch(e) {}
//      if(!vaResPath) return null;
      var vnSize = (!vaResPath) ? 0 : vaResPath.length;
      for(var i = 0; i < vnSize; i++){
        voNode = new eXria.data.json.Node(null, null, null, {
          instObj : voInst,
          path : vaResPath[i]
        });
        voNodeList.push(voNode);
      }
      var voParentNodeObj = null;
      if(voNodeList.length == 0) {
        voNodeList = null; 
      } else {
        voParentNodeObj = voNodeList[0].getParentNode().node; 
      }
      return new eXria.data.json.NodeList(voNodeList, this.getLastNodeName(psXpath), voParentNodeObj);
    }

    voNode = this.getInstObj(psXpath);
    if(voNode == null) return null;
    voNodeList = voNode.node;
    if(!(voNodeList instanceof Array)) {
      voNodeList = voNode;
      voNodeList = [voNodeList];
      voNodeList.nodeName = voNode.name;
      voNodeList.parent = voNode.parentNode;
    }
    return new eXria.data.json.NodeList(voNodeList, voNode.name, voNode.parentNode);
  };
  /**
   * Instance의 하위Node들을 넘겨받은 XPath로 조회하여 배열 객체로 반환하는 메소드.
   * plugin 버전은 데이타 호환성 때문에 문자열을 반환받으나 여기서는 배열 객체를 바로 반환함.
   * 일반적으로 이후에 응용코드에서 반환값을 eval하여 사용하게 되는데 이럴경우에만 이 메소드 사용이 가능하고
   * 메소드의 반환값을 문자열로만 취급할 경우에는 사용불가.
   * @param {String} psXpath 조회할 Xpath
   * @return 생성된 NodeList
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodesStr = function(psXpath) {
    var voNode = null;
    var voNodeList = null;

    if(this.isQueryPath(psXpath)) {
      voNodeList = [];
      var voInst = this.instObj;
      var vsPath = this.convertToJsonPath(psXpath);
      var vaResPath = null;
      try {
        vaResPath = jsonPath(voInst, vsPath, {resultType:"PATH"});
      } catch(e) {}
      if(!vaResPath) return null;
      var vnSize = vaResPath.length;
      for(var i = 0; i < vnSize; i++){
        voNode = new eXria.data.json.Node(null, null, null, {
          instObj : voInst,
          path : vaResPath[i]
        });
        voNodeList.push(voNode);
      }
      if(voNodeList.length == 0) { return null; }
      return voNodeList;
    }

    voNode = this.getInstObj(psXpath);
    if(voNode == null) return null;
    voNodeList = voNode.node;
    if(!(voNodeList instanceof Array)) {
      voNodeList = voNode;
      voNodeList = [voNodeList];
      voNodeList.nodeName = voNode.name;
      voNodeList.parent = voNode.parentNode;
    }
    return voNodeList;
  };
  /**
   * 모든 하위노드를 삭제한다.
   * @return void
   * @type void
   */
  this.clear = function() {
    delete this.document;
    this.model = null;
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 alert으로 출력
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return void
   * @type void
   */
  this.print = function(psXpath) {
    alert(this.getJSON(psXpath, false));
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 문자열로 반환
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return xml 노드를 문자열화한 객체
   * @type String
   */
  this.nodeToStr = function(psXpath) {
    if (psXpath == null || psXpath == undefined) {
      return;
    }
    return this.getJSON(psXpath);
  };
  /**
   * 넘겨 받은 XPath의 Node를 복사하여 리턴한다.
   * @param {String} psXPath 복사할 Node의 XPath
   * @param {String} pbDeep 깊은복사 유무 ( True : Deep Copy )
   * @return 복사된 노드
   * @type XMLNode
   */
  this.cloneNode = function(psXPath, pbDeep) {
    try {
      return new eXria.data.json.Node(this.selectSingleNode(psXPath));
    } catch (e) {
      return null;
    }
  };
  /**
   * 해당 XPath 하위에 두번째 파라미터로 넘어온 XML Text Node구조를 생성한다.
   * @param {String} psXpath 생성할 Node의 Parent Node가 될 Node의 XPath
   * @param {String} psTxt 생성할 Node XML Text
   * @return void
   * @type void
   */
  this.appendNodeByTxt = function(psXPath, psTxt) {
    var voNode = this.selectSingleNode(psXPath);
    var voApdNodeObj = eval("("+psTxt+")");
    var voApdNode = null;
    if(voNode.node instanceof Array){ //부모가 배열O
      voApdNode = new eXria.data.json.Node(voApdNodeObj);
      voNode.appendChild(voApdNode);
    }else{                            //부모가 배열X
      for(var vsAttr in voApdNodeObj){
        voApdNode = new eXria.data.json.Node(voApdNodeObj[vsAttr], vsAttr);
        voNode.appendChild(voApdNode);
      }
    }
  };


  this.getInstObj = function(psPath) {
    var vaPath = psPath.split("/");
    var voNode = this.instObj;

    if(voNode == null) return null;
    var vnCnt = vaPath.length;
    var vsNodeName = null;
    var voParentNode = null;
    var vnIdx;
    for (var i = 0; i < vnCnt; i++) {
      if (vaPath[i] === "") continue;
      vsNodeName = vaPath[i];
      if((/^.*\[([0-9]+)\]/.test(vaPath [i]))) {
        vnIdx = eval(RegExp.$1);
        if(page.metadata.useDomPath) vnIdx--;
        vaPath[i] = vaPath[i].substring(0, vaPath[i].indexOf("["));
        vaPath.splice(i + 1, 0, vnIdx);
        vnCnt++;
      }
      voParentNode = voNode;
      voNode = voNode [vaPath [i]];
      if(voNode == null) break;
      if(typeof(voNode) == "object") {
        voNode.nodeName = vaPath [i];
        voNode.parent = voParentNode;
      }
    }

    if(voNode !== undefined) {
      voNode = new eXria.data.json.Node(voNode, vsNodeName, voParentNode);
    }
    return voNode;
  };


  this.getLastNodeName = function(psPath){
    var vaPath = psPath.match(/\/[^\/]*(\[[^\[]+\])*/g);
    var vnCnt = vaPath.length;
    var vsNodeName = null;

    for (var i = 0; i < vnCnt; i++) {
      if (!vaPath [i]) continue;
      vsNodeName = vaPath[i].substring(1);
      if (page.metadata.useDomPath) {
        if(/^.*\[([0-9]+)\]/.test(vsNodeName)) {
          vsNodeName = eval(RegExp.$1);
          vsNodeName--;
        }  else if(/^.*(\[.+\])/.test(vsNodeName)) {
          vsNodeName = "" + RegExp.$1;
        }
      }
    }
    return vsNodeName;
  };

  this.isQueryPath = function(psPath) {
    return /\[[^\[]*[^0-9\[]+[^\[]*\]/.test(psPath);
  };

  this.convertToJsonPath = function(psPath) {
    var vaPath = psPath.match(/\/[^\/]*/g);
    var vnCnt = vaPath.length;
    var vsNodeName = null;

    var voBase = this;
    var voQueryConvFunc = function(psQuery) {
      var vsConvQuery = "";
      var vnIdx = null;
      var vnSize = null;
      var vaVar = null;
      var vaSeparator = null;
      var vaAllVar = null;
      var vsVar = null;
      var vaInnReplaceTarget = [];
      psQuery = psQuery.substring(1, psQuery.length - 1);
      psQuery = psQuery.replace(/child\:\:/g, "");
      psQuery = psQuery.replace(/(\s)+or(\s)+/gi, " || ");
      psQuery = psQuery.replace(/(\s)+and(\s)+/gi, " && ");
      if(psQuery.indexOf("starts-with") > -1) {
        psQuery = psQuery.substring(psQuery.indexOf("(")+1, psQuery.lastIndexOf(")"));
        var vsParam = psQuery.split(",");
        psQuery = vsParam[0].trim()+".startsWith("+vsParam[1].trim()+")";
      }
      if (psQuery.indexOf("ends-with") > -1) {
        psQuery = psQuery.substring(psQuery.indexOf("(")+1, psQuery.lastIndexOf(")"));
        var vsParam = psQuery.split(",");
        psQuery = vsParam[0].trim()+".endsWith("+vsParam[1].trim()+")";
      }
      if (psQuery.indexOf("contains") > -1) {
        psQuery = psQuery.substring(psQuery.indexOf("(")+1, psQuery.lastIndexOf(")"));
        var vsParam = psQuery.split(",");
        psQuery = vsParam[0].trim()+".indexOf("+vsParam[1].trim()+")>=0";
      }
      var vnInnReqSeq = 0;
      var vsInnPath = null;
      while(/(^|\s|\+|\-|\*|\/?=(\s|\/)|&|\||=|>|<)(\/([^$\s\+\-\*\/&\|=><]|\/(?!(\s|\/)))+)/.test(psQuery)) {
        vsInnPath = "" + RegExp.$3;
        psQuery = psQuery.replace(vsInnPath, "@" + (vnInnReqSeq++));
        vaInnReplaceTarget.push(voBase.convertToJsonPath(vsInnPath));
      }
      vnSize = vaInnReplaceTarget.length;
      for(var i = 0; i < vnSize; i++) {
        psQuery = psQuery.replace("@" + i, vaInnReplaceTarget[i]);
      };
      vsConvQuery += "[?(";
      vaVar = psQuery.split(/(\s*=\s*|\s*<=*\s*|\s*>=*\s*|\s*&+\s*|\s*\|+\s*|\s*\+\s*|\s*\-\s*|\s*\*\s*|\s*\/\s*)/g);
      if(vaVar.join("") != psQuery) {
        vaSeparator = psQuery.match(/(\s*=\s*|\s*<=*\s*|\s*>=*\s*|\s*&+\s*|\s*\|+\s*|\s*\+\s*|\s*\-\s*|\s*\*\s*|\s*\/\s*)/g);
        vnSize = vaVar.length;
        vaAllVar = [];
        for(var i = 0; i < vnSize; i++) {
          vaAllVar.push(vaVar[i]);
          if(vaSeparator[i] != null) vaAllVar.push(vaSeparator[i]);
        }
      } else {
        vaAllVar = vaVar;
      }
      vnSize = vaAllVar.length;
      var vbString = false;
      for(var i = 0; i < vnSize; i++) {
        vsVar = vaAllVar[i];
        vsVar = vsVar.replace(/(\s*<=*\s*|\s*>=*\s*|\s*&+\s*|\s*\|+\s*|\s*\+\s*|\s*\-\s*|\s*\*\s*|\s*\/\s*)/g, "");
        if(vsVar == "") continue;
        if(/\s*=\s*/.test(vsVar)) {
          vaAllVar[i] = vaAllVar[i].replace("=", "==");
          continue;
        }
        if(/^'.*'$/.test(vsVar) || /^\$.*/.test(vsVar)) continue;
        if(vsVar.indexOf("'") == 0) {
            vbString = true;
        } else if(vsVar.lastIndexOf("'") == vsVar.length - 1) {
            if(vsVar.lastIndexOf("'") == vsVar.length - 1) vbString = false;
            continue;
        }
        if(vbString) {
          continue;
        }
        if(!isFinite(vsVar)) vaAllVar[i] = "@." + vsVar;
      }
      vsConvQuery += vaAllVar.join("");
      vsConvQuery += ")]";
      return vsConvQuery;
    };

    var vaRoBrk = null;
    var vaLoBrk = null;
    var vnRoCnt = 0;
    var vsQuery, vsConvQuery;
    for (var i = 0; i < vnCnt; i++) {
      if (!vaPath[i]) continue;
      vaRoBrk = vaPath[i].match(/\[/g);
      if(vaRoBrk == null) vaRoBrk = [];
      vaLoBrk = vaPath[i].match(/\]/g);
      if(vaLoBrk == null) vaLoBrk = [];
      if(vnRoCnt > 0) {
        vaPath[i] = vaPath[i - 1] + vaPath[i];
        vaPath[i - 1] = "";
      }
      vnRoCnt += vaRoBrk.length;
      vnRoCnt -= vaLoBrk.length;
      if(vnRoCnt > 0) continue;

      if (/^\/[^\/]*\[([0-9]+)\]/.test(vaPath[i])) {
        if(page.metadata.useDomPath) {
          vsQuery = eval(RegExp.$1);
          vsConvQuery = "[" + (vsQuery - 1) + "]";
          vsQuery = "[" + RegExp.$1 + "]";
          vaPath[i] = vaPath[i].replace(vsQuery, vsConvQuery);
        }
      } else if(/^\/[^\/]*(\[.+\])/.test(vaPath[i])) {
        vsQuery = "" + RegExp.$1;
        vsConvQuery = voQueryConvFunc(vsQuery);
//        if(page.metadata.useDomPath) vaPath[i] = vsConvQuery;
//        else vaPath[i] = vaPath[i].replace(vsQuery, vsConvQuery);
        vaPath[i] = vaPath[i].replace(vsQuery, vsConvQuery);
      }
      vaPath[i] = vaPath[i].replace(/^\//, ".");
    }
    psPath = vaPath.join("");
    psPath = "$" + psPath;
    return psPath;
  };


  this.createElement = function(psElementName) {
    var voNode = new eXria.data.json.Node({}, psElementName);
    return voNode;
  };

  this.createTextNode = function(psKey, psValue) {
    var voNode = {};
    voNode[psKey] = (psValue==null) ? "" : psValue;
    return new eXria.data.json.Node(voNode[psKey], psKey);
  };
  
  this.createNode = function(psNodeName, psValue) {
    var voNewNode = null;
    voNewNode = this.createElement(psNodeName);
    if(psValue) {
      voNewNode.setNodeValue(psValue);
    }
    return voNewNode;
  };
	
  this.createMapNode = function(psName) {
    var voNode = this.createElement(psName);
    return new eXria.data.json.MapNode(voNode);
  };
	/**
	 * Instance를 Copy 하기 위하여 사용한다.
	 * @param {String} psInstPath 해당 컨트롤의 Instance Path
	 */
	this.copyOriginInstance = function(psInstPath) {
		if(psInstPath == null) return null;
	  var vsInstancePath = psInstPath;
	  var vsJsonData = null;

		vsJsonData = this.getJSON(vsInstancePath);
		this.copyInstObj = eval("("+vsJsonData+")");
	};
};
