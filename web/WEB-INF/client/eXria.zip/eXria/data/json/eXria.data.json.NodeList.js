/**
 * @fileoverview
 * XHTML Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 */
/**
 * XHTML Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 * @author Choe, hyeon jong.
 * @version 2.0
 * @param {NodeList} XHTML NodeList Object
 * @constructor
 * @base eXria.data.NodeList
 */
eXria.data.json.NodeList = function(poResult, psNodeName, poParent) {
  /**
   * Inherit
   */
  eXria.data.NodeList.call(this);
  /**
   * NodeList
   * @type Array (eXria.data.json.Node)
   * @private
   */
  this.nodeList = poResult;

  this.name = psNodeName;

  this.parentNode = poParent;
  /**
   * return item cound in NodeList
   * @return item count number
   * @type Number
   */
  this.getLength = function() {
    if(this.nodeList == null) return 0;
    return (this.nodeList.length != null) ? this.nodeList.length : this.nodeList.getLength();
  };
  /**
   * return NodeItem of parameter index
   * @param {Number} pnIdx
   * @return Node
   * @type Node
   */
  this.item = function(pnIdx) {
    var voNodeList = (this.nodeList.nodeList) ? this.nodeList.nodeList : this.nodeList;
    if(voNodeList == null) return null;
    
    var voNode = voNodeList[pnIdx];
    if(voNode == null) return null;

    if(!(voNode instanceof eXria.data.json.Node || voNode instanceof eXria.data.xhtml.Node)) {
      voNode = new eXria.data.json.Node(voNode, pnIdx, voNodeList);
    }
    return voNode;
  };
};