/**
 * @fileoverview
 * Document Node Object Class
 */
/**
 * json.Node
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.JsNode
 */
eXria.data.json.Node = function(poNode, psName, poParent, poInfoObj) {
	this.infoObj = null;
  if(poInfoObj) {
  	this.infoObj = poInfoObj;
    var vsPath = this.infoObj.path;
    vsPath = vsPath.replace(/^\$/, "");
    var vaPath = vsPath.match(/\[[^\[]+\]/g);
    psName = vaPath[vaPath.length - 1].replace(/((\[\'?)|(\'?\]))/g, "");
    if(isFinite(psName)) psName = parseInt(psName);
    var vnPathStIdx = 0;
    if(this.infoObj.instObj.nodeName != null) vnPathStIdx = 1;
    if(psName == "#text") {
      vsPath = vaPath.slice(vnPathStIdx, vaPath.length - 1).join("");
    }
    poNode = eval("this.infoObj.instObj" + vsPath);
    this.infoObj.parentPath = vaPath.slice(0, vaPath.length - 1).join("");
  }
  if (poNode == null) {
    throw new Error("Node is null.");
  }
  /**
   * inherit
   */
//  eXria.data.Node.call(this, poNode);
  /**
   * XMLNode
   * @type XMLElementNode
   * @private
   */
  if(typeof(poNode) != "object" && (psName == null || !isNaN(psName))) psName = "#text";
  this.node = poNode;
  /**
   * XMLNode Tag Name
   * @type String
   * @private
   */
  this.name = psName;
  /**
   * parent json node object
   * @type Object
   * @private
   */
  this.parentNode = poParent;

  if(this.node != null && typeof(this.node) == "object") {
    if(psName == null) this.name = this.node.nodeName;
    else this.node.nodeName = psName;
    if(poParent == null) this.parentNode = this.node.parent;
    else this.node.parent = poParent;
  }
};

eXria.data.json.Node.prototype = {
  /**
   * 파라미터로 넘어온 Node를 자식 Node의 마지막에 추가한다.
   * @param {eXria.data.JsNode} poNode 추가할 Node Object
   * @type void
   * @return void
   */
  appendChild : function(poNode, psRowTagName) {
    var vsNodeName = poNode.getNodeName();
    if(!poNode) return;
    
    if(this.node === "") {
      this.parentNode[this.name] = this.createElement(this.name).node;
      this.node = this.parentNode[this.name];
      this.node.nodeName = this.name;
      this.node.parent = this.parentNode;
    }
    poNode.parentNode = this.node;
    
    //초기 데이터 셋에 대해 row 에 대해서 배열로 선언해 주는 부분 13.9.4 추가
    if(psRowTagName != null && this.node[psRowTagName] == null) this.node[psRowTagName] = [];
    
    if(psRowTagName != null && this.node[psRowTagName] instanceof Array){ //dataset일때 row이름이 배열인지 체크
      this.node[psRowTagName].push(poNode.node);
    }else if(this.node instanceof Array){   //this.node 배열O
      this.node.push(poNode.node);
    }else if(typeof(poNode.name) == "number") { // this.node 배열X , poNode가 배열의element
      var voOldPNode = poNode.getParentNode();
      var vsPNodeName = voOldPNode.name;
      var voPNode = null;
      if(this.node[vsPNodeName] == null) {
        voPNode = this.createElement(voOldPNode.name, []);
        
        this.appendChild(voPNode);
      }
      var voPNodeObj = this.node[vsPNodeName];
      voPNodeObj.push(poNode.node);
      poNode.parentNode = voPNodeObj;
      if(this.infoObj) {
        var voBase = this;
        poNode.infoObj =  {
            instObj : voBase.infoObj.instObj,
            path : voBase.infoObj.path + "/" + 	vsPNodeName
        } 
      }
    }else if(vsNodeName != "#text") {       //this.node 배열X
      this.node[vsNodeName] = poNode.node;
    }else {
      var voParentNode = this.node.parentNode;
      if(voParentNode) voParentNode[this.name] = poNode.node;
      this.node = poNode.node;
    }
  },
  /**
   * 현재 Node와 동일한 Node를 복사하여 리턴한다.
   * @param {Boolean} pbDeep deep copy 유무를 지정한다. (true | false)
   * @return 복사된 Node Object
   * @type eXria.data.JsNode
   */
  cloneNode : function(pbDeep) {
    if(pbDeep != true) pbDeep = false;
    var vsNode = this.getJSON(this.node);
    var voNode = eval("("+vsNode+")");
    if(!pbDeep) {
      for(var attr in voNode){
        voNode[attr] = "";
      }
    }
    var voPNode = this.getParentNode();
    voPNode = (voPNode == null) ? null : voPNode.node;
    return new eXria.data.json.Node(voNode, this.name, voPNode, this.infoObj);
  },
  /**
   * 현재 Node의 자식 Node들을 NodeList 형식으로 리턴한다.
   * @type eXria.data.JsNodeList
   * @return 생성된 자식 Node List
   */
  getChildNodes : function() {
    var voParent = this.node;
    var vaNodeList = [];
    var voNode = null;
    if(voParent instanceof Array) {
      vaNodeList = voParent;
    } else {
      if(typeof(voParent) != "object") {
        var voInfoObj = this.getInfoObj();
        if(voInfoObj != null) {
          voInfoObj.path += "[#text]";
          voNode = new eXria.data.json.Node(null, null, null, voInfoObj);
        } else {
          voNode = new eXria.data.json.Node(voParent, null, voParent);
        }
        vaNodeList.push(voNode);
      } else {
        for(var vsKey in voParent){
          if(eXria.protocols.json.ReservedType[vsKey]) continue;
          voNode = new eXria.data.json.Node(voParent[vsKey], vsKey, voParent);
          vaNodeList.push(voNode);
        }
      }
    }
//    if(vaNodeList.length == 0) { return null; }
    return new eXria.data.json.NodeList(vaNodeList, this.name, voParent);
  },
  /**
   * 현재 Node의 첫번째 자식 Node를 리턴한다.
   * @type eXria.data.JsNode
   * @return 현재 Node의 첫번째 자식 Node
   */
  getFirstChild : function() {
    var voChildNodes = this.node;
    var voFirstChild, vsFirstKey, voRet;

    if(voChildNodes instanceof Array) {
      voFirstChild = voChildNodes[0];
    } else if(typeof(voChildNodes) == "string"){
      voRet = null;
    } else {
      for (var i in voChildNodes) {
        if (i != "parent" && i != "nodeName") {
          vsFirstKey = i;
          break;
        }
      }
    }
    if(!!vsFirstKey) voRet = new eXria.data.json.Node(voChildNodes[vsFirstKey], vsFirstKey, voChildNodes);
    else if (!voFirstChild) voRet = null;
    else voRet = new eXria.data.json.Node(voFirstChild, null, voChildNodes);
    return voRet;
  },
  /**
   * 현재 Node의 마지막 자식 Node를 리턴한다.
   * @type eXria.data.JsNode
   * @return 현재 Node의 마지막 자식 Node
   */
  getLastChild : function() {
    var voNode = this.node.lastChild;
    if (!voNode) { return null; }
    return new eXria.data.json.Node(voNode);
  },
  /**
   * 현재 Node의 바로 다음 Node를 리턴한다.
   * @type eXria.data.JsNode
   * @return 현재 Node의 다음 Node
   */
  getNextSibling : function() {
    var voNode = this.node.nextSibling;
    if(!voNode) { return null; }
    return new eXria.data.json.Node(voNode);
  },
  /**
   * 현재 Node의 이름을 리턴한다.
   * @type String
   * @return 현재 Node의 이름
   */
  getNodeName : function() {
    return this.name;
  },
  /**
   * 현재 Node의 value를 리턴한다.
   * @type String
   * @return 현재 Node의 Value
   */
  getNodeValue : function() {
    var voValue = this.node;
    if(voValue == null) voValue = "";
    if(typeof(voValue) == "object") voValue = null;
    return voValue;
  },
  /**
   * 현재 Node의 부모 Node를 리턴한다.
   * @type eXria.data.JsNode
   * @return 현재 Node의 부모 Node
   */
  getParentNode : function() {
    var voBase = this;
    if(this.infoObj) return new eXria.data.json.Node(null, null, null, {
      instObj : voBase.infoObj.instObj,
      path : voBase.infoObj.parentPath
      });
    var voNode = this.parentNode;
    if(!voNode) { return null; }
    return new eXria.data.json.Node(voNode, voNode.nodeName, voNode.parent);
  },
  /**
   * 현재 Node의 바로 전 Node를 리턴한다.
   * @type eXria.data.JsNode
   * @return 현재 Node의 바로 전 Node
   */
  getPreviousSibling : function() {
    var voParentNode;
    var voNode;
    if(this.parentNode){
      voParentNode = this.parentNode;
      //만들어야함
    }
    if(!voNode) { return null; }
    return new eXria.data.json.Node(voNode);
  },
  /**
   * Element를 생성하여 리턴한다.
   * @param {String} psTagName 생성할 Element의 Tag Name
   * @param {String} psValue 생성할 Element의 Value [ null을 넘길 경우 TextNode가 생성되지 않은 Element 리턴 ]
   * @type {eXria.data.JsNode}
   * @return 생성된 Element
   */
  createElement : function(psTagName, psValue) {
    if(psValue == null) psValue = {};
    voNode = new eXria.data.json.Node(psValue, psTagName);
    return voNode;
  },
  /**
   * TextNode를 생성하여 리턴
   * @param {String} psValue 생성할 Node의 Value값
   * @type {eXria.data.JsNode}
   * @return 생성된 TextNode
   */
  createTextNode : function(psValue) {
    if(psValue == null) return null;
    return new eXria.data.json.Node(psValue);
  },
  /**
   * 현재 Node의 자식 Node 유무를 리턴한다.
   * @type Boolean
   * @return 자식 Node의 존재 유무
   */
  hasChildNodes : function() {
    if(this.node != null && typeof(this.node) == 'object'){
      var voNode = this.node;
      var vbHasChild = false;
      if(voNode instanceof Array) {
        if(voNode.length > 0) vbHasChild = true;
      } else {
        for(var vsAttr in voNode){
          if(eXria.protocols.json.ReservedType[vsAttr]) continue;
          vbHasChild = true;
          break;
        }
      }
      return vbHasChild;
    } else if(this.node != null && this.getNodeType() == 1) {
      return true;
    } else {
      return false;
    }
  },
  /**
   * 현재 Node의 자식 Node 중 파라미터로 넘어온 Node와 일치하는 Node를 삭제한다.
   * @param {eXria.data.JsNode} poNode 삭제할 Node
   * @type eXria.data.JsNode
   * @return 삭제된 Node
   */
  removeChild : function(poNode) {
    if (!poNode) return;
    var voNodeObj = poNode.node;
    var voPNodeObj = poNode.parentNode;
    var voPNodeArry = voPNodeObj[poNode.name];
    
    if (voPNodeObj instanceof Array) {
      voPNodeObj.splice(poNode.name, 1);
      if(page.metadata.useDomPath && voPNodeObj.length == 0) {
        var voGPNodeObj = voPNodeObj.parent;
        delete voGPNodeObj[voPNodeObj.nodeName];
      }
//      voParentNode.splice(voNodeObj.name + "[" + poNode.idx + "]", 1);
    }else if(voPNodeObj instanceof Object && voPNodeArry instanceof Array && !voNodeObj.parent){
      voPNodeArry.splice(voNodeObj.DataSetRowIdx, 1);
      if(page.metadata.useDomPath && voPNodeArry.length == 0) {
        var voGPNodeObj = voPNodeArry.parent;
        delete voGPNodeObj[voPNodeArry.nodeName];
      }
    }else{
      delete voPNodeObj [poNode.name];
    }
    voNodeObj.parent = null;
    poNode.parentNode = null;
    if (typeof (voNodeObj) == "object") voNodeObj.parent = null;

    return poNode;
  },
  /**
   * 현재 Node의 Value 파라미터로 넘어온 데이터로 변경한다.
   * @param {String} psValue 변경할 데이터
   * @type void
   * @return void
   */
  setNodeValue : function(psValue) {
    psValue = (psValue ? psValue : "");
    var voParent = this.parentNode;
    if(!!voParent) voParent[this.name] = psValue;
    this.node = psValue;
  },
  /**
   * 두번째 파라미터로 넘어온 Node와 동일한 Node가 있을 경우 해당 위치에 첫번째 파라미터로 넘어온 Node를 셋팅.
   * @param {eXria.data.JsNode} poNewNode 추가할 Node
   * @param {eXria.data.JsNode} poOldNode 덮어 쓸 Node
   * @type eXria.data.JsNode
   * @return 삭제된 Node
   */
  replaceChild : function(poNewNode, poOldNode) {
    if(poOldNode.node){
      this.node = poNewNode.node;
      var voNode = this.node;
      if(typeof(voNode) == "object"){
        voNode.nodeName = this.name;
        voNOde.parent = this.parentNode;
      }
      return poOldNode;
    } else {
      return null;
    }
  },
  /**
   * 두번째 파라미터로 넘어온 Node의 앞에 첫번째로 넘어온 파라미터 Node를 추가한다.
   * @param {eXria.data.JsNode} poNewNode 추가할 Node
   * @param {eXria.data.JsNode} poRefNode 덮어 쓸 Node
   * @type eXria.data.JsNode
   * @return insert 되기 전 Node
   */
  insertBefore : function(poNewNode, poRefNode) {
//    var voOldNode = this.node.insertBefore(poNewNode.node, poRefNode.node);
//    if(voOldNode) {
//      return poRefNode;
//    } else {
//      return null;
//    }
      var voParentNode = poRefNode.getParentNode();
      poNewNode.parentNode = voParentNode.node;
      var vbArray = voParentNode.node instanceof Array;
      var vnIdx = poRefNode.name;
      if(vbArray){
        voParentNode.splice(vnIdx, 0, poNewNode.node);
        poRefNode.name = vnIdx + 1;
        if(typeof(poRefNode.node) == "object") poRefNode.node.nodeName = vnIdx + 1;
      } else {
        voParentNode.node[poNewNode.name] = poNewNode.node;
      }
      return poRefNode;
  },
  /**
   * node type을 리턴한다.
   * @type Number
   * @return 해당 Node의 node Type
   */
 getNodeType : function() {
//    var vnNodeType = 3;
//    if(this.node != null) {
//      if(typeof(this.node) == "object") vnNodeType = 1;
//    }
//    return vnNodeType;
		return (this.name == "#text" ? 3 : 1);
  },
  /**
   * 현재 클래스의 이름을 반환 한다.
   * @type String
   * @return 현재 클래스 이름
   */
  toString : function() {
    return "eXria.data.json.Node";
  },
  /**
   * 파라미터로 넘어온 Node와 현재 Node가 같은 Node인지 비교한다.
   * @param {eXria.data.JsNode} poNode 비교할 Node
   * @return 두개의 Node가 같은 Node인지 유무
   * @type Boolean
   */
  equal : function(poNode) {
  return this.node == poNode.node;
  },
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.JsNode
   * @return Node Object
   */
  getElementByTagName : function(psTagName) {
    var voNodes = this.getChildNodes();
    var voNode;
    if(voNodes != null){
      for(var i = 0, vnLen = voNodes.getLength(); i < vnLen ; i++){
        voNode = voNodes.item(i);
        if(voNode == null) continue;
        if(voNode.name == psTagName) return voNode;
        
        if(voNode.getNodeType() == 1){
          if(voNode.getElementByTagName(psTagName) != null){
            return voNode;
          }
        }
      }
    }
//    var voNodes = this.getElementsByTagName(psTagName);
//    if(voNodes.getLength() == 0) {
//      return null;
//    } else {
//      return voNodes.item(0);
//    }
  },
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.JsNodeList
   * @return NodeList Object
   */
  getElementsByTagName : function(psTagName) {
  var voNodes = this.node.getElementsByTagName(psTagName);
  if(!voNodes) return null;
  return new eXria.data.json.NodeList(voNodes);
  },
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.JsNode
   * @return NodeList Object
   */
  getElementByTagNameFromChildNodes : function(psTagName) {
    var voNodes = this.getChildNodes();
    var voNode = null;
    var voTmpNode = null;
    for(var i = 0, vnLen = voNodes.getLength() ; i < vnLen ; i++) {
      voNode = voNodes.item(i);
      if(voNode.getNodeName() == psTagName) {
        voTmpNode = voNode;
        break;
      }
    }
    return voTmpNode;
  },
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Collection
   * @return eXria.data.Collection Object
   */
  getElementsByTagNameFromChildNodes : function(psTagName) {
    var voNodes = this.getChildNodes();
    var voNodeArr = new eXria.data.ArrayCollection();

    for(var i = 0, vnLen = voNodes.getLength() ; i < vnLen ; i++) {
      var voNode = voNodes.item(i);
      if(voNode.name == psTagName) {
        voNodeArr.add(new eXria.data.json.Node(voNode.node, psTagName, this.node));
      }
    }
    return voNodeArr;
  },
  /**
   * 현재 Node의 XML 스트링을 리턴.
   * @type String
   * @return XML String
   */
  getXML : function() {
    if (window.page.metadata.browser.ie > 0) {
      return this.node.xml;
    } else {
      var vSerializer = new XMLSerializer();
      return vSerializer.serializeToString(this.node);
    }
  },
  /**
   * 노드의 특정 속성 반환한다.
   * @param {String} psAttr 속성 명
   * @type String
   * @return 노드의 해당 속성 값
   */
  getAttribute : function(psAttr) {
    return this.node[psAttr];
  },
  
  getAttributes : function() {
  	return new eXria.data.json.NodeList([], this.name, this.parentNode);
  },
  /**
   * 노드의 특정 비표준 속성을 반환한다.
   * @param {String} psAttr 비표준 속성 명
   * @type String
   * @return 노드의 해당 속성 값
   */
  getUserAttribute : function(psAttr) {
    return this.node[psAttr];
  },
  /**
   * 노드의 특정 속성 값을 설정한다.
   * @param {String} psAttr 속성 명
   * @param {String} psValue 속성 값
   */
  setAttribute : function(psAttr, psValue) {
    this.node[psAttr] = psValue;
  },
  /**
   * 노드 관계 정보 저장 객체를 반환하는 메소드
   * @type Object
   * @return 노드 관계 정보 저장 객체
   */
  getInfoObj : function() {
    var voInfoObj = null;
    if(this.infoObj) {
      voInfoObj = this.infoObj;
    } else {
      vsPath = "['" + this.name + "']";
      voInstObj = null;
      voParent = this.parentNode;
      while(voParent) {
        voInstObj = voParent;
        if(voParent.nodeName == null) break;
        vsPath = "['" + voParent.nodeName + "']" + vsPath;
        voParent = voParent.parent;
      }
      if(voInstObj) {
        voInfoObj = {
          instObj : voInstObj,
          path : vsPath
        }
      }
    }
    return voInfoObj;
  },
  /**
   * 노드의 특정 비표준 속성 값을 설정한다.
   * @param {String} psAttr 비표준 속성 명
   * @param {String} psValue 속성 값
   */
  setUserAttribute : function(psAttr, psValue) {
    this.node[psAttr] = psValue;
  },
  
  getJSON : function(poNodeObj, pbFillKey) {
    var voNode = poNodeObj;
    var vsRet = null;
    if (voNode == null) {
      return "null";
    } else if (voNode.constructor == String) {
      if(pbFillKey && voNode.name != null) vsRet = "{" + voNode.name + " : " + escapeJSONString(voNode) + "}";
      else vsRet = escapeJSONString(voNode);
      return vsRet;
    } else if (voNode.constructor == Number) {
      return voNode.toString();
    } else if (voNode.constructor == Boolean) {
      return voNode.toString();
    } else if (voNode.constructor == Date) {
      return '{javaClass: "java.util.Date", time: ' + voNode.valueOf() + '}';
    } else if (voNode.constructor == Array) {
      var v = [];
      for (var i = 0; i < voNode.length; i++) {
        v.push(this.getJSON(voNode [i]));
      }
      return "[" + v.join(", ") + "]";
    } else {
      var v = [];
      for (attr in voNode) {
        if (voNode [attr] == null) {
          v.push("\"" + attr + "\": null");
        }  else if (typeof voNode [attr] == "function" || eXria.protocols.json.ReservedType[attr]) {
          // TODO function일 경우도 파싱
          // skip
        } else {
          v.push(escapeJSONString(attr) + ": " + this.getJSON(voNode [attr], false));
        }
      }
      var vsStr = v.join(", ");

      if (!vsStr) {
        vsRet =  "\"\"";
      } else {
        if(pbFillKey && voNode.name != null) vsRet = "{" + voNode.name + " : " + v.join(", ") + "}";
        else vsRet = "{" + v.join(", ") + "}";
      }return vsRet;
    }
  }
};

//====================================================================================

function escapeJSONChar(pcChar) {
  if (pcChar == "\"" || pcChar == "\\") return "\\" + pcChar;
  else if (pcChar == "\b") return "\\b";
  else if (pcChar == "\f") return "\\f";
  else if (pcChar == "\n") return "\\n";
  else if (pcChar == "\r") return "\\r";
  else if (pcChar == "\t") return "\\t";
  var hex = pcChar.charCodeAt(0).toString(16);
  if (hex.length == 1) return "\\u000" + hex;
  else if (hex.length == 2) return "\\u00" + hex;
  else if (hex.length == 3) return "\\u0" + hex;
  else return "\\u" + hex;
};
function escapeJSONString(psString) {
  //Rather inefficient way to do it
  var parts = psString.split("");
  for (var i = 0; i < parts.length; i++) {
    var c = parts [i];
    if (c == '"' || c == '\\' || c.charCodeAt(0) < 32 || c.charCodeAt(0) >= 128) {
      parts [i] = this.escapeJSONChar(parts [i]);
    }
  }
  return "\"" + parts.join("") + "\"";
};

