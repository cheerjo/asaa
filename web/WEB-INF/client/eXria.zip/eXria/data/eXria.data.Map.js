﻿/**
 * @fileoverview
 * Map 객체를 생성하기 위한 클래스
 */
/**
 * Map 객체를 생성하기 위한 클래스
 * @author Kim, Min Seok
 * @version 1.0
 * eXria.data.Map
 * @constructor
 */
eXria.data.Map = function() {
  /**
   * Map의 변경 상태를 체크하기 위한 플래그 변수
   * @type Boolean
   * @private
   */
  this.isChanged = true;
  /**
   * Key의 생성 순서를 체크하기 위한 넘버링 변수
   * @type Number
   * @private
   */
  this.seq = 0;
  /**
   * Map 내부의 Element 갯수를 저장하는 변수
   * @private
   */
  this.cnt = 0;
  /**
   * Map에 저장될 데이터를 가지고 있을 Object 객체
   * @private
   */
  this.entries = new Object();
  /**
   * key의 순번 데이터를 가지고 있을 Object 객체
   * @private
   */
  this.seqEntries = {};
  /**
   * 순번을 key로 하여 Map key를 데이터로 가지고 있을 Object 객체
   * @private
   */
  this.keyEntries = {};
  /**
   * 넘어온 Key와 매핑되는 Value를 리턴, 메핑되는 데이터가 없다면 null 리턴
   * @param {String} psKey 찾아올 Value의 Key
   * @return Key와 매핑되어 있는 Value
   * @type Object
   */
  this.get = function(psKey) {
    var voEntry = this.entries[psKey];
    return voEntry == undefined ? null : voEntry;
  };
  /**
   * 넘어온 Key, Value를 map에 저장
   * @param {String} psKey Key
   * @param {Object} psValue value
   * @return void
   * @type void
   */
  this.put = function(psKey, poValue) {
    this.isChanged = true;
    if(this.entries[psKey] === undefined) {
      this.keyEntries[this.seq] = psKey;
      this.seqEntries[psKey] = this.seq++;
    }
    this.entries[psKey] = poValue;
  };
  /**
   * Map의 데이터를 가진 엔트리 객체를 리턴
   * @return Map에 저장되어 있는 모든 데이터를 가진 객체
   * @type Object
   */
  this.getEntries = function() {
    return this.entries;
  };
};