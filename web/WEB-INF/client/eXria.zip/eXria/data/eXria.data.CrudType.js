﻿/**
 * @fileoverview
 * Curd 사용시 타입을 결정하는 상수 클래스</br>
 * enum list</br>
 * - eXria.data.CrudType.UNCHANGEDFLAG : 데이터셋의 로우가 변경이 되지 않은 상태</br>
 * - eXria.data.CrudType.ADDEDFLAG : 추가된 로우일 경우</br>
 * - eXria.data.CrudType.DELETEDFLAG : 삭제된 로우일 경우</br>
 * - eXria.data.CrudType.MODIFIEDFLAG : 자료가 수정된 경우</br>
 * - eXria.data.CrudType.CRUDALLTYPE : Create, Read, Update, Delete 모든 변경 상태일 경우</br>
 * - eXria.data.CrudType.EXCEPDELETEALLTYPE : 삭제상태를 제외한 상태일 경우
 */
/**
 * Curd 사용시 타입을 결정하는 상수 클래스
 * @author Choe, Hyeon Jong
 * @version 1.0
 * @constructor
 */
eXria.data.CrudType = {
  UNCHANGEDFLAG     : 0X0001,
  ADDEDFLAG       : 0X0002,
  DELETEDFLAG     : 0X0004,
  MODIFIEDFLAG      : 0X0008,
  EMPTYEDFLAG       : 0X0010,
  CRUDALLTYPE     : 0X000E,
  EXCEPDELETEALLTYPE  : 0X000C
};