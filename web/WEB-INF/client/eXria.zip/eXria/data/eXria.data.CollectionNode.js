/**
 * @fileoverview
 * XML Node를 Collection 형태로 wrapping 하는 클래스의 Interface
 */
/**
 * XML Node를 Collection 형태로 wrapping 하는 클래스의 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.Node
 */
eXria.data.CollectionNode = function(poNode) {
  /**
   * inherit
   */
  eXria.data.Node.call(this, poNode);
  /**
   * Collection에 파라미터로 넘어온 Node를 추가한다.
   * @param {XMLNode} poNode 추가할 Node
   * @return void
   * @type void
   */
  this.add = null;
  /**
   * 현재 Collection의 Item 갯수를 리턴한다.
   * @return 하위 ElementNode의 갯수
   * @type Number
   */
  this.size = null;
  /**
   * Parameter로 넘어온 Index에 해당하는 위치의 Node를 리턴한다.
   * @param {Number} pnIndex 리턴받은 Node의 Index
   * @return 해당 Index의 Node. Index가 Node의 범위 밖인 경우 null을 리턴한다.
   * @type Node
   */
  this.get = null;
  /**
   * Collection에서 Parameter로 넘어온 Index에 해당되는 위치에 두번째 Parameter로 넘어온 Node를 추가한다. 만약 해당 Index에 기존 Node가 존재할 경우 기존 Node는 삭제 된다.
   * @param {Number} pnIndex 추가할 위치 Index
   * @param {XMLNode} poNode 추가할 Node
   * @return 넘겨받은 Index에 Node가 존재할 경우 기존 Node를 대체하고 기존 Node를 리턴한다.
   * @type Node
   */
  this.set = null;
  /**
   * 넘겨 받은 Index에 Node를 추가 한다. 해당 Index에 기존에 Node가 존재 할 경우 해당 Node 및 이후 Index의 Node들의 Index가 하나씩 밀린다.
   * @param {Number} pnIndex 추가할 위치 Index
   * @param {XMLNode} poNode 추가할 Node
   * @return 넘겨받은 Index에 Node가 존재할 경우 기존 Node를 대체하고 기존 Node를 리턴한다.
   * @type Node
   */
  this.insert = null;
  /**
   * Parameter로 넘어온 Index에 해당하는 Node를 삭제한다.
   * @param {Number} pnIndex 삭제할 Node Index
   * @return 삭제된 Node 참조값
   * @type Node
   */
  this.remove = null;
  /**
   * Collection의 모든 Node를 삭제 하고 Collection을 초기화 한다.
   * @return void
   * @type void
   */
  this.clear = null;
  /**
   * 현재 Collection이 비어 있는지 체크하여 리턴한다.
   * @return 비어있는 노드일 경우 TRUE, 아닐 경우 FALSE
   * @type Boolean
   */
  this.isEmpty = null;
  /**
   * 현재 Collection의 모든 Node를 Iterator로 변환하여 리턴한다.
   * @return 내부객체를 조회하는 Iterator
   * @type eXria.data.ArrayIterator
   * @see eXRia.data.ArrayIterator
   */
  this.iterator = null;
  /**
   * 현재 메소드 이름을 리턴한다.
   * @return 현재 메소드명
   * @type String
   */
  this.toString = null;
};
