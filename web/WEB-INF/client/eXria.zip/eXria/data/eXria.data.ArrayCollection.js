﻿/**
 * @fileoverview
 * XML Node를 Array Collection 형태로 wrapping 하거나 새로운 Array Collection을 생성하는 클래스
 */
/**
 * XML Node를 Array Collection 형태로 wrapping 하거나 새로운 Array Collection을 생성하는 클래스
 * @author Kim, Min Seok
 * @version 1.0
 * @param {eXria.data.Collection} poCollection Collection Object
 * @constructor
 * @base eXria.data.Collection
 */

eXria.data.ArrayCollection = function(poCollection) {
  /**
   * inherit
   */
  eXria.data.Collection.call(this);

  if(poCollection != null) {
    this.elements = poCollection.elements;
    this.cnt = poCollection.elements.length;
  }
  /**
   * Parameter로 넘어온 Array의 Index에 Value를 대입한다. 만약 해당 Index에 기존의 데이터가 있을 기존의 데이터는 삭제 된다.
   * @param {Number} pnIndex item index
   * @param {Object} poValue item value
   * @return 넘어온 index에 이전에 들어있던 데이터 Object
   * @type Object
   */
  this.set = function(pnIndex, poValue) {
    this.rangeCheck(pnIndex);
    var voOld = this.elements[pnIndex];
    this.elements[pnIndex] = poValue;
    if(!voOld) this.cnt++;
    return voOld;
  };
  /**
   * Parameter로 넘어온 Index에 해당되는 Item이 존재할 경우 삭제한다.
   * @param {Number} pnIndex 삭제할 Item Index
   * @return 삭제될 요소
   * @type Object
   */
  this.remove = function(pnIndex) {
    this.rangeCheck(pnIndex);
    var voElement = this.elements.splice(pnIndex, 1);
    if(voElement) {
      voElement = voElement[0];
      this.cnt--;
    }
    return voElement;
  };
  /**
   * 현재 Array Collection의 모든 데이터를 삭제하고 Array를 초기화 시킨다.
   * @return void
   * @type void
   */
  this.clear = function() {
    this.elements = new Array();
    this.cnt = 0;
  };
  /**
   * Array Collection에 Item의 존재 유무를 리턴한다.
   * @return Element가 없을 경우 TRUE, 있다면 FALSE
   * @type Boolean
   */
  this.isEmpty = function() {
  return (this.cnt == 0);
  };
  /**
   * 현재 Array Collection의 데이터를 Array Iterator 객체로 변환하여 리턴한다.
   * @return Collection Iterator
   * @type eXria.data.ArrayIterator
   * @see eXria.data.ArrayIterator
   */
  this.iterator = function() {
    return new eXria.data.ArrayIterator(this);
  };
  /**
   * 현재 Array Collection의 모든 데이터를 "," 구분자를 사용하여 문자열로 리턴한다.
   * @return Item List String in Collection
   * @type String
   */
  this.toString = function() {
    return "[" + this.elements.join(", ") + "]";
  };
};
