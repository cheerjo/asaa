/**
 * @fileoverview
 * FireFox, Safari, Chrome, Opera 등의 Document를 생성하는 클래스
 * @private
 */
/**
 * FireFox, Safari, Chrome, Opera 등의 Document를 생성하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @base eXria.data.xhtml.Document
 * @constructor
 * @private
 */
eXria.data.xhtml.GeckoDocument = function(poPage) {
  /**
   * inherit
   */
  eXria.data.xhtml.Document.call(this);
  /**
   * page Object
   * @type Object
   */
  this.page = poPage;
  /**
   * dom Object
   * @type Object
   * @private
   */
  this.dom = this.page.window.document.implementation.createDocument("", "", null);
  if (this.dom == null) { throw new Error("Can not create Document."); }
  /**
   * 넘겨받은 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 XML Element
   * @type XMLElementNode
   * @private
   */
  this.selectSingleNode = function(psXpath) {
  try {
      var voXPathResult = this.dom.evaluate(psXpath, this.dom, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
      return voXPathResult.singleNodeValue;
  } catch(e) {
      return null;
  }
  };
  /**
   * 넘겨받은 XPath에 해당하는 Node들을 조회하여 NodeList로 리턴한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 NodeList를 Wrapping한 NodeList 객체
   * @type eXria.data.NodeList
   * @private
   */
  this.selectNodes = function(psXpath) {
    try {
      var voXPathResult = this.dom.evaluate(psXpath, this.dom, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return new eXria.data.xhtml.GeckoNodeList(voXPathResult);
    } catch(e) {
        return null;
    }
  };
  /**
   * 넘겨받은 XMLElement를 Node에 Append한다.
   * @param {XMLNode} poXML XML Node
   * @return void
   * @type void
   * @private
   */
  this.loadXML = function(poXML) {
    if(this.dom.documentElement) {
      this.dom.replaceChild(poXML, this.dom.documentElement);
    } else {
      this.dom.appendChild(poXML.cloneNode(true));
    }
  };
  /**
   * 넘겨받은 Text를 Parsing하여 Node에 Append한다.
   * @param {String} psTXT XML Text
   * @return void
   * @type void
   * @private
   */
  this.loadTXT = function(psTXT) {
    var voParser = new eXria.data.xhtml.GeckoDOMParser();
    var voDom = voParser.parse(psTXT);
    delete this.dom;
    this.dom = voDom;
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 alert으로 출력
   * @param {String} poNode print 하고자 하는 XML Node
   * @return void
   * @type void
   * @private
   */
  this.print = function(poNode) {
  if(poNode == null && poNode == undefined) {
    throw new Error("Node is null.");
  } else {
    var vSerializer = new XMLSerializer();
    alert(vSerializer.serializeToString(poNode));
  }
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 문자열로 반환
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return xml 노드를 문자열화한 객체
   * @type String
   */
  this.nodeToStr = function(poNode) {
  if(poNode == null && poNode == undefined) {
    throw new Error("Node is null.");
  } else {
    var vSerializer = new XMLSerializer();
    return vSerializer.serializeToString(poNode);
  }
  };
};
