eXria.data.xhtml.Sort = function(poDataSet) {
  this.dataSet = poDataSet;
  this.originRow = this.dataSet.originData;
  this.viewData = this.dataSet.viewData;
  this.sortItems = [];
};

eXria.data.xhtml.Sort.prototype = {
  SORT_COL_NM : 0,
  SORT_TYPE : 1,
  SORT_ASC : 2,
  SORT_ROW_IDX : "rowIdx",
  SORT_ROW_STAUTS : "status",
  /**
   * clear
   * @return void
   * @type void
   */
  clear : function() {
    this.sortItems = null;
    this.sortItems = [];
  },
  /**
   * add sort item
   * @param {String} psNodeName node name
   * @param {Number} pnType sort type
   * @param {Boolean} pbAsc is asc
   * @return void
   * @type void
   */
  addSortItem : function(psNodeName, pnType, pbAsc) {
    var voItem = [ psNodeName, Number(pnType), pbAsc ];
    this.sortItems[this.sortItems.length] = voItem;
  },
  /**
   * return sort item
   * @param {String} psNodeName
   * @return sort item
   * @type Array
   */
  get : function(psNodeName) {
    var voItem;
    for ( var i = 0, len = this.sortItems.length; i < len; i++) {
      voItem = this.sortItems[i];
      if (voItem[0] == psNodeName) {
        return voItem;
      }
    }
    return null;
  },
  /**
   * return sort column names
   * @return sort column names
   * @type Array
   */
  getColumnNames : function() {
    var len = this.sortItems.length;
    var voNames = [];
    for ( var i = 0; i < len; i++) {
      voNames[i] = this.sortItems[i][this.SORT_COL_NM];
    }
    return voNames;
  },
  /**
   * sort
   * @return void
   * @type void
   */
  doSort : function() {
    var voInst = this.dataSet.model.getInstance(this.dataSet
        .getConnectionInfo());
    var vsXPath = this.dataSet.getSourceQuery() + "/";

    var voNodeList = [];
    var vnSortLen = this.sortItems.length;
    var voSortItem;
    var voNode, vnNodeLen, vnRowLen;
    var i, j;
    var voSortValues = [];

    var vnRowCnt = this.viewData.getRowCnt();
    var vsColName, voColNode;
    var voViewRow, voOrgRow, vnStatus;

    var vnStatusIdx = this.dataSet.STATUSIDX;
    var vnOrgIdx = this.dataSet.ORIGINIDX;
    var vsSortColNm = this.SORT_COL_NM;
    var vsSortRowIdx = this.SORT_ROW_IDX;
    var vsSortRowStatus = this.SORT_ROW_STAUTS;
    var vsAttrName = this.dataSet.DATA_ROW_ATTR_NAME;
    for (i = 0; i < vnRowCnt; i++) {
      var voCol = [];
      voViewRow = this.viewData.getRow(i);
      vnStatus = voViewRow[vnStatusIdx];
      voOrgRow = this.originRow.getRowElement(voViewRow[vnOrgIdx]);
      for (j = 0; j < vnSortLen; j++) {
        vsColName = this.sortItems[j][vsSortColNm];
        voColNode = voOrgRow.getElementByTagNameFromChildNodes(vsColName);
        voCol[j] = voColNode.getNodeValue();
      }

      voCol[j] = {};
      voCol[j][vsSortRowIdx] = voColNode.getParentNode().getAttribute(vsAttrName);
      voCol[j][vsSortRowStatus] = vnStatus;

      voSortValues[i] = voCol;
    }

    voSortValues.sort(this
        .sorter(this.sortItems, this.SORT_TYPE, this.SORT_ASC));

    var vnLen = voSortValues.length;
    var vnLast = voSortValues[0].length - 1;
    var voList = [];
    var voData;

    for ( var i = 0; i < vnLen; i++) {
      voData = voSortValues[i][vnLast];
      voList[i] = [ voData[vsSortRowIdx], voData[vsSortRowStatus] ];
    }
    this.viewData.restoreRows(voList);
  },
  
  sorter : function(poSortItems, pnType, pnIsAsc) {
    return function(a, b) {
      var len = a.length - 1;
      var d1, d2;
      var vnSrcType, vbIsAsc;
      var result;
      for ( var i = 0; i < len; i++) {
        vnSrcType = poSortItems[i][pnType];
        vbIsAsc = poSortItems[i][pnIsAsc];

        d1 = a[i];
        d2 = b[i];

        if (vnSrcType != 1) {
          d1 = Number(d1);
          d2 = Number(d2);
        }

        if (d1 < d2) {
          result = -1;
        } else if (d1 > d2) {
          result = 1
        } else if (d1 == d2) {
          continue;
        }

        if (vbIsAsc == false) {
          result = result * -1;
        }
        return result;
      }
      return 0;
    }
  }
};