/**
 * @fileoverview
 * eXria.data.xhtml Package
 */
/**
 * eXria.data.xhtml package
 * @author Choe, hyeon jong.
 */
eXria.data.xhtml = {};