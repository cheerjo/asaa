eXria.data.xhtml.AutoCUD = function(poDataSet) {
  this.dataSet = poDataSet;
  this.original = poDataSet.originData;
  this.autoCudTables = {};
  this.attr = {};
  this.useOriginalValue;
};

eXria.data.xhtml.AutoCUD.prototype = {
  TABLE_PK : "PRIMARYKEYS",
  UPDATECOLS : "UPDATECOLUMNS",
  CUDTABLE : "XRAUTOCUD",
  ORIGINAL_APPENDIX : "__origin",
  CUD_TYPE : "CRUDTYPE",
  CUD_TYPE_INSERT : "I",
  CUD_TYPE_UPDATE : "U",
  CUD_TYPE_DELETE : "D",
  CUD_TYPE_UNCHANGED : "R",

  /**
   * cud data에 original value 사용 유무 지정
   * @param {Boolean} pbOrigin
   * @return void
   * @type void
   */
  setUseOriginVal : function(pbOrigin) {
    this.useOriginalValue = pbOrigin;
  },
  /**
   * cud data에 original value 사용 유무 리턴
   * @return use origin val
   * @type Boolean
   */
  isUseOriginalValue : function() {
    return this.useOriginalValue;
  },
  /**
   * add attribute
   * @param {String} psKey key
   * @param {String} psValue value
   * @return void
   * @type void
   */
  setAttr : function(psKey, psValue) {
    this.attr[psKey] = psValue;
  },
  /**
   * return attribute value
   * @param {String} psKey key
   * @return attribute 값
   * @type String
   */
  getAttr : function(psKey) {
    return this.attr[psKey];
  },
  /**
   * create table info object 
   * @param {String} psTableName table name
   * @return void
   * @type void
   */
  createTableInfo : function(psTableName) {
    if (this.autoCudTables[psTableName] != null) {
      if(window.console) window.console.warn("AutoCUD Table is already created : " + psTableName);
    } else {
      var voTable = new eXria.data.xhtml.AutoCUDTableInfo();
      voTable.setId(psTableName);
      this.autoCudTables[psTableName] = voTable;
    }
  },
  /**
   * add table infomation
   * @param {eXria.data.xhtml.AutoCUDTableInfo} poAutoCUDTableInfo table info object
   * @return void
   * @type void
   */
  addTableInfo : function(poAutoCUDTableInfo) {
    var tableName = poAutoCUDTableInfo.getId();
    this.autoCudTables[tableName] = poAutoCUDTableInfo;
  },
  /**
   * return table info
   * @param {String} psTableName tablename
   * @return table info object
   * @type eXria.data.xhtml.AutoCUDTableInfo
   */
  getTableInfo : function(psTableName) {
    return this.autoCudTables[psTableName];
  },
  /**
   * remove table info
   * @param {String} psTableName table name
   * @return void
   * @type void
   */
  removeTableInfo : function(psTableName) {
    delete this.autoCudTables[psTableName];
  },
  /**
   * table name list
   * @return table name list
   * @type Array
   */
  getTableNames : function() {
    var voTableNames = [];
    var cnt = 0;
    for ( var m in this.autoCudTables) {
      voTableNames[cnt++] = m;
    }
    return voTableNames;
  },
  /**
   * parse meta data
   * @return parsed meta data
   * @type String
   * @private
   */
  parseMetaData : function() {
    var s = "";
    var voTable;
    var vsXr = "";
    var vsPrefix;

    for ( var m in this.autoCudTables) {
      voTable = this.autoCudTables[m];
      vsPrefix = voTable.getPrefix();

      vsXr = vsXr + encodeURIComponent(vsPrefix) + ":" + encodeURIComponent(voTable.getId()) + ",";
      // primary keys
      s = s + encodeURIComponent(vsPrefix + this.TABLE_PK) + "=";
      var pks = voTable.getPrimaryKeys();
      for ( var pk in pks) {
        s = s + encodeURIComponent(pks[pk] + ":" + pk + ",");
      }
      s = s + "&";

      // columns
      s = s + encodeURIComponent(voTable.getPrefix() + this.UPDATECOLS) + "=";
      var uCols = voTable.getUpdateCols();
      for ( var cols in uCols) {
        s = s + encodeURIComponent(uCols[cols] + ":" + cols + ",");
      }
      s = s + "&";
    }
    if (s != "") {
      s = s + this.CUDTABLE + "=" + vsXr.substr(0, vsXr.length - 1) + "&";
    }
    return s;
  },
  /**
   * parse auto cud data
   * @return parsed autocud data
   * @type String
   * @private
   */
  parseData : function() {
    var header = this.original.getHeader();
    var colNames = header.getHeaderColumns();
    var rowSize = this.original.getRowCnt();

    var row;
    var rowStatus;
    var rowStatusStr;
    var tableInfoIter;
    var tableInfo;
    var rowWrited;
    var prefix;
    var column;
    var len, j;
    var vnDeleteFlag = this.dataSet.REAL_DELETE_FLAG;
    var vnEmptyFlag = this.dataSet.ETBEMPTYEDFLAG;
    var vnUnChangeFlag = this.dataSet.ETBUNCHANGEDFLAG;
    var vsAllTypeWrite = this.dataSet.getCRUDAttr("alltype");

    var result = "";
    var cnt = 0;

    for ( var i = 0; i < rowSize; i++) {
      rowWrited = false;
      rowStatus = this.original.getStatus(i);

      if ((this.useOriginalValue == true) && (rowStatus == vnDeleteFlag)) {
        continue;
      }
      
      if(rowStatus == vnUnChangeFlag){
        cnt++;
      }

      if (vsAllTypeWrite != "true" && (rowStatus == vnEmptyFlag || rowStatus == vnUnChangeFlag)) {
        continue;
      }

      for ( var m in this.autoCudTables) {
        tableInfo = this.autoCudTables[m];
        prefix = tableInfo.getPrefix();

        len = colNames.length;

        for (j = 0; j < len; j++) { // column loop
          if (tableInfo.isUpdateSource(colNames[j]) || tableInfo.isPrimaryKeySource(colNames[j])) { // update column
            rowWrited = true;
            result = result + encodeURIComponent(prefix + colNames[j]) + "=" + encodeURIComponent(this.original.getValue(i, j)) + "&";
            if (this.useOriginalValue == true || tableInfo.isPrimaryKeySource(colNames[j])) {
              result = result + encodeURIComponent(prefix + colNames[j] + this.ORIGINAL_APPENDIX) + "=" + encodeURIComponent(this.original.getOriginalValue(i, j)) + "&";
            }
          }
        }

        if (rowWrited) {
          rowStatusStr = this.getRowStatusString(rowStatus);
          result = result + encodeURIComponent(prefix + this.CUD_TYPE) + "=" + encodeURIComponent(rowStatusStr) + "&";
        }
      }
    }
    
    
//      if(vsAllTypeWrite != "true" &&  (cnt == rowSize)) {
//        for ( var m in this.autoCudTables) {
//          tableInfo = this.autoCudTables[m];
//          prefix = tableInfo.getPrefix();
//          rowStatusStr = this.getRowStatusString(vnUnChangeFlag);
//          result = result + encodeURIComponent(prefix + this.CUD_TYPE) + "=" + encodeURIComponent(rowStatusStr) + "&";
//        }
//      }
    
    return result;
  },
  /**
   * return cud type
   * @param {Number} pnStatus status
   * @return cud type character
   * @type String
   * @private
   */
  getRowStatusString : function(pnStatus) {
    var status = "";
    switch (pnStatus) {
      case this.dataSet.ETBADDEDFLAG:
        status = this.CUD_TYPE_INSERT;
        break;
      case this.dataSet.ETBDELETEDFLAG:
        status = this.CUD_TYPE_DELETE;
        break;
      case this.dataSet.ETBEMPTYEDFLAG:
        status = this.CUD_TYPE_UNCHANGED;
        break;
      case this.dataSet.ETBMODIFIEDFLAG:
        status = this.CUD_TYPE_UPDATE;
        break;
      case this.dataSet.REAL_DELETE_FLAG:
        status = this.CUD_TYPE_DELETE;
        break;
      case this.dataSet.ETBUNCHANGEDFLAG:
        status = this.CUD_TYPE_UNCHANGED;
        break;
    }
    return status;
  },
  /**
   * return auto cud string
   * @return parsed auto cud data string
   * @type String
   */
  getAutoCRUDString : function() {
    var result = this.parseMetaData();
    if (result == "") return "";
    result = result + this.parseData();
    return result;
  }
};
