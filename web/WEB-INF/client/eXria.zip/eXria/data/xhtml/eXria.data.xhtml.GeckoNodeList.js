﻿/**
 * @fileoverview
 * FireFox, Safari, Chrome, Opera의 XML Node를 List로 wrapping 하는 클래스
 */
/**
 * FireFox, Safari, Chrome, Opera의 XML Node를 List로 wrapping 하는 클래스
 * @version 2.0
 * @param {XPathResult} Gecko XPath Result Object
 * @base eXria.data.NodeList
 * @constructor
 * @private
 */
eXria.data.xhtml.GeckoNodeList = function(poResult) {
  /**
   * Inherit
   */
  eXria.data.NodeList.call(this);
  /**
   * Gecko XMLResult
   * @type XMLPathResult
   * @private
   */
  this.xpathResult = poResult;
  /**
   * return Item count in NodeList
   * @return item count number
   * @type Number
   */
  this.getLength = function() {
    if(this.xpathResult == null) {
      return 0;
    } else {
      return this.xpathResult.snapshotLength;
    }
  };
  /**
   * return NodeItem of parameter index
   * @param {Number} pnIdx index
   * @return node
   * @type XMLNode
   */
  this.item = function(pnIdx) {
    return this.xpathResult.snapshotItem(pnIdx);
  };
};