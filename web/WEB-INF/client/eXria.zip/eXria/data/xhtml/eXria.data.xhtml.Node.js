/**
 * @fileoverview
 * Document Node Object Class
 */
/**
 * xhtml.Node
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.Node
 */
eXria.data.xhtml.Node = function(poNode, pbDom) {
  if(page.metadata.useJsonInstance && !pbDom) {
    eXria.data.json.Node.call(this, poNode);
    return;
  }
  if (poNode == null) {
    throw new Error("Node is null.");
  }
  /**
   * inherit
   */
//  eXria.data.Node.call(this, poNode);
  /**
   * XMLNode
   * @type XMLElementNode
   * @private
   */
  this.node = poNode;
  /**
   * XMLNode Tag Name
   * @type String
   * @private
   */
  this.name = this.node.nodeName;
};

eXria.data.xhtml.Node.prototype = {
  /**
   * 파라미터로 넘어온 Node를 자식 Node의 마지막에 추가한다.
   * @param {eXria.data.Node} poNode 추가할 Node Object
   * @type void
   * @return void
   */
appendChild : function(poNode) {
  if(!poNode) return;
  this.node.appendChild(poNode.node);
  },
  /**
   * 현재 Node와 동일한 Node를 복사하여 리턴한다.
   * @param {Boolean} pbDeep deep copy 유무를 지정한다. (true | false)
   * @return 복사된 Node Object
   * @type eXria.data.Node
   */
  cloneNode : function(pbDeep) {
  if(pbDeep != true) pbDeep = false;
  return new eXria.data.xhtml.Node(this.node.cloneNode(pbDeep));
  },
  /**
   * 현재 Node의 자식 Node들을 NodeList 형식으로 리턴한다.
   * @type eXria.data.NodeList
   * @return 생성된 자식 Node List
   */
  getChildNodes : function() {
  var voChildNodes = this.node.childNodes;
  if(!voChildNodes) { return null; }
  return new eXria.data.xhtml.NodeList(voChildNodes);
  },
  /**
   * 현재 Node의 첫번째 자식 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 첫번째 자식 Node
   */
  getFirstChild : function() {
  var voNode = this.node.firstChild;
  if(!voNode) { return null; }
  return new eXria.data.xhtml.Node(voNode);
  },
  /**
   * 현재 Node의 마지막 자식 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 마지막 자식 Node
   */
  getLastChild : function() {
  var voNode = this.node.lastChild;
  if(!voNode) { return null; }
  return new eXria.data.xhtml.Node(voNode);
  },
  /**
   * 현재 Node의 바로 다음 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 다음 Node
   */
  getNextSibling : function() {
  var voNode = this.node.nextSibling;
  if(!voNode) { return null; }
  return new eXria.data.xhtml.Node(voNode);
  },
  /**
   * 현재 Node의 이름을 리턴한다.
   * @type String
   * @return 현재 Node의 이름
   */
  getNodeName : function() {
    return this.name;
  },
  /**
   * 현재 Node의 value를 리턴한다.
   * @type String
   * @return 현재 Node의 Value
   */
  getNodeValue : function() {
  var vsValue = null;
  var vnNodeType = this.node.nodeType;
  if(vnNodeType == 1) {
    var voChildNode = this.node.firstChild;
    if(!voChildNode) {
    vsValue = "";
    } else {
      vsValue = voChildNode.nodeValue;
    }
  } else if(vnNodeType == 3 || vnNodeType == 4) {
    vsValue = this.node.nodeValue;
  } else {
    vsValue = null;
  }
  return vsValue;
  },
  /**
   * 현재 Node의 부모 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 부모 Node
   */
  getParentNode : function() {
  var voNode = this.node.parentNode;
  if(!voNode) { return null; }
    return new eXria.data.xhtml.Node(voNode);
  },
  /**
   * 현재 Node의 바로 전 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 바로 전 Node
   */
  getPreviousSibling : function() {
  var voNode = this.node.previousSibling;
  if(!voNode) { return null; }
    return new eXria.data.xhtml.Node(voNode);
  },
  /**
   * Element를 생성하여 리턴한다.
   * @param {String} psTagName 생성할 Element의 Tag Name
   * @param {String} psValue 생성할 Element의 Value [ null을 넘길 경우 TextNode가 생성되지 않은 Element 리턴 ]
   * @type {eXria.data.Node}
   * @return 생성된 Element
   */
  createElement : function(psTagName, psValue) {
  var voNode = null;
  try {
    var voOwnerDocument = this.node.ownerDocument;
    voNode = new eXria.data.xhtml.Node(voOwnerDocument.createElement(psTagName));
    if(psValue != null) {
    voNode.appendChild(new eXria.data.xhtml.Node(voOwnerDocument.createTextNode(psValue)));
    }
  } catch(e) { voNode = null; }
  return voNode;
  },
  /**
   * TextNode를 생성하여 리턴
   * @param {String} psValue 생성할 Node의 Value값
   * @type {eXria.data.Node}
   * @return 생성된 TextNode
   */
  createTextNode : function(psValue) {
  var voNode = null;
  try {
    voNode = this.node.ownerDocument.createTextNode(psValue)
  } catch(e) { return null; }
  return new eXria.data.xhtml.Node(voNode);
  },
  /**
   * 현재 Node의 자식 Node 유무를 리턴한다.
   * @type Boolean
   * @return 자식 Node의 존재 유무
   */
  hasChildNodes : function() {
    return this.node.hasChildNodes();
  },
  /**
   * 현재 Node의 자식 Node 중 파라미터로 넘어온 Node와 일치하는 Node를 삭제한다.
   * @param {eXria.data.Node} poNode 삭제할 Node
   * @type eXria.data.Node
   * @return 삭제된 Node
   */
  removeChild : function(poNode) {
  if(!poNode) return;
  var voRemoveNode = this.node.removeChild(poNode.node);
  if(voRemoveNode) {
    return poNode;
  } else {
    return null;
  }
  },
  /**
   * 현재 Node의 Value 파라미터로 넘어온 데이터로 변경한다.
   * @param {String} psValue 변경할 데이터
   * @type void
   * @return void
   */
  setNodeValue : function(psValue) {
  try {
    psValue = (psValue ? psValue : "");
      var voValue = this.node.firstChild;
      if(voValue != null) {
    voValue.nodeValue = psValue;
    } else {
    this.node.appendChild(this.node.ownerDocument.createTextNode(psValue));
    }
  } catch(e) { return null; }
  },
  /**
   * 두번째 파라미터로 넘어온 Node와 동일한 Node가 있을 경우 해당 위치에 첫번째 파라미터로 넘어온 Node를 셋팅.
   * @param {eXria.data.Node} poNewNode 추가할 Node
   * @param {eXria.data.Node} poOldNode 덮어 쓸 Node
   * @type eXria.data.Node
   * @return 삭제된 Node
   */
  replaceChild : function(poNewNode, poOldNode) {
  var voRepChild = this.node.replaceChild(poNewNode.node, poOldNode.node);
  if(voRepChild) {
    return poOldNode;
  } else {
    return null;
  }
  },
  /**
   * 두번째 파라미터로 넘어온 Node의 앞에 첫번째로 넘어온 파라미터 Node를 추가한다.
   * @param {eXria.data.Node} poNewNode 추가할 Node
   * @param {eXria.data.Node} poRefNode 덮어 쓸 Node
   * @type eXria.data.Node
   * @return insert 되기 전 Node
   */
  insertBefore : function(poNewNode, poRefNode) {
  var voOldNode = this.node.insertBefore(poNewNode.node, poRefNode.node);
  if(voOldNode) {
    return poRefNode;
  } else {
    return null;
  }
  },
  /**
   * node type을 리턴한다.
   * @type Number
   * @return 해당 Node의 node Type
   */
  getNodeType : function() {
  return this.node.nodeType;
  },
  /**
   * 현재 클래스의 이름을 반환 한다.
   * @type String
   * @return 현재 클래스 이름
   */
  toString : function() {
  return "eXria.data.xhtml.Node";
  },
  /**
   * 파라미터로 넘어온 Node와 현재 Node가 같은 Node인지 비교한다.
   * @param {eXria.data.Node} poNode 비교할 Node
   * @return 두개의 Node가 같은 Node인지 유무
   * @type Boolean
   */
  equal : function(poNode) {
  return this.node == poNode.node;
  },
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Node
   * @return Node Object
   */
  getElementByTagName : function(psTagName) {
    var voNodes = this.getElementsByTagName(psTagName);
    if(voNodes.getLength() == 0) {
      return null;
    } else {
      return voNodes.item(0);
    }
  },
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.NodeList
   * @return NodeList Object
   */
  getElementsByTagName : function(psTagName) {
  var voNodes = this.node.getElementsByTagName(psTagName);
  if(!voNodes) return null;
  return new eXria.data.xhtml.NodeList(voNodes);
  },
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Node
   * @return NodeList Object
   */
  getElementByTagNameFromChildNodes : function(psTagName) {
    var voNodes = this.getChildNodes();
    var voNode = null;
    var voTmpNode = null;
    for(var i = 0, vnLen = voNodes.getLength() ; i < vnLen ; i++) {
      voNode = voNodes.item(i);
      if(voNode.getNodeName() == psTagName) {
        voTmpNode = voNode;
        break;
      }
    }
    return voTmpNode;
  },
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Collection
   * @return eXria.data.Collection Object
   */
  getElementsByTagNameFromChildNodes : function(psTagName) {
    var voNodes = this.node.childNodes;
    var voNodeArr = new eXria.data.ArrayCollection();

    for(var i = 0, vnLen = voNodes.length ; i < vnLen ; i++) {
      var voNode = voNodes.item(i);
      if(voNode.nodeName == psTagName) {
        voNodeArr.add(new eXria.data.xhtml.Node(voNode));
      }
    }
    return voNodeArr;
  },
  /**
   * 현재 Node의 XML 스트링을 리턴.
   * @type String
   * @return XML String
   */
  getXML : function() {
    if (window.page.metadata.browser.ie > 0) {
      return this.node.xml;
    } else {
      var vSerializer = new XMLSerializer();
      return vSerializer.serializeToString(this.node);
    }
  },
  /**
   * 노드의 특정 속성 반환한다.
   * @param {String} psAttr 속성 명
   * @type String
   * @return 노드의 해당 속성 값
   */
  getAttribute : function(psAttr) {
    return this.node.getAttribute(psAttr);
  },
  /**
   * 노드의 특정 비표준 속성을 반환한다.
   * @param {String} psAttr 비표준 속성 명
   * @type String
   * @return 노드의 해당 속성 값
   */
  getUserAttribute : function(psAttr) {
    var voRet = this.node[psAttr];
    if(voRet == null) voRet = this.node.getAttribute(psAttr);
    return voRet;
  },
  /**
   * 노드의 특정 속성 값을 설정한다.
   * @param {String} psAttr 속성 명
   * @param {String} psValue 속성 값
   */
  setAttribute : function(psAttr, psValue) {
    this.node.setAttribute(psAttr, psValue);
  },
  /**
   * 노드의 특정 비표준 속성 값을 설정한다.
   * @param {String} psAttr 비표준 속성 명
   * @param {String} psValue 속성 값
   */
  setUserAttribute : function(psAttr, psValue) {
    try {
      this.node[psAttr] = psValue;
    } catch(err) {
      this.node.setAttribute(psAttr, psValue);
    }
  },

  getAttributes : function() {
  	var attrs = this.node.attributes;
  	var attrList = new eXria.data.xhtml.NodeList(attrs);
  	return attrList;
  }
};