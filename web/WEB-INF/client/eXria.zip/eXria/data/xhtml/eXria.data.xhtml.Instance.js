/**
 * @fileoverview
 * XHTML Mode에서의 Instance 객체를 관리하는 클래스
 */
/**
 * XHTML Mode에서의 Instance 객체를 관리하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {String} psId Instance Id
 * @param {eXria.form.Model} poModel eXria Model Objecct
 * @constructor
 * @base eXria.data.Instance
 */
eXria.data.xhtml.Instance = function(psId, poModel) {
  if(page.metadata.useJsonInstance) {
    eXria.data.json.Instance.call(this, psId, poModel);
    return;
  }
  /**
   * inherit
   */
  eXria.data.Instance.call(this, psId, poModel);
  /**
   * document
   * @type Object
   */
  this.document = eXria.data.xhtml.DocumentFactory.createDocument(
      this.model.page, psId);
  /**
   * 특정 URL의 XML Document를 인스턴스에 바인딩한다.
   * @param {String} psUrl 바인딩할 XML의 URL
   * @return void
   * @type void
   */
  this.loadURL = function(psUrl) {
    this.document.loadURL(psUrl);
  };
  /**
   * XML Element를 인스턴스에 바인딩한다.
   * @param {XMLElement} poXML 바인딩할 XMLElement
   * @return void
   * @type void
   */
  this.loadXML = function(poXML) {
    this.document.loadXML(poXML);
  };
  /**
   * XML Text를 파싱하여 인스턴스에 바인딩한다.
   * @param {String} psTxt 파싱할 XML Text
   * @return void
   * @type void
   */
  this.loadTXT = function(psTxt) {
    this.document.loadTXT(psTxt);
  };
  /**
   * Node를 주어진 타입에 따라 생성하여 그 객체를 리턴한다.
   * @param {String} psNodeName 생성할 node Name
   * @param {String}  psValue 생성할 Node의 Value
   * @type XMLNode
   * @return 생성된 XML Node
   */
  this.createNode = function(psNodeName, psValue) {
    var voNewNode = null;
    try {
      voNewNode = this.document.createNode(psNodeName);
      if (psValue) {
        voNewNode.appendChild(voNewNode.ownerDocument.createTextNode(psValue));
      }
    } catch (e) {
      return null;
    }
    return new eXria.data.xhtml.Node(voNewNode);
  };
  /**
   * 파라미터로 넘어온 이름의 Element를 생성하여 리턴한다.
   * @param {String} psElementName 생성될 엘리먼트 이름
   * @return 생성된 Element Node
   * @type eXria.data.Node
   * @see eXria.data.Node
   */
  this.createElement = function(psElementName) {
    if(!psElementName) { return null; }
    return this.createNode(psElementName, null);
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 ValueNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 ValueNode
   * @type eXria.data.xhtml.ValueNode
   * @see eXria.data.xhtml.ValueNode
   */
  this.createValueNode = function(psName) {
    var voNode = this.document.createNode(psName);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.ValueNode(new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 MapNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 MapNode
   * @type eXria.data.xhtml.MapNode
   * @see eXria.data.xhtml.MapNode
   */
  this.createMapNode = function(psName) {
    var voNode = this.document.createNode(psName);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.MapNode(new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 CollectionNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 CollectionNode
   * @type eXria.data.xhtml.CollectionNode
   * @see eXria.data.xhtml.CollectionNode
   */
  this.createCollectionNode = function(psName) {
    var voNode = this.document.createNode(psName)
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.CollectionNode(
        new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 넘겨 받은 XPath의 하위에 Node를 추가한다.
   * @param {String} psPath 추가할 위치에 해당하는 XPath
   * @param {XMLNode} poNode 추가할 XMLNode
   * @return void
   * @type void
   */
  this.appendNode = function(psPath, poNode) {
    var voNode = null;
    voNode = this.document.selectSingleNode(psPath);
    if (voNode == null) {
      throw new Error("Can not find the node : " + psPath);
    }

    voNode = new eXria.data.xhtml.Node(voNode);
    voNode.appendChild(poNode);
  };
  /**
   * 넘겨받은 XPath를 단순 Value형태로 처리하기 위한 ValueNode를 생성하여 리턴한다.
   * @param {String} psXpath psClassName 참조 대상 클래스명
   * @return 생성된 ValueNode
   * @type eXria.data.xhtml.ValueNode
   * @see eXria.data.xhtml.ValueNode
   */
  this.getValueNode = function(psXpath) {
    var voNode = this.document.selectSingleNode(psXpath);
    if (voNode == null) {
      return null;
    }
    return new eXria.data.xhtml.ValueNode(new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 파라미터로 넘어온 XPath의 Node Value를 리턴한다.
   * @param {String} psXpath 조회대상의 XPath 경로
   * @type String
   * @return 조회된 Value
   */
  this.getValue = function(psXpath) {
    try {
      var voNode = new eXria.data.xhtml.Node(this.document.selectSingleNode(psXpath));
      return voNode != null ? voNode.getNodeValue() : null;
    } catch (e) {
      return null;
    }
  };
  /**
   * Instance의 dom객체의 XML 내용을 XPath를 이용하여 해당 위치에 데이터를 문자열로 얻는다.
   * @return dom 객체의 XML 문자열
   * @param {String} psXPath XPath 문자열
   * @type String
   */
  this.getXML = function(psXPath) {
    if (!psXPath) {
      return;
    }

    var voNode = this.document.selectSingleNode(psXPath);
    if (voNode == null && voNode == undefined) {
      throw new Error("Cannot find XPath node.");
    } else {
      if (this.model.page.metadata.browser.ie > 0) {
        return voNode.xml;
      } else {
        var vSerializer = new XMLSerializer();
        return vSerializer.serializeToString(voNode);
      }
    }
  };
  /**
   * Instnace의 주어진 XPath 경로에 Value를 설정한다.
   * @param {String} psXpath Value를 설정하기 위한 XPath 경로
   * @param {String} psValue 설정하고자 하는 Value
   * @return void
   * @type void
   */
  this.setValue = function(psXpath, psValue) {
    var voNode = this.document.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    voNode = new eXria.data.xhtml.Node(voNode);
    psValue = (psValue ? psValue : "");
    var vsValue = voNode.setNodeValue(psValue);
  };
  /**
   * 넘겨받은 XPath를 Map형태로 처리하기 위한 MapNode를 생성하여 리턴한다.
   * @param {String} psXpath psClassName 참조 대상 클래스명
   * @return 생성된 MapNode
   * @type eXria.data.xhtml.MapNode
   * @see eXria.data.xhtml.MapNode
   */
  this.getMapNode = function(psXpath) {
    var voNode = this.document.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.MapNode(new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 넘겨받은 XPath를 Collection형태로 처리하기 위한 CollectionNode를 생성하여 리턴한다.
   * @param {String} psXpath 처리할 기준 Node XPath
   * @return 생성된 CollectionNode
   * @type eXria.data.xhtml.CollectionNode
   * @see eXria.data.xhtml.CollectionNode
   */
  this.getCollectionNode = function(psXpath) {
    var voNode = this.document.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.CollectionNode(
        new eXria.data.xhtml.Node(voNode));
  };
  /**
   * 넘겨받은 Xpath의 Node를 삭제한다.
   * @param {String} psXpath 삭제할 Node의 XPath
   * @return 삭제된 노드
   * @type eXria.data.Node
   */
  this.removeNode = function(psXpath) {
  var voNodeObj = null;
  if(typeof(psXpath) == "string") {
      voNodeObj = new eXria.data.xhtml.Node(this.document.removeNode(psXpath));
  } else {
    voNodeObj = psXpath;
    voParentNode = voNodeObj.getParentNode();
    voParentNode.removeChild(voNodeObj);
  }
    return voNodeObj;
  };
  /**
   * 해당 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 Node
   * @type XMLNode
   */
  this.selectSingleNode = function(psXpath) {
    var voNode = this.document.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.Node(voNode);
  };
  /**
   * Instance의 하위Node를 넘겨받은 XPath로 조회하여 리턴한다.
   * @param {String} psXpath 조회할 Xpath
   * @return 생성된 NodeList
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodes = function(psXpath) {
    var voNodes = this.document.selectNodes(psXpath);
    if (!voNodes) {
      return null;
    }
    return new eXria.data.xhtml.NodeList(voNodes);
  };
  /**
   * Instance의 하위Node들을 넘겨받은 XPath로 조회하여 배열 객체로 반환하는 메소드.
   * plugin 버전은 데이타 호환성 때문에 문자열을 반환받으나 여기서는 배열 객체를 바로 반환함.
   * 일반적으로 이후에 응용코드에서 반환값을 eval하여 사용하게 되는데 이럴경우에만 이 메소드 사용이 가능하고
   * 메소드의 반환값을 문자열로만 취급할 경우에는 사용불가.
   * @param {String} psXpath 조회할 Xpath
   * @return 생성된 NodeList
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodesStr = function(psXpath) {
    var voNodes = this.document.selectNodes(psXpath);
    if (!voNodes) {
      return null;
    }
    var vnCnt = voNodes.getLength();
    var vaNode = [];
    for(var i = 0; i < vnCnt; i++) {
      vaNode.push(voNodes.item(i));
    }
    return vaNode;
  };
  /**
   * 모든 하위노드를 삭제한다.
   * @return void
   * @type void
   */
  this.clear = function() {
    delete this.document;
    this.model = null;
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 alert으로 출력
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return void
   * @type void
   */
  this.print = function(psXpath) {
    alert(this.getXML(psXpath));
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 문자열로 반환
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return xml 노드를 문자열화한 객체
   * @type String
   */
  this.nodeToStr = function(psXpath) {
    if (psXpath == null || psXpath == undefined) {
      return;
    }
    return this.getXML(psXpath);
  };
  /**
   * 넘겨 받은 XPath의 Node를 복사하여 리턴한다.
   * @param {String} psXPath 복사할 Node의 XPath
   * @param {String} pbDeep 깊은복사 유무 ( True : Deep Copy )
   * @return 복사된 노드
   * @type XMLNode
   */
  this.cloneNode = function(psXPath, pbDeep) {
    try {
      return new eXria.data.xhtml.Node(this.document.selectSingleNode(psXPath)
          .cloneNode(pbDeep));
    } catch (e) {
      return null;
    }
  };
  /**
   * 해당 XPath 하위에 두번째 파라미터로 넘어온 XML Text Node구조를 생성한다.
   * @param {String} psXpath 생성할 Node의 Parent Node가 될 Node의 XPath
   * @param {String} psTxt 생성할 Node XML Text
   * @return void
   * @type void
   */
  this.appendNodeByTxt = function(psXPath, psTxt) {
    var vsTmpName = "tmp" + new Date().getTime();
    var vsTxt = "<" + vsTmpName + ">" + psTxt + "</" + vsTmpName + ">";
    var vsOrgNodeStr = this.getXML("/root");

    this.loadTXT(vsTxt);
    var voNewNode = this.selectSingleNode("/" + vsTmpName).cloneNode(true);

    this.removeNode("/" + vsTmpName);

    this.loadTXT(vsOrgNodeStr);

    var voNewChild = voNewNode.getChildNodes();
    var vnLen = voNewChild.getLength();

    var voParentNode = this.selectSingleNode(psXPath);

    for(var i = 0 ; i < vnLen ; i++) {
      voParentNode.appendChild(voNewChild.item(i).cloneNode(true));
    }
  };
};
