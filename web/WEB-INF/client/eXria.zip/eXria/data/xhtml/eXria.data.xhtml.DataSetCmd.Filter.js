eXria.data.xhtml.Filter = function(poDataSet) {
  this.dataSet = poDataSet;
  this.viewData = poDataSet.viewData;
  this.originData = poDataSet.originData;
  this.isViewDeleteFlag;
};

eXria.data.xhtml.Filter.prototype = {
  /**
   * filtering 
   * @param {String} psXPath xpath
   * @return void
   * @type void
   */
  doFilter : function(psXPath) {
    var voOrgIdxs = this.retrieveIndex(psXPath);
    this.viewData.clear();

    var vnRowStatus, vnOrgIdx, voRow;
    var vnLen = voOrgIdxs.length;
    var vnDeleteFlag = this.dataSet.ETBDELETEDFLAG;
    for ( var i = 0; i < vnLen; i++) {
      vnOrgIdx = voOrgIdxs[i];
      voRow = this.originData.getRowElement(vnOrgIdx);
      vnRowStatus = this.originData.getStatus(vnOrgIdx);
      if (vnRowStatus == vnDeleteFlag && !this.isViewDeleteFlag) {
        continue;
      } else {
        this.viewData.addRow(null, vnOrgIdx, vnRowStatus);
      }
    }
  },
  /**
   * retrive index
   * @param {String} psXPath
   * @return filtered index list
   * @type Array
   * @ignore
   */
  retrieveIndex : function(psXPath) {
    var vsXPath = this.dataSet.getSourceQuery() + "[" + psXPath + "]";
    var voNodeList = this.dataSet.model.getInstance(this.dataSet.getConnectionInfo()).selectNodes(vsXPath);
    if (voNodeList == null) return [];
    var vnLen = voNodeList.getLength();
    var voResult = [];
    var vsAttrName = this.dataSet.DATA_ROW_ATTR_NAME;
    for ( var i = 0; i < vnLen; i++) {
      voResult[i] = voNodeList.item(i).getAttribute(vsAttrName);
    }
    return voResult;
  },
  /**
   * clear filter
   * @return void
   * @type void
   */
  clear : function() {
    this.viewData.clear();

    var vnRowCnt = this.originData.getRowCnt();
    var voRow, vnStatus;
    for ( var i = 0; i < vnRowCnt; i++) {
      voRow = this.originData.getRowElement(i);
      vnStatus = this.originData.getStatus(i);
      this.viewData.addRow(null, i, vnStatus);
    }
  },
  /**
   * set is view delete row
   * @param {Boolean} pbFlag delete row view flag
   * @return void
   * @type void
   */
  setIsViewDeleteFlag : function(pbFlag) {
    this.isViewDeleteFlag = pbFlag;
  }
};