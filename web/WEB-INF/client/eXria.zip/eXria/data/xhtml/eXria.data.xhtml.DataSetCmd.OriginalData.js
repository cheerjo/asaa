eXria.data.xhtml.OriginalData = function(poDataSet) {
  this.dataSet = poDataSet;
  // 로우 노드 리스트 [[row object, attribute, status, hidestatus], ......]
  this.row = [];
  // 실제 current, origin value 관리 리스트 [["original value", "current value"],[]...]
  // valueRow의 경우 dataset의 특정 컬럼에 get/set이 일어날 경우 동적 생성(해당 컬럼이 존재하는 row 일괄 생성)
  this.dataRow = [];
  this.header = this.dataSet.getHeader(); // 헤더

  var voInst = this.dataSet.model.getInstance(this.dataSet.getConnectionInfo());
  this.parentNode = (voInst) ? this.dataSet.model.getInstance(this.dataSet.getConnectionInfo()).selectSingleNode(this.dataSet.getSourceQuery().substr(0, this.dataSet.getSourceQuery().lastIndexOf("/"))) : null;
};

eXria.data.xhtml.OriginalData.prototype = {
  COL_ORIGIN_VAL : 0, //org
  COL_CURRENT_VAL : 1, //current
  /**
   * 헤더 오브젝트 리턴
   * @return header array
   * @type Array
   */
  getHeader : function() {
    return this.header;
  },
  /**
   * 컬럼 추가
   * @param {Number} pnIdx insert column index
   * @param {String} psColName insert column name
   * @return inserted header index
   */
  addColumn : function(pnIdx, psColName) {
    var vnHeaderIdx = this.header.addHeaderColumn(pnIdx, psColName);
    var i, len = this.row.length;
    var voRowNode, voRowEntry;
    var vsRowNode = this.dataSet.ROW_NODE;
    var voDataRow = null;

    for (i = 0; i < len; i++) {
      voRowEntry = this.getDataRow(i);
      var voNew = [ "", "" ];
      voRowEntry.splice(vnHeaderIdx, 0, voNew);

      voRowNode = this.row[i][vsRowNode];
      var voNode = voRowNode.getElementByTagNameFromChildNodes(psColName);

      if (voNode == null) {
        voNode = this.parentNode.createElement(psColName, "");
        voRowNode.appendChild(voNode);
      } else {
        var voTxt = voNode.getNodeValue();
        if (voTxt == null) {
          voTxt = this.parentNode.createTextNode("");
          voNode.appendChild(voTxt);
        }
      }
    }
    return vnHeaderIdx;
  },
  /**
   * 컬럼 삭제
   * @param {Number} pnIdx remove header index
   * @return void
   * @type void
   */
  removeColumn : function(pnIdx) {
    var vsHeaderNm = this.header.getHeaderColumn(pnIdx);
    this.header.removeColumn(pnIdx);
    var len = this.dataRow.length;
    var voRow;
    for ( var i = 0; i < len; i++) {
      voRow = this.dataRow[i];
      voRow.splice(pnIdx, 1);
    }

    var vsRowNode = this.dataSet.ROW_NODE;
    if (this.dataSet.isDataSync()) {
      var len = this.row.length, delCol;
      for ( var i = 0; i < len; i++) {
        voRow = this.row[i][vsRowNode];
        delCol = voRow.getElementByTagNameFromChildNodes(vsHeaderNm);
        if (delCol != null) {
          voRow.removeChild(delCol);
        }
      }
    }
  },
  /**
   * 인스턴스 데이터를 실제 orgin data와 current data로 분리하여 필요시에만 생성</br>
   * 생성 시점은 dataset에 set 혹은 get 메소드가 실행될 때 row 단위로 생성 되며 이미 생성된 row의 경우 해당 데이터 리턴</br>
   * 이 부분의 경우 프로그램상 부하가 많이 걸리며 인스턴스 데이터를 list 형식으로 새로 저장하기 때문에 데이터의 양에 따라 메모리가 소비됨.</br>
   * 때문에 다량의 데이터를 한번에 로드(Grid에서 Paging을 쓰지 않거나 auto의 경우) 할 경우</br>
   * 처리 시간 및 메모리 사용이 증가 할 수 있음.</br>
   * 또한 메모리 낭비를 줄이기 위하여 original data의 경우 현 시점에 셋팅 되지 않으며,
   * data row 생성 후 실제 데이터에 변경이 일어날때 (dataset.set) original data를 셋팅함.
   * @param {Number} pnIdx row index
   * @param {Number} pnColIdx column index
   * @return array 형식의 데이터 ["original data index", "current data index"]
   * @type Array
   * @ignore
   */
  getDataRow : function(pnIdx, pnColIdx) {
    var voDataRow = this.dataRow[pnIdx];
    if (voDataRow == null) {
      voDataRow = [];
      this.dataRow[pnIdx] = voDataRow;
    } else {
      return voDataRow;
    }

    if (pnColIdx == null)
      return voDataRow;

    var voCol = voDataRow[pnColIdx];
    if (voCol == null) {
      var voRow = this.row[pnIdx][this.dataSet.ROW_NODE];

      var vnType, vsNodeName, vnIdx, vsValue;
      var vnColCur = this.COL_CURRENT_VAL;
      var vnColOri = this.COL_ORIGIN_VAL;
      var i;
      var voChilds = voRow.getChildNodes();
      var vnLen = voChilds.getLength();

      for (i = 0; i < vnLen; i++) {
        voChild = voChilds.item(i);
        vnType = voChild.getNodeType();
        if (vnType != 1) {
          continue;
        }
        var voColNode = [];
        vsNodeName = voChild.getNodeName();
        vnIdx = this.header.getHeaderIndex(vsNodeName);
        if (vnIdx == -1) {
          continue;
        }

        vsValue = voChild.getNodeValue();
        voColNode[vnColCur] = vsValue;
        if(voColNode[vnColOri] === undefined){
          voColNode[vnColOri] = voColNode[vnColCur];
        }
        voDataRow[vnIdx] = voColNode;
      }

      var vnHeaderLen = this.header.getHeaderCnt();
      for (i = 0; i < vnHeaderLen; i++) {
        if (voDataRow[i] == null) {
          voDataRow[i] = [ "", "" ];
        }
      }
    }
    return voDataRow;
  },
  /**
   * data row에 데이터 셋팅, status 변경
   * @param {Number} pnIdx row index
   * @param {Number} pnColIdx column index
   * @param {String} psVal value
   * @return void
   * @type void
   */
  setValue : function(pnIdx, pnColIdx, psVal) {
    psVal = psVal == null ? "" : psVal;

    var voRow = this.row[pnIdx];
    if (voRow == null)
      return;

    var voDataRow = this.getDataRow(pnIdx, pnColIdx);

    var voCol = voDataRow[pnColIdx];
    if (voCol[this.COL_ORIGIN_VAL] === undefined) {
      voCol[this.COL_ORIGIN_VAL] = voCol[this.COL_CURRENT_VAL];
    }

    if (voCol[this.COL_CURRENT_VAL] === psVal) {
      return;
    }

    var vsStatus = this.dataSet.ROW_STATUS;
    var rowStatus = voRow[vsStatus];
    if (rowStatus == this.dataSet.ETBEMPTYEDFLAG) {
      voRow[vsStatus] = this.dataSet.ETBADDEDFLAG;
    } else if (rowStatus == this.dataSet.ETBUNCHANGEDFLAG) {
      voRow[vsStatus] = this.dataSet.ETBMODIFIEDFLAG;
    }

    this.setValueOnly(pnIdx, pnColIdx, psVal, voRow, voCol);
  },

  /**
   * data row에 데이터 셋팅, status 없음
   * @param {Number} pnIdx row index
   * @param {Number} pnColIdx column index
   * @param {String} psVal value
   * @param {Object} poRow row object
   * @param {Object} poCol column object
   * @return void
   * @type void
   */
  setValueOnly : function(pnIdx, pnColIdx, psVal, poRow, poCol) {
    if (poRow == null || poCol == null) {
      poRow = this.row[pnIdx];
      var voDataRow = this.getDataRow(pnIdx, pnColIdx);
      poCol = voDataRow[pnColIdx];
    }

    if (poCol[this.COL_ORIGIN_VAL] === undefined) {
      poCol[this.COL_ORIGIN_VAL] = poCol[this.COL_CURRENT_VAL];
    }

    poCol[this.COL_CURRENT_VAL] = psVal;

    var vsStatus = this.dataSet.HIDE_ROW_STATUS;
    var rowStatus = poRow[vsStatus];
    if (rowStatus == this.dataSet.ETBEMPTYEDFLAG) {
      poRow[vsStatus] = this.dataSet.ETBADDEDFLAG;
    } else if (rowStatus == this.dataSet.ETBUNCHANGEDFLAG) {
      poRow[vsStatus] = this.dataSet.ETBMODIFIEDFLAG;
    }

    if (this.dataSet.isDataSync()) {
      var vsColName = this.header.getHeaderColumn(pnColIdx);
      var voRow = poRow[this.dataSet.ROW_NODE];
      var voNode = voRow.getElementByTagName(vsColName);
      if(voNode == null) {
        voRow.appendChild(voRow.createElement(vsColName));
        voNode = voRow.getElementByTagName(vsColName);
      }
      voNode.setNodeValue(psVal);
    }
  },
  /**
   * 현재 dataset column의 값
   * @param {Number} pnRowIdx row index
   * @param {Number} pnColIdx column index
   * @return 해당 컬럼의 데이터
   * @type String
   */
  getValue : function(pnRowIdx, pnColIdx) {
    var voDataRow = this.getDataRow(pnRowIdx, pnColIdx);
    return voDataRow[pnColIdx][this.COL_CURRENT_VAL];
  },
  /**
   * dataset column의 초기 셋팅 데이터
   * @param {Number} pnRowIdx row index
   * @param {Number} pnColIdx column index
   * @return 해당 컬럼의 데이터
   * @type String
   */
  getOriginalValue : function(pnRowIdx, pnColIdx) {
    var voRow = this.row[pnRowIdx];
    if (voRow == null)
      return "";

    var voDataRow = this.getDataRow(pnRowIdx, pnColIdx);
    if (voDataRow[pnColIdx][this.COL_ORIGIN_VAL] === undefined) {
      return voDataRow[pnColIdx][this.COL_CURRENT_VAL];
    }
    return voDataRow[pnColIdx][this.COL_ORIGIN_VAL];
  },
  /**
   * row 추가
   * @param {Array} poRow row object
   * @return 로우 추가 후 row count
   * @type Number
   */
  addRow : function(poRow) {
    if (poRow == null) {
      poRow = [];
      var vnEmpty = this.dataSet.ETBEMPTYEDFLAG;
      poRow[this.dataSet.ROW_STATUS] = vnEmpty;
      poRow[this.dataSet.HIDE_ROW_STATUS] = vnEmpty;

      var voRow = this.parentNode.createElement(this.dataSet.getRowTagName());
      voRow.setAttribute(this.dataSet.DATA_ROW_ATTR_NAME, this.row.length);

      var vnHeaderCnt = this.header.getHeaderCnt();
      var vsHeader;
      for ( var i = 0; i < vnHeaderCnt; i++) {
        vsHeader = this.header.getHeaderColumn(i);
        var voCol = this.parentNode.createElement(vsHeader, "");
        voRow.appendChild(voCol);
      }
      
      this.parentNode.node = this.parentNode.parentNode[this.parentNode.name];
      this.parentNode.appendChild(voRow, this.dataSet.getRowTagName());

      poRow[this.dataSet.ROW_ATTR] = {};
      poRow[this.dataSet.ROW_NODE] = voRow;
    }

    this.row[this.row.length] = poRow;
    return this.row.length - 1;
  },
  /**
   * 실제 로우 node 를 리턴
   * @param {Number} pnIdx row index
   * @return row node
   * @type eXria.data.Node
   */
  getRowElement : function(pnIdx) {
    return this.row[pnIdx][this.dataSet.ROW_NODE];
  },
  /**
   * row object 리턴
   * @param {Number} pnIdx row index
   * @return row object 
   * @type Array
   */
  getRow : function(pnIdx) {
    return this.row[pnIdx];
  },
  /**
   * 로우 카운트 리턴
   * @return row 갯수
   * @type Number
   */
  getRowCnt : function() {
    return this.row.length;
  },
  /**
   * clear
   * @return void
   * @type void
   */
  clear : function() {
    this.row = null;
    this.row = [];
    this.dataRow = null;
    this.dataRow = [];
  },
  /**
   * row attribute 추가
   * @param {Number} pnIdx row index
   * @param {String} psKey attribute key
   * @param {String} psVal attribute value
   * @return void
   * @type void
   */
  setRowAttr : function(pnIdx, psKey, psVal) {
    if(this.row[pnIdx][this.dataSet.ROW_ATTR] == null){
      this.row[pnIdx][this.dataSet.ROW_ATTR] = {};
    }
    var voAttr = this.row[pnIdx][this.dataSet.ROW_ATTR];
    voAttr[psKey] = psVal;
  },
  /**
   * row attribute 리턴
   * @param {Number} pnIdx row index
   * @param {String} psKey attribute key
   * @return attribute value
   * @type String
   */
  getRowAttr : function(pnIdx, psKey) {
    var voAttr = this.row[pnIdx][this.dataSet.ROW_ATTR];
    if(voAttr == null) return null;
    return voAttr[psKey];
  },
  /**
   * status 설정
   * @param {Number} pnIdx row index
   * @param {Number} pnStatus status
   * @return void
   * @type void
   */
  setStatus : function(pnIdx, pnStatus) {
    this.row[pnIdx][this.dataSet.ROW_STATUS] = pnStatus;
    this.row[pnIdx][this.dataSet.HIDE_ROW_STATUS] = pnStatus;

    if (pnStatus == this.dataSet.REAL_DELETE_FLAG) {
      var voRow = this.row[pnIdx][this.dataSet.ROW_NODE];
      voRow.getParentNode().removeChild(voRow);
    }
  },
  /**
   * status 리턴
   * @param {Number} pnIdx row index
   * @return row status
   * @type Number
   */
  getStatus : function(pnIdx) {
    return this.row[pnIdx][this.dataSet.ROW_STATUS];
  },
  /**
   * setValueOnly를 사용하여 status 변경을 하지 않아도 암묵적으로 저장된 row status를 리턴 
   * @param {Number} pnIdx row index
   * @return row status
   * @type Number
   * @ignore
   */
  getHideStatus : function(pnIdx) {
    return this.row[pnIdx][this.dataSet.HIDE_ROW_STATUS];
  },
  /**
   * 실제 instance node를 삭제
   * @return void
   * @type void
   */
  clearInstance : function() {
    if (this.parentNode != null) {
      var voNodes = this.parentNode.getChildNodes();
      if(voNodes == null) return ;
      var vnLen = voNodes.getLength();
      var voNode;
      for ( var i = 0; i < vnLen; i++) {
        voNode = voNodes.item(i);
        this.parentNode.removeChild(voNode);
      }
    }
  },
  /**
   * 컬럼 복사
   * @param {Number} pnColIdx column index
   * @param {String} psColName column name
   * @param {Object} poOrgData original data
   * @return void
   * @type void
   */
  cloneColumn : function(pnColIdx, psColName, poOrgData) {
    var vnTargetIdx = this.header.getHeaderIndex(psColName);
    var vnCnt = poOrgData.getRowCnt();

    if (this.getRowCnt() < vnCnt) {
      while (this.getRowCnt() < cnt) {
        this.addRow(null);
      }
    }

    var voSrcRow;
    var vsColVal, vsColOrgVal;
    for ( var i = 0; i < cnt; i++) {
      vsColVal = poOrgData.getValue(i, pnColIdx);
      vsColOrgVal = poOrgData.getOriginalValue(i, pnColIdx);
      this.setValue(i, vnTargetIdx, vsColOrgVal);
      this.setValue(i, vnTargetIdx, vsColVal);
    }
  },
  /**
   * dataset originData 수정
   * @param {Number} pnRowIdx row index
   * @param {Number} pnColIdx column index
   * @param {Number} psVal value
   * @return void
   * @type void
   */
  setOriginalData : function(pnRowIdx, pnColIdx, psVal){
    var voDataRow = this.getDataRow(pnRowIdx, pnColIdx);
    voDataRow[pnColIdx][this.COL_ORIGIN_VAL] = psVal;
  }
};