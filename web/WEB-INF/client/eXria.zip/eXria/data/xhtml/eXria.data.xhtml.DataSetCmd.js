eXria.data.xhtml.DataSetCmd = function(psId, pnTypeSource, psConnectionInfo, psSourceQuery, pbSourceSync, pbKeepOriginValue, poModel) {
	this.id = psId;
	this.srcType = pnTypeSource;
	this.conInfo = (psConnectionInfo == null) ? "" : psConnectionInfo;
	this.srcQuery = (psSourceQuery == null) ? "" : psSourceQuery;
	this.srcSync = pbSourceSync;
	this.isKeepOrgin = pbKeepOriginValue;
	this.model = poModel;

  this.rowTagName;

  var vnSlash = this.srcQuery.lastIndexOf("/");
	if (vnSlash > 0) {
		this.rowTagName = this.srcQuery.substr(vnSlash + 1);
	} else {
		this.rowTagName = "list";
	}
	
	this.ETBUNCHANGEDFLAG = 1;
	this.ETBADDEDFLAG = 2;
	this.ETBDELETEDFLAG = 4;
	this.ETBMODIFIEDFLAG = 8;
	this.REAL_DELETE_FLAG = 9;
	this.ETBEMPTYEDFLAG = 16;
	
	this.ROW_STATUS = "status"; //dataset, org
	this.HIDE_ROW_STATUS = "hide_status"; //dataset, org
	this.ROW_ATTR = "attribute"; //filter, dataset, org, sort
	this.ROW_NODE = "row"; //dataset, org
	this.DATA_ROW_ATTR_NAME = "DataSetRowIdx"; //dataset, filter, sort
	this.ORIGINIDX = 0; //dataset, sort, view
	this.STATUSIDX = 1; //sort, viewData
	this.VIEWIDX = 2; //dataset, view

	this.dataSet = this;
	
  this.header = null;
  this.viewData = null;
  this.originData = null;
  this.delData = null;
  this.sorter = null;
  this.filter = null;
  
  this.init = function() {
	  this.header = new eXria.data.xhtml.Header(this);
	  this.delData = new eXria.data.xhtml.DelData(this);
	  this.originData = new eXria.data.xhtml.OriginalData(this);
	  this.viewData = new eXria.data.xhtml.ViewData(this);
	  this.sorter = new eXria.data.xhtml.Sort(this);
	  this.filter = new eXria.data.xhtml.Filter(this);
	  this.autoCUD = new eXria.data.xhtml.AutoCUD(this);
	  this.autoCUD.setUseOriginVal(this.isKeepOrgin);
  };
  
  this.getHeader = function() {
  	return this.header;
  };
  /**
   * Primary key 정보를 설정한다.
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName 설정할 primary key
   * @return void
   * @type void
   */
  this.addPrimaryKey = function(psTableName, psName, psSourceName) {
  	var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			voTable.addPrimaryKey(psSourceName, psName);
		} else {
			throw new Error(psTableName + " not register.");
		}
  };
  /**
   * column 정보를 update 한다.
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName update 할 값
   * @return void
   * @type void
   */
  this.addUpdateColumn = function(psTableName, psName, psSourceName) {
  	var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			voTable.addUpdateColumn(psSourceName, psName);
		} else {
			throw new Error(psTableName + " not register.");
		}
  };
  /**
   * source와 target의 index를 설정한다.
   * @param {Number} pnSourceIndex 대상 src index
   * @param {Number} pnTargetIndex 대상 target index
   * @return void
   * @type void
   */
  this.changeRowIndex = function(pnSrcIdx, pnTgIdx) {
  	var vnViewIdx = this.toArrayIndex(pnSrcIdx);
		var vnTargetIdx = this.toArrayIndex(pnTgIdx);

		var vnSwap1 = this.viewData.getOriginalIndex(vnViewIdx);
		var vnSwap2 = this.viewData.getOriginalIndex(vnTargetIdx);

		this.viewData.setOriginalIndex(vnViewIdx, vnSwap2);
		this.viewData.setOriginalIndex(vnTargetIdx, vnSwap1);
  };
  /**
   * 해당 테이블에서 primary key 정보를 삭제한다.
   * @param {String} psTableName 대상 테이블 이름
   * @return void
   * @type void
   */
  this.clearPrimaryKeys = function(psTableName) {
  	var voTable = this.autoCUD.getTableInfo(psTableName);
		if (voTable != null) {
			voTable.clearPrimaryKey();
		} else {
			throw new Error(psTableName + " not register.");
		}
  };
  /**
   * sort parameter를 clear 한다.
   * @return void
   * @type voiddnd
   
   */
  this.clearSortItem = function() {
  	this.sorter.clear();
  };
  /**
   * column 정보를 clear 한다.
   * @param {String} psTableName 대상 table name
   * @return void
   * @type void
   */
  this.clearUpdateColumns = function(psTableName) {
  	var voTable = this.autoCUD.getTableInfo(psTableName);
		if (voTable != null) {
			voTable.clearUpdateCololumn();
		} else {
			throw new Error(psTableName + " not register.");
		}
  };
  /**
   * 현재 DataSet에 특정 컬럼을 다른 DataSet으로 복사한다.
   * @param {String} psScrCol 원본 컬럼명
   * @param {String} psDataSetId 복사할 데이터셋 Id명
   * @return 복사 성공 여부 성공시 True
   * @type Boolean
   */
  this.cloneCol = function(psSrcCol, psDataSetId) {
  	var vnColIdx = this.header.getHeaderIndex(psSrcCol);
  	var voTargetDs = this.model.getDataSet(psDataSetId);
  	if(voTargetDs == null) {
  		throw new Error("DataSet is null : " + psDataSetId);
  	}
  	
  	var vnAppendIdx = voTargetDs.appendColumn(psSrcCol);
  	voTargetDs.originData.cloneColumn(vnColIdx, psSrcCol, this.originData);
  	return true;
  };
  /**
   * XPath filter 설정
   * @param {String} psXPath 적용대상 경로
   * @param {Boolean} pbApply 적용 유무
   * @param {Boolean} pbViewDelFlagRow delete flag row를 보이고자 할 경우 true 보이지 말고자 할 경우 false
   * @return -1
   * @type Number
   */
  this.compositeFilter = function(psXPath, pbApply) {
  	if(pbApply == true) {
  		this.filter.setIsViewDeleteFlag(pbApply);
  		this.filter.doFilter(psXPath);
  	} else {
  		this.filter.clear();
  	}
  };
  /**
   * xpath를 이용하여 필터링된 자료의 DataSet RowID를 알아낸다.
   * @param {String} psXPath 해당 DataSet에서 추출 하고자 하는 컬럼의 연산식
   * @return 해당 연산으로 필터링 된 RowIndex를 문자열로 ','로 구분하여 리턴한다.
   * 결과 값이 없을 경우 ""을 리턴한다.
   * @type String
   */
  this.compositeIdx = function(psXPath) {
  	var voIdxs = this.filter.retrieveIndex(psXPath);
  	return voIdxs.join(",");
  };
  /**
   * 찾고자 하는 Column:Value 쌍을 복수로 입력하여 값에 해당하는 RowID를 "," 구분하여 리턴한다.
   * 인자 값은 컬럼명과 그 컬럼에서 찾을 Value를 ":"로 구분하여 넣어주고 복수개일 경우 Column:Value쌍을 ","로 구분하여
   * 다수개의 조건을 넣어 줄 수 있다.
   * @param {String} psKeyArray 찾고자 하는 DataSet의 Column명
   * @return ","로 구분되어진 문자열
   * @type String
   */
  this.find = function(psKeyArray) {
  	if(psKeyArray == null || "" == psKeyArray || psKeyArray.indexOf(":") < 0) {
  		return null;
  	}
  	
  	var voKeys = psKeyArray.split(",");
  	var vnKeyLen = voKeys.length;
  	
  	var vnRowLen = this.viewData.getRowCnt();
  	var vbMatch;
  	var vnOrgIdx, voRow;
  	var i, j;
  	var voKeyAttr;
  	var vsColName, vsValue, vnColIdx, voNode;
  	var voResult = [];
  	
  	for(i = 0 ; i < vnRowLen ; i++) {
  		vbMatch = true;
  		vnOrgIdx = this.viewData.getOriginalIndex(i);
  		row = this.originData.getRowElement(vnOrgIdx);
  		
  		for(j = 0 ; j < vnKeyLen ; j++) {
  			voKeyAttr = voKeys[j].split(":");
  			vsColName = voKeyAttr[0];
  			vsValue = voKeyAttr[1];
  			
  			voNode = row.getElementByTagNameFromChildNodes(vsColName);
  			
  			if(vsValue != voNode.getNodeValue()) {
  				vbMatch = false;
  				break;
  			}
  		}
  		if(vbMatch) {
  			voResult[voResult.length] = i + 1;
  		}
  	}
  	return voResult.join(",");
  };
  /**
   * 주어진 index의 row를 delete 한다.
   * @param {Number} pnIndex 삭제 대상 row의 index
   * @return index가 범위를 넘으면 -1 리턴
   * @type Number
   */
  this.deleteRow = function(pnIdx) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	
  	if(this.viewData.rangeCheck(pnIdx) == false) {
  		return -1;
  	}
  	
  	var vnOrgIdx = this.viewData.getOriginalIndex(pnIdx);
  	if(vnOrgIdx == null) return -1;
  	
		this.viewData.deleteRow(pnIdx);
		var vnStatus = this.originData.getStatus(vnOrgIdx);
		
		if(this.srcSync) {
			if(vnStatus != this.ETBADDEDFLAG) {
				this.delData.addRow(vnOrgIdx);
			}
			if(vnStatus == this.ETBUNCHANGEDFLAG) {
				this.originData.setStatus(vnOrgIdx, this.REAL_DELETE_FLAG);
				this.originData.setStatus(vnOrgIdx, this.ETBDELETEDFLAG);
			} else if(vnStatus == this.ETBADDEDFLAG) {
				this.originData.setStatus(vnOrgIdx, this.REAL_DELETE_FLAG);
			} else {
				this.originData.setStatus(vnOrgIdx, this.ETBDELETEDFLAG);
			}
		} else {
			if(vnStatus == this.ETBADDEDFLAG) {
				this.originData.setStatus(vnOrgIdx, this.REAL_DELETE_FLAG);
			} else {
				this.originData.setStatus(vnOrgIdx, this.ETBDELETEDFLAG);
			}
		}
		return 0;
  };
  /**
   * 주어진 row의 fieldname을 통한 value 질의
   * @param {Number} pnIndex row index
   * @param {String} psFieldName field name
   * @return 조회 결과 리턴
   * @type String
   */
  this.get = function(pnIdx, psName) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	var vnHeaderIdx = this.header.getHeaderIndex(psName);
  	var vnOrgIdx = this.viewData.getOriginalIndex(pnIdx);
  	return (vnOrgIdx == null) ? "" : this.originData.getValue(vnOrgIdx, vnHeaderIdx);
  };
  /**
   * 컬럼의 수를 리턴
   * @return 컬럼의 수
   * @type Number
   */
  this.getColCnt = function() {
  	return this.header.getHeaderCnt();
  };
  /**
   * 주어진 컬럼 인덱스에 해당하는 컬럼 명을 반환하는 메소드
   * @return 주어진 컬럼 인덱스에 해당하는 컬럼 명
   * @param {Number} pnIndex 컬럼 인덱스
   * @type String
   */
  this.getColName = function(pnIdx) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	return this.header.getHeaderColumn(pnIdx);
  };
  /**
   * DataSet의 CRUD Node의 속성을 리턴한다.
   * @param {String} psAttrName 해당 속성 명
   * @return 해당 속성명에 속성값을 리턴한다.
   * @type String
   */
  this.getCRUDAttr = function(psAttrName) {
  	return this.autoCUD.getAttr(psAttrName);
  };
  /**
   * index 값을 얻는다
   * @return index값 리턴
   * @type Number
   */
  this.getIndex = function() {
  	return this.viewData.getIndex();
  };
  /**
   * Row에 설정한 특정 속성을 가져온다.
   * @param {Number} pnIndex 조회할 Row 번호
   * @param {String} psAttrName 질의 할 속성 명
   * @return 속성 값
   * @type String
   */
  this.getRowAttr = function(pnIdx, pnAttrNm) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	pnIdx = this.viewData.getOriginalIndex(pnIdx);
  	return this.originData.getRowAttr(pnIdx, pnAttrNm);
  };
  /**
   * Row 갯수를 얻는다
   * @return Row Count 값
   * @type Number
   */
  this.getRowCnt = function() {
  	return this.viewData.getRowCnt();
  };
  /**
   * DataSet에 설정한 Sort 정보를 Node Path 별로 질의하여 결과를 리턴한다.
   * @param {String} psRef 컬럼 Node Path
   * @return 질의한 소트 정보
   * @type String
   */
  this.getSortItem = function(psRef) {
  	return this.sorter.get(psRef);
  };
  /**
   * DataSet에 설정한 Sort Item의 Column 정보를 리턴한다.<br/>
   * 여러개의 Column 정보가 있을 경우 "," 딜리미터를 이용하여 분리하여 리턴
   * @return Sort Item에 존재하는 Column 명
   * @type String
   */
  this.getSortItemColumNames = function() {
  	var voNames = this.sorter.getColumnNames();
  	return voNames.join(",");
  };
  /**
   * crud type을 얻는다
   * @param {Number} pnIndex 조회대상 index
   * @return CrudType Number
   * @type Number
   */
  this.getStatus = function(pnIdx) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	return this.viewData.getStatus(pnIdx);
  };
  /**
   * 모든 Row 상태 중 입력한 상태를 가지고 있는 Row에 index 값을 구분자로 연결하여 리턴한다.
   *  ex) var voDataset = page.getDataSet("dataset1");
   *      voDataset.getStatusIndex(eXria.data.CrudType.ADDEDFLAG, ";");
   * @param {Number} pnType 조회대상 CRUDTYPE (eXria.data.CrudType)
   * @param {String} psDelimeter 연결할 구분자, 생략할 경우 ',' 기본 설정
   * @return 입력 상태를 가진 Row의 index값
   * @type String
   */
  this.getStatusIndex = function(pnType, psDelimeter) {
  	psDelimeter = psDelimeter == null ? "," : psDelimeter;

		var size = this.viewData.getRowCnt();
		var viewDataIdx;
		var status;
		
		var result = "";
		
		for(var i = 0 ; i < size ; i++) {
			status = this.viewData.getStatus(i);
			if(pnType == status) {
				viewDataIdx = i + 1;
				if(i == size - 1) {
         result = result + viewDataIdx; 
        } else {
         result = result + viewDataIdx + psDelimeter; 
        }
			}
		}
		return result;
  };
  /**
   * 주어진 index에 새로운 row를 insert 한다
   * @param {Number} pnIndex Insert 대상 Index
   * @param {Boolean} pbAfter pnIndex 뒤에 추가 유무
   * @return insert 후 row 갯수
   * @type Number
   */
  this.insertRow = function(pnIdx, pbAfter) {
  	var vnViewIdx = this.toArrayIndex(pnIdx);
		
		var vnOrgIdx = 0;
		
		if(this.viewData.getRowCnt() <= 0) {
			vnOrgIdx = this.originData.addRow();
			this.viewData.addRow(vnViewIdx, vnOrgIdx, this.ETBEMPTYEDFLAG);
		} else {
			if(pbAfter) {
				vnViewIdx++;
			}
	
			vnOrgIdx = this.originData.addRow();
			this.viewData.addRow(vnViewIdx, vnOrgIdx, this.ETBEMPTYEDFLAG);
			
			var voRow = this.originData.getRowElement(vnOrgIdx);
			var voTarget = this.originData.getRowElement(this.viewData.getOriginalIndex(vnViewIdx));
			
//			if(pbAfter) {
//				if(voTarget != null) {
//					voRow.getParentNode().insertBefore(voRow, voTarget);
//				}
//			} else {
//				voRow.getParentNode().insertBefore(voRow, voTarget);
//			}
		}
		
		var vnAfterRowCnt = this.viewData.getRowCnt();
		return vnAfterRowCnt;
  };
  
  this.getOriginDataList = function() {
  	return this.originData;
  }
  
  this.clear = function() {
		this.originData.clear();
		this.viewData.clear();
		this.delData.clear();
		this.sorter.clear();
		this.filter.clear();
  };
  /**
   * DataSet을 Rebuild 한다.
   * @param {Boolean} pbAdd Add 유무 설정
   * @return Row Count
   * @type Number
   */
  this.rebuild = function(pbAdd) {
  	if (!pbAdd) {
			this.clear();
		}

		var childNode;
		var rowElement;
		var tagName;
		var addedCnt = 0;
		
		var voInst = this.model.getInstance(this.conInfo);
		var rowNodes = (voInst) ? voInst.selectNodes(this.srcQuery) : null;
		if(rowNodes == null) return 0;
		var nodeSize = rowNodes.getLength();
		var vnIdx;
		var voColNodes, voColNode;
		var len, j;
		var voAttr, vnAttrSize, voAttrNode, vsAttrName;
		
		for (var i = 0; i < nodeSize; i++) {
			childNode = rowNodes.item(i);
			if(childNode.getNodeType() != 1) continue;
			
			var row = [];
			row[this.ROW_STATUS] = this.ETBUNCHANGEDFLAG;
			row[this.HIDE_ROW_STATUS] = this.ETBUNCHANGEDFLAG;
			row[this.ROW_NODE] = childNode;
			
//			row[this.ROW_ATTR] = {};
//			
//			voAttr = childNode.getAttributes();
//			vnAttrSize = voAttr.getLength();
//			for(j = 0 ; j < vnAttrSize ; j++) {
//				voAttrNode = voAttr.item(j);
//				if(voAttrNode != null) {
//					vsAttrName = voAttrNode.getNodeName();
//					if(vsAttrName != null) {
//						row[this.ROW_ATTR][vsAttrName] = voAttrNode.getNodeValue();
//					}
//				}
//			}
			
			childNode.setAttribute(this.DATA_ROW_ATTR_NAME, i);
			
			this.addRow(row);
			addedCnt++;
		}
    
    //parentNode sync 맞추기 위한 코드
    var voInst = this.dataSet.model.getInstance(this.dataSet.getConnectionInfo());
    var vsPath = this.dataSet.getSourceQuery().substr(0, this.dataSet.getSourceQuery().lastIndexOf("/"));
    this.originData.parentNode = (voInst) ? voInst.selectSingleNode(vsPath) : null;
    
		return addedCnt;
  };
  
  this.addRow = function(row) {
		var originIdx = this.originData.addRow(row);
		this.viewData.addRow(null, originIdx, this.ETBUNCHANGEDFLAG);
	};
	
  /**
   * primary key 정보를 삭제한다.
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName 삭제할 primary key 값
   * @return void
   * @type void
   */
  this.removePrimaryKey = function(psTableName, psColName, psPkName) {
		var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			voTable.removePrimaryKey(psPkName);
		} else {
			throw new Error("AutoCUD Table not register : " + psTableName);
		}
	};
  /**
   * column 정보를 remove 한다
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName remove 할 값
   * @return void
   * @type void
   */
  this.removeUpdateColumn = function(psTableName, psColName, psDbName) {
		var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			voTable.removeUpdateColumn(psDbName);
		} else {
			throw new Error("AutoCUD Table not register : " + psTableName);
		}
	};
  /**
   * instance를 reset 한다
   * @param {Boolean} pbResetInstance 연결된 Instance와 동기화 여부를 결정한다. false시에 동기화 된다.
   * @return void
   * @type void
   */
  this.reset = function(pbResetInstance) {
		if(pbResetInstance) {
			//true일때 instance까지 지운다
			this.originData.clearInstance();
		}
		
		//false일때 dataSet만 지운다
		this.originData.clear();
		this.viewData.clear();
		this.delData.clear();
		this.sorter.clear();
		this.filter.clear();
  };
  /**
   * 원본값으로 restore 한다
   * @param {Boolean} pbAll all 유무
   * @return void
   * @type void
   */
  this.restoreOriginVal = function(pbAll) {
  	if(pbAll) {
			var vnViewRowCnt = this.viewData.getRowCnt();
			var vnHeaderCnt = this.header.getHeaderCnt();
			var vnOrgIdx;
			var voRow;
			var voCol;
			var vnStatus;
			var vsOrg, vsCurrent;
			
			for(var i = 0 ; i < vnViewRowCnt ; i++) {
				vnOrgIdx = this.viewData.getOriginalIndex(i);
				vnStatus = this.originData.getHideStatus(vnOrgIdx);
				
				if(vnStatus == this.ETBUNCHANGEDFLAG) continue;
				
				for(var j = 0; j < vnHeaderCnt ; j++) {
					this.originData.setValueOnly(vnOrgIdx, j, this.originData.getOriginalValue(vnOrgIdx, j));
				}
			}
		} else {
			var vnOrgIdx = this.viewData.getIndex();
			var voCol;
			
			var vnHeaderCnt = this.getColCnt();
			for(var i = 0; i < vnHeaderCnt; i++) {
				this.originData.setValueOnly(vnOrgIdx, i, this.originData.getOriginalValue(vnOrgIdx, i));
			}
		}
  };
  /**
   * 주어진 row의 fieldname에 value를 설정한다
   * @param {Number} pnIndex row index
   * @param {String} psFieldName field name
   * @param {String} psValue 설정할 값
   * @return 성공 : 1, 실패 : 0
   * @type Number
   */
  this.set = function(pnIdx, psFieldName, psValue) {
  	psValue = psValue == null ? "" : psValue.toString();

  	pnIdx = this.toArrayIndex(pnIdx);
		
		//range check
		if(this.viewData.rangeCheck(pnIdx) == false) {
			return 0;
		}
		
		var vnOrgIdx = this.viewData.getOriginalIndex(pnIdx);
		var vnColIdx = this.header.getHeaderIndex(psFieldName);
		
		if(vnColIdx == -1) {
			return 0;
		} else {
			this.originData.setValue(vnOrgIdx, vnColIdx, psValue);
			var vnStatus = this.originData.getStatus(vnOrgIdx);
			this.viewData.setStatus(pnIdx, vnStatus);
			
			return 1;
		}
  };
  /**
   * Data 동기화 설정을 한다
   * @param {Boolean} pbSync 동기화 여부 설정
   * @return void
   * @type void
   */
  this.setDataSync = function(pbSync) {
  	this.srcSync = pbSync;
  };
  /**
   * index를 설정한다
   * @param {Number} pnIndex 설정할 index 값
   * @return void
   * @type void
   */
  this.setIndex = function(pnIdx) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	this.viewData.setIndex(pnIdx);
  };
  /**
   * table에 prefix를 설정한다
   * @param {String} psTableName 설정 대상
   * @param {String} psPrefix 설정할 값
   * @return void
   * @type void
   */
  this.setPrefix = function(psTableName, psPrefix) {
		var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			voTable.setPrefix(psPrefix);
		} else {
			throw new Error("AutoCUD Table not register : " + psTableName);
		}
	};
  
  this.getOriginalDataIndex = function(pnIdx) {
  	pnIdx = this.toArrayIndex(pnIdx);
  	
		//range check
		if(this.viewData.rangeCheck(pnIdx) == false) {
			return -1;
		}
		
		var vnOrgIdx = this.viewData.getOriginalIndex(pnIdx);
		return vnOrgIdx;
  };
  /**
   * 해당 Row에 속성을 설정한다
   * @param {Number} pnIndex Row Number
   * @param {String} psAttrName 속성 명
   * @param {String} psAttrVal 속성 값
   * @return void
   * @type void
   */
  this.setRowAttr = function(pnIdx, psAttrName, psAttrVal) {
  	if(psAttrVal == null) psAttrVal = "";
		
		var vsOrgIdx = this.getOriginalDataIndex(pnIdx);
		
		if(vsOrgIdx == -1) {
			return;
		}
		
		var voRow = this.originData.setRowAttr(vsOrgIdx, psAttrName, psAttrVal);
  };
  /**
   * sort item을 설정한다
   * @param {String} psNodeName 대상 Node 설정
   * @param {Number} pnType 1 : text, 0 : not text
   * @param {Boolean} pbAscending true : 오름차순, false : 내림차순
   * @return void
   * @type void
   */
  this.setSortItem = function(psNodeName, pnType, pbAsc) {
  	this.sorter.addSortItem(psNodeName, pnType, pbAsc);
  };
  /**
   * 원하는 index에 CRUD type을 설정한다
   *  ex) var voDataset = page.getDataSet("dataset1");
   *      voDataset.setStatus(1, eXria.data.CrudType.MODIFIEDFLAG);
   * @param {Number} pnIndex 설정할 index
   * @param {Number} pnType crud type (eXria.data.CrudType)
   * @return void
   * @type void
   */
  this.setStatus = function(pnIdx, pnType) {
		var vnViewIdx = this.toArrayIndex(pnIdx);
		
		if(this.viewData.rangeCheck(vnViewIdx) == false) {
			return;
		}
		
		this.viewData.setStatus(vnViewIdx, pnType);

		//original
		var vnOrgIdx = this.viewData.getOriginalIndex(vnViewIdx);
		this.originData.setStatus(vnOrgIdx, pnType);
  };
  /**
   * CRUD type을 설정한다
   *  ex) var voDataset = page.getDataSet("dataset1");
   *      voDataset.setStatusAll(eXria.data.CrudType.MODIFIEDFLAG);
   * @param {Number} pnType crud type (eXria.data.CrudType)
   * @return void
   * @type void
   */
  this.setStatusAll = function(pnType) {
  	var vnLen = this.viewData.getRowCnt();
		var vnOrgIdx;
		var row;
		for(var i = 0; i < vnLen; i++) {
			this.viewData.setStatus(i, pnType);

			vnOrgIdx = this.viewData.getOriginalIndex(i);
			this.originData.setStatus(vnOrgIdx, pnType);
		}
  };
  /**
   * 범위로 입력한 Row에 CRUD Type으로 설정한다.
   *  ex) page.getDataSet("dataset1").setStatusRange(1, 2, eXria.data.CrudType.ADDEDFLAG);
   * @param {Number} pnStart 시작 Row 번호
   * @param {Number} pnEnd 종료 Row 번호
   * @param {Number} pnType CRUDTYPE (eXria.data.CrudType)
   * @return void
   * @type void
   */
  this.setStatusRange = function(pnStart, pnEnd, pnType) {
  	var vnSt = this.toArrayIndex(pnStart);
		var vnEn = this.toArrayIndex(pnEnd);

		var vnOrgIdx;
		var row;
		for(var i = vnSt; i <= vnEn; i++) {
			this.viewData.setStatus(i, pnType);

			vnOrgIdx = this.viewData.getOriginalIndex(i);
			this.originData.setStatus(vnOrgIdx, pnType);
		}
  };
  /**
   * set은 값을 변경 하면서 동시에 그 Row에 상태값을 수정된 상태로 변경 하지만
   * 이 메서드는 status를 변경하지 않고 단지 value만을 변경 한다.
   * @param {Number} pnIndex row index
   * @param {String} psFieldName Field Name
   * @param {String} psValue 설정할 값
   * @return 성공하면 1, 실패하면 0
   * @type Number
   */
  this.simpleSet = function(pnIdx, psName, psValue) {
  	pnIdx = this.toArrayIndex(pnIdx);

		if(this.viewData.rangeCheck(pnIdx) == false) {
			return 0;
		}
		
		psValue = psValue == null ? "" : psValue.toString();
    
		
		var vnOrgIdx = this.viewData.getOriginalIndex(pnIdx);

		var vnColIdx = this.header.getHeaderIndex(psName);
		if(vnColIdx == -1) {
			return 0;
		} else {
			this.originData.setValueOnly(vnOrgIdx, vnColIdx, psValue);
			return 1;
		}
  };
  /**
   * sort를 수행한다
   * @return void
   * @type void
   */
  this.sort = function() {
  	this.sorter.doSort();
  };
  /**
   * 현재 DataSet에 설정 되어 있는 PrimaryKey들을 "," 구분자로 하여 문자열로 리턴한다.
   * @param {String} psTableName AUTOCRUD request 테이블 명. ""일 경우 모든 테이블의 primary key를 반환
   * @type String
   * @return Primary Key 값들
   */
  this.getPrimaryKeys = function(psTableName) {
		var result = "";
		var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			var pks = voTable.getPrimaryKeys();
			var pk;
			for(var m in pks) {
				result = result + pks[m] + ":" + m + ",";
			}

			if(result.length > 0) {
				result = result.substr(0, result.length - 1);
			}
		} else {
//			throw new Error("AutoCUD Table not register : " + psTableName);
		}
		
		return result;
  };
  /**
   * 현재 DataSet에 설정 되어 있는 update column들을 "," 구분자로 하여 문자열로 리턴한다.
   * @param {String} psTableName AUTOCRUD request 테이블 명.
   * @type String
   * @return 현재 DataSet에서 입력한 table에 설정 되어 있는 UpdateColumn들을 "," 구분자로 하여 문자열로 리턴한다.
   */
  this.getUpdateCols = function(psTableName) {
		var result = "";
		var voTable = this.autoCUD.getTableInfo(psTableName);
		if(voTable != null) {
			var upCols = voTable.getUpdateCols();
			var pk;
			for(var m in upCols) {
				result = result + upCols[m] + ":" + m + ",";
			}

			if(result.length > 0) {
				result = result.substr(0, result.length - 1);
			}
		} else {
			throw new Error("AutoCUD Table not register : " + psTableName);
		}
		
		return result;
	};
  /**
   * 현재 DataSet에 등록된 AUTOCRUD request 테이블명들을 "," 구분자로 하여 문자열로 리턴한다.
   * @type String
   * @return  DataSet에 등록 되어져 있는 AutoCRUD처리 테이블들의 이름을 리턴한다. 복수개일 경우 "," 구분자로 구분하여 리턴한다.
   */
  this.getCRUDTableNames = function() {
  	var voTableNames = this.autoCUD.getTableNames();
  	return voTableNames.join(",");
  };
  /**
   * DataSet에서 삭제된 로우의 전체 count를 리턴한다.
   * @type Number
   * @return delete된 row의 전체 수.
   */
  this.getDelTableRowCnt = function() {
  	return this.delData.getRowCnt();
  };
  /**
   * DataSet에서 삭제된 로우 중 해당 인덱스와 컬럼명의 값을 리턴한다.
   * @param {Number} pnIdx Row Index
   * @param {String} psFieldName 컬럼 명
   * @return index 조건으로 검색된 삭제 row의 해당 컬럼의 값.
   * @type String
   */
  this.getDelTableValue = function(pnIdx, psFieldName) {
  	var pnIdx = this.toArrayIndex(pnIdx);
		var vnColIdx = this.header.getHeaderIndex(psFieldName);

		var vnOrgIdx = this.delData.getOriginalIndex(pnIdx);
		var vsValue = this.originData.getValue(vnOrgIdx, vnColIdx);
		
		return vsValue;
  };
  /**
   * 현재 DataSet에 등록된 AUTOCRUD request 테이블을 등록하는 메소드.
   * @param {String} psTableName AUTOCRUD request 테이블 명
   * @return void
   * @type void
   */
  this.addCRUDTable = function(psName) {
		this.autoCUD.createTableInfo(psName);
	};
  /**
   * DataSet에 CRUD 테이블에서 해당 테이블 명을 가지고 있는 테이블을 삭제한다.
   * @param {String} psTableName 삭제할 테이블 명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.removeCRUDTable = function(psTableName) {
  	this.autoCUD.removeTableInfo(psTableName);
  	return 0;
  };
  /**
   * 현재 DataSet에 등록된 request 테이블의 prefix를 얻어오는 메소드.
   * @param {String} psTableName AUTOCRUD request 테이블 명
   * @return 첫 인자로 입력한 아이디를 가지는 테이블의 Prefix 값을 문자열로 리턴하여 준다.
   * @type String
   */
  this.getPrefix = function(psTableName) {
  	var vsPrefix = null;
		var voTableInfo = this.autoCUD.getTableInfo(psTableName);
		if(voTableInfo != null) {
			vsPrefix = voTableInfo.getPrefix();
		} else {
			throw new Error("AutoCUD Table not register : " + psTableName);
		}
		return vsPrefix;
  };
  /**
   * submission에 추가할 수 있는 CRUD 문자열 정보를 반환해주는 메소드.
   * @param {Boolean} pbGetUnchanged Unchanged Status의 row데이타 정보도 가져올지 여부
   * @type String
   * @return submission에 추가할 수 있는 CRUD 문자열 정보를 반환
   */
  this.getAutoCRUDString = function() {
  	var vsData = this.autoCUD.getAutoCRUDString();
		return vsData;
  };
  /**
   * 해당 Row에서 필드명과 일치하는 곳에 수정 바로 이전 값을 리턴한다.
   * @param {Number} pnIndex row index
   * @param {String} psFieldName field name
   * @type String
   * @return 수정되기 이전 값을 리턴한다. 이 기능을 쓰기 위해서는 Keep the Original Data 속성이 설정 되어 있어야 한다.
   */
  this.getOrigin = function(pnIdx, psName) {
  	pnIdx = this.toArrayIndex(pnIdx);
		
		if(this.viewData.rangeCheck(pnIdx) == false) {
			return null;
		}
		
		var vnOrgIdx = this.viewData.getOriginalIndex(pnIdx);
		var resultVal = null;

		var vnColIdx = this.header.getHeaderIndex(psName);
		if(vnColIdx == -1) {
			resultVal = null;
		} else {
			resultVal = this.originData.getOriginalValue(vnOrgIdx, vnColIdx);
		}
		
		return resultVal;
  };
  /**
   * DataSet과 원본 데이터와의 Sync 상태를 리턴한다.
   * @return Sync 상태시 True 리턴
   * @type Boolean
   */
  this.isDataSync = function() {
  	return this.srcSync;
  };
  /**
   * DataSet의 Keep Original Value 상태 리턴
   * @return Keep 상태시 True 리턴
   * @type Boolean
   */
  this.isKeepOriginalValue = function() {
  	return this.isKeepOrgin;
  };
  /**
   * CRUD에 관계된 데이타셋 속성 값을 설정하기 위한 메소드.
   * - submission에서 데이타셋으로 부터 unchanged status의 row정보를 하져올 때 setCRUDAttr("alltype", "true")를 호출함.
   *   해제시에는 setCRUDAttr("alltype", "false")를 호출함.
   * @param {String} psName 속성명
   * @param {String} psValue 속성값
   * @return void
   * @type void
   */
  this.setCRUDAttr = function(psName, psValue) {
  	if(psValue == null) psValue = "";
		this.autoCUD.setAttr(psName, psValue);
  };
  /**
   * 현재 DataSet을 초기화 시킨다.
   * @type void
   * @return void
   */
  this.refresh = function() {};
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트를 추가한다.
   * @param {Array} paCol 추가할 컬럼 Array
   * @type void
   * @return void
   */
  this.addSkipSCList = null;
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트 중 파라미터로 넘어온 컬럼들을 삭제한다.
   * @param {Array} paCol 삭제할 컬럼 Array
   * @type void
   * @return void
   */
  this.removeSkipSCList = null;
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트를 전부 삭제한다.
   * @type void
   * @return void
   */
  this.clearSkipSCList = null;
  /**
   * DataSet에 새로운 Column을 추가한다.
   * Instance와 Sync 되어 있을 시 Instance node의 구조도 자동으로 변경 되어진다.
   * @param {Number} pnIndex 컬럼을 삽입시킬 위치 값
   * @param {String} psColName 새로 생성 될 컬럼명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.addColumn = function(pnIdx, psColName) {
  	var vnHeaderLen = this.header.getHeaderCnt();
  	pnIdx = (pnIdx == null || pnIdx > vnHeaderLen) ? vnHeaderLen + 1 : pnIdx;
  	pnIdx = this.toArrayIndex(pnIdx);
  	if(psColName == null) -1;
  	return this.originData.addColumn(pnIdx, psColName);
  };
  /**
   * DataSet의 마지막에 새로운 Column을 추가한다.
   * Instance와 Sync 되어 있을 시 Instance node의 구조도 자동으로 변경 되어진다.
   * @param {String} psColName 새로 생성 될 컬럼명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.appendColumn = function(psColName) {
  	if(psColName == null) return -1;
  	return this.addColumn(null, psColName);
  };
  /**
   * DataSet에 해당 컬럼명을 가지고 있는 컬럼을 삭제한다.
   * @param {String} psColName 삭제할 컬럼명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.removeColumn = function(psColName) {
  	if(psColName == null) return -1;
  	var vnIdx = this.header.getHeaderIndex(psColName);
		this.originData.removeColumn(vnIdx);
		return 0;
  };
  /**
   * dataset의 Source Type을 리턴한다.
   * @return dataset의 Source Type
   * @type {Number}
   */
  this.getSrcType = function() {
  	return this.srcType;
  };
  /**
   * dataset의 Connection Info를 리턴한다.
   * @return dataset의 Connection Info
   * @type {String}
   */
  this.getConnectionInfo = function() {
  	return this.conInfo;
  };
  /**
   * dataset의 Source Query를 리턴한다.
   * @return dataset의 Source Query
   * @type {String}
   */
  this.getSourceQuery = function() {
  	return this.srcQuery;
  };
  /**
   * DataSet의 특정 Row에 해당하는 실제 Instance의 Row를 반환한다.
   * @param {Number} pnIdx 실제 리턴 받기를 원하는 DataSet Row Number
   * @return Instance Row 번호
   * @type {Number}
   */
  this.getInstanceRowIndex = function(pnIdx) {
  	var vnOrgIdx = this.getOriginalDataIndex(pnIdx);
  	return vnOrgIdx + 1;
  };
  
  this.toArrayIndex = function(pnIdx) {
  	pnIdx = (pnIdx <= 1 ? 0 : pnIdx - 1);
		return pnIdx;
  };

  this.getRowDataStrContainFrontIndex = function(pnStIdx, pnEndIdx) {
  	var pnStIdx = this.toArrayIndex(pnStIdx);
		var pnEndIdx = this.toArrayIndex(pnEndIdx);
		
		var orgIdx = null;
		var i, j;
		
		var headerNames = this.header.getHeaderColumns();
		var columnLen = headerNames.length;
		var voMainList = [];
		for(i = pnStIdx ; i < pnEndIdx ; i++) {
			orgIdx = this.viewData.getOriginalIndex(i);
			
			var voRow = {};
			voRow["@frontIndex"] = parseInt(this.viewData.getOriginalIndex(i)) + 1;
			for(j = 0 ; j < columnLen ; j++) {
				orgValue = this.originData.getValue(orgIdx, j);
				voRow[headerNames[j]] = orgValue;
			}
			voMainList.push(voRow);
		}
//    var resultData = (voMainList.toJSON) ? voMainList.toJSON() : JSON.stringify(voMainList);
    var resultData = null;
    if(window.JSON) {
      resultData = (voMainList.toJSON) ? voMainList.toJSON() : window.JSON.stringify(voMainList);
    } else {
      resultData = eXria.controls.xhtml.Util.toJSONString(voMainList);
    }
		return resultData; 
  };
  
  this.getRowTagName = function() {
  	return this.rowTagName;
  };
  
  this.getRowDataList = function(pnStart, pnEnd) {
    pnStart = this.toArrayIndex(pnStart);
    pnEnd = this.toArrayIndex(pnEnd);
    
    var voHeaderNames = this.header.getHeaderColumn();
		var vnColLen = voHeaderNames.length;
		
		var vnViewRowCnt = this.viewData.getRowCnt();
		
		if(pnEnd > (vnViewRowCnt - 1)) {
			pnEnd = vnViewRowCnt;
		}

		var vnOrgIdx = 0;
		var vsOrgVal = null;
		
		var voNodeList = [];
		
		var i=0, j=0;
		for(i = pnStart ; i <= pnEnd ; i++) {
			vnOrgIdx = this.viewData.getOriginalIndex(i);
			var voMap = new eXria.data.xhtml.MapNode();
			
			for(j = 0 ; j < vnColLen ; j++) {
				vsOrgVal = this.originData.getValue(vnOrgIdx, j);
				voMap.put(voHeaderNames[j], vsOrgVal);
			}
			voNodeList[i] = voMap;
		}
		return voNodeList;
  };
  
  this.getRowDataStr = function(pnStart, pnEnd) {
  	var pnStIdx = this.toArrayIndex(pnStIdx);
		var pnEndIdx = this.toArrayIndex(pnEndIdx);
		
		var orgIdx = null;
		var i, j;
		
		var headerNames = this.header.getHeaderColumns();
		var columnLen = headerNames.length;
		var voMainList = new Array();
		
		for(i = pnStIdx ; i <= pnEndIdx ; i++) {
			orgIdx = this.viewData.getOriginalIndex(i);
			var voRow = {};
			for(j = 0 ; j < columnLen ; j++) {
				orgValue = this.originData.getValue(orgIdx, j);
				voRow[headerNames[j]] = orgValue;
			}
			voMainList.push(voRow);
		}
		return (voMainList.toJSON) ? voMainList.toJSON() : window.JSON.stringify(voMainList);
  };
  
  /**
   * dataset 모든 row의 특정 속성 값을 배열에 담아 반환해주는 메소드
   * @param {String} psAttrName 검색 요청 속성명
   * @return 모든 row의 특정 속성 값을 담은 배열
   */
  this.getRowsAttr = function(psAttrName) {
  	var vnRowLen = this.viewData.getRowCnt();

		var voAttrData = [];
		var voRow = null;
		var voAttr = null;
		for(var i = 0 ; i < vnRowLen ; i++) {
			voRow = this.originData.getRow(this.viewData.getOriginalIndex(i));
			voAttr = voRow.getAttr(psAttrName);
			if(voAttr != null && voAttr != "") {
				var voAttribute = [];
				voAttribute[0] = i + 1;
				voAttribute[1] = voAttr;
				voAttrData.add(voAttribute);
			}
		}
		return voAttrData;
  };
  /**
   * dataset 모든 row의 특정 속성을 일괄 설정하기 위한 메소드
   * @param {String} psAttrName 값 설정 대상 속성명
   * @param {String} psAttrValue 일괄 설정 속성 값
   */
  this.setRowsAttr = function(psAttrName, psAttrValue) {
  	if(psAttrValue == null) psAttrValue = "";
		
		var vnRowLen = this.viewData.getRowCnt();
		var vnOrgIdx;
		for(var i = 0 ; i < vnRowLen ; i++) {
			vnOrgIdx = this.viewData.getOriginalIndex(i);
			this.originData.setRowAttr(vnOrgIdx, psAttrName, psAttrValue);
		}
  };
  /**
   * dataset originData 수정
   * @param {Number} pnIdx row index
   * @param {Number} pnColIdx column index
   * @param {Number} psVal value
   * @return void
   * @type void
   */
  this.setOrigin = function(pnIdx, pnColIdx, psVal) {
    this.originData.setOriginalData(pnIdx, pnColIdx, psVal);
  };
  
  this.init();
};