eXria.data.xhtml.Header = function(poDataSet) {
  //header names
  this.header = [];
};

eXria.data.xhtml.Header.prototype = {
  /**
   * add header name
   * @param {Number} pnIdx insert index
   * @param {String} psHeader header name
   * @return insert index
   * @type Number
   */
  addHeaderColumn : function(pnIdx, psHeader) {
    if (pnIdx == null) {
      pnIdx = this.header.length;
    }
    this.header.splice(pnIdx, 0, psHeader)

    return pnIdx;
  },
  /**
   * remove column
   * @param {Number} pnIdx remove index
   * @return void
   * @type void
   */
  removeColumn : function(pnIdx) {
    this.header.splice(pnIdx, 1);
  },
  /**
   * clear header names
   * @return void
   * @type void
   */
  clear : function() {
    this.header = null;
    this.header = [];
  },
  /**
   * exist header
   * @param {String} psHeader header name
   * @return is exist header name
   * @type Boolean
   */
  contains : function(psHeader) {
    var i, len = this.header.length;
    for (i = 0; i < len; i++) {
      if (this.header[i] == psHeader) {
        return true;
      }
    }
    return false;
  },
  /**
   * return parameter index header name
   * @param {Number} pnIdx header index
   * @return header name
   * @type String
   */
  getHeaderColumn : function(pnIdx) {
    return this.header[pnIdx];
  },
  /**
   * return parameter header name index
   * @param {String} psHeader header name
   * @return header index
   * @type Number
   */
  getHeaderIndex : function(psHeader) {
    var len = this.getHeaderCnt(), cnt = -1;

    while (++cnt < len) {
      if (this.header[cnt] == psHeader) {
        return cnt;
      }
    }
    return -1;
  },
  /**
   * return header count
   * @return header count
   * @type Number
   */
  getHeaderCnt : function() {
    return this.header.length;
  },
  /**
   * return header name list
   * @return header name list
   * @type Array
   */
  getHeaderColumns : function() {
    return this.header;
  }
};