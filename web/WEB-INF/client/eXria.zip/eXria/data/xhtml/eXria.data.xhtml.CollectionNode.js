/**
 * @fileoverview
 * XHTML Mode 사용시 Document Node를 Collection으로 wrapping 해주는 클래스
 */
/**
 * XHTML Mode 사용시 Document Node를 Collection으로 wrapping 해주는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.xhtml.Node
 */
eXria.data.xhtml.CollectionNode = function(poNode) {
  if(page.metadata.useJsonInstance) {
    eXria.data.json.CollectionNode.call(this, poNode);
    return;
  }
  /**
   * inherit
   */
//  if(page.metadata.modelType == eXria.form.ModelType.PLUGIN) {
//    eXria.data.plugin.Node.call(this, poNode.node);
//  } else {
//  eXria.data.xhtml.Node.call(this, poNode.node);
//  }
  this.node = poNode;
  /**
   * 노드의 리스트 저장 속성
   * @private
   */
  this.nodeList = null;
  /**
   * Collection에 파라미터로 넘어온 Node를 추가한다.
   * @param {XMLNode} poNode 추가할 Node
   * @return void
   * @type void
   */
  this.add = function(poNode) {
    try {
      this.node.appendChild(poNode);
      this.nodeList[this.cnt] = poNode;
      this.cnt++;
    } catch(err) {
      throw err;
    }
  };
  /**
   * 현재 Collection의 Item 갯수를 리턴한다.
   * @return 하위 ElementNode의 갯수
   * @type Number
   */
  this.size = function() {
    return this.cnt;
  };
  /**
   * Parameter로 넘어온 Index에 해당하는 위치의 Node를 리턴한다.
   * @param {Number} pnIndex 리턴받은 Node의 Index
   * @return 해당 Index의 Node. Index가 Node의 범위 밖인 경우 null을 리턴한다.
   * @type  XMLNode
   */
  this.get = function(pnIndex) {
    var voNodeList = this.nodeList;
    return voNodeList[pnIndex];
  };
  /**
   * 주어진 값이 현재 Node 구성 요소의 인덱스 번호로서 적합한 지 여부를 검사하는 메소드
   * Collection의 Range안에 없을 경우 Error Throw.
   * @param {Number} pnIndex 체크할 Index
   * @return void
   * @type void
   * @private
   */
  this.rangeCheck = function(pnIndex) {
    if (pnIndex < 0 || pnIndex > this.cnt) {
      throw new Error("Index out of range : " + pnIndex);
    }
  };
  /**
   * Collection에서 Parameter로 넘어온 Index에 해당되는 위치에 두번째 Parameter로 넘어온 Node를 추가한다. 만약 해당 Index에 기존 Node가 존재할 경우 기존 Node는 삭제 된다.
   * @param {Number} pnIndex 추가할 위치 Index
   * @param {XMLNode} poNode 추가할 Node
   * @return 넘겨받은 Index에 Node가 존재할 경우 기존 Node를 대체하고 기존 Node를 리턴한다.
   * @type XMLNode
   */
  this.set = function(pnIndex, poNode) {
    var vnSize = this.cnt;
    if (vnSize < pnIndex) {
      throw new Error("Index out of range : " + pnIndex);
    } else if (vnSize == pnIndex) {
      this.add(poNode);
      return null;
    } else {
      var voOldNode = null;
//      voOldNode = this.node.replaceChild(poNode, this.get(pnIndex));
    voOldNode = this.node.replaceChild(poNode, this.get(pnIndex));
      if(voOldNode) this.nodeList[pnIndex] = poNode;
      return poNode;
    }
  };
  /**
   * 넘겨 받은 Index에 Node를 추가 한다. 해당 Index에 기존에 Node가 존재 할 경우 해당 Node 및 이후 Index의 Node들의 Index가 하나씩 밀린다.
   * @param {Number} pnIndex 추가할 위치 Index
   * @param {XMLNode} poNode 추가할 Node
   * @return 넘겨받은 Index에 Node가 존재할 경우 기존 Node를 대체하고 기존 Node를 리턴한다.
   * @type XMLNode
   */
  this.insert = function(pnIndex, poNode) {
    var vnSize = this.cnt;
    if(vnSize < pnIndex - 1) { // over
      throw new Error("Index out of range : " + pnIndex);
    } else if(vnSize == pnIndex - 1) { // last
      this.add(poNode);
      return null;
    } else {
//      poNode = this.node.insertBefore(poNode, this.get(pnIndex));
    poNode = this.node.insertBefore(poNode, this.get(pnIndex));
      this.nodeList.splice(pnIndex, 0, poNode);
      this.cnt++;
      return poNode;
    }
  };
  /**
   * Parameter로 넘어온 Index에 해당하는 Node를 삭제한다.
   * @param {Number} pnIndex 삭제할 Node Index
   * @return 삭제된 Node 참조값
   * @type XMLNode
   */
  this.remove = function(pnIndex) {
//    var voNode = this.node.removeChild(this.get(pnIndex));
  var voNode = this.node.removeChild(this.get(pnIndex));
    if(voNode) {
      this.nodeList.splice(pnIndex, 1);
      this.cnt--;
    }
    return voNode;
  };
  /**
   * Collection의 모든 Node를 삭제 하고 Collection을 초기화 한다.
   * @return void
   * @type void
   */
  this.clear = function() {
//    var voNode = this.node;
//    var voNodes = voNode.childNodes;
  var voNodes = this.node.getChildNodes();
//    var vnLength = voNodes.length;
  var vnLength = voNodes.getLength();
    var voItem = null;
    for (var i = 0; i < vnLength; i++) {
      voItem = voNodes.item(0);
      this.node.removeChild(voItem);
    }
    this.nodeList = [];
    this.cnt = 0;
  };
  /**
   * 현재 Collection이 비어 있는지 체크하여 리턴한다.
   * @return 비어있는 노드일 경우 TRUE, 아닐 경우 FALSE
   * @type Boolean
   */
  this.isEmpty = function() {
    return (this.size() == 0);
  };
  /**
   * 현재 Collection의 모든 Node를 Iterator로 변환하여 리턴한다.
   * @return 내부객체를 조회하는 Iterator
   * @type eXria.data.ArrayIterator
   * @see eXria.data.ArrayIterator
   */
  this.iterator = function() {
  this.elements = this.nodeList;
    return new eXria.data.ArrayIterator(this);
  };
  /**
   * 현재 메소드 이름을 리턴한다.
   * @return 내부요소를 파싱한 String 값
   * @type String
   */
  this.toString = function() {
    return "CollectionNode";
  };
  /**
   * 반복되는 하위 노드의 tagName 저장 속성
   * @return void
   * @type void
   * @private
   */
  this.reset = function() {
    var vnSize = 0;
    var vaNodeList = [];
    var voNodes = this.node.getChildNodes();
    if(voNodes == null) {
      this.nodeList = [];
      this.cnt = vnSize;
      return ;
    }
    var vnLength = voNodes.getLength();
    var voItem = null;
    for(var i = 0; i < vnLength; i++) {
      voItem = voNodes.item(i);
      if (voItem.getNodeType() == 1) { // Element
        vaNodeList.push(voItem);
      }
    }
    vnSize = vaNodeList.length;
    this.nodeList = vaNodeList;
    this.cnt = vnSize;
  };
  /**
   * 생성시 reset 메소드 호출
   * @private
   */
  this.reset();
};
