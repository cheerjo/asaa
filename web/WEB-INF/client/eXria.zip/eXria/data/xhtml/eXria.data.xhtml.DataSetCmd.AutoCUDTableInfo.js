eXria.data.xhtml.AutoCUDTableInfo = function() {
  //table id
  this.id = null;
  //update col names
  this.updateCols = {};
  //pk names
  this.pks = {};
  //prefix
  this.prefix = null;
  //user str
  this.usrStr = "";
};

eXria.data.xhtml.AutoCUDTableInfo.prototype = {
  /**
   * set id
   * @param {String} id id
   * @return void
   * @type void
   */
  setId : function(id) {
    this.id = id;
  },
  /**
   * get id
   * @return id
   * @type String
   */
  getId : function() {
    return this.id;
  },
  /**
   * add update column
   * @param {String} dbId db id
   * @param {String} id id
   * @return void
   * @type void
   */
  addUpdateColumn : function(dbId, id) {
    this.updateCols[dbId] = id;
  },
  /**
   * remove update column
   * @param {String} dbId db id
   * @return void
   * @type void
   */
  removeUpdateColumn : function(dbId) {
    delete this.updateCols[dbId];
  },
  /**
   * clear update column
   * @return void
   * @type void
   */
  clearUpdateCololumn : function() {
    this.updateCols = null;
    this.updateCols = {};
  },
  /**
   * get update column names
   * @return update column names
   * @type Object
   */
  getUpdateCols : function() {
    return this.updateCols;
  },
  /**
   * add primary key
   * @param {String} dbId db id
   * @param {String} id id
   * @return void
   * @type void
   */
  addPrimaryKey : function(dbId, id) {
    this.pks[dbId] = id;
  },
  /**
   * get primary key
   * @param {String} pk primary key
   * @return primary key
   * @type String
   */
  getPrimaryKey : function(pk) {
    return this.pks[pk];
  },
  /**
   * get primary key object
   * @return pk id
   * @type String
   */
  getPrimaryKeys : function() {
    return this.pks;
  },
  /**
   * remove primay key
   * @param {String} dbId db id
   * @return void
   * @type void
   */
  removePrimaryKey : function(dbId) {
    delete this.pks[dbId];
  },
  /**
   * clear primary key
   * @return void
   * @type void
   */
  clearPrimaryKey : function() {
    this.pks = null;
    this.pks = {};
  },
  /**
   * set prefix
   * @param {String} p prefix name
   * @return void
   * @type void
   */
  setPrefix : function(p) {
    this.prefix = p;
  },
  /**
   * get prefix
   * @return prefix name
   * @type String
   */
  getPrefix : function() {
    return this.prefix;
  },
  /**
   * set user string
   * @param {String} s user string
   * @return void
   * @type void
   */
  setUsrStr : function(s) {
    if (!s)
      s = "";
    this.usrStr = s;
  },
  /**
   * get user string
   * @return user string
   * @type String
   */
  getUsrStr : function() {
    return this.usrStr;
  },
  /**
   * reset user string
   * @return void
   * @type void
   */
  resetUsrStr : function() {
    this.usrStr = "";
  },
  /**
   * return parameter name is update target
   * @param {String} s column name
   * @return is update target
   * @type Boolean
   */
  isUpdateSource : function(s) {
    var voUpdateCols = this.updateCols;
    for(var vsKey in voUpdateCols) {
      if(voUpdateCols[vsKey] == s) {
        return true;
      }
    }
    return false;
  },
  /**
   * return parameter name is primary key
   * @param {String} psSourceName source name
   * @return is primary key
   * @type Boolean
   */
  isPrimaryKeySource : function(psSourceName) {
    var voPk = this.pks[psSourceName];
    if (voPk == null) {
      return false;
    } else {
      return true;
    }
  },
  /**
   * reset table
   * @return void
   * @type void
   */
  resetTable : function() {
    this.id = null;
    this.pks = null;
    this.pks = {};
    this.updateCols = null;
    this.updateCols = {};
    this.prefix = null;
  }
};