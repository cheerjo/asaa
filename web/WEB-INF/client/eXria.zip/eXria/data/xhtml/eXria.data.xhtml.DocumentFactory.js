/**
 * @fileoverview
 * Document를 Browser Type에 맞도록 생성하여 리턴하는 클래스
 */
/**
 * Document를 Browser Type에 맞도록 생성하여 리턴하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @constructor
 * @private
 */
eXria.data.xhtml.DocumentFactory = {
  /**
   * 사용자 Browser Type에 맞는 XMLDocument를 생성하여 리턴한다.
   * @return eXria.data.Document
   * @private
   */
  createDocument : function(poPage, psId) {
    var voDocument = null;
    if(window.ActiveXObject !== undefined) {
    voDocument = new eXria.data.xhtml.MsieDocument(poPage, psId);
    } else if(window.document.implementation && window.document.implementation.createDocument) {
    voDocument = new eXria.data.xhtml.GeckoDocument(poPage, psId);
    }
    return voDocument;
  }
};
