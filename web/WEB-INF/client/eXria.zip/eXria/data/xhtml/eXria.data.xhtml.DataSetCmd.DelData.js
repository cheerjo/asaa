eXria.data.xhtml.DelData = function(poDataSet) {
  //delete row index list
  this.delData = [];
};

eXria.data.xhtml.DelData.prototype = {
  /**
   * add delete row index
   * @param {Number} pnIdx delete row index
   * @return void
   * @type void
   */
  addRow : function(pnIdx) {
    this.delData[this.delData.length] = pnIdx;
  },
  /**
   * clear
   * @return void
   * @type void
   */
  clear : function() {
    this.delData = null;
    this.delData = [];
  },
  /**
   * return delete row count;
   * @return delete row count
   * @type Number
   */
  getRowCnt : function() {
    return this.delData.length;
  }
};