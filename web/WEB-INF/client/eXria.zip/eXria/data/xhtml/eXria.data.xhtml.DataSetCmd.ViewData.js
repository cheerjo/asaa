eXria.data.xhtml.ViewData = function(poDataSet) {
  this.dataSet = poDataSet;
  // 그리드에 보여질 데이터 리스트 [[orgIdx, status, view idx], [] ...]
  this.viewData = [];
  this.index = 0;
};

eXria.data.xhtml.ViewData.prototype = {
  /**
   * row 추가
   * @param {Number} pnRowIdx row index
   * @param {Number} pnOrgIdx original data index
   * @param {Number} pnStatus status
   * @return void
   * @type void
   */
  addRow : function(pnRowIdx, pnOrgIdx, pnStatus) {
    var row = [ pnOrgIdx, pnStatus, this.viewData.length ];
    if (pnRowIdx != null) {
      this.viewData.splice(pnRowIdx, 0, row);
    } else {
      this.viewData[this.viewData.length] = row;
    }
  },
  /**
   * row 삭제
   * @param {Number} pnIdx row index
   * @return void
   * @type void
   */
  deleteRow : function(pnIdx) {
    this.viewData.splice(pnIdx, 1)
  },
  /**
   * 파라미터로 넘어온 인덱스의 실제 로우 인덱스를 리턴
   * @param {Number} pnIdx row index
   * @return original data row index
   * @type Number
   */
  getOriginalIndex : function(pnIdx) {
    var row = this.viewData[pnIdx];
    if (row == null)
      return null;

    return row[this.dataSet.ORIGINIDX];
  },
  /**
   * original data의 row 인덱스를 셋팅
   * @param {Number} pnIdx row index
   * @param {Number} pnOriIdx original row index
   * @return void
   * @type void
   */
  setOriginalIndex : function(pnIdx, pnOriIdx) {
    var row = this.viewData[pnIdx];
    if (row != null) {
      row[this.dataSet.ORIGINIDX] = pnOriIdx;
    }
  },
  /**
   * return row status
   * @param {Number} pnIdx row index
   * @return row status
   * @type Number
   */
  getStatus : function(pnIdx) {
    var row = this.viewData[pnIdx];
    if (row == null)
      return null;

    return row[this.dataSet.STATUSIDX];
  },
  /**
   * set row status
   * @param {Number} pnIdx row index
   * @param {Number} pnStatus row status
   * @return void
   * @type void
   */
  setStatus : function(pnIdx, pnStatus) {
    var row = this.viewData[pnIdx];
    if (row != null) {
      row[this.dataSet.STATUSIDX] = pnStatus;
    }
  },
  /**
   * view data의 row count 리턴
   * @return row count
   * @type Number
   */
  getRowCnt : function() {
    return this.viewData.length;
  },
  /**
   * clear
   * @return void
   * @type void
   */
  clear : function() {
    this.viewData = null;
    this.viewData = [];
    this.index = 0;
  },
  /**
   * set index
   * @param {Number} pnIdx index
   * @return void
   * @type void
   */
  setIndex : function(pnIdx) {
    var len = this.viewData.length;
    if (len <= pnIdx) {
      pnIdx = len - 1;
    }
    pnIdx = pnIdx < 0 ? 0 : pnIdx;
    this.index = pnIdx;
  },
  /**
   * get index
   * @return index
   * @type Number
   */
  getIndex : function() {
    var row = this.viewData[this.index];
    if (row == null)
      return null;

    return row[this.dataSet.ORIGINIDX];
  },
  /**
   * 파라미터로 받은 인덱스가 정상적인 인덱스인지 리턴
   * @param {Number} pnIdx row index
   * @return 인덱스의 정상 유무
   * @type Boolean
   */
  rangeCheck : function(pnIdx) {
    if (pnIdx < 0 || pnIdx > (this.viewData.length - 1)) {
      return false;
    } else {
      return true;
    }
  },
  /**
   * view Data를 새로 구성
   * @param {Array} poList data list
   * @return void
   * @type void
   */
  restoreRows : function(poList) {
    this.clear();
    var len = poList.length;

    for ( var i = 0; i < len; i++) {
      this.addRow(null, poList[i][0], poList[i][1]);
    }
  },
  /**
   * return row
   * @param {Number} pnIdx row index
   * @return row
   * @type Array
   */
  getRow : function(pnIdx) {
    return this.viewData[pnIdx];
  },
  /**
   * get view index
   * @param {Number} pnIdx row index
   * @return view index
   * @type Number
   */
  getViewIdx : function(pnIdx) {
    if (!this.rangeCheck(pnIdx))
      return null;
    return this.viewData[pnIdx][this.dataSet.VIEWIDX];
  }
};