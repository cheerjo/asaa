﻿/**
 * @fileoverview
 * IE의 Dom Parser 클래스
 */
/**
 * IE의 Dom Parser 클래스
 * use Microsoft.XMLDOM
 * @version 2.0
 * @base eXria.data.DOMParser
 * @constructor
 * @private
 */
eXria.data.xhtml.MsieDOMParser = function(poPage) {
  eXria.data.DOMParser.call(this);
  /**
   * IE DOM Parser
   * @type DOMParser
   * @private
   */
  this.parser = eXria.data.DomDocumentFactory.getDomDocument(poPage);
  /**
   * String 형태의 XML을 파싱하여 DOM으로 리턴한다.
   * @param {String} psData XML Text
   * @return Parsing된 XMLDocument
   * @type XMLDocument
   */
  this.parse = function(psData) {
    this.parser.loadXML(psData);
    return this.parser;
  };
};