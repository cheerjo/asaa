/**
 * @fileoverview
 * XHTML Mode 사용시 XML Node의 Data에 대한 관리를 담당하는 클래스
 */
/**
 * XHTML Mode 사용시 XML Node의 Data에 대한 관리를 담당하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.xhtml.Node
 */
eXria.data.xhtml.ValueNode = function(poNode) {
  /**
   * inherit
   */
//  if(page.metadata.modelType == eXria.form.ModelType.PLUGIN) {
//    eXria.data.plugin.Node.call(this, poNode);
//  } else {
//  eXria.data.xhtml.Node.call(this, poNode);
//  }
  this.node = poNode;
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.
   * @return extNode 값
   * @type String
   */
  this.getValue = function() {
//    var voValue = this.node.firstChild;
//    return voValue != null ? voValue.nodeValue : null;
  return String(this.node.getNodeValue());
  };
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.
   * @param {String} psValue value
   * @return void
   * @type void
   */
  this.setValue = function(psValue) {
  psValue = (psValue ? psValue : "");
//    var voValue = this.node.firstChild;
//    if(voValue != null) {
//      voValue.nodeValue = psValue;
//    } else {
//      this.node.appendChild(this.node.ownerDocument.createTextNode(psValue));
//    }
//  if(!psValue) {
//    return;
//  }
  this.node.setNodeValue(psValue);
  };
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.<br/>
   * 만약 값이 없을경우 argument의 값을 대신 리턴한다.
   * @param {String} psFix default value
   * @return TextNode의 값 또는 argument의 값
   * @type String
   */
  this.getString = function(psFix) {
    return eXria.util.StringUtil.fixNull(this.getValue(), psFix);
  };
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.
   * 설정 값이 Null 일경우 두번째 argument의 값을 설정한다.
   * @param {String} psValue value
   * @param {String} psFix alternate value
   * @return void
   * @type void
   */
  this.setString = function(psValue, psFix) {
    this.setValue(eXria.util.StringUtil.fixNull(psValue, psFix));
  };
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.<br/>
   * 만약 값이 없을경우 argument의 값을 대신 리턴한다.
   * @param {Number} pnFix alternate value
   * @return Number로 치환된 TextNode 값
   * @type Number
   */
  this.getNumber = function(pnFix) {
    return eXria.util.NumberUtil.fixNull(this.getValue(), pnFix);
  };
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.
   * 설정 값이 Null 일경우 두번째 argument의 값을 설정한다.
   * @param {Number} pnValue value
   * @param {Number} pnFix alternate value
   * @return void
   * @type void
   */
  this.setNumber = function(pnValue, pnFix) {
    this.setValue(eXria.util.NumberUtil.fixNull(pnValue), pnFix);
  };
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.<br/>
   * 만약 값이 없을경우 argument의 값을 대신 리턴한다.
   * @param {Boolean} pbFix alternate value
   * @return boolean으로 치환된 TextNode 값
   * @type Boolean
   */
  this.getBoolean = function(pbFix) {
  //return eXria.util.BooleanUtil.fixNull(this.getValue(), pbFix); fixNull -> fix(20090420 최현종)
    return eXria.util.BooleanUtil.fix(this.getValue(), pbFix);
  };
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.
   * 설정 값이 Null 일경우 두번째 argument의 값을 설정한다.
   * @param {Boolean} puValue value
   * @param {Boolean} pbFix alternate value
   * @return void
   * @type void
   */
  this.setBoolean = function(puValue, pbFix) {
    //this.setValue(eXria.util.BooleanUtil.fixNull(puValue), pbFix); 20090420 최현종 수정
  this.setValue(eXria.util.BooleanUtil.fix(puValue, pbFix));
  };
};
