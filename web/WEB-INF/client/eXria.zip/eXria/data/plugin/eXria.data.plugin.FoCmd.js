﻿/**
 * @fileoverview
 * Plugin Mode 사용시 File과 관련된 기능을 제공하는 클래스
 */
/**
 * Plugin Mode 사용시 File과 관련된 기능을 제공하는 클래스
 * @author Cheo, hyeon jong.
 * @version 1.0
 * @param {eXria.data.plugin.FoCmd} poFoCmd
 * @constructor
 */ 
eXria.data.plugin.FoCmd = function(poFoCmd, poModel) {
  /**
   * model
   * @type eXria.form.Model
   */
   this.model = poModel;
  /**
   * foCmd
   * @type eXria.data.plugin.FoCmd
   * @private
   */
  this.foCmd = poFoCmd;
  /**
   * file을 close 한다.
   * @return File이 정상적으로 close 되면 true 리턴
   * @type Boolean
   */
  this.close = function() {
	return this.foCmd.close();
  };
  /**
   * 대상 경로에 파일을 복사한다.
   * @param {String} psDestination 복사대상 경로
   * @param {Boolean} pbOverWrite 덮어쓰기 유무
   * @return void
   * @type void
   */
  this.copy = function(psDestination, pbOverWrite) {
	this.foCmd.copy();
  };  
  /**
   * 현재 파일의 포인터를 리턴한다.
   * @return 현재 파일 포인터의 위치
   * @type Number
   */
  this.getFilePos = function() {
	return this.foCmd.getFilePos();
  };
  /**
   * 파일 포인터의 위치가 EOF인지 검사
   * @return EOF이면 true 리턴
   * @type Boolean
   */
  this.isEndOfFile = function() {
	return this.foCmd.isEndOfFile();
  };
  /**
   * 파일의 내용을 모두 읽어서 문자열로 리턴한다.
   * @return 파일의 내용이 들어있는 문자열
   * @type String
   */
  this.readAll = function() {
	return this.foCmd.readAll();
  };
  /**
   * 파일의 내용을 줄단위로 읽어서 문자열로 리턴한다.
   * @return 파일에서 줄단위로 읽은 문자열
   * @type String
   */
  this.readLine = function() {
	return this.foCmd.readLine();
  };
  /**
   * 파일에서 파라미터로 넘어온 Byte만큼 문자열을 리턴한다.
   * @param {Number} pnReadLen 읽어올 문자열의 Byte
   * @return Byte 길이 만큼의 문자열
   * @type String
   */
  this.read = function(pnReadLen) {
	return this.foCmd.read(pnReadLen);
  };
  /**
   * 파일 포인터를 원하는 위치로 이동한다.
   * @param {Number} pnOffset 기준점으로 부터 이동할 거리(Byte단위)
   * @param {Number} pnWhence 이동의 기준점으로서 다음 중 선택(0:File의 시작점, 1:File의 현재위치, 2:File의 EOF(End Of File))
   * @return void
   * @type void
   */
  this.seek = function(pnOffset, pnWhence) {
	this.foCmd.seek(pnOffset, pnWhence);
  };
  /**
   * 파일의 시작지점으로 이동
   * @return void
   * @type void
   */
  this.seekToBegin = function() {
	this.foCmd.seekToBegin();
  };
  /**
   * 파일의 끝으로 이동
   * @return void
   * @type void
   */
  this.seekToEnd = function() {
	this.foCmd.seekToEnd();
  };
  /**
   * 파일에 문자열을 주어진 길이만큼 Write 한다.
   * @param {String} psWord Write 할 문자열
   * @param {Number} pnCount Write 할 길이
   * @return 쓰여질 파일이 읽기전용일때는 false 리턴
   * @type Boolean
   */
  this.write = function(psWord, pnCount) {
	return this.foCmd.write(psWord, pnCount);
  };
  /**
   * 파일에 줄단위로 주어진 문자열을 Write 한다.
   * @param {String} psWord write 할 문자열
   * @return 쓰여질 파일이 읽기 전용일때 false 리턴
   * @type Boolean
   */
  this.writeLine = function(psWord) {
	return this.foCmd.writeLine(psWord);
  };
  /**
   * 파일에 줄단위로 주어진 문자열을 Unicode로 Write 한다.
   * @param {String} psWord
   * @return 쓰여질 파일이 읽기전용일때는 false 리턴
   * @type Boolean
   */
  this.writeLineUnicodeStr = function(psWord) {
	return this.foCmd.writeLineUnicodeStr(psWord);
  };
  /**
   * 파일에 문자열을 ansi string으로 write한다.
   * @param {String} psWord write할 문자열
   * @return 쓰여질 파일이 읽기전용일때는 false리턴
   * @type Boolean
   */
  this.writeStr = function(psWord) {
	return this.foCmd.writeStr(psWord);
  };
  /**
   * 파일에 문자열을 Unicode로 Write한다.
   * @param {String} psWord write할 문자열
   * @return 쓰여질 파일이 읽기전용일때는 fasle 리턴
   * @type Boolean
   */
  this.writeUnicodeStr = function(psWord) {
	return this.foCmd.writeUnicodeStr(psWord);
  };
};