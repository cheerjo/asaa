/**
 * @fileoverview
 * Encoding Type에 대한 상수 정의 클래스</br>
 * "|"를 사용하여 BOM, NOBOM등의 상수와 조합 가능</br>
 * enum list</br>
 * eXria.data.plugin.EncType.ASCII<br/>
 * eXria.data.plugin.EncType.UTF8<br/>
 * eXria.data.plugin.EncType.UTF16<br/>
 * eXria.data.plugin.EncType.BOM<br/>
 * eXria.data.plugin.EncType.NOBOM<br/>
 */
/**
 * Encoding Type에 대한 상수 정의 클래스
 * @author Choe, Hyeon Jong
 * @version 1.0
 * @constructor
 */
eXria.data.plugin.EncType = {
	ASCII		:	0X100,
 	UTF8		:	0X200,
 	UTF16		:	0X400,
	BOM			:	0X1000,
	NOBOM		:	0X2000
};