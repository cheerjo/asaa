﻿/**
 * @fileoverview
 * PLUGIN Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 */
/**
 * PLUGIN Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 * 
 * @author Choe, hyeon jong.
 * @version 1.0
 * @param {NodeList}
 *          PLUGIN NodeList Object
 * @constructor
 * @base eXria.data.NodeList
 */
eXria.data.plugin.JreNodeList = function(poResult) {
  /**
   * Inherit
   */
  eXria.data.NodeList.call(this);
  /**
   * JreNodeList
   * @type PLUGINNodeList
   * @private
   */
  this.nodeList = poResult;
  /**
   * return item cound in NodeList
   * @return item count number
   * @type Number
   */
  this.getLength = function() {
    return this.nodeList.getLength();
  };
  /**
   * return NodeItem of parameter index
   * @param {Number} pnIdx
   * @return Node
   * @type Node
   */
  this.item = function(pnIdx) {
    var voNode = this.nodeList.item(pnIdx);
    if (voNode == null)
      return null;
    else
      return new eXria.data.plugin.JreNode(voNode);
  };
};