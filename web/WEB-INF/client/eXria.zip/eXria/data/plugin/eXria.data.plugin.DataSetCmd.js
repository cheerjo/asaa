/**
 * @fileoverview
 * Plugin Mode에서의 DataSet 사용시 내부의 메서드를 래핑해주는 클래스
 */
/**
 * Plugin Mode에서의 DataSet 사용시 내부의 메서드를 래핑해주는 클래스
 * @author Choe, hyeon jong.
 * @version 1.0
 * @param {Object} poDataSet dataset
 * @constructor
 * @base eXria.data.DataSetCmd
 */
eXria.data.plugin.DataSetCmd = function(psId, poModel) {
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트
   * @type eXria.data.ArrayMap
   */
  this.skippedStatusCheckList = new eXria.data.ArrayMap();
  /**
   * Inherit
   */
  eXria.data.DataSetCmd.call(this, psId, poModel);
  /**
   * use decode
   * @return void
   * @type Number
   * @private
   */
  this.isEncodeData = false;
  try {
    this.isEncodeData = (this.model.plugin.getJREVersionNumber() >= 1.7 && this.model.page.metadata.browser.ie == 0);
  } catch(e) {
    this.isEncodeData = false;
  }
  /**
   * Primary key 정보를 설정한다.
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName 설정할 primary key
   * @return void
   * @type void
   */
  this.addPrimaryKey = function(psTableName, psName, psSourceName) {
    this.dataSet.addPrimaryKey(psTableName, psName, psSourceName);
  };
  /**
   * column 정보를 update 한다.
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName update 할 값
   * @return void
   * @type void
   */
  this.addUpdateColumn = function(psTableName, psName, psSourceName) {
    this.dataSet.addUpdateColumn(psTableName, psName, psSourceName);
  };
  /**
   * source와 target의 index를 설정한다.
   * @param {Number} pnSourceIndex 대상 src index
   * @param {Number} pnTargetIndex 대상 target index
   * @return void
   * @type void
   */
  this.changeRowIndex = function(pnSourceIndex, pnTargetIndex) {
    this.dataSet.changeRowIndex(pnSourceIndex, pnTargetIndex);
  };
  /**
   * 해당 테이블에서 primary key 정보를 삭제한다.
   * @param {String} psTableName 대상 테이블 이름
   * @return void
   * @type void
   */
  this.clearPrimaryKeys = function(psTableName) {
    this.dataSet.clearPrimaryKeys(psTableName);
  };
  /**
   * sort parameter를 clear 한다.
   * @return void
   * @type void
   */
  this.clearSortItem = function() {
    this.dataSet.clearSortItem();
  };
  /**
   * column 정보를 clear 한다.
   * @param {String} psTableName 대상 table name
   * @return void
   * @type void
   */
  this.clearUpdateColumns = function(psTableName) {
    this.dataSet.clearUpdateColumns(psTableName);
  };
  /**
   * 현재 DataSet에 특정 컬럼을 다른 DataSet으로 복사한다.
   * @param {String} psScrCol 원본 컬럼명
   * @param {String} pnDataSetId 복사할 데이터셋 Id명
   * @return 복사 성공 여부 성공시 True
   * @type Boolean
   */
  this.cloneCol = function(psScrCol, pnDataSetId) {
    return this.dataSet.cloneCol(psScrCol, pnDataSetId);
  };
  /**
   * XPath filter 설정.
   * @param {String} psXPath 적용대상 경로
   * @param {Boolean} pbApply 적용 유무
   * @param {Boolean} pbViewDelFlagRow delete flag row를 보이고자 할 경우 true 보이지 말고자 할 경우 false
   * @return -1
   * @type Number
   */
  this.compositeFilter = function(psXPath, pbApply, pbViewDelFlagRow) {
    if(pbViewDelFlagRow == null) {
      pbViewDelFlagRow = false;
    }
    return this.dataSet.compositeFilter(psXPath, pbApply, pbViewDelFlagRow);
  };
  /**
   * xpath를 이용하여 필터링된 자료의 DataSet RowID를 알아낸다.
   * @param {String} psXPath 해당 DataSet에서 추출 하고자 하는 컬럼의 연산식
   * @return 해당 연산으로 필터링 된 RowIndex를 문자열로 ','로 구분하여 리턴한다.
   * 결과 값이 없을 경우 ""을 리턴한다. 
   * @type String
   */
  this.compositeIdx = function(psXPath) {
    return this.dataSet.compositeIdx(psXPath);
  };
  /**
   * 주어진 index의 row를 delete 한다.
   * @param {Number} pnIndex 삭제 대상 row의 index
   * @return index가 범위를 넘으면 -1 리턴
   * @type Number
   */
  this.deleteRow = function(pnIndex) {
    return this.dataSet.deleteRow(pnIndex);
  };
  /**
   * 찾고자 하는 Column:Value 쌍을 복수로 입력하여 값에 해당하는 RowID를 "," 구분하여 리턴한다. 
   * 인자 값은 컬럼명과 그 컬럼에서 찾을 Value를 ":"로 구분하여 넣어주고 복수개일 경우 Column:Value쌍을 ","로 구분하여
   * 다수개의 조건을 넣어 줄 수 있다. 
   * @param {String} psKeyArray 찾고자 하는 DataSet의 Column명
   * @return ","로 구분되어진 문자열
   * @type String
   */
  this.find = function(psKeyArray) {
    return this.dataSet.find(psKeyArray);
  };
  /**
   * 주어진 row의 fieldname을 통한 value 질의.
   * @param {Number} pnIndex row index
   * @param {String} psFieldName name
   * @return 조회 결과 리턴
   * @type String
   */
  this.get = function(pnIndex, psFieldName) {
    var voData = null;
    voData = this.dataSet.get(pnIndex, psFieldName);
    if(voData == null) voData = "";

    if(this.isEncodeData) {
      voData = decodeURIComponent(voData);
    }
    
    return String(voData);
  };
  /**
   * 컬럼의 수를 리턴
   * @return 컬럼의 수
   * @type Number
   */
  this.getColCnt = function() {
    return this.dataSet.getColCnt();
  };
  /**
   * 주어진 컬럼 인덱스에 해당하는 컬럼 명을 반환하는 메소드
   * @return 주어진 컬럼 인덱스에 해당하는 컬럼 명
   * @param {Number} pnIndex 컬럼 인덱스
   * @type String
   */
  this.getColName = function(pnIndex) {
    return this.dataSet.getColName(pnIndex);
  };
  /**
   * DataSet의 CRUD Node의 속성을 리턴한다.
   * @param {String} psAttrName 해당 속성 명
   * @return 해당 속성명에 속성값을 리턴한다.
   * @type String
   */
  this.getCRUDAttr = function(psAttrName) {
    return this.dataSet.getCRUDAttr(psAttrName);
  };
  /**
   * index 값을 얻는다
   * @return index값 리턴
   * @type Number
   */
  this.getIndex = function() {
    return this.dataSet.getIndex();
  };
  /**
   * Row에 설정한 특정 속성을 가져온다.
   * @param {Number} pnIndex 조회할 Row 번호
   * @param {String} psAttrName
   * @return 속성값
   * @type String
   */
  this.getRowAttr = function(pnIndex, psAttrName) {
    return this.dataSet.getRowAttr(pnIndex, psAttrName);
  };
  /**
   * Row 갯수를 얻는다
   * @return Row Count 값
   * @type Number
   */
  this.getRowCnt = function() {
    return this.dataSet.getRowCnt();
  };
  /**
   * DataSet에 설정한 Sort 정보를 Node Path 별로 질의하여 결과를 리턴한다.
   * @param {String} psRef
   * @return 질의한 소트 정보
   * @type String
   */
  this.getSortItem = function(psRef) {
    return this.dataSet.getSortItem(psRef);
  };
  /**
   * DataSet에 설정한 Sort Item의 Column 정보를 리턴한다.<br/>
   * 여러개의 Column 정보가 있을 경우 "," 딜리미터를 이용하여 분리하여 리턴
   * @return Sort Item에 존재하는 Column 명
   * @type String
   */
  this.getSortItemColumNames = function() {
	  return this.dataSet.getSortItemColumNames();
  };
  /**
   * crud type을 얻는다
   * @param {Number} pnIndex 조회대상 index
   * @return CrudType Number
   * @type Number
   */
  this.getStatus = function(pnIndex) {
    return this.dataSet.getStatus(pnIndex);
  };
  /**
   * 모든 Row 상태 중 입력한 상태를 가지고 있는 Row에 index 값을 구분자로 연결하여 리턴한다.
   * @param {Number} pnType 조회대상 CRUDTYPE (eXria.data.CrudType)
   * @param {String} psDelimeter 연결할 구분자, 생략할 경우 ',' 기본 설정
   * @return 입력 상태를 가진 Row의 index값
   * @type String 
   */
  this.getStatusIndex = function(pnType, psDelimeter) {
    return String(this.dataSet.getStatusIndex(pnType, psDelimeter));
  };
  /**
   * 주어진 index에 새로운 row를 insert 한다
   * @param {Number} pnIndex Insert 대상 Index
   * @param {Boolean} pbAfter pnIndex 뒤에 추가 유무
   * @return insert 후 row 갯수
   * @type Number
   */
  this.insertRow = function(pnIndex, pbAfter) {
    if(!(pbAfter === true)) pbAfter = false;
    return this.dataSet.insertRow(pnIndex, pbAfter);
  };
  /**
   * DataSet을 Rebuild 한다.
   * @param {Boolean} pbAdd Add 유무 설정
   * @return Row Count
   * @type Number
   */
  this.rebuild = function(pbAdd) {
	if(pbAdd == null) pbAdd = false;
    return this.dataSet.rebuild(pbAdd);
  };
  /**
   * primary key 정보를 삭제한다.
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName 삭제할 primary key 값
   * @return void
   * @type void
   */
  this.removePrimaryKey = function(psTableName, psName, psSourceName) {
    this.dataSet.removePrimaryKey(psTableName, psName, psSourceName);
  };
  /**
   * column 정보를 remove 한다
   * @param {String} psTableName 대상 table name
   * @param {String} psName 대상 col name
   * @param {String} psSourceName remove 할 값
   * @return void
   * @type void
   */
  this.removeUpdateColumn = function(psTableName, psName, psSourceName) {
    this.dataSet.removeUpdateColumn(psTableName, psName, psSourceName);
  };
  /**
   * instance를 reset 한다
   * @param {Boolean} pbResetInstance 
   * @return void
   * @type void
   */
  this.reset = function(pbResetInstance) {
    if(!(pbResetInstance === true)) pbResetInstance = false;
    this.dataSet.reset(pbResetInstance);
  };
  /**
   * 원본값으로 restore 한다
   * @param {Boolean} pbAll all 유무
   * @return void
   * @type void
   */
  this.restoreOriginVal = function(pbAll) {
    this.dataSet.restoreOriginVal(pbAll);
  };
  /**
   * 주어진 row의 fieldname에 value를 설정한다
   * @param {Number} pnIndex row index
   * @param {String} psFiledName field name
   * @param {String} psValue 설정할 값
   * @return 성공 : 1, 실패 : 0
   * @type Number
   */
  this.set = function(pnIndex, psFieldName, psValue) {
    var voMap = this.skippedStatusCheckList;
    if(voMap.get(psFieldName) == null) {
      return this.dataSet.set(pnIndex, psFieldName, psValue);
    } else {
      return this.dataSet.simpleSet(pnIndex, psFieldName, psValue);
	}
  };
  /**
   * Data 동기화 설정을 한다
   * @param {Boolean} pbSync 동기화 여부 설정
   * @return void
   * @type void
   */
  this.setDataSync = function(pbSync) {
    this.dataSet.setDataSync(pbSync);
  };
  /**
   * index를 설정한다
   * @param {Number} pnIndex 설정할 index 값
   * @return void
   * @type void
   */
  this.setIndex = function(pnIndex) {
    this.dataSet.setIndex(pnIndex);
  };
  /**
   * table에 prefix를 설정한다
   * @param {String} psTableName 설정 대상
   * @param {String} psPrefix 설정할 값
   * @return void
   * @type void
   */
  this.setPrefix = function(psTableName, psPrefix) {
    this.dataSet.setPrefix(psTableName, psPrefix);
  };
  /**
   * 해당 Row에 속성을 설정한다
   * @param {Number} pnIndex Row Number
   * @param {String} psAttrName 속성 명
   * @param {String} psAttrVal 속성 값
   * @return void
   * @type void
   */
  this.setRowAttr = function(pnIndex, psAttrName, psAttrVal) {
    this.dataSet.setRowAttr(pnIndex, psAttrName, psAttrVal);
  };
  /**
   * sort item을 설정한다
   * @param {String} psNodeName 대상 Node 설정
   * @param {Number} pnType 1 : text, 0 : not text
   * @param {Boolean} pbAscending true : 오름차순, false : 내림차순
   * @return void
   * @type void
   */
  this.setSortItem = function(psNodeName, pnType, pbAscending) {
    this.dataSet.setSortItem(psNodeName, pnType, pbAscending);
  };
  /**
   * 원하는 index에 CRUD type을 설정한다
   * @param {Number} 설정할 index
   * @param {Number} pnType crud type (eXria.data.CrudType)
   * @return void
   * @type void
   */
  this.setStatus = function(pnIndex, pnType) {
    this.dataSet.setStatus(pnIndex, pnType);
  };
  /**
   * CRUD type을 설정한다
   * @param {Number} pnType crud type (eXria.data.CrudType)
   * @return void
   * @type void
   */
  this.setStatusAll = function(pnType) {
    this.dataSet.setStatusAll(pnType);
  };
  /**
   * 범위로 입력한 Row에 CRUD Type으로 설정한다.
   * @param {Number} pnStart 시작 Row 번호
   * @param {Number} pnEnd 종료 Row 번호
   * @param {Number} pnType CRUDTYPE (eXria.data.CrudType)
   * @return void
   * @type void
   */
  this.setStatusRange = function(pnStart, pnEnd, pnType) {
    this.dataSet.setStatusRange(pnStart, pnEnd, pnType);
  };
  /**
   * set은 값을 변경 하면서 동시에 그 Row에 상태값을 수정된 상태로 변경 하지만
   * 이 메서드는 status를 변경하지 않고 단지 value만을 변경 한다.
   * @param {Number} pnIndex row index
   * @param {String} psFieldName Field Name
   * @param {String} psValue 설정할 값
   * @return 성공하면 1, 실패하면 0
   * @type Number 
   */
  this.simpleSet = function(pnIndex, psFieldName, psValue) {
    return this.dataSet.simpleSet(pnIndex, psFieldName, psValue);
  };
  /**
   * sort를 수행한다
   * @return void
   * @type void
   */
  this.sort = function() {
    this.dataSet.sort();
  };
  /**
   * 현재 DataSet에 설정 되어 있는 PrimaryKey들을 "," 구분자로 하여 문자열로 리턴한다.
   * @param {String} psTableName AUTOCRUD request 테이블 명. ""일 경우 모든 테이블의 primary key를 반환
   * @type String
   * @return Primary Key 값들
   */
  this.getPrimaryKeys = function(psTableName) {
    return this.dataSet.getPrimaryKeys(psTableName);
  };
  /**
   * 현재 DataSet에 설정 되어 있는 update column들을 "," 구분자로 하여 문자열로 리턴한다.
   * @param {String} psTableName AUTOCRUD request 테이블 명.
   * @type String
   * @return 현재 DataSet에서 입력한 table에 설정 되어 있는 UpdateColumn들을 "," 구분자로 하여 문자열로 리턴한다.
   */
  this.getUpdateCols = function(psTableName) {
    return this.dataSet.getUpdateCols(psTableName);
  };
  /**
   * 현재 DataSet에 등록된 AUTOCRUD request 테이블명들을 "," 구분자로 하여 문자열로 리턴한다.
   * @type String
   * @return  DataSet에 등록 되어져 있는 AutoCRUD처리 테이블들의 이름을 리턴한다. 복수개일 경우 "," 구분자로 구분하여 리턴한다. 
   */
  this.getCRUDTableNames = function() {
    return this.dataSet.getCRUDTableNames();
  };
  /**
   * DataSet에서 삭제된 로우의 전체 count를 리턴한다.
   * @type Number
   * @return delete된 row의 전체 수.
   */
  this.getDelTableRowCnt = function() {
    return this.dataSet.getDelTableRowCnt();
  };
  /**
   * DataSet에서 삭제된 로우 중 해당 인덱스와 컬럼명의 값을 리턴한다.
   * @param {Number} pnIdx Row Index
   * @param {String} psFieldName 컬럼 명
   * @return index 조건으로 검색된 삭제 row의 해당 컬럼의 값.
   * @type String
   */
  this.getDelTableValue = function(pnIdx, psFieldName) {
    return this.dataSet.getDelTableValue(pnIdx, psFieldName);
  };
  /**
   * 현재 DataSet에 등록된 AUTOCRUD request 테이블을 등록하는 메소드.
   * @param {String} psTableName AUTOCRUD request 테이블 명
   * @return void
   * @type void
   */
  this.addCRUDTable = function(psTableName) {
    return this.dataSet.addCRUDTable(psTableName);
  };
  /**
   * DataSet에 CRUD 테이블에서 해당 테이블 명을 가지고 있는 테이블을 삭제한다.
   * @param {String} psTableName 삭제할 테이블 명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.removeCRUDTable = function(psTableName) {
    return this.dataSet.removeCRUDTable(psTableName);
  };
  /**
   * 현재 DataSet에 등록된 request 테이블의 prefix를 얻어오는 메소드.
   * @param {String} psTableName AUTOCRUD request 테이블 명
   * @return 첫 인자로 입력한 아이디를 가지는 테이블의 Prefix 값을 문자열로 리턴하여 준다.
   * @type String
   */
  this.getPrefix = function(psTableName) {
    return this.dataSet.getPrefix(psTableName);
  };
  /**
   * submission에 추가할 수 있는 CRUD 문자열 정보를 반환해주는 메소드.
   * @param {Boolean} pbGetUnchanged Unchanged Status의 row데이타 정보도 가져올지 여부
   * @type String
   * @return submission에 추가할 수 있는 CRUD 문자열 정보를 반환
   */
  this.getAutoCRUDString = function(pbGetUnchanged) {
    if(pbGetUnchanged) return this.dataSet.getAutoCRUDString(1);
    else return this.dataSet.getAutoCRUDString();
  };
  /**
   * 해당 Row에서 필드명과 일치하는 곳에 수정 바로 이전 값을 리턴한다.
   * @param {Number} pnIndex row index
   * @param {String} psFieldName field name
   * @type String
   * @return 수정되기 이전 값을 리턴한다. 이 기능을 쓰기 위해서는 Keep the Original Data 속성이 설정 되어 있어야 한다. 
   */
  this.getOrigin = function(pnIndex, psFieldName) {
    var voOriginData = null;
    voOriginData = this.dataSet.getOrigin(pnIndex, psFieldName);
    if(voOriginData == null) voOriginData = "";

    if(this.isEncodeData) {
      voOriginData = decodeURIComponent(voOriginData);
    }
    
    return String(voOriginData);
  };
  /**
   * DataSet과 원본 데이터와의 Sync 상태를 리턴한다.
   * @return Sync 상태시 True 리턴
   * @type Boolean
   */
  this.isDataSync = function() {
    return this.dataSet.isDataSync();
  };
  /**
   * DataSet의 Keep Original Value 상태 리턴
   * @return Keep 상태시 True 리턴
   * @type Boolean
   */
  this.isKeepOriginalValue = function() {
    return this.dataSet.isKeepOriginalValue();
  };
  /**
   * CRUD에 관계된 데이타셋 속성 값을 설정하기 위한 메소드.
   * - submission에서 데이타셋으로 부터 unchanged status의 row정보를 하져올 때 setCRUDAttr("alltype", "true")를 호출함.
   *   해제시에는 setCRUDAttr("alltype", "false")를 호출함.
   * @param {String} psName 속성명
   * @param {String} psValue 속성값
   * @return void
   * @type void
   */
  this.setCRUDAttr = function(psName, psValue) {
    this.dataSet.setCRUDAttr(psName, psValue);
  };
  /**
   * 현재 DataSet을 초기화 시킨다.
   * @type void
   * @return void
   */
  this.refresh = function() {
    if(this.model) this.dataSet = this.model.plugin.getDataSet(this.id);
  };
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트를 추가한다.
   * @param {Array} paCol 추가할 컬럼 Array
   * @type void
   * @return void
   */
  this.addSkipSCList = function(paCol) {
    var voMap = this.skippedStatusCheckList;
    for(var i = paCol.length - 1; i >= 0; i--) {
      voMap.put(paCol[i], "");
    }
  };
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트 중 파라미터로 넘어온 컬럼들을 삭제한다.
   * @param {Array} paCol 삭제할 컬럼 Array
   * @type void
   * @return void
   */
  this.removeSkipSCList = function(paCol) {
  	var voMap = this.skippedStatusCheckList;
  	for(var i = paCol.length - 1; i >= 0; i--) {
  	  voMap.remove(paCol[i]);
  	}
  };
  /**
   * 데이타셋 status관리를 하지 않을 컬럼 리스트를 전부 삭제한다.
   * @type void
   * @return void
   */
  this.clearSkipSCList = function() {
    this.skippedStatusCheckList.clear();
  };
  /**
   * DataSet에 새로운 Column을 추가한다.
   * Instance와 Sync 되어 있을 시 Instance node의 구조도 자동으로 변경 되어진다.
   * @param {Number} pnIndex 컬럼을 삽입시킬 위치 값
   * @param {String} psColName 새로 생성 될 컬럼명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.addColumn = function(pnIndex, psColName) {
    if(pnIndex == -1) return this.dataSet.addColumn(psColName)
    return this.dataSet.addColumn(pnIndex, psColName);
  };
  /**
   * DataSet의 마지막에 새로운 Column을 추가한다.
   * Instance와 Sync 되어 있을 시 Instance node의 구조도 자동으로 변경 되어진다.
   * @param {String} psColName 새로 생성 될 컬럼명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.appendColumn = function(psColName) {
    return this.dataSet.addColumn(psColName);
  };
  /**
   * DataSet에 해당 컬럼명을 가지고 있는 컬럼을 삭제한다.
   * @param {String} psColName 삭제할 컬럼명
   * @return 성공시 0을 리턴하며 그 외에 값은 내부 에러코드
   * @type Number
   */
  this.removeColumn = function(psColName) {
    return this.dataSet.removeColumn(psColName);
  };
  /**
   * 요청된 범위의 Plugin ExriaNode 객체들을 배열에 담아 반환하는 메소드
   * @param {Number} pnStart 시작 행 인덱스(1 base)
   * @param {Number} pnStart 마지막 행 인덱스(1 base)
   * @return 요청된 범위의 Plugin ExriaNode 객체를 담은 배열
   * @type Array(Object)
   */
  this.getRowDataList = function(pnStart, pnEnd) {
    if(!pnStart || pnStart < 1) pnStart = 1;
    if(!pnEnd || pnEnd < 1) pnEnd = 0;
    return this.dataSet.getRowDataList(pnStart, pnEnd);
  };
  /**
   * 요청된 범위의 Plugin ExriaNode 객체들을 javascript에서 배열화할 수 있는 문자열을 반화하는 메소드
   * @param {Number} pnStart 시작 행 인덱스(1 base)
   * @param {Number} pnStart 마지막 행 인덱스(1 base)
   * @return 요청된 범위의 Plugin ExriaNode 객체를 담은 배열
   * @type Array(Object)
   */
  this.getRowDataStr = function(pnStart, pnEnd) {
    if(!pnStart || pnStart < 1) pnStart = 1;
    if(!pnEnd || pnEnd < 1) pnEnd = 0;
    return String(this.dataSet.getRowDataStr(pnStart, pnEnd));
  };
  /**
   * dataset 모든 row의 특정 속성 값을 배열에 담아 반환해주는 메소드
   * @param {String} psAttrName 검색 요청 속성명
   * @return 모든 row의 특정 속성 값을 담은 배열
   */
  this.getRowsAttr = function(psAttrName) {
    var voList = this.dataSet.getRowsAttr(psAttrName);
    return voList.toArray();
  };
  /**
   * dataset 모든 row의 특정 속성을 일괄 설정하기 위한 메소드
   * @param {String} psAttrName 값 설정 대상 속성명
   * @param {String} psAttrValue 일괄 설정 속성 값
   */
  this.setRowsAttr = function(psAttrName, psAttrValue) {
    return this.dataSet.setRowsAttr(psAttrName, psAttrValue);
  };
  /**
   * dataset의 Source Type을 리턴한다.
   * @return dataset의 Source Type
   * @type {Number}
   */
  this.getSrcType = function() {
    return this.dataSet.getSrcType();
  };
  /**
   * dataset의 Connection Info를 리턴한다.
   * @return dataset의 Connection Info
   * @type {String}
   */
  this.getConnectionInfo = function() {
    return this.dataSet.getConnectionInfo();
  };
  /**
   * dataset의 Source Query를 리턴한다.
   * @return dataset의 Source Query
   * @type {String}
   */
  this.getSourceQuery = function() {
    return this.dataSet.getSourceQuery();
  };
  
    /**
   * dataset originData 수정
   * @param {Number} pnIdx row index
   * @param {Number} pnColIdx column index
   * @param {Number} psVal value
   * @return void
   * @type void
   */
  this.setOrigin = function(pnIdx, pnColIdx, psVal) {
    this.dataSet.setOrigin(pnIdx, pnColIdx, psVal);
  };
  
  this.getHeader = function() {
    this.dataSet.getHeader();
  };
};