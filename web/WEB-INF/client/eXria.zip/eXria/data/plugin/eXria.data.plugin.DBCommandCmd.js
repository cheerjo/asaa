/**
 * @fileoverview
 * Plugin Mode 사용시 DB Command에 대한 관리를 하는 클래스
 */
/**
 * Plugin Mode 사용시 DB Command에 대한 관리를 하는 클래스
 * @author Choe, hyeon jong
 * @version 1.0
 * @param {Object} poCommand command
 * @constructor
 */
eXria.data.plugin.DBCommandCmd = function(psId, poModel, poCommand) {
  /**
   * id
   * @type String
   */
  this.id = psId;
  /**
   * model
   * @type eXria.form.Model
   */
  this.model = poModel;
  /**
   * command object
   * @type DBCommnadCmd
   * @private
   */
  this.command = poCommand;
  /**
   * target에 이미 노드가 있을경우에 뒤에 추가 한다.
   * @type Number
   */
  this.ETBDATAADD = this.command.ETBDATAADD;
  /**
   * target에 이미 노드가 있을경우에 지우고 추가 한다.
   * @type Number
   */  
  this.ETBDATAREPLACE = this.command.ETBDATAREPLACE;
  /**
   * 들어온 데이터의 필드명에 맞추어 target에 적용 한다.
   * @type Number
   */  
  this.ETBFIELDNAMENEW = this.command.ETBFIELDNAMENEW;
  /**
   * target에 있는 field만 생성 한다.
   * @type Number
   */  
  this.ETBFIELDMATCH = this.command.ETBFIELDMATCH;
  /**
   * source에 첫줄을 필드명으로 생성한다.
   * @type Number
   */  
  this.ETBFIRSTROWFIELD_SRC = this.command.ETBFIRSTROWFIELD_SRC;
  /**
   * target에 첫줄을 필드명으로 생성한다.
   * @type Number
   */  
  this.ETBFIRSTROWFIELD_TGT = this.command.ETBFIRSTROWFIELD_TGT;
  /**
   * source와 target에 있는 모든 첫줄을 필드명으로 생성한다.
   * @type Number
   */  
  this.ETBFIRSTROWFIELD_ALL = this.command.ETBFIRSTROWFIELD_ALL;
  /**
   * excel export시 cell안에 데이터 세로정렬을 위로 한다.
   * @type Number
   */
  this.EXCEL_VERTICALALIGN_TOP = this.command.EXCEL_VERTICALALIGN_TOP;
  /**
   * excel export시 cell안에 데이터 세로정렬을 가운데로 한다.
   * @type Number
   */
  this.EXCEL_VERTICALALIGN_MIDDLE = this.command.EXCEL_VERTICALALIGN_MIDDLE;
  /**
   * excel export시 cell안에 데이터 세로정렬을 아래로 한다.
   * @type Number
   */
  this.EXCEL_VERTICALALIGN_BOTTOM = this.command.EXCEL_VERTICALALIGN_BOTTOM;
  /**
   * 조회한 결과를 반영할 타겟을 설정한다.
   * @param {Number} pnType target의 타입
   * @param {String} psTargetName target name
   * @param {String} psTarget ConnectionString
   * @return void
   * @type void
   */
  this.changeTarget = function(pnType, psTargetName, psTargetConnectionString) {
    this.command.changeTarget(pnType, psTargetName, psTargetConnectionString);
  };
  /**
   * 등록된 파라미터들을 clear한다.
   * @return void
   * @type void
   */
  this.clearParameters = function() {
    this.command.clearParameters();
  };
  /**
   * setQueryString으로 설정한 조회 SQL을 실행한다.
   * @param {Number} pnTypeAdd
   * @return 조회돤 record 수 리턴
   * @type Number
   */
  this.executeQuery = function(pnTypeAdd) {
    return this.command.executeQuery(pnTypeAdd);
  };
  /**
   * setQueryString으로 설정한 SQL(Create, Insert, Update, Delete)을 실행한다.
   * @return 변경된 건수
   * @type Number
   */
  this.executeUpdate = function() {
    return this.command.executeUpdate();
  };
  /**
   * excel export시 cell의 세로정렬을 변경한다.
   * @param {Number} 세로정렬값
   * @return void
   * @type void
   */
  this.setVerticalAlign = function(pnVarticalAlign){
  	this.command.setVerticalAlign(pnVarticalAlign);
  }
  /**
   * 조회할 리스트의 마지막 row index를 리턴한다.
   * @return 마지막 row index
   * @type Number
   */
  this.getMaxRow = function() {
    return this.command.getMaxRow();
  };
  /**
   * 조회할 리스트의 처음 row index를 리턴한다.
   * @return 처음 row index
   * @type Number
   */
  this.getMinRow = function() {
    return this.command.getMinRow();
  };
  /**
   * 특정 index의 parameter를 삭제한다.
   * @param {Number} pnIndex 삭제대상 index
   * @return void
   * @type void
   */
  this.removeParameter = function(pnIndex) {
    this.command.removeParameter(pnIndex);
  };
  /**
   * 행 또는 열에 대한 사용자정의 구분자를 설정한다.
   * @param {Number} pnType type(1:Source Col, 2:Source Row, 4:Target Col, 8:Target Row)
   * @param {String} psDelimiter 사용자 정의 구분자
   * @return void
   * @type void
   */
  this.setDelimiter = function(pnType, psDelimiter) {
    this.command.setDelimiter(pnType, psDelimiter);
  };
  /**
   * 조회 시 source의 column과 매칭 할 target의 column명을 설정한다.
   * @param {String} psSourceName source column 이름
   * @param {String} psTargetName Target column 이름
   * @return void
   * @type void
   */
  this.setFieldMatch = function(psSourceName, psTargetName) {
    this.command.setFieldMatch(psSourceName, psTargetName);
  };
  /**
   * 조회할 리스트의 마지막 row index를 설정
   * @param {Number} pnIndex
   * @return void
   * @type void
   */
  this.setMaxRow = function(pnIndex) {
    this.command.setMaxRow(pnIndex);
  };
  /**
   * 조회할 리스트의 처음 row index를 설정
   * @param {Number} pnIndex
   * @return void
   * @type void
   */
  this.setMinRow = function(pnIndex) {
    this.command.setMinRow(pnIndex);
  };
  /**
   * 특정 index에 parameter를 추가하거나 설정한다.
   * @param {Number} pnIndex 설정 대상 index
   * @param {String} psValue 설정할 parameter
   * @return void
   * @type void
   */
  this.setParameter = function(pnIndex, psValue) {
    this.command.setParameter(pnIndex, psValue);
  };
  /**
   * SQL을 실행하기 위한 SQL문장을 설정한다.
   * @param {String} psQuery SQL 문장을 설정
   * @return void
   * @type void
   */
  this.setQueryString = function(psQuery) {
    this.command.setQueryString(psQuery);
  };
  /**
   * source와 target간의 동기화를 설정한다.
   * @param {Boolean} pbSync true일 경우 동기화 설정
   * @return void
   * @type void
   */
  this.setSync = function(pbSync) {
    this.command.setSync(pbSync);
  };
  /**
   * Export 할 Excel의 Column 순서를 지정한다.
   * @param {String} psSeq Column 순서
   * @return void
   * @type void
   */
  this.setColSeq = function(psSeq) {
    this.command.setColSeq(psSeq);
  }
};