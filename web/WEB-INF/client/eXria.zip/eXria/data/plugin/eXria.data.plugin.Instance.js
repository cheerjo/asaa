/**
 * @fileoverview
 * Plugin Mode 사용시 사용되는 Instance를 관리하는 클래스
 */
/**
 * Plugin Mode 사용시 사용되는 Instance를 관리하는 클래스
 * 
 * @version 1.0
 * @param {nsIInstance} poInstance Plugin Instance Object
 * @param {String} psId Instance Id
 * @param {eXria.form.Model} poModel Model Object
 * @constructor
 * @type eXria.data.plugin.Instance
 * @return void
 */
eXria.data.plugin.Instance = function(poInstance, psId, poModel) {
  /**
   * inherit
   */
  eXria.data.Instance.call(this, psId, poModel);
  /**
   * this.pluginInstance
   * @type Object
   * @private
   */
  this.pluginInstance = poInstance;
  /**
   * loadXML, loadURL, loadTXT 메소드 사용시 append 혹은 replace를 결정하는 플래그
   * <br/>Plugin에서만 사용 가능한 플래그
   * @type Number
   */
  this.LOADREPLACE = this.pluginInstance.LOAD_REPLACE;
  /**
   * loadXML, loadURL, loadTXT 메소드 사용시 append 혹은 replace를 결정하는 플래그
   * <br/>Plugin에서만 사용 가능한 플래그
   * @type Number
   */
  this.LOADAPPEND = this.pluginInstance.LOAD_APPEND;
  /**
   * page
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.page = this.model.page;
  /**
   * document
   * @type Object
   * @private
   */
  this.document = {};
  /**
   * document DOM
   * @type Object
   * @private
   */
  this.document.dom = poInstance.dom;
  /**
   * pluginType
   * @type Number
   * @private
   */
  this.modelType = this.page.metadata.modelType;
  /**
   * model type Object
   * @type Object
   * @private
   */
  this.modelTypeObj = eXria.form.ModelType;
  /**
   * plugin type
   * @type Number
   * @private
   */
  this.pluginType = this.modelTypeObj.PLUGIN;
  /**
   * use decode
   * @return void
   * @type Number
   * @private
   */
  this.isEncodeData = false;
  try {
    this.isEncodeData = (this.model.plugin.getJREVersionNumber() >= 1.7 && this.page.metadata.browser.ie == 0);
  } catch(e) {
    this.isEncodeData = false;
  }
  /**
   * plugin type에 맞춰 node Object를 생성하여 리턴
   * @param {XMLNode} poNode
   * @type eXria.data.Node
   * @return wrapping 된 Node
   * @private
   */
  this.getWrapNodeObject = function(poNode) {
    if (this.modelType == this.pluginType) {
      return new eXria.data.plugin.NativeNode(poNode);
    } else {
      if(this.isEncodeData) {
        if(poNode == null) return null;
        return new eXria.data.plugin.JreNode(poNode);
      } else {
        return poNode;
      }
    }
  };
  /**
   * 특정 URL의 XML Document를 인스턴스에 바인딩한다.
   * @param {String} psUrl 바인딩할 XML의 URL
   * @param {Number} pnMode XML 바인딩 시 [InstanceObj.LOADREPLACE | InstanceObj.LOADAPPEND] 설정
   * @return void
   * @type void
   */
  this.loadURL = function(psUrl, pnMode) {
  	if(pnMode != this.LOADAPPEND && pnMode != this.LOADREPLACE) pnMode = this.LOADAPPEND;
    this.pluginInstance.loadURL(psUrl, pnMode);
  };
  /**
   * XML Element를 인스턴스에 바인딩한다.
   * @param {XMLElement} poXML 바인딩할 XMLElement
   * @param {Number} pnMode XML 바인딩 시 [InstanceObj.LOADREPLACE | InstanceObj.LOADAPPEND] 설정
   * @return void
   * @type void
   */
  this.loadXML = function(poXML, pnMode) {
  	if(pnMode != this.LOADAPPEND && pnMode != this.LOADREPLACE) pnMode = this.LOADAPPEND;
    this.pluginInstance.loadXML(poXML, pnMode);
  };
  /**
   * XML Text를 파싱하여 인스턴스에 바인딩한다.
   * @param {String} psTxt 파싱할 XML Text
   * @param {Number} pnMode XML 바인딩 시 [InstanceObj.LOADREPLACE | InstanceObj.LOADAPPEND] 설정
   * @return void
   * @type void
   */
  this.loadTXT = function(psTxt, pnMode) {
  	if(pnMode != this.LOADAPPEND && pnMode != this.LOADREPLACE) pnMode = this.LOADAPPEND;
    this.pluginInstance.loadTXT(psTxt, pnMode);
  };
  // 2009-05-20 추가
  /**
   * Node를 주어진 타입에 따라 생성하여 그 객체를 리턴한다. Type이 없을 경우 Default로 Element Node가 리턴 된다.
   * @param {String} psNodeName 두번째 파라미터로 넘어오는 Type에 따라 Node명 또는 그 Node의 Value가 된다.
   * @param {Number} pnType Type [eXria.data.NodeType]
   * @type eXria.data.Node
   * @return 생성된 XML Node
   */
  this.createNode = function(psNodeName, psValue, pnType) {
    if (!pnType)
      pnType = this.pluginInstance.ETBNODETYPE_ELEMENT;
    try {
      if (!psValue) {
        return this.getWrapNodeObject(this.pluginInstance.createNullNode(psNodeName, pnType));
      } else {
        return this.getWrapNodeObject(this.pluginInstance.createNode(psNodeName, psValue, pnType));
      }
    } catch (e) {
      return null;
    }
  };
  /**
   * 파라미터로 넘어온 이름의 Element를 생성하여 리턴한다.
   * @param {String} psElementName 생성될 엘리먼트 이름
   * @return 생성된 Element Node
   * @type eXria.data.Node
   * @see eXria.data.Node
   */
  this.createElement = function(psElementName) {
    if(!psElementName) { return null; }
    return this.createNode(psElementName, null, this.pluginInstance.ETBNODETYPE_ELEMENT);
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 ValueNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 value node
   * @type eXria.data.ValueNode
   * @see eXria.data.ValueNode
   */
  this.createValueNode = function(psName) {
    var voNode = this.pluginInstance.createNode(psName, "", 1);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.ValueNode(this.getWrapNodeObject(voNode)); // create
                                                                            // Element
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 MapNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 MapNode
   * @type eXria.data.MapNode
   * @see eXria.data.MapNode
   */
  this.createMapNode = function(psName) {
    var voNode = this.pluginInstance.createNode(psName, "", 1);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.MapNode(this.getWrapNodeObject(voNode)); // create
                                                                          // Element
  };
  /**
   * 넘겨받은 Tag Name을 가지는 ElementNode를 생성하여 CollectionNode로 wrapping하여 리턴한다.
   * @param {String} psName 생성할 ElementNode의 TagName
   * @return 생성된 CollectionNode
   * @type eXria.data.CollectionNode
   * @see eXria.data.CollectionNode
   */
  this.createCollectionNode = function(psName) {
    var voNode = this.pluginInstance.createNode(psName, "", 1);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.CollectionNode(this.getWrapNodeObject(voNode)); // create
                                                                                // Element
  };
  /**
   * 넘겨 받은 XPath의 하위에 Node를 추가한다.
   * @param {String} psPath 추가할 위치에 해당하는 XPath
   * @param {XMLNode} poNode 추가할 XMLNode
   * @return void
   * @type void
   */
  this.appendNode = function(psPath, poNode) {
    if(poNode.node != null) poNode = poNode.node;
    this.pluginInstance.appendNode(psPath, poNode);
  };
  // 2009-05-20 추가
  /**
   * Instnace의 주어진 XPath 경로에 Value를 설정한다.
   * @param {String} psXpath Value를 설정하기 위한 XPath 경로
   * @param {String} psValue 설정하고자 하는 Value
   * @return void
   * @type void
   */
  this.setValue = function(psXpath, psValue) {
    this.pluginInstance.setValue(psXpath, psValue);
  };
  // 2009-05-20 추가
  /**
   * Instance의 Value를 XPath를 통해서 조회 한다.
   * @param {String} psXpath 조회대상의 XPath 경로
   * @type String
   * @return 조회된 Value
   */
  this.getValue = function(psXpath) {
    var voValue = this.pluginInstance.getValue(psXpath);
    if(voValue == null) return null;
    
    var vsValue = String(voValue) + "";  

    if(this.isEncodeData) {
      vsValue = decodeURIComponent(vsValue);
    }
    
    return vsValue;
  };
  /**
   * Instance의 dom객체의 XML 내용을 XPath를 이용하여 해당 위치에 데이터를 문자열로 얻는다.
   * @return dom 객체의 XML 문자열
   * @param {String} psXPath XPath 문자열
   * @type String
   */
  this.getXML = function(psXPath) {
    return String(this.pluginInstance.getXML(psXPath));
  };
  /**
   * 넘겨받은 XPath를 단순 Value형태로 처리하기 위한 ValueNode를 생성하여 리턴한다.
   * @param {String} psXpath Value Node로 얻고자 하는 Node의 Path
   * @return ValueNode
   * @type eXria.data.ValueNode
   * @see eXria.data.ValueNode
   */
  this.getValueNode = function(psXpath) {
    var voNode = this.pluginInstance.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.ValueNode(this.getWrapNodeObject(voNode));
  };
  /**
   * 넘겨받은 XPath를 Map형태로 처리하기 위한 MapNode를 생성하여 리턴한다.
   * @param {String} psXpath Map Node로 얻고자 하는 Node의 Path
   * @return MapNode
   * @type eXria.data.MapNode
   * @see eXria.data.MapNode
   */
  this.getMapNode = function(psXpath) {
    var voNode = this.pluginInstance.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.MapNode(this.getWrapNodeObject(voNode));
  };
  /**
   * 넘겨받은 XPath를 Collection형태로 처리하기 위한 CollectionNode를 생성하여 리턴한다.
   * @param {String} psXpath 처리할 기준 Node XPath
   * @return CollectionNode
   * @type eXria.data.CollectionNode
   * @see eXria.data.CollectionNode
   */
  this.getCollectionNode = function(psXpath) {
    var voNode = this.pluginInstance.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }
    return new eXria.data.xhtml.CollectionNode(this.getWrapNodeObject(voNode));
  };
  /**
   * 넘겨받은 Xpath의 Node를 삭제한다.
   * @param {String} psXpath 삭제할 Node의 XPath
   * @return 삭제된 노드
   * @type eXria.data.Node
   */
  this.removeNode = function(psXpath) {
    var voNode = this.pluginInstance.removeNode(psXpath);
    return this.getWrapNodeObject(voNode);
  };
  /**
   * 해당 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 Node
   * @type eXria.data.Node
   */
  this.selectSingleNode = function(psXpath) {
    var voNode = this.pluginInstance.selectSingleNode(psXpath);
    if (!voNode) {
      return null;
    }

    return this.getWrapNodeObject(voNode);
  };
  /**
   * Instance의 하위Node를 넘겨받은 XPath로 조회하여 리턴한다.
   * @param {String} psXpath 조회할 Xpath
   * @return NodeList
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodes = function(psXpath) {
    var voNodeList = this.pluginInstance.selectNodes(psXpath);

    if (!voNodeList) {
      return null;
    }

    var voResultNodeList = null;

    if (this.modelType == this.pluginType) {
      voResultNodeList = new eXria.data.plugin.NativeNodeList(voNodeList);
    } else {
      if(this.isEncodeData) {
        voResultNodeList = new eXria.data.plugin.JreNodeList(voNodeList);
      } else {
        voResultNodeList = voNodeList;
      }
    }

    return voResultNodeList;
  };
  /**
   * clear
   * @return void
   * @type void
   * @ignore
   */
  this.clear = function() {
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 alert으로 출력
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return void
   * @type void
   */
  this.print = function(psXpath) {
    if (psXpath == null || psXpath == undefined) {
      return;
    }
    alert(this.getXML(psXpath));
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 문자열로 반환
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return xml 노드를 문자열화한 객체
   * @type String
   */
  this.nodeToStr = function(psXpath) {
    if (psXpath == null || psXpath == undefined) {
      return;
    }
    return this.getXML(psXpath);
  };
  /**
   * 넘겨 받은 XPath의 Node를 복사하여 리턴한다.
   * @param {String} psXPath 복사할 Node의 XPath
   * @param {String} pbDeep 깊은복사 유무 ( True : Deep Copy )
   * @return 복사된 노드
   * @type eXria.data.Node
   */
  this.cloneNode = function(psXPath, pbDeep) {
    var vnDeep = 1;
    if (pbDeep == false || pbDeep != 1) {
      vnDeep = 0;
    }
    return this.getWrapNodeObject(this.pluginInstance
        .cloneNode(psXPath, vnDeep));
  };
  /**
   * Instance의 하위Node를 넘겨받은 XPath로 조회하여 자바스크립트로 배열화할 수 있는 문자열을 반환하는 메소드
   * @param {String} psXpath 조회할 Xpath
   * @return 문자열화 된 Node List
   * @type String
   */
  this.selectNodesStr = function(psXPath) {
    return String(this.pluginInstance.selectNodesStr(psXPath));
  };
  /**
   * 해당 XPath 하위에 두번째 파라미터로 넘어온 XML Text Node구조를 생성한다.
   * @param {String} psXpath 생성할 Node의 Parent Node가 될 Node의 XPath
   * @param {String} psTxt 생성할 Node XML Text
   * @return void
   * @type void
   */
  this.appendNodeByTxt = function(psXPath, psTxt) {
	this.pluginInstance.appendNodeByTxt(psXPath, psTxt);
  };
};
