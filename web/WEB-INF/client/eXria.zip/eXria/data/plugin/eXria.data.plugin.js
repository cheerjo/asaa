﻿/**
 * @fileoverview
 * eXria.data.plugin Package
 */
/**
 * eXria.data.plugin package
 * @author Choe, hyeon jong.
 */ 
eXria.data.plugin = {}