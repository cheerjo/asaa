﻿/**
 * @fileoverview
 * Plugin Mode 사용시 파일의 추가 및 삭제 이동등을 담당하는 클래스
 */
/**
 * Plugin Mode 사용시 파일의 추가 및 삭제 이동등을 담당하는 클래스
 * @version 1.0
 * @author Choe, hyeon jong.
 * @param {eXria.data.plugin.FsoCmd} poFso
 * @constructor
 * @type eXria.data.plugin.FsoCmd
 * @return void
 */ 
eXria.data.plugin.FsoCmd = function(poFso, poModel) {
  /**
   * model
   * @type eXria.form.Model
   */
  this.model = poModel;
  /**
   * fso
   * @type eXria.data.plugin.FsoCmd
   * @private
   */
  this.fso = poFso;
  /**
   * 파일 오픈을 읽기전용으로 할 경우 선택.
   * @type Number
   */
  this.ETBFTYPE_READONLY = this.fso.ETBFTYPE_READONLY;
  /**
   * 파일 오픈을 쓰기전용으로 할 경우 선택. 기존 자료 있을 시에 삭제 된다.
   * @type Number
   */
  this.ETBFTYPE_WRITEONLY = this.fso.ETBFTYPE_WRITEONLY;
  /**
   * 파일 오픈을 읽고쓰기로 할 경우 선택.
   * @type Number
   */
  this.ETBFTYPE_READWRITE = this.fso.ETBFTYPE_READWRITE;
  /**
   * 파일 오픈을 추가 모드로 할 경우 선택. 파일 내용의 맨 뒤부터 자료가 저장 되어진다.
   * @type Number
   */
  this.ETBFTYPE_APPEND = this.fso.ETBFTYPE_APPEND;
  /**
   * 파일 오픈을 이진파일로 할 경우 선택.
   * @type Number
   */
  this.ETBFTYPE_BINARY = this.fso.ETBFTYPE_BINARY;
  /**
   * 파일 내용 저장 문자코드가 ansi일 경우 선택.
   * @type Number
   */
  this.ETBFFORMAT_ASCII = this.fso.ETBFFORMAT_ASCII;
  /**
   * 파일 내용 저장 문자코드가 UTF8일 경우 선택.
   * @type Number
   */
  this.ETBFFORMAT_UTF8 = this.fso.ETBFFORMAT_UTF8;
  /**
   * 파일 내용 저장 문자코드가 UTF8 NOBOM일 경우 선택.
   * @type Number
   */
  this.ETBFFORMAT_UTF8_NOBOM = this.fso.ETBFFORMAT_UTF8_NOBOM;
  /**
   * 파일 내용 저장 문자코드가 UTF16일 경우 선택.
   * @type Number
   */
  this.ETBFFORMAT_UTF16 = this.fso.ETBFFORMAT_UTF16;
  /**
   * 파일 내용 저장 문자코드가 UTF16 NOBOM일 경우 선택.
   * @type Number
   */
  this.ETBFFORMAT_UTF16_NOBOM = this.fso.ETBFFORMAT_UTF16_NOBOM;
	
  /**
   * 열기 대화상자시 단일선택을 가능하게 한다.
   * @type Number
   */
  this.ETBFPICKEROPEN = this.fso.ETBFPICKEROPEN;
  /**
   * 열기 대화상자시 다중선택을 가능하게 한다.
   * @type Number
   */
  this.ETBFPICKERMUILTI = this.fso.ETBFPICKERMUILTI;
  /**
   * 열기 대화상자시 다중선택을 가능하게 한다.
   * @type Number
   */
  this.ETBFPICKEROPENMUILTI = this.fso.ETBFPICKEROPENMUILTI;
  /**
   * 저장 대화상자를 연다.
   * @type Number
   */
  this.ETBFPICKERSAVE = this.fso.ETBFPICKERSAVE;
  /**
   * 폴더 선택 전용 대화상자를 연다.
   * @type Number
   */
  this.ETBFPICKERFOLDER = this.fso.ETBFPICKERFOLDER;
  /**
   * File을 복사한다.
   * @param {String} psSource 원본 File Path
   * @param {String} psDestination 대상 File Path
   * @param {Boolean} pbOverWrite 덮어쓰기 유무
   * @return 복사 실패시 false 리턴
   * @type Boolean
   */
  this.copyFile = function(psSource, psDestination, pbOverWrite) {
	return this.fso.copyFile(psSource, psDestination, pbOverWrite);
  };
  /**
   * Folder를 주어진 경로에 create 한다.
   * @param {String} psFolderName create할 path
   * @return 실패시 false 리턴
   * @type Boolean
   */
  this.createFolder = function(psFolderName) {
	return this.fso.createFolder(psFolderName);
  };
  /**
   * File을 삭제한다.
   * @param {String} psFileName 삭제 대상의 File Path
   * @param {String} psForce 미 정의 (""입력)
   * @return 실패시 false 리턴
   * @type Boolean
   */
  this.deleteFile = function(psFileName, psForce) {
	return this.fso.deleteFile(psFileName, psForce);
  };
  /**
   * 조회대상 드라이브가 존재하는지 검사
   * @param {String} psDriveSpec 조회 할 드라이브 지정
   * @return 조회대상 드라이브가 존재하면 true
   * @type Boolean
   */
  this.driveExists = function(psDriveSpec) {
	return this.fso.driveExists(psDriveSpec);
  };
  /**
   * 조회 대상 File이 존재하는지 검사
   * @param {String} psFileSpec 조회대상 File Path
   * @return 조회대상 File이 존재하면 true
   * @type Boolean
   */
  this.fileExists = function(psFileSpec) {
	return this.fso.fileExists(psFileSpec);
  };
  /**
   * 조회 대상의 Folder가 존재하는지 검사
   * @param psFolderSpec
   * @return 조회대상 Folder Path
   * @type Boolean
   */
  this.folderExists = function(psFolderSpec) {
	return this.fso.folderExists(psFolderSpec);
  };
  /**
   * File을 이동한다.
   * @param {String} psSource 원본 File Path
   * @param {String} psDestination 대상 File Path
   * @return 이동 실패시 false 리턴
   * @type Boolean
   */
  this.moveFile = function(psSource, psDestination) {
	return this.fso.moveFile(psSource, psDestination);
  };
  /**
   * Text File을 주어진 option으로 open하고 FoCmd 인터페이스를 얻는다.
   * @param {String} psFileName open대상의 File Path
   * @param {Number} pnIoMode 입출력에 대한 Option 설정 [eXria.data.plugin.IOMode 참조]
   * @param {Boolean} pbCreate true : file을 새로 생성하고 기존파일이 없으면 만들고 있으면 덮어씀. false : 존재하는 파일을 open할때 기존 파일이 있어야함.
   * @param {Number} pnFormat 인코딩 설정 [eXria.data.plugin.EncType 참조]
   * @return FoCmd 타입의 File Object를 다루기 위한 인터페이스
   * @type eXria.data.plugin.FoCmd
   */
  this.openTextFile = function(psFileName, pnIoMode, pbCreate, pnFormat) {
	return new eXria.data.plugin.FoCmd(this.fso.openTextFile(psFileName, pnIoMode, pbCreate, pnFormat), this.model);
  };
  /**
   * 조회대상 폴더의 파일 목록을 문자열로 리턴한다.
   * @param {String} psPathSpec 조회 대상 경로
   * @return psPathSpec 위치의 파일들을 ';' 구문자를 통하여 파일명을 리턴
   * @type String
   */
  this.getFileList = function(psPathSpec) {
	return this.fso.getFileList(psPathSpec);
  };
  /**
   * File Open, Save 대화상자를 사용자에게 보여주고 선택 가능하게 한다.
   * @param {String} psTitle 파일 선택 다이얼로그의 타이틀명을 설정
   * @param {String} psInitFileName 다이얼로그에 기본 파일 이름을 설정
   * @param {String} psFilter 확장자의 선택 콤보를 만든다.
   * @param {Number} pnPickerFlag 
	 * @param {String} psFilePath 사용자에게 처음으로 보여 줄 Path 지정
   * @return 선택된 파일명이 리턴, 다중선택 파일은 ';' 구분자로 연결됨
   * @type String
   */
  this.showFilePicker = function(psTitle, psInitFileName, psFilter, pnPickerFlag, psFilePath) {
	if(!psFilePath) psFilePath = null;
	return this.fso.showFilePicker(psTitle, psInitFileName, psFilter, pnPickerFlag, psFilePath);
  };
  /**
   * 외부명령을 실행한다.
   * @param {String} psPathSpec 실행하고자 하는 파일의 path
   * @return void
   * @type void
   */
  this.executeFile = function(psPathSpec) {
	this.fso.executeFile(psPathSpec);
  };
  /**
   * 클라이언트 파일의 권한을 변경한다.
   * @param {String} psFileName 권한설정 대상의 File Path
   * @paran {Number} pnPermission 권한설정 Flag
   * @return 실패시 false 리턴
   * @type Boolean
   */
  this.chmod = function(psFileName, pnPermission) {
	  return this.fso.chmod(psFileName, pnPermission);
  };
};