﻿/**
 * @fileoverview
 * Collection으로 wrapping 되어 있는 클래스에 대해 Iterator로 warpping 하는 클래스
 */
/**
 * Collection으로 wrapping 되어 있는 클래스에 대해 Iterator로 warpping 하는 클래스
 * @constructor
 * @param {eXria.data.Collection} poCollection Iterator로 변환할 Collection 오브젝트
 */
eXria.data.Iterator = function(poCollection) {
  /**
   * Iterator로 변환할 Collecton Object
   * @type eXria.data.Collection
   * @private
   */
  this.collection = poCollection.elements;
  /**
   * cursor
   * 현재 참조하고 있는 Iterator 요소의 위치 값 저장
   */
  this.cursor = -1;
  /**
   * 다음에 참조할 Iterator의 요소의 존재여부를 반환하는 메소드.
   * 함수 호출 후 커서(Iterator 요소의 위치) 값이 하나 증가 됨.
   * @return 다음에 참조할 Iterator의 요소가 있다면 TRUE, 없다면 FALSE
   * @type Boolean
   */
  this.hasNext = function() {
    //if(this.cursor < this.collection.length - 1) {
  if(this.cursor < this.collection.length - 1) {
      this.cursor++;
      return true;
    }
    return false;
  };
  /**
   * 현재 커서 값의 Iterator 요소를 반환하는 메소드
   * @throws 현재 커서 값이 유효하지 않을 경우 IndexOutOfBoundsException이 발생됨
   * @return 현재 커서 값의 Iterator 요소
   * @type Object
   */
  this.next = function() {
    //if (this.cursor >= this.collection.length) {
  if(this.cursor >= this.collection.length) {
      throw new Error("No such element.");
    }
    return this.collection[this.cursor];
  };
};
