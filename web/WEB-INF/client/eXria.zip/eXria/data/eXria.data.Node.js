﻿/**
 * @fileoverview
 * Node Object를 관리하기 위한 Interface
 */
/**
 * Node Object를 관리하기 위한 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {Node} poNode XML Node
 * @constructor
 */
eXria.data.Node = function(poNode) {
  /**
   * Node Object
   * @type Node
   * @see Node
   */
  this.node = null;
  /**
   * Node Name
   * @type String
   */
  this.name = null;
  /**
   * 파라미터로 넘어온 Node를 자식 Node의 마지막에 추가한다.
   * @param {eXria.data.Node} poNode 추가할 Node Object
   * @type void
   * @return void
   */
  this.appendChild = null;
  /**
   * 현재 Node와 동일한 Node를 복사하여 리턴한다.
   * @param {Boolean} pbDeep deep copy 유무를 지정한다. (true | false)
   * @return 복사된 Node Object
   * @type eXria.data.Node
   */
  this.cloneNode = null;
  /**
   * 현재 Node의 자식 Node들을 NodeList 형식으로 리턴한다.
   * @type eXria.data.NodeList
   * @return 생성된 자식 Node List
   */
  this.getChildNodes = null;
  /**
   * 현재 Node의 첫번째 자식 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 첫번째 자식 Node
   */
  this.getFirstChild = null;
  /**
   * 현재 Node의 마지막 자식 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 마지막 자식 Node
   */
  this.getLastChild = null;
  /**
   * 현재 Node의 바로 다음 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 다음 Node
   */
  this.getNextSibling = null;
  /**
   * 현재 Node의 이름을 리턴한다.
   * @type String
   * @return 현재 Node의 이름
   */
  this.getNodeName = null;
  /**
   * 현재 Node의 value를 리턴한다.
   * @type String
   * @return 현재 Node의 Value
   */
  this.getNodeValue = null;
  /**
   * 현재 Node의 부모 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 부모 Node
   */
  this.getParentNode = null;
  /**
   * 현재 Node의 바로 전 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 바로 전 Node
   */
  this.getPreviousSibling = null;
  /**
   * Element를 생성하여 리턴한다.
   * @param {String} psTagName 생성할 Element의 Tag Name
   * @param {String} psValue 생성할 Element의 Value [ null을 넘길 경우 TextNode가 생성되지 않은 Element 리턴 ]
   * @type eXria.data.Node
   * @return 생성된 Element
   */
  this.createElement = null;
  /**
   * TextNode를 생성하여 리턴
   * @param {String} psValue 생성할 Node의 Value값
   * @type eXria.data.Node
   * @return 생성된 TextNode
   */
  this.createTextNode = null;
  /**
   * 현재 Node의 자식 Node 유무를 리턴한다.
   * @type Boolean
   * @return 자식 Node의 존재 유무
   */
  this.hasChildNodes = null;
  /**
   * 현재 Node의 자식 Node 중 파라미터로 넘어온 Node와 일치하는 Node를 삭제한다.
   * @param {eXria.data.Node} poNode 삭제할 Node
   * @type eXria.data.Node
   * @return 삭제된 Node
   */
  this.removeChild = null;
  /**
   * 현재 Node의 Value 파라미터로 넘어온 데이터로 변경한다.
   * @param {String} psValue 변경할 데이터
   * @type void
   * @return void
   */
  this.setNodeValue = null;
  /**
   * 두번째 파라미터로 넘어온 Node와 동일한 Node가 있을 경우 해당 위치에 첫번째 파라미터로 넘어온 Node를 셋팅.
   * @param {eXria.data.Node} poNewNode 추가할 Node
   * @param {eXria.data.Node} poOldNode 덮어 쓸 Node
   * @type eXria.data.Node
   * @return 삭제된 Node
   */
  this.replaceChild = null;
  /**
   * 두번째 파라미터로 넘어온 Node의 앞에 첫번째로 넘어온 파라미터 Node를 추가한다.
   * @param {eXria.data.Node} poNewNode 추가할 Node
   * @param {eXria.data.Node} poRefNode 덮어 쓸 Node
   * @type eXria.data.Node
   * @return insert 되기 전 Node
   */
  this.insertBefore = null;
  /**
   * node type을 리턴한다.
   * @type Number
   * @return 해당 Node의 node Type
   */
  this.getNodeType = null;
  /**
   * 현재 클래스의 이름을 반환 한다.
   * @type String
   * @return Class Name
   */
  this.toString = null;
  /**
   * 노드의 특정 속성 반환한다.
   * @param {String} psAttr 속성 명
   * @type String
   * @return 노드의 해당 속성 값
   */
  this.getAttribute = null;
  /**
   * 노드의 특정 속성 값을 설정한다.
   * @param {String} psAttr 속성 명
   * @param {String} psValue 속성 값
   */
  this.setAttribute = null;
  /**
   * 파라미터로 넘어온 Node와 현재 Node가 같은 Node인지 비교한다.
   * @param {eXria.data.Node} poNode 비교할 Node
   * @return 두개의 Node가 같은 Node인지 유무
   * @type Boolean
   */
  this.equal = null;
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Node
   * @return Node Object
   */
  this.getElementByTagName = null;
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.NodeList
   * @return NodeList Object
   */
  this.getElementsByTagName = null;
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Node
   * @return Node Object
   */
  this.getElementByTagNameFromChildNodes = null;
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Collection
   * @return eXria.data.Collection Object
   */
  this.getElementsByTagNameFromChildNodes = null;
  /**
   * 현재 Node의 XML 스트링을 리턴.
   * @type String
   * @return XML String
   */
  this.getXML = null;
};
