/**
 * @fileoverview
 * eXria.data package
 */
/**
 * eXria.data package
 * @author Kim, Min Seok
 * @version 1.0
 */
eXria.data = {};
