﻿/**
 * @fileoverview
 * Node Type을 상수정의 한 클래스</br>
 * enum list</br>
 * - eXria.data.NodeType.ELEMENT</br>
 * - eXria.data.NodeType.ATTRIBUTE</br>
 * - eXria.data.NodeType.TEXT</br>
 * - eXria.data.NodeType.CDATA_SECTION</br>
 * - eXria.data.NodeType.COMMENT</br>
 * - eXria.data.NodeType.DOCUMENT
 */
/**
 * Node Type을 상수정의 한 클래스
 * @author Choe, Hyeon Jong
 * @version 1.0
 * @constructor
 */
eXria.data.NodeType = {
  ELEMENT     : 0X0000,
  ATTRIBUTE   : 0X0001,
  TEXT      : 0X0002,
  CDATA_SECTION : 0X0004,
  COMMENT     : 0X0008,
  DOCUMENT    : 0X0010
};