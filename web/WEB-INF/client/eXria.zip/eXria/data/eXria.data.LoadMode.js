﻿/**
 * @fileoverview
 * DOM Document Load시 기존 Document의 DOM을 대체할지 추가할지를 결정하는 상수 클래스</br>
 * enum list</br>
 * - REPLACE : 기존의 DOM 삭제 후 생성
 * - APPEND : 기존의 DOM 에 추가
 */
/**
 * DOM Document Load시 기존 Document의 DOM을 대체할지 추가할지를 결정하는 상수 클래스
 * enum(eXria.data.LoadMode.REPLACE, eXria.data.LoadMode.APPEND)
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.data.LoadMode = {
  REPLACE : 1,
  APPEND  : 2
};