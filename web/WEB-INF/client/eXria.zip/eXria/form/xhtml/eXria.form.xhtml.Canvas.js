/**
 * @fileoverview
 * 화면에 표시되는 모든 객체 및 이벤트를 관리하는 클래스
 */

/**
 * 화면에 표시되는 모든 객체 및 이벤트를 관리하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {String} psId Canvas Id
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 * @base eXria.form.Canvas
 */
eXria.form.xhtml.Canvas = function(psId, poPage) {
  /**
   * base
   * @private
   */
  var base = this;
  /**
   * 현재 Canvas 내부에서 일어나는 event를 관리하는 Object
   * @type eXria.event.EventManager
   * @private
   */
  this.eventManager = new eXria.event.EventManager();
  /**
   * tab index
   * @type Number
   * @private
   */
  this.tabIndex = -1; //@private
  /**
   * access key
   * @type Number
   * @private
   */
  this.accessKey = null; //@private
  /**
   * focus control
   * @type Number
   * @private
   */
  this.focusedControl = null; //@private
  /**
   * const key
   * @private
   */
  this.constKey = {
    TAB: 9,
    ALT: 18,
    0: 48,
    9: 57,
    A: 65,
    Z: 90,
    pad0: 96,
    pad9: 105
  };
  /**
   * context menu id
   * @type Number
   * @private
   */
  this.contextMenuId = null;
  /**
   * selected context menu id
   * @type Number
   * @private
   */
  this.selectedContextMenuId = null;  //@private
  /**
   * left
   * readonly
   * @type Number
   * @private
   */
  this.left = 0;  // readonly
  /**
   * top
   * readonly
   * @type Number
   * @private
   */
  this.top = 0;   // readonly
  /**
   * Canvas의 Width
   * @type Number
   */
  this.width = 1024;
  /**
   * Canvas의 Height
   * @type Number
   */
  this.height = 768;
  /**
   * Canvas backgound color
   * @type String
   */
  this.backgroundColor = null;
  /**
   * Canvas backgound image
   * @type String
   */
  this.backgroundImage = null;
  /**
   * Canvas backgound position
   * @type String/Number
   */
  this.backgroundPosition = null;
  /**
   * Canvas backgound repeat
   * @type String
   */
  this.backgroundRepeat = null;

  /**
   * Canvas Color
   * @type String
   */
  this.color = null;              // 컨트롤에 전파되는 속성
  /**
   * Canvas font-Family
   * @type String
   */
  this.fontFamily = null;         // 컨트롤에 전파되는 속성
  /**
   * Canvas font-Size
   * @type Number
   */
  this.fontSize = null;           // 컨트롤에 전파되는 속성
  /**
   * Canvas font-Style
   * @type String
   */
  this.fontStyle = null;          // 컨트롤에 전파되는 속성
  /**
   * Canvas font-Weight
   * @type String
   */
  this.fontWeight = null;         // 컨트롤에 전파되는 속성
  /**
   * Canvas focus-BorderColor
   * @type Number
   */
  this.focusBorderColor = null;   // 컨트롤에 전파되는 속성
  /**
   * Canvas focus-BorderStyle
   * @type String
   */
  this.focusBorderStyle = null;   // 컨트롤에 전파되는 속성
  /**
   * Canvas focus-BorderWidth
   * @type Number
   */
  this.focusBorderWidth = null;     // 컨트롤에 전파되는 속성

  /**
   * Canvas 의 CSS를 저장하고 있는 Map
   * @type eXria.data.ArrayMap
   */
  this.cssClassMap = new eXria.data.ArrayMap();
  
  this.recursiveCnt = 0;
  this.recursiveMap = new eXria.data.ArrayMap();

  /**
   * ctrl
   * @type Object
   * @private
   */
  this.ctrl = null;
  /**
   * @private
   */
  this.eventControlMap = null;
  /**
   * @private
   */
  this.delayedKeydown = new eXria.data.ArrayCollection();

  this.tooltipHandler = {
     //backgroundImage : "eXria/controls/xhtml/images/arrow.gif", // arrowImage
    rightBottomImage   : null,
    leftBottomImage    : null,
    rightTopImage      : null,
    leftTopImage       : null,
    borderWidth        : null,
    borderStyle        : null,
    borderColor        : null,
    backgroundColor    : null,
    fontSize           : null,
    filter             : null,
    opacity            : null,
    width              : null,
    height             : null,
    fontFamily         : null,
    fontStyle          : null,
    fontWeight         : null,
    padding            : null,
    paddingLeft        : null,
    paddingRight       : null,
    paddingTop         : null,
    paddingBottom      : null,
    backgroundImage    : null,
    backgroundPosition : null,
    backgroundRepeat   : null
  };
  /**
   * 컨트롤에 전파되는 툴팁 속성
   */
  /*
  this.tooltip = {
    backgroundImage : "eXria/controls/xhtml/images/arrow.gif", // arrowImage
    borderColor : "#317082",
    borderStyle : "solid",
    borderWidth : 2,
    color : null,
    backgroundColor : "#FFFFFF",
    fontSize : 10,
    filter : "alpha(opacity:70)",
    opacity : "0.70"
  };
  */
  //this.tooltip = null;
  /**
   * @private
   */
  this.df = {};

  /**
   * inherit
   */
  eXria.form.Canvas.call(this, psId, poPage);

  /**
   * canvas 초기화
   * @return void
   * @type void
   * @private
   */
  this.init = function() {
    var voDocument = this.page.window.document;
//    this.loadCssClassMap();

    var voCtrl = voDocument.createElement("div");
    voCtrl.id = this.id;
    voCtrl.tabIndex = 0;

    var vnIEVer = this.page.metadata.browser.ie;
    if(vnIEVer > 0 && vnIEVer < 8) {
      voCtrl.hideFocus = true;
    } else {
      voCtrl.style.outlineStyle = "none";
    }

    voDocument.id = this.id;

    this.eventManager.addListener(voDocument, "onclick", this.mediateEvent);
    this.eventManager.addListener(voDocument, "ondblclick", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onmousedown", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onmouseup", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onmouseover", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onmousemove", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onmouseout", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onkeypress", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onkeydown", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onkeyup", this.mediateEvent);
    this.eventManager.addListener(voDocument, "onmousewheel", this.mediateEvent);

    //TODO theme theme
    //voCtrl.className = eXria.theme.DefaultStyle.CANVAS;
    //page style setup ?
    voDocument.body.appendChild(voCtrl);

    //html control set 20081127
    this.ctrl = voCtrl;

    // ContextMenu -> UI 컨트롤의 우클릭 시 표시되는 브라우저 기본 메뉴를 제한
    voDocument.oncontextmenu = function() {
      return false;
    };
    this.refresh();
  };
  /**
   * load css class map
   * @private
   */
  this.loadCssClassMap = function() {
    var voCssClassMap = this.cssClassMap;
    var voStyleSheets = this.page.window.document.styleSheets;
    var voStyleSheet = null;
    var voRules = null;
    var voRule = null;
    for (var s = 0; s < voStyleSheets.length; s++) {
      voStyleSheet = voStyleSheets[s];
      try {
        if(voStyleSheet.rules) {                       // IE와 Safari
          voRules = voStyleSheet.rules;
        }
        else if(voStyleSheet.cssRules) {               // FireFox와 Opera
          voRules = voStyleSheet.cssRules;
        }
        for (var r = 0; r < voRules.length; r++) {
          voRule = voRules[r];
          voCssClassMap.put(voRule.selectorText, voRule.style);
        }
      } catch(err) {}
    }
  };

  /**
   * 속성에 대한 값을 리턴
   * @private
   */
  this.getAttrValue = function(psAttrName, psAttrValue) {
    if(psAttrValue != null) {
      return psAttrValue;
    } else {
      var vsAttrValue = null;
      //if(this.canvas)  vsAttrValue = this.canvas.getFormExtendAttrValue(psAttrName);
      if(vsAttrValue != null) {
        return vsAttrValue;
      } else {
        vsAttrValue = this.getDefaultValue(psAttrName);  // TODO : 위의 소스로 교체할것
        return vsAttrValue;
      }
    }
  };
  /**
   * canvas의 default 속성값을 리턴
   * @param {String} psAttrName 속성명
   * @return 속성명에 해당하는 속성값
   * @type String
   */
  this.getDefaultValue = function(psAttrName){
    var vaAttrName = psAttrName.split(".");
    var vsDefaultValue = null;
    if(vaAttrName.length == 1) {
      vsDefaultValue = eXria.controls.xhtml.Default.Form[psAttrName];
    } else if (vaAttrName.length == 2) {
      vsDefaultValue = eXria.controls.xhtml.Default.Form[vaAttrName[0]][vaAttrName[1]] != null ? eXria.controls.xhtml.Default.Form[vaAttrName[0]][vaAttrName[1]] : vsDefaultValue;
    }
    if( vsDefaultValue === undefined) {
      //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
      return null;
    }
    return vsDefaultValue;
  };

  /**
   * Canvas 내부의 모든 객체에 대해 새로 고침을 수행한다.
   * @return void
   * @type void
   */
  this.refresh = function() {
    /* style */
    this.df = {};
    var voDf = this.df;
    var voCtrl = this.getCtrl();

  // yhkim 2009.09.16  최외곽에도 class를 적용해줘야 한다.
  voCtrl.className = "Default_Form_Class";

    voCtrl.style.position = "absolute";
    voCtrl.style.overflow = "hidden";
    voCtrl.style.top = "0px";
    voCtrl.style.left = "0px";

    this.backgroundColor = this.getAttrValue("backgroundColor", this.backgroundColor);
    this.backgroundImage = this.getAttrValue("backgroundImage", this.backgroundImage);
    if(this.backgroundImage != null) {
      this.backgroundImage = eXria.controls.xhtml.Util.getBackgroundImagePath(this.backgroundImage, this.page.window);
    }
    this.backgroundPosition = this.getAttrValue("backgroundPosition", this.backgroundPosition);
    this.backgroundRepeat = this.getAttrValue("backgroundRepeat", this.backgroundRepeat);

    if(this.backgroundColor) {
        voCtrl.style.backgroundColor = this.backgroundColor;
      }
    if(this.backgroundImage !== null ) {
      if(this.backgroundImage === '') this.backgroundImage = 'none';
    voCtrl.style.backgroundImage = this.backgroundImage;
      if(this.backgroundRepeat) {
          voCtrl.style.backgroundRepeat = this.backgroundRepeat;
      } else {
        //voCtrl.style.backgroundRepeat = "no-repeat";
      }
    }
    if(this.backgroundPosition) {
      voCtrl.style.backgroundPosition = this.backgroundPosition;
    } else {
      //voCtrl.style.backgroundPosition = "center center";
    }

    if(this.width) voCtrl.style.width = "" + this.width + "px";
    else voCtrl.style.width = "100%";
    if(this.height) voCtrl.style.height = "" + this.height + "px";
    else voCtrl.style.height = "100%";
    /* style */

    var voProgressCtrl = page.model.progressCtrl;
    if(voProgressCtrl) {
      voProgressCtrl.style.left = (this.width - page.model.pgImgWh) / 2 + "px";
      voProgressCtrl.style.top = (this.height - page.model.pgImgHt) / 2 + "px";
    }
  };

  /**
   * 페이지 내부의 최상위 div를 리턴
   * @return 페이지 내부의 최상위 div 객체
   * @type Object
   */
  this.getCtrl = function() {
  return this.ctrl; //20081127
    //return this.page.window.document.getElementById(this.id);
  };

  /**
   * 넘어온 속성에 맞춰 해당 control을 생성한다.
   * @param {String} psType type
   * @param {String} psId id
   * @param {Number} pnLeft left
   * @param {Number} pnTop top
   * @param {Number} pnWidth width
   * @param {Number} pnHeight height
   * @return eXria.controls.Control
   * @type eXria.controls.Control
   */
  this.createControl = function(psType, psId, pnLeft, pnTop, pnWidth, pnHeight) {
    var voControl = this.getControl(psId);
    if (voControl != null) { throw new Error("Control Id is already exist : " + psId); }
    var voType = eXria.controls.xhtml.ControlTypeProvider.get(psType);
    voControl = new voType(psId, pnLeft, pnTop, pnWidth, pnHeight);
    this.ctlMap.put(psId, voControl);
    return voControl;
  };

  /**
   * 파라미터로 넘어온 컨트롤을 canvas에 추가 시킨다.
   * @param {eXria.control.Control} poControl control
   * @return void
   * @type void
   */
  this.appendControl = function(poControl) {
    var voControl = this.getControl(poControl.id);
    if(voControl != null) { throw new Error("Control is already appended : " + poControl.id); }
    if(poControl.isLoaded()) { throw new Error("Control is already loaded : " + poControl.id); }
    poControl.canvas = this; /* control에  canvas 세팅 */
    poControl.window = this.page.window;
    poControl.document = poControl.window.document;
    var voCtrl = poControl.create();
    var voCanvasCtrl = this.getCtrl();

    if(voCtrl) {
      if(voCanvasCtrl != voCtrl.parentNode) voCanvasCtrl.appendChild(voCtrl);
    }
    this.controls.put(poControl.id, poControl);
    this[poControl.id] = poControl;
    if(poControl.load) {
      poControl.load(poControl.document, poControl);
    }
  };

  /**
   * 다국어 사용시 Container Control에 Import가 있을 경우 문제를 해결하기 위한 메소드
   * @type void
   * @private
   */
  this.appendSubImp = function() {
  var voCtls = this.controls.getValueCollection();
  var voContainer = null, voMoveCtl = null, voTabPageSet = null;
  var voTabPage = null, voImpList = null, voImpName = null, voParent = null;
  var vnCtlLen = 0, vnTabPageLen = 0, vnImpLen = 0;
  var i, j, k, m;

  var voDoc = this.page.window.document;
  var voXhtml = eXria.controls.xhtml;

  for(i = 0, vnCtlLen = voCtls.size() ; i < vnCtlLen ; i++) {
    voContainer = voCtls.get(i);
    if(voContainer instanceof voXhtml.Tab || voContainer instanceof voXhtml.SlideTab) {
    voTabPageSet = (voContainer.tabPageSet) ? voContainer.tabPageSet : voContainer.contentPaneSet;

    for(j = 0, vnTabPageLen = voTabPageSet.size() ; j < vnTabPageLen ; j++) {
      voTabPage = voTabPageSet.get(j);  //subPage 리스트 가져옴
      voImpList = voTabPage.impList;  //impList 가져옴
      if(voImpList.size() == 0) { continue; }
      else {  //list를 가지고 있을때
      for(k = 0, vnImpLen = voImpList.size() ; k < vnImpLen ; k++) {
        voImpName = voImpList.get(k);
        voMoveCtl = voDoc.getElementById(voImpName);
        voMoveCtl = voMoveCtl.parentNode.removeChild(voMoveCtl);
        voParent = voDoc.getElementById(voTabPage.id);
        voParent.appendChild(voMoveCtl);
      }
      }
    }
    } else if(voContainer instanceof voXhtml.FreeForm || voContainer instanceof voXhtml.Group) {
    voImpList = voContainer.impList;
    if(voImpList.size() == 0) { continue; }
    else {
      for(m = 0, vnImpLen = voImpList.size() ; m < vnImpLen ; m++) {
      voImpName = voImpList.get(m);
      voMoveCtl = voDoc.getElementById(voImpName);
      voMoveCtl = voMoveCtl.parentNode.removeChild(voMoveCtl);
      voParent = voDoc.getElementById(voContainer.id);
      voParent.appendChild(voMoveCtl);
      }
    }
    }
  }
  };

  //20081204-1 test
  //
  /**
   * register control
   * 넘어온 control을 canvas에 등록한다.
   * @param {eXria.controls.Control} poControl control
   * @return void
   * @type void
   * @private
   */
  this.registerControl = function(poControl) {
    var voControl = this.getControl(poControl.id);
    if(voControl != null) { throw new Error("Control is already registered : " + poControl.id); }
    this.controls.put(poControl.id, poControl);
    this[poControl.id] = poControl;
  };
  /**
   * unregister control
   * 넘어온 ID의 control이 canvas에 등록되어 있을 경우 등록을 해지한다.
   * @param {String} psId Control ID
   * @return void
   * @type void
   * @private
   */
  this.unregisterControl = function(psId) {
    var voControl = this.getControl(psId);
    if(voControl == null) { throw new Error("Control does not exist : " + psId); }
    if(this.focusedControl == voControl) this.focusedControl = null;
    if(this.collapseControl == voControl) this.collapseControl = null;
    this.controls.remove(psId);
    delete this[psId];
  };

  /**
   * 파라미터로 넘어온 ID의 control을 삭제한다.
   * @param {String} psId Control ID
   * @return void
   * @type void
   */
  this.removeControl = function(psId) {
    var voControl = this.getControl(psId);
    var voCtrl = voControl.getCtrl();
    if(this.focusedControl == voControl) this.focusedControl = null;
    voControl.clear();
    if(voCtrl.parentNode) voCtrl.parentNode.removeChild(voCtrl);
    this.controls.remove(psId);
    delete this[psId];
  };

  /**
   * ContextMenu를 보임
   * @param {String} psId context ID
   * @param {String} psMenuId menu ID
   * @param {Number} pnLeft Left
   * @param {Number} pnTop Top
   * @return void
   * @type void
   */
  this.showContextMenu = function(psId, psMenuId, pnLeft, pnTop) {
    var that = this;
    var voFunc = function(){
      that.hideContextMenu();
      var voDocument = that.page.window.document;
      var voMenuControl = that.getControl(psMenuId);
      if(voMenuControl == null || voMenuControl.visible == false) return;

      var vsDisplay = voMenuControl.ctrl.style.display;
      if(voMenuControl != null && voMenuControl !== undefined && vsDisplay == "none") {
        voMenuControl.baseControlId = psId;
        voMenuControl.left = pnLeft;
        voMenuControl.top = pnTop;
        voMenuControl.isShowing = true;
        voMenuControl.visible = true;
        voMenuControl.refresh();
        that.selectedContextMenuId = psMenuId;
        that.collapseControl = voMenuControl;
      }
    }

    if(!!this.page.metadata.browser.webkit){
      window.setTimeout(voFunc,200);
    } else {
      voFunc();
    }
  };

  /**
   * ContextMenu를 숨김
   * @return void
   * @type void
   */
  this.hideContextMenu = function() {
    if(this.selectedContextMenuId) {
      var voDocument = this.page.window.document;
      var voMenuControl = this.getControl(this.selectedContextMenuId);

      // 컨텍스트 메뉴 자신을 안보이게 처리
      var voMenuCtrl = voDocument.getElementById(voMenuControl.id);
      if(voMenuCtrl) voMenuCtrl.style.display = "none";
      voMenuControl.isShowing = false;

      this.collapseControl = null;

      if(voMenuControl.showedItem) {
        this.hideContextSubMenu(voMenuControl.showedItem);
        voMenuControl.showedItem = null;
      }

      this.selectedContextMenuId = null;
    }
  };
  /**
   * 서브 메뉴가 있는 경우 그 상위 아이템 메뉴까지 찾아가며 안보이게 처리하는 메소드
   * @param {eXria.controls.xhtml.MenuItem} poItem 서브 메뉴를 포함하는 아이템 객체
   * @return void
   * @type void
   * @private
   */
  this.hideContextSubMenu = function(poItem) {
    var voDocument = this.page.window.document;
    var voSubCtrl = voDocument.getElementById(poItem.id + "_SubMenu");
    if(voSubCtrl) voSubCtrl.style.display = "none";
    if(poItem.parent) this.hideContextSubMenu(poItem.parent);
  };

  /**
   * 컨트롤에 전파되는 폼 속성의 값을 구함.
   * @param {String} psAttrName 속성명
   * @return 컨트롤에 전파되는 폼 속성 값
   * @type Object
   * @private
   */
  this.getFormExtendAttrValue = function(psAttrName) {
    if(psAttrName == "color" || psAttrName == "fontFamily" || psAttrName == "fontSize" ||
    psAttrName == "fontStyle" || psAttrName == "fontWeight" || psAttrName == "focusBorderColor" ||
    psAttrName == "focusBorderStyle" || psAttrName == "focusBorderWidth") {
      return this[psAttrName];
    } else {
      return null;
    }
  };

  /**
   * 폼 속성의 디폴트 값을 구함.
   * @param {String} psAttrName 속성 이름
   * @return 넘어온 속성명에 대한 디폴트 값
   * @type String
   */
  this.getFormDefaultValue = function(psAttrName) {
    var vsDefaultValue = eXria.controls.xhtml.Default.Form[psAttrName];
    if(vsDefaultValue === undefined) return null;
    else return vsDefaultValue;
  };
  /**
   * tab index를 설정한다.
   * @param {Number} pnIndex
   * @param {eXria.controls.Control} poControl
   * @return void
   * @type void
   */
  this.setTabIndex = function(pnIndex, poControl) {
    if(pnIndex < 0 || pnIndex > this.controls.size()) {
      throw new Error("TabIndex must be with range(0 ~ " + (this.controls.size()) + ")");
    }
    var vnOldTabIndex = poControl.tabIndex;

    var voControls = this.controls.entries;
    var voControl = null;

    for(var member in voControls) {
      if(voControls[member].tabIndex == pnIndex) {
      voControls[member].tabIndex = vnOldTabIndex;
      break;
      }
    }
    poControl.tabIndex = pnIndex;
  };
  /**
   * mediate event
   * @return Boolean
   * @private
   */
  this.mediateEvent = function(e) {
    try {
      if(e != null || page.metadata.browser.ie != 0) base.runEvent(e, base);
    } catch(err) {
      return false;
    }
  };
  /**
   * run event
   * @param {eXria.controls.Control} poControl
   * @return void
   * @type void
   * @private
   */
  this.runEvent = function(e, poControl){
    var voEvent = new eXria.event.Event(e, this.page.window);
    var vsType = voEvent.type;
    var vsAtEvent = "at" + vsType;    // 컨트롤별 이벤트 처리
    var vsCoEvent = "co" + vsType;    // 공통 이벤트 처리
    var vsOnEvent = "on" + vsType;    // 사용자 지정 이벤트 처리
    var vsFinalEvent = "final" + vsType;    //이벤트 종료 처리
    if(vsType == "mouseover") {
      this.mouseoverObj = null;
    }

    if(vsType == "click" && this.isRClick(voEvent)) return;
    if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
    if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
    if (poControl[vsOnEvent]) { try { poControl[vsOnEvent](voEvent); } catch(err) {} }
    if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
  };

  /**
   * at mouse wheel
   * 마우스 휠 이벤트를 처리한다.
   * @return void
   * @type void
   * @private
   */
//  this.atmousewheel = function(e) {
//    var voTarget = e.target;
//    this.setFocusByControl(null, null, voTarget);
//    this.doCollapseForAllFrame();
//  };
  
  // ContextMenu
  /**
   * at mouse down
   * 마우스 다운 이벤트를 처리한다.
   * @return 왼쪽 마우스 클릭 시 true 리턴, 오른쪽 마우스 클릭 시 context menu 호출
   * @type Boolean
   * @private
   */
  this.atmousedown = function(e) {
//      if (!base.inElement(e, base.id)) {
//        var voTarget = e.target;
//        this.setFocusByControl(null, null, voTarget);
//        }
//      }
    if (base.isRClick(e)) {
      base.showContextMenu(base.id, base.contextMenuId, e.clientX, e.clientY);
    }
  };
  /**
   * 클릭 이벤트를 처리한다.
   * @param {Object} e event
   * @return void
   * @type void
   * @private
   */
  this.atclick = function(e) {
    var voTarget = e.target;
    this.setFocusByControl(null, null, voTarget);
    this.doCollapseForAllFrame();
  };

  /**
   * keydown 이벤트를 처리한다.
   * @param {Object} poEvent event
   * @return void
   * @type void
   * @private
   */
  this.atkeydown = function(poEvent) {
    if(poEvent.target && (poEvent.target.readOnly || (poEvent.target.tagName != "INPUT" && poEvent.target.tagName != "TEXTAREA"))) {
      if(poEvent.keyCode == 8) poEvent.stopEvent();
    }
    if(this.focusedControl && this.focusedControl.toString() == "GridEx") {
      return;
    }
    var vnKeyCode = poEvent.keyCode;
    if((poEvent.ctrlKey) && (vnKeyCode >= this.constKey["0"] && vnKeyCode <= this.constKey["pad9"])) {
      this.onHotKey(poEvent);
      if(this.selectedContextMenuId) poEvent.stopEvent();
      return;
    }

    if((vnKeyCode != this.constKey["TAB"]) &&
      (poEvent.altKey == false || (vnKeyCode < this.constKey["a"] || vnKeyCode > this.constKey["Z"]))) {
        return;
    }

    if(poEvent.altKey) this.onAccessKey(poEvent);
    if(vnKeyCode == this.constKey["TAB"]) this.onTab(poEvent);
    return;
  };

  /**
   * keyup 이벤트를 처리한다.
   * @param {Object} poEvent event
   * @return void
   * @type void
   * @private
   */
  this.atkeyup = function(poEvent) {
    var voCollection = this.delayedKeydown;
    var vnSize = voCollection.size();
    if(vnSize > 0) {
      for(var i = 0; i < vnSize; i++) {
        var voAction = voCollection.get(i);
        voAction(poEvent);
      }
      voCollection.clear();
    }
  };

  /**
   * 마우스 오른쪽 버튼이 눌려졌는지를 체크
   * @return 오른쪽 마우스가 눌렸다면 true, 아니라면 false 리턴
   * @type Boolean
   * @private
   */
  this.isRClick = function(e) {
    return (e.mousebutton == 2) ? true : false;
  };

  /**
   * 이벤트가 Form에서 발생했는지를 확인
   * @param {Object} e event
   * @param {String} psCanvasId
   * @return Boolean
   * @private
   */
  this.inElement = function(e, psCanvasId) {
    if(e.target.id == psCanvasId) return true;
    else if(e.target.parentNode == document && e.target.parentNode.id == psCanvasId) {
      return true;
    }
    else
      return false;
  };
  /**
   * 탭이 눌렸을때를 처리
   * @param {Object} poEvent
   * @return void
   * @type void
   * @private
   */
  this.onTab = function(poEvent) {
//debugger;
    var voContainer = null;
    var voFocusedControl = this.focusedControl;
    if(voFocusedControl) {
      if(voFocusedControl.parent) {
        voContainer = voFocusedControl.parent;
      }
    }
    var vnSize = this.getTabedSize(voContainer);
    var vnTab = this.tabIndex;
    var voControl = null;
    var voSubControls = null;
    var voBegin = null;
    var vbContinue = null;
    var vbOut = null;
    var vnBeginCnt = 0;
    do {
      vbOut = false;
      if(poEvent.shiftKey == true) {
        vnTab--;
        if(vnTab < 1) {
          if(voContainer) {
            if(voContainer instanceof eXria.controls.xhtml.TabPage ||
                voContainer instanceof eXria.controls.xhtml.SlidePage) {
              vnTab = voContainer.parent.tabIndex;
            } else {
              vnTab = voContainer.tabIndex;
            }
            if(voContainer.parent) {
              voContainer = voContainer.parent;
              if(voContainer instanceof eXria.controls.xhtml.Tab ||
                  voContainer instanceof eXria.controls.xhtml.SlideTab) {
                if(voContainer.parent) voContainer = voContainer.parent;
                else voContainer = null;
              }
            } else {
              voContainer = null;
            }
            vnSize = this.getTabedSize(voContainer);
            vbOut = true;
          } else {
            vnTab = vnSize;
          }
        }
      } else {
        vnTab++;
        if(vnTab > vnSize || vnTab == 0) {
          if(voContainer) {
            if(voContainer instanceof eXria.controls.xhtml.TabPage ||
                voContainer instanceof eXria.controls.xhtml.SlidePage) {
              vnTab = voContainer.parent.tabIndex;
            } else {
              vnTab = voContainer.tabIndex;
            }
            if(voContainer.parent) {
              voContainer = voContainer.parent;
              if(voContainer instanceof eXria.controls.xhtml.Tab ||
                  voContainer instanceof eXria.controls.xhtml.SlideTab) {
                if(voContainer.parent) voContainer = voContainer.parent;
                else voContainer = null;
              }
            } else {
              voContainer = null;
            }
            vnSize = this.getTabedSize(voContainer);
            vbOut = true;
          } else {
            vnTab = 1;
          }
        }
      }
      voControl = this.getControlByTabIndex(vnTab, voContainer);
      //voControl의 값이 루프 초기값과 같은 지 비교(무한루프 방지 목적)
      if(voControl == voBegin) {
        vnBeginCnt++;
        if(vnBeginCnt == 2) voControl = null;
      }
      if(voBegin == null) voBegin = voControl;
      if(!vbOut && voControl) {
        voSubControls = null;
        voSubControl = null;
        var voPage = null;
        if(voControl instanceof eXria.controls.xhtml.Group || voControl instanceof eXria.controls.xhtml.FreeForm) {
          voSubControls = voControl.controls;
        } else if(voControl instanceof eXria.controls.xhtml.Tab ||
            voControl instanceof eXria.controls.xhtml.SlideTab) {
          voPage = voControl.getPage(voControl.selectedIndex);
          if(voPage) voSubControls = voPage.controls;
        }
        if(voSubControls) {
          if(poEvent.shiftKey == true) voSubControl = this.getFirstTabedSub(voSubControls, true);
          else voSubControl = this.getFirstTabedSub(voSubControls);
        }
        if(voSubControl) {
          voControl = voSubControl;
          vnTab = voControl.tabIndex;
          if(voControl.parent) vnSize = this.getTabedSize(voControl.parent)
        }
      }
      vbContinue = false;
      if(voControl) {
        if(voControl instanceof eXria.controls.xhtml.Group ||
          voControl instanceof eXria.controls.xhtml.FreeForm ||
            voControl instanceof eXria.controls.xhtml.Tab ||
            voControl instanceof eXria.controls.xhtml.SlideTab) {
          vbContinue = true;
        }
      }

    if(voControl.visible == false || voControl.disabled == true) {
      if(voContainer === null && vnTab >= vnSize) vbContinue = false;
    else vbContinue = true;
    }
    } while(vbContinue)

    if(voControl) this.setFocusByControl(voControl, poEvent);
    poEvent.stopEvent();
  };

  /**
   * getFirstTabCtl
   * @param {eXria.controls.Control} poControls control Collection
   * @return {eXria.controls.Control} control Object
   * @private
   */
  this.getFirstTabCtl = function(poControls){
    var vnSize = poControls.size();
    var voControl = null;
    var voFirstTabedControl = null;

    var vaCList = [], vaGList = [];

    for(var i = 0; i < vnSize; i++) {
      voControl =  poControls.get(i);
      if(voControl.tabIndex > 0) {
        if(voControl.visible != false && voControl.disabled != true) {
          if("Freeform" === voControl.toString() ||
             "SlideTab" === voControl.toString() ||
             "Tab" === voControl.toString() ||
             "Group" === voControl.toString()) {
            vaGList.push(voControl);
          }else{
            vaCList.push(voControl);
          }
        }
      }
    }

    var voFnc = function(a, b){
      if(a.tabIndex < b.tabIndex)
        return -1;
      if(a.tabIndex > b.tabIndex)
        return 1;

      return 0;
    };

    if(!!vaCList[0]){
      vaCList.sort(voFnc);
      vaGList.sort(voFnc);
      voFirstTabedControl = vaCList[0];

      if(!!vaGList[0] && vaCList[0].tabIndex <= vaGList[0].tabIndex && null != vaGList[0].controls){
        voFirstTabedControl = this.getFirstTabCtl(vaGList[0].controls);
      }
    }else if(!!vaGList[0]){
      vaGList.sort(voFnc);
      
      if(!!vaGList[0] <= vaGList[0].tabIndex && null != vaGList[0].controls){
        voFirstTabedControl = this.getFirstTabCtl(vaGList[0].controls);
      }
    }
    
    return voFirstTabedControl;
  };

  /**
   * getFirstTabedSub
   * @param {eXria.controls.Control} poControls control Collection
   * @param {Boolean} pbReverse 재귀호출 유무
   * @param {Number} pnBound parent control의 tab index
   * @return {eXria.controls.Control} control Object
   * @private
   */
  this.getFirstTabedSub = function(poControls, pbReverse, pnBound) {
    var vnSize = poControls.size();
    var voControl = null;
    var voFirstTabedControl = null;
    for(var i = 0; i < vnSize; i++) {
      voControl =  poControls.get(i);
      if(voControl.tabIndex > 0) {
        if(voControl.visible != false && voControl.disabled != true) {
          if(pbReverse) {
            if(voFirstTabedControl == null || voControl.tabIndex > voFirstTabedControl.tabIndex) {
              if(pnBound == null) voFirstTabedControl = voControl;
              else if(voControl.tabIndex < pnBound) voFirstTabedControl = voControl;
            }
          } else {
            if(voFirstTabedControl == null || voControl.tabIndex < voFirstTabedControl.tabIndex) {
              if(pnBound == null) voFirstTabedControl = voControl;
              else if(voControl.tabIndex > pnBound) voFirstTabedControl = voControl;
            }
          }
        }
      }
    }
    var voBound = null;
    if(voFirstTabedControl instanceof eXria.controls.xhtml.Group) {
      voBound = voFirstTabedControl;
      voFirstTabedControl = this.getFirstTabedSub(voFirstTabedControl.controls, pbReverse);
    } else if(voFirstTabedControl instanceof eXria.controls.xhtml.Tab ||
        voFirstTabedControl instanceof eXria.controls.xhtml.SlideTab) {
      voBound = voFirstTabedControl;
      var voPage = voFirstTabedControl.getPage(voFirstTabedControl.selectedIndex);
      if(voPage) {
        voFirstTabedControl = this.getFirstTabedSub(voPage.controls, pbReverse);
      } else {
        voFirstTabedControl = null;
      }
    }
    if(voFirstTabedControl == null && voBound) {
      voFirstTabedControl = this.getFirstTabedSub(voBound.parent.controls, pbReverse, voBound.tabIndex);
    }

    return voFirstTabedControl;
  };

  /**
   * getTabedSize
   * @param {Object} poContainer
   * @return tabedsize
   * @type Number
   * @private
   */
  this.getTabedSize = function(poContainer) {
    var voParent = poContainer;
    if(poContainer == null) {
      poContainer = this;
    }
    var vnCnt = 0;
    var voControls = poContainer.controls
    var vnSize = voControls.size();
    var voCollection = null;
    if(voControls instanceof eXria.data.ArrayMap) {
      //voCollection = voControls.getValueCollection();
      voCollection = voControls.entries;
      for (var member in voCollection) {
    var voControl = voCollection[member];
    // 2009.09.18 yhkim
    if(voControl.tabIndex > 0 && voControl.parent == voParent) {
      vnCnt++;
    }
      }
    } else {
      voCollection = voControls;

      var voControl = null;
      for(var i = 0; i < vnSize; i++) {
        voControl = voCollection.get(i);
        // 2009.09.18 yhkim
    if(voControl.tabIndex > 0 && voControl.parent == voParent) {
          vnCnt++;
        }
      }
    }
//    var voControl = null;
//    for(var i = 0; i < vnSize; i++) {
//      voControl = voCollection.get(i);
//      if(voControl.df.tabIndex > 0 && voControl.parent == voParent) {
//        vnCnt++;
//      }
//    }
    return vnCnt;
  };
  /**
   * getControlByTabIndex
   * @param {Number} pnTabIndex
   * @param {Object} poContainer
   * @return voControl
   * @type eXria.controls.Control
   * @private
   */
  this.getControlByTabIndex = function(pnTabIndex, poContainer) {
    var voParent = poContainer;
    if(poContainer == null) poContainer = this;
    var voControls = poContainer.controls;
//    var voIterator = null;
    var voControl = null;

    if(voControls instanceof eXria.data.ArrayMap) {
      //voIterator = voControls.getValueCollection().iterator();
      var voElements = voControls.entries;
      for(var member in voElements) {
      voControl = voElements[member];
      if(voControl.tabIndex == pnTabIndex && voControl.parent == voParent) {
          break;
        }
      }
    } else {
      var voIterator = voControls.iterator();
      while(voIterator.hasNext()) {
      voControl = voIterator.next();
      if(voControl.tabIndex == pnTabIndex && voControl.parent == voParent) {
        break;
      }
      }
    }
    return voControl;
  };
  /**
   * onAccessKey
   * access key가 눌렸을때의 이벤트 처리
   * @param {Object} poEvent
   * @private
   */
  this.onAccessKey = function(poEvent) {
    var voOldFocusedControl = this.focusedControl;
    var vsKey = String.fromCharCode(poEvent.e.keyCode);
    vsKey = vsKey.toUpperCase();
    var vsControlKey = null;

    var voElements = this.controls.entries;

    var voControl = null;
    var vbPrevious = false, vbCurrent = false;
    if(voOldFocusedControl == null) vbPrevious = true;

    for(var member in voElements) {
      voControl = voElements[member];
      vsControlKey = voControl.accessKey;
      if(vsControlKey != null) vsControlKey = vsControlKey.toUpperCase();
      if(voControl == voOldFocusedControl) {
        if(voControl.setFocusStyle) voControl.setFocusStyle(false);
        if(voControl.doblur) voControl.doblur();
        vbPrevious = true;
      }
      if(vsControlKey == vsKey) {
        if(voControl.setFocusStyle) voControl.setFocusStyle(true);
        if(voControl.dofocus) voControl.dofocus();
        vbCurrent = true;
        this.focusedControl = voControl;
        if(voControl.tabIndex != 0) this.tabIndex = voControl.tabIndex;
      }
      if(vbPrevious && vbCurrent) break;
    }
    poEvent.stopEvent();
  };

  /**
   *  Ctrl + HotKey의 조합에서 HotKey 문자만을 추출.
   *  @param {String} psHotKey
   *  @return HotKey 문자
   *  @type String
   *  @private
   */
  this.getHotKeyChar = function(psHotKey) {
    var vaHotKey = null;
    var vsReturnChar = null;
    if(psHotKey == null || psHotKey === undefined || psHotKey == "") return "";
    vaHotKey = psHotKey.split(" ");
    if(vaHotKey.length == 3) {
        vsReturnChar = vaHotKey[2];
        if(vsReturnChar.length > 2) new Error("HOT Key is not one character");
    } else {
      vaHotKey = psHotKey.split("+");
      vsReturnChar = vaHotKey[0];
    }
    return eXria.util.StringUtil.trim(vsReturnChar).toUpperCase();
  };
  /**
   * onHotKey
   * hot key가 눌렸을 경우의 이벤트 처리
   * @param {Object} poEvent event
   * @return void
   * @type void
   * @private
   */
  this.onHotKey = function(poEvent) {
    var vsKey = String.fromCharCode(poEvent.keyCode);
    var voElements1, voElements2 = null;
    var voChildItem1, voChildItem2 = null;
    var voMenuControl = null;

    if(this.selectedContextMenuId != null) {
      voMenuControl = this.getControl(this.selectedContextMenuId);

      if(voMenuControl && voMenuControl.visible == true) {
        //voIterator1 = voMenuControl.items.getValueCollection().iterator();
      voElements1 = voMenuControl.items.entries;

      for(var member in voElements1) {
        voChildItem1 = voElements1[member];
          if(this.getHotKeyChar(voChildItem1.hotKey) == vsKey) {
            voChildItem1.selected = true;
            voMenuControl.selectedItem = voChildItem1;
            poEvent.objectType = "item";
            poEvent.object = voChildItem1;
            poEvent.baseControlId = voMenuControl.baseControlId;
            if(voMenuControl.atclick) voMenuControl.atclick(poEvent);
            if(voMenuControl.coclick) voMenuControl.coclick(poEvent);
            if(voMenuControl.onclick) voMenuControl.onclick(poEvent);
            this.hideContextMenu();
          }
        if(voMenuControl.showedItem) {
        if(voMenuControl.showedItem.id == voChildItem1.id) {
          voElements2 = voChildItem1.items.entries;
          for(var member2 in voElements2) {
            voChildItem2 = voElements2[member2];

              if(this.getHotKeyChar(voChildItem2.hotKey) == vsKey) {
                  voChildItem2.selected = true;
                  voMenuControl.selectedItem = voChildItem2;
                  poEvent.objectType = "item";
                  poEvent.object = voChildItem2;
                  poEvent.baseControlId = voMenuControl.baseControlId;
                if(voMenuControl.atclick) voMenuControl.atclick(poEvent);
                  if(voMenuControl.coclick) voMenuControl.coclick(poEvent);
                  if(voMenuControl.onclick) voMenuControl.onclick(poEvent);
                    this.hideContextMenu();
              }
            }
          }
        }
      }
    }
    }
  };
  /**
   * setFocus
   * 포커싱이 일어난 컨트롤에 대한 처리를 해준다.
   * @param {Number} pnTabIndex
   * @return void
   * @type void
   * @private
   */
  this.setFocus = function(pnTabIndex) {
    var voOldFocusedControl = this.focusedControl;
    var voElements = this.controls.entries;
    var voControl = null;
    var vbPrevious = false, vbCurrent = false;
    if(voOldFocusedControl == null) vbPrevious = true;

    for(var member in voElements) {
      voControl = voElements[member];
      if(voControl == voOldFocusedControl) {
        if(voControl.setFocusStyle) voControl.setFocusStyle(false);
        if(voControl.doblur) voControl.doblur();
        vbPrevious = true;
        if(voControl.toString && voControl.toString() == "ComboBox") {
          if(voControl != this.focusedControl) voControl.showList(false);
        }
      }

      if(voControl.tabIndex == pnTabIndex) {
        // 2009.07.20 focus시에 그룹 컨트롤 확인하기
        var vnCnt = this.controls.cnt;
        if(vnCnt > 1 && voControl.parent && voControl.parent.toString) {
          var voParent = voControl.parent.toString();
          if( voParent == "Group" || voParent == "SlideTab" ||
              voParent == "FreeForm" || voParent == "SubPage" || voParent == "tab")
            continue;
        }
        this.focusedControl = voControl;
        this.tabIndex = pnTabIndex;
        if(voControl.setFocusStyle) voControl.setFocusStyle(true);
        if(voControl.dofocus) voControl.dofocus();
        vbCurrent = true;
      }
      if(vbPrevious && vbCurrent) return;
    }


    this.clearAllFocus();
  };
  /**
   * setFocusByControl
   * 파라미터로 넘어온 컨트롤에 포커스를 맞춰준다.
   * @param {eXria.controls.Control} poControl
   * @param {eXria.event.Event} poEventToStop
   * @return void
   * @type void
   */
  this.setFocusByControl = function(poControl, poEventToStop) {
    if(poEventToStop) poEventToStop.stopEvent();
    if(!!poControl && !!poControl['disabled']) return;

    var voControl = null;
    voControl = this.focusedControl;
  // 초기 포커스가 없는 경우 부모노드에 포커스를 준다(form,group등)
  // subPage밀리는 현상으로 롤백
//  if(this.focusedControl === null) {
//    if(poControl && poControl.getCtrl() && poControl.getCtrl().parentNode) {
//      poControl.getCtrl().parentNode.focus();
//      poControl.getCtrl().parentNode.blur();
//    }
//  }

    if(voControl) {
      if(voControl.setFocusStyle) voControl.setFocusStyle(false);
      if(voControl.doblur) voControl.doblur();
    }
    this.focusedControl = null;

    var voCollapseControl = this.collapseControl;
    if(voCollapseControl && (voCollapseControl != poControl)) {
      this.doCollapseControl(this);
    }

    if(poControl) {
      if(poControl.setFocusStyle) poControl.setFocusStyle(true);
      this.focusedControl = poControl;
      // 2009.09.18 yhkim
    this.tabIndex = poControl.tabIndex;
      if(poControl.dofocus) poControl.dofocus(poEventToStop);
    } else {
      this.tabIndex = -1;
    }
  };
  /**
   * makeEventControlMap
   * @param {Object} poElement
   * @return voMap
   * @type eXria.data.Map
   * @private
   */
  this.makeEventControlMap = function(poElement) {
    var voMap = new eXria.data.ArrayMap();
    var voParent = null;
    var voControl = null;
    var vsId = null;
    voParent = poElement.parentNode;
    while(voParent) {
      if(voParent.id) vsId = voParent.id;
      if(vsId) {
        voControl = this.getControl(vsId);
        if(voControl) voMap.put(vsId, voControl);
      }
      voParent = voParent.parentNode;
    }
    return voMap;
  };
  /**
   * 컨트롤의 포커싱을 해제한다.
   * @return void
   * @type void
   */
  this.clearFocus = function() {
    //var voIterator = this.controls.getValueCollection().iterator();
  var voElements = this.controls.entries;
    var voControl = null;

    for(var member in voElements) {
      voControl = voElements[member];
      if(voControl.tabIndex == this.tabIndex || voControl == this.focusedControl) {
        if(voControl.setFocusStyle) voControl.setFocusStyle(false);
        this.tabIndex = -1;
        break;
      }
    }
  };
  /**
   * 모든 컨트롤의 포커싱을 해제한다.
   * @return void
   * @type void
   */
  this.clearAllFocus = function() {
    //var voIterator = this.controls.getValueCollection().iterator();
    var voElements = this.controls.entries;
    var voControl = null;

    for(var member in voElements) {
      voControl = voElements[member];
      if(voControl.setFocusStyle) voControl.setFocusStyle(false);
      if(voControl.toString && voControl.toString() == "ComboBox") voControl.showList(false);
      this.tabIndex = -1;
      this.focusedControl = null;
    }
  };
  /**
   * 등록된 이벤트를 해제한다.
   * @return void
   * @type void
   */
  this.clearEvents = function() {
    var voDocument = this.page.window.document;
    var voId = voDocument.id;
    voDocument.oncontextmenu = null;
    voDocument.ondragstart = null;
    var voTargetMember = this.eventManager.events.get(voId + ".onclick");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onclick", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".ondblclick");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "ondblclick", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onmousedown");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onmousedown", this.mediateEvent);
    var voTargetMember = this.eventManager.events.get(voId + ".onmouseup");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onmouseup", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onmouseover");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onmouseover", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onmousemove");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onmousemove", this.mediateEvent);
    var voTargetMember = this.eventManager.events.get(voId + ".onmouseout");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onmouseout", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onkeypress");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onkeypress", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onkeydown");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onkeydown", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onkeyup");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onkeyup", this.mediateEvent);
    voTargetMember = this.eventManager.events.get(voId + ".onmousewheel");
    if(voTargetMember) this.eventManager.removeListener(voDocument, "onmousewheel", this.mediateEvent);
  };

  /**
   * canvas에 속한 모든 컨트롤을 해제.
   * @return void
   * @type void
   * @private
   */
  this.close = function() {
    //canvas에 속한 컨트롤들을 모두 제거한다.
//    for(var member in this) {
//      if(this[member]) {
//        this[member].ctrl = null;
//      }
//    }
//    this.ctrl = null;
  };
  /**
   * getCssStyle
   * 파라미터로 넘어온 classname과 일치하는 class를 리턴한다.
   * @param {String} psClassName class name
   * @return 넘어온 classname과 일치하는 class
   * @type eXria.data.ArrayMap
   * @private
   */
  this.getCssStyle = function(psClassName) {
    return this.cssClassMap.get("." + psClassName);
  };

  this.init();
};
/**
 * @private
 */
eXria.form.xhtml.Canvas.prototype.doCollapseForAllFrame = function() {
  var voTopWindow = this.page.window.top;
  this.doCollapseForWindow(voTopWindow);
};
/**
 * eXria.form.xhtml.Canvas.prototype.doCollapseForWindow
 * @param {Object} poWindow
 * @type Object
 * @return Boolean
 * @private
 */
eXria.form.xhtml.Canvas.prototype.doCollapseForWindow = function(poWindow) {
  var voDocument = null;
  try {
    voDocument = poWindow.document;
  } catch(err) {
    return false;
  }
  var voFrames = voDocument.getElementsByTagName("frame");
  var voFrame = null;
  var voWindow = null;
  var vbBreak = false;
  if(poWindow.page) {
    vbBreak = this.doCollapseOnPage(poWindow.page);
    if(vbBreak) return true;
  }

  for(var i = 0; i < voFrames.length; i++) {
    voFrame = voFrames[i];
    voWindow = voFrame.contentWindow;
    if(voWindow) {
      vbBreak = this.doCollapseForWindow(voWindow);
      if(vbBreak) return true;
    }
  }

  voFrames = voDocument.getElementsByTagName("iframe");
  for(var i = 0; i < voFrames.length; i++) {
    voFrame = voFrames[i];
    voWindow = voFrame.contentWindow;
    if(voWindow) {
      vbBreak = this.doCollapseForWindow(voWindow);
      if(vbBreak) return true;
    }
  }
  return false;
};
/**
 * doCollapseOnPage
 * @param {eXria.form.Page} poPage
 * @type Boolean
 * @return Boolean
 * @private
 */
eXria.form.xhtml.Canvas.prototype.doCollapseOnPage = function(poPage) {
  var voCanvas = poPage.canvas;
  if(voCanvas) {
    if(voCanvas.id == this.id) return false;
    if(voCanvas.focusedControl && voCanvas.focusedControl.doblur) voCanvas.focusedControl.doblur();
    var voCollapseControl = voCanvas.collapseControl;
    if(voCollapseControl) {
      this.doCollapseControl(voCanvas)
      return true;
    } else {
      return false;
    }
  }
  return false;
};
/**
 * doCollapseControl
 * @param {eXria.form.Canvas} poCanvas
 * @return void
 * @type void
 * @private
 */
eXria.form.xhtml.Canvas.prototype.doCollapseControl = function(poCanvas) {
  var voCollapseControl = poCanvas.collapseControl;
  if(!voCollapseControl) return;
  poCanvas.collapseControl = null;
  switch(voCollapseControl.toString()) {
  case "ComboBox" :
    voCollapseControl.showList(false);
    break;
  case "DateInput" :
  case "EditMask" :
    voCollapseControl.calendar.hide();
    break;
  case "ContextMenu" :
    poCanvas.hideContextMenu();
    break;
  }
};
