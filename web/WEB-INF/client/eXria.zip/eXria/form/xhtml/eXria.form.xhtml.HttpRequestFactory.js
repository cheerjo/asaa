/**
 * @fileoverview
 * Browser별 XMLHttpRequest 생성 Factory.
 */

/**
 * Browser별 XMLHttpRequest 생성 Factory.
 * @version 1.0
 * @constructor
 * @private
 */
eXria.form.xhtml.HttpRequestFactory = {
  msxmlNames : ["MSXML2.XMLHTTP.5.0",
                "MSXML2.XMLHTTP.4.0",
                "MSXML2.XMLHTTP.3.0",
                "MSXML2.XMLHTTP",
                "Microsoft.XMLHTTP" ]
  ,
  create : function() {
  /* Microsoft MSXML ActiveX */
  if(window.ActiveXObject !== undefined) {

    for(var i = 0;i < this.msxmlNames.length; i++) {
      try {
      return new ActiveXObject(this.msxmlNames[i]);
      } catch (e) {}
    }
  } else if(window.XMLHttpRequest) {
    /* Mozilla XMLHttpRequest */
    return new XMLHttpRequest();
  } else {
    /* None found */
    return null;
  }
  }
};