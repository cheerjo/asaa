/**
 * @fileoverview
 * CanvasType
 */

/**
 * CanvasType
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 * @private
 */
eXria.form.CanvasType = {
  XHTML : 0,
  FLEX : 1,
  SILVERLIGHT : 2,
  XBUILDER : 3 /* reserved */
};
