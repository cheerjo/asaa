﻿/**
 * @fileoverview
 * Page가 RunTime시 필요로하는 데이터들을 저장하는 클래스
 */

/**
 * Page가 RunTime시 필요로하는 데이터들을 저장하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 */
eXria.form.PageMetadata = function(poPage) {
  /**
   * 현재 Page 객체
   * @type eXria.form.Page
   */
  this.page = poPage;
  /**
   * 현재 Browser를 구분한다.
   * ie, opera, gecko, webkit, mobile로 구분가능하며 해당 Browser의 버전을 저장
   * @type eXria.lang.Browser
   */
  this.browser = new eXria.lang.Browser(this.page);
  /**
   * eXria version
   * @type Number
   */
  this.version = null;
  /**
   * 현재 Page의 url
   * @type String
   */
  this.url = this.page.window.document.URL;
  /**
   * 현재 Page의 url에서 contextpath에 이전 부분
   * @type String
   */
  this.domainUrl = null;
  /**
   * 현재 Page의 Domain
   * @type String
   */
  this.domain = this.page.window.document.domain;
  /**
   * 현재 Page의 referer
   * @type String
   */
  this.referer = this.page.window.document.referer;
  /**
   * base
   * @type Object
   * @private
   */
  this.base = null;
  /**
   * 현재 page type
   * @type Number
   */
  this.pageType = null;
  /**
   * 현재 Page에 포함된 canvas type
   * @type Number
   */
  this.canvasType = null;
  /**
   * 현재 Page에 포함된 model type
   * @type Number
   */
  this.modelType = null;
  /**
   * 현재 Browser의 language
   * @type String
   */
  this.language = null;
  /**
   * AJAX Submission시 호출될 Base URL
   * Server에서 Metadata 호출 시점에 생성하여 내려 보낸다.
   */
  this.submitBaseUrl = null;
  /**
   * static file이 위치하는 url
   * @type String
   */
  this.resourceBaseUrl = null;
  /**
   * 현재 page가 로딩된 화면의 location path 정보 저장
   * @type String
   */
  this.documentBaseUrl = null;
  /**
   * enable during page loading
   * define in web.xml
   * default false
   * @type Boolean
   */
  this.loadingProgressEnabled = false;
  /**
   * eXria Locale
   * @type String
   */
  this.eXriaLocale = null;
  /**
   * availableLocale
   * @type Array
   */
  this.availableLocale = null;
  /**
   * default Locale
   * @type String
   */
  this.defaultLocale =  null;
  /**
   * LocaleList
   * @type Map
   */
  this.localeList = null;
  /**
   * applyOrder
   * @type Array
   */
  this.applyOrder = null;
  /**
   * multi language type
   * @type String
   */
  this.multilingualType = "static";
  /**
   * multi language title
   * @type String
   */
  this.multilingualTitle = null;
  /**
   * eXriaLocale Query Parameter Name
   * @type String
   */
  this.localeParamName = null;
  /**
   * jre plugin log level
   * @type String
   */
  this.logLevel = null;
  /**
   * jre address tmp
   * @type String
   */
  this.jreDownloadAddr = null;
  /**
   * jre plugin info object
   * @type Object
   * @ignore
   */
  this.jre = {};
  /**
   * appletPath
   * @type String
   * @ignore
   */
  this.jre.appletPath = null;
  /**
   * version
   * @type String
   * @ignore
   */
  this.jre.version = null;
  /**
   * initHeapSize
   * @type String
   * @ignore
   */
  this.jre.initHeapSize = null;
  /**
   * maxHeapSize
   * @type String
   * @ignore
   */
  this.jre.maxHeapSize = null;
  /**
   * jvmArgument
   * @type String
   * @ignore
   */
  this.jre.jvmArgument = null;
  /**
   * updateCheck
   * @type String
   * @ignore
   */
  this.jre.updateCheck = null;
  /**
   * updatePolicy
   * @type String
   * @ignore
   */
  this.jre.updatePolicy = null;
  /**
   * offLineAllowed
   * @type String
   * @ignore
   */
  this.jre.offLineAllowed = null;
  /**
   * properties
   * @type String
   * @ignore
   */
  this.jre.properties = null;
};
