﻿/**
 * @fileoverview
 * ModelFactory
 */

/**
 * ModelFactory
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 * @private
 */
eXria.form.ModelFactory = {
  create : function(pnType, poPage) {
    if(poPage.model != null) {
      throw new Error("Model is already created.");
    }

    var vsId = poPage.id + "_model";

    switch(pnType) {
      case eXria.form.ModelType.XHTML :
        return new eXria.form.xhtml.Model(vsId, poPage);
      case eXria.form.ModelType.PLUGIN :
    case eXria.form.ModelType.JRE :
        var voModel = new eXria.form.plugin.Model(vsId, poPage);
        voModel.create();
        return voModel;
      default :
        throw new Error("No such model type : " + pnType);
    }
  }
};
