/**
 * @fileoverview
 * Model Object의 Interface
 */

/**
 * Model Object의 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {String} psId Model Id
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 */
eXria.form.Model = function(psId, poPage) {
  /**
   * id
   * @type String
   */
  this.id = psId;
  /**
   * page Object
   * @type eXria.form.Page
   */
  this.page = poPage;

  /**
   * 서버로 부터 Submission 및 Instance Load
   * @param {String} psUrl server url (synchronization)
   * @return void
   * @type void

   */
  this.loadURL = null;
  /**
   * 넘겨받은 XMLElement를 Node에 Append한다.
   * @param {XMLNode} poXML XML Node
   * @return void
   * @type void
   */
  this.loadXML = null;
  /**
   * 넘겨받은 Text를 Parsing하여 Node에 Append한다.
   * @param {String} psTXT XML Text
   * @return void
   * @type void
   */
  this.loadTXT = null;
  /**
   * loadModel
   * @param {String} psUrl server URL
   * @param {Object} poView UI Object
   * @return void
   * @type void
   */
  this.loadModel = null;

  /**
   * 인스턴스 생성
   * @param {String} psId Instance ID
   * @return 생성된 Instance 리턴
   * @type eXria.data.Instance
   * @see eXria.data.Instance
   */
  this.createInstance = null;
  /**
   * 넘어온 인스턴스를 instance 객체에 붙인다.
   * @param {eXria.data.Instance} poInstance Instance 객체
   * @return void
   * @type void
   */
  this.appendInstance = null;
  /**
   * 넘어온 ID와 일치하는 인스턴스를 찾아 리턴한다.
   * @param {String} psId
   * @return Instance Object
   * @type eXria.data.Instance
   */
  this.getInstance = null;
  /**
   * 넘어온 ID와 일치하는 인스턴스를 찾아 삭제한다.
   * @param {String} psId id
   * @return void
   * @type void
   */
  this.removeInstance = null;

  /**
   * submission을 생성한다.
   * @param {String} psId
   * @return 생성된 Submission
   * @type eXria.protocols.Submission
   * @see eXria.protocols.Submission
   */
  this.createSubmission = null;
  /**
   * 넘어온 submission 객체를 submission에 추가 시킨다.
   * @param {eXria.protocols.Submission} poSubmission submission
   * @return void
   * @type void
   */
  this.appendSubmission = null;
  /**
   * 넘어온 ID와 일치하는 서브미션을 리턴.
   * @param {String} psId
   * @return Submission Object
   * @type eXria.protocols.Submission
   */
  this.getSubmission = null;
  /**
   * 넘어온 ID와 일치하는 Submission을 삭제한다.
   * @param {String} psId Submission ID
   * @return void
   * @type void
   */
  this.removeSubmission = null;

  /**
   * dataset 리턴
   * @param {String} psId
   * @return dataset Object
   * @type eXria.data.DataSetCmd
   * @see eXria.data.DataSetCmd
   */
  this.getDataSet = null;

  /**
   * close
   * @return void
   * @type void
   * @ignore
   */
  this.close = null;

  /**
   * 화면 loading 시 progress bar 출력
   * @param {Boolean} pbShow boolean : true - progress bar 출력, false - progress bar 종료
   * @return void
   * @type void
   */
  this.progressAction = null;

  /**
   * Server Error Message를 전부 삭제한다.
   * @type void
   * @return void
   */
  this.clearErrorMessage = null;

  /**
   * Server Error Message를 반환한다.
   * @param {Boolean} pbCode 에러 코드 리턴 유무
   * @param {Boolean} pbMsg 에러 메세지 리턴 유무
   * @param {Boolean} pbSrc 에러 소스 리턴 유무
   * @type eXria.data.ArrayCollection
   * @return Error String을 담고 있는 Array 객체
   */
  this.getErrorMessage = null;
  /**
   * AES암호화 후 Base64 처리 된 문자열을 복호화 하여 원본 문자열을 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psStr
   * @type String
   * @return Base64 decoding 후 복호화 하여 원본 문자열
   */
  this.decryptStr = null;
  /**
   * plugin 내부 AES 알고리즘으로 입력된 파라미터 문자열을 암호화 하여 Base64 처리 후 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psStr
   * @type String
   * @return 암호화와 Base64처리 된 문자열
   */
  this.encryptStr = null;
  /**
   * 파라미터로 넘어온 이름과 동일한 DB를 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psDBName DB Name
   * @return 넘어온 이름과 동일한 DB를 가져온다.
   * @type Object
   */
  this.getDB = null;
  /**
   * 커넥션 객체를 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return connection 객체
   * @type eXria.data.plugin.DBConnectionCmd
   * @see eXria.data.plugin.DBConnectionCmd
   */
  this.getConnection = null;
  /**
   * 파일시스템 객체를 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return 파일시스템 객체
   * @type eXria.data.plugin.FsoCmd
   */
  this.getFileSystemObject = null;
  /**
   * Client의 IP를 구한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return Client의 IP
   * @type String
   */
  this.getClientIP = null;
  /**
   * Host Name을 구한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return host name
   * @type String
   */
  this.getHostName = null;
  /**
   * 현재 이 플러그인의 버전을 확인한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return 현재 플러그인 버전 정보
   * @type String
   */
  this.getVersion = null;
  /**
   * Logger 인터페이스를 얻는다.<br/>(Plugin Mode 에서만 사용 가능)
   * @type  eXria.form.plugin.Logger
   * @return Logger Object
   */
  this.getLogger = null;
  /**
   * 콤보구분 DataSet ID 리스트 문자열을 반환하는 메소드.<br/>(Plugin Mode 에서만 사용 가능)
   * @type String
   * @return DataSet ID 리스트 (ex. dst1,dst2,dst3)
   */
  this.getDataSetIdList = null;
  /**
   * 콤보구분 인스턴스 ID 리스트 문자열을 반환하는 메소드.
   * @type String
   * @return 인스턴스 ID 리스트 (ex. instance,instance1)
   */
  this.getInstanceIdList = null;
  /**
   * 콤보구분 Submission ID 리스트 문자열을 반환하는 메소드.
   * @type String
   * @return Submission ID 리스트 (ex. sms1,sms2,sms3)
   */
  this.getSubmissionIdList = null;
  /**
   * 현재 클라이언트 PC의 Mac Address를 리턴
   * @type String
   * @return Mac Address
   */
  this.getMacAddr = null;
  
  this.asyncEventQueue = [];
  
  this.asyncEventQueueMap = new eXria.data.ArrayMap();
  
  this.runningStateMap = new eXria.data.ArrayMap();
  
  this.tranIdMap = new eXria.data.ArrayMap();
  
  this.startAsyncEventTransaction = function() {
    var vnSeq = 0;
    var vsSeq = null;
    while(true) {
      vsSeq = vnSeq + "";
      if(this.tranIdMap.get(vsSeq) == null) {
        this.tranIdMap.put(vsSeq, "");
        break;
      }
      vnSeq++;
    }
    this.asyncEventQueueMap.put(vsSeq, []);
    return vsSeq;
  };
  
  this.checkLastInQueue = function(psId) {
    var vaQueue = null;
    if(psId != null) vaQueue = this.asyncEventQueueMap.get(psId);
    else vaQueue = this.asyncEventQueue;
    var vnSize = vaQueue.length;
    var vnRes = 0;
    var voSub = null;
    for(var i = 0; i < vnSize; i++) {
      voSub = vaQueue[i];
      if(voSub.responseState != null) vnRes++;
    }
    return vnSize == vnRes;
  };
  
  this.runCallbacks = function(psId) {
    if(psId != null) this.runningStateMap.put(psId, true);
    else this.gonnaRunCallbacks = true;
    if(this.checkLastInQueue(psId)) this.excuteAndClearCallbacks(psId);
  };
  
  this.excuteAndClearCallbacks = function(psId) {
    var vaQueue = null;
    var vnSize = null;
    if(psId != null) {
      vaQueue = this.asyncEventQueueMap.get(psId);
//      this.asyncEventQueueMap.remove(psId);
      this.runningStateMap.remove(psId);
      this.tranIdMap.remove(psId);
      var voCollection = this.runningStateMap.getValueCollection();
      vnSize = voCollection.size();
      var vbRunning = false;
      for(var i = 0; i < vnSize; i++) {
        if(voCollection.get(i)) {
          vbRunning = true;
          break;
        }
      }
      if(!vbRunning) this.progressAction(false);
    } else {
      vaQueue = this.asyncEventQueue.slice(0);
      this.gonnaRunCallbacks = null;
//      this.asyncEventQueue.length = 0;
      this.progressAction(false);
    }
    
    vnSize = vaQueue.length;
    var voSub = null;
    for(var i = 0; i < vnSize; i++) {
      voSub = vaQueue[i];
      voSub.callback(voSub.responseState);
      voSub.callback = null;
      voSub.asynGrpId = null;
      voSub.responseState = null;
    }
    
    if(psId != null){
      this.asyncEventQueueMap.remove(psId);
    } else {
      this.asyncEventQueue.length = 0;
    }
  };
};
