/**
 * @fileoverview
 * Page 내부의 Canvas 객체에 대한 Interface
 */

/**
 * Page 내부의 Canvas 객체에 대한 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {String} psId Canvas Id
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 */
eXria.form.Canvas = function(psId, poPage) {
  /**
   * Canvas Id
   * @type String
   */
  this.id = psId;
  /**
   * 현재 Canvas를 포함하는 Page Obejct
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.page = poPage;
  /**
   * canvas에 놓여진 컨트롤들을 저장하고 있는 map
   * @type eXria.data.ArrayMap
   * @see eXria.data.ArrayMap
   */
  this.controls = new eXria.data.ArrayMap();
  /**
   * createControl에 의해 생성된 컨트롤을 id를 키로 하여 저장하는 map
   * @type eXria.data.ArrayMap
   */
  this.ctlMap = new eXria.data.ArrayMap();
/* style */
  /**
   * Canvas width
   * @type Number
   */
  this.width = null;
  /**
   * Canvas height
   * @type Number
   */
  this.height = null;
  /**
   * Canvas background color
   * @type String
   */
  this.backgroundColor = null;
  /**
   * Canvas background image
   * @type String
   */
  this.backgroundImage = null;
  /**
   * Canvas background repeat
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * Canvas background position
   * @type Number
   */
  this.backgroundPosition = null;

/* style */

  /**
   * canvas 초기화
   * @return void
   * @type void
   * @private
   */
  this.init = null;
  /**
   * 페이지 내부의 최상위 div를 리턴
   * @return 페이지 내부의 최상위 div 객체
   * @type Object
   */
  this.getCtrl = null;
  /**
   * 넘어온 속성에 맞춰 control을 생성한다.
   * @param {String} psType type
   * @param {String} psId id
   * @param {Number} pnLeft left
   * @param {Number} pnTop top
   * @param {Number} pnWidth width
   * @param {Number} pnHeight height
   * @type eXria.controls.Control
   * @return eXria.controls.Control
   */
  this.createControl = null;
  /**
   * 파라미터로 넘어온 컨트롤을 canvas에 추가 시킨다.
   * @param {eXria.control.Control} poControl control
   * @return void
   * @type void
   */
  this.appendControl = null;
  /**
   * 넘어온 id와 일치하는 control을 찾아 리턴
   * @param {String} psId control Id
   * @return control Object
   * @type eXria.control.Control
   * @ignore
   */
  this.getControl = function(psId) {
    var voControl = this[psId];
    return voControl ? voControl : null;
  };
  /**
   * 파라미터로 넘어온 ID의 control을 삭제한다.
   * @param {String} psId Control ID
   * @return void
   * @type void
   */
  this.removeControl = null;
  /**
   * canvas에 속한 모든 컨트롤을 해제.
   * @return void
   * @type void
   */
  this.close = null;
};
