/**
 * @fileoverview
 * Modal Window 생성 클래스
 */

/**
 * Modal Window 생성 클래스
 * @version 1.0
 * @param {String} psUrl Page URL
 * @param {String} psId Page Id
 * @param {String} psFeature Page Open Feature
 * @param {String} poPage Parent Page Object
 * @constructor
 */
eXria.form.ModalWindow = function(psUrl, psId, psFeature, poPage) {
  if(!psUrl || !psId || !poPage) {
  throw new Exception("Modal parameter error.");
  }
  /**
   * url
   * @type String
   * @private
   */
  this.url = psUrl;
  /**
   * Modal Window id
   * @type String
   */
  this.id = psId;
  /**
   * Modal Window의 parent Page
   * @type eXria.form.Page
   */
  this.parent = poPage;

  if(psFeature) { this.feature = psFeature; }
  else { this.feature = ""; }
  /**
   * MODAL 윈도우를 생성하여 리턴한다.
   * @return 생성된 모달객체
   * @type eXria.form.ModalWindow
   * @see eXria.form.ModalWindow
   */
  this.open = function() {
    /*var vsParam = "?libScope=page";
    if(vsPopUrl.indexOf("?") > -1) vsParam = "&libScope=page";
    var vnPopIdx = vsPopUrl.lastIndexOf(".") + 1;
    if(vsPopUrl.substring(vnPopIdx, vnPopIdx+3) != "xrf") vsParam = "";*/

    var voBrowser = this.parent.metadata.browser;
    var vsUrl = eXria.util.UrlUtil.getAbsoluteUrl(this.url);
    if (voBrowser.ie > 0 || voBrowser.gecko == 1.9 || voBrowser.webkit > 0) {
      if (voBrowser.ie > 0) {
        this.parent.window.showModalDialog(poPage.metadata.resourceBaseUrl
            + "exria.modal.load.xrf?url=" + vsUrl/* + vsParam */, this.parent,
            this.feature);
      } else {
        this.parent.window.showModalDialog(vsUrl/* + vsParam */, this.parent,
            this.feature);
      }
    } else {
      if(voBrowser.gecko >= 1.9) {
        this.parent.window.showModalDialog(vsUrl/* + vsParam */, this.parent,
            this.feature);
      }else{
        if(!!parent.window.openDialog){
          this.parent.window.openDialog(vsUrl/* + vsParam */, this.id, "modal;"
              + this.feature);
        }else{
          this.parent.window.showModalDialog(vsUrl/* + vsParam */, this.parent,
              this.feature);
        }
      }
    }
    return this;
  };
  /**
   * get page
   * @type
   * @private
   */
  this.getPage = function() {};
};