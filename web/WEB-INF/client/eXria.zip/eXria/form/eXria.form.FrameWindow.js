﻿/**
 * @fileoverview
 * Page 내부에 생성되는 Frame Window 객체를 관리하는 클래스
 */

/**
 * Page 내부에 생성되는 Frame Window 객체를 관리하는 클래스
 * @version 1.0
 * @param {String} psId Page Id
 * @param {String} poPage Parent Page Object
 * @constructor
 */
eXria.form.FrameWindow = function(psId, poPage) {
  /**
   * id
   * @type String
   */
  this.id = psId;
  /**
   * parent
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.parent = poPage;
  /**
   * subpage
   * @type Object
   */
  this.subpage = null;
  /**
   * FrameWindow를 생성하여 리턴한다.
   * @type eXria.form.FrameWindow
   * @see eXria.form.FrameWindow
   */
  this.open = function() {
    return this;
  };
  /**
   * 생성된 프레임 내부의 Page를 리턴한다.
   * @return 생성된 프레임 네부의 Page
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.getPage = function() {
  if(this.subpage == null) {
      this.subpage = this.parent.getControl(this.id).getCtrl();
  }
    return this.subpage.contentWindow.page;
  };
};