﻿/**
 * @fileoverview
 * 사용자 Session 정보를 관리하는 클래스
 */

/**
 * 사용자 Session 정보를 관리하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 * @base eXria.form.Context
 */
eXria.form.SessionContext = function(poPage) {
  /**
   * inherit
   */
  eXria.form.Context.call(this, poPage);
  /**
   * modified
   * @type Boolean
   * @private
   */
  this.modified = false;
   /**
    * resSessionData
    * @type Object
    * @private
    */
  this.resSessionData = null;
  /**
   * Ajax Request URL
   * @type String
   * @private
   */
  var vsRequestURL = this.page.metadata.resourceBaseUrl + "exria.server.session.xrf";
  /**
   * Request Header에 셋팅할 key데이터
   * @type String
   * @private
   */
  var vsReqHeaderKey = "method";
  /**
   * 셋팅된 키에 매핑될 데이터
   * @type String
   * @private
   */
  var vsSync = "synchronize"; //synchronize
  /**
   * 셋팅된 키에 매핑될 데이터
   * @type String
   * @private
   */
  var vsUpdate = "update";  //update
  /**
   * getHttpRequest
   * @type String
   * @return {Object} voHttpRequest
   * @private
   */
  this.getHttpRequest = function(vsReqHeaderValue, vsSendData) {
  var voHttpRequest = eXria.form.xhtml.HttpRequestFactory.create();
  voHttpRequest.open("POST", vsRequestURL, false);
  voHttpRequest.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
  voHttpRequest.setRequestHeader(vsReqHeaderKey, vsReqHeaderValue);
  voHttpRequest.send(vsSendData);

  return voHttpRequest;
  };
  /**
   * server의 session 정보를 읽어 client측에 동기화 시킨다.
   * @return void
   * @type void
   */
  this.synchronize = function() {
  var voHttpRequest = this.getHttpRequest(vsSync, null);

  if(voHttpRequest.readyState == 4) {
    var customEval = function(psJsonStr) {
    return (new Function("", "return " + psJsonStr + ";"))();
    };

    switch(voHttpRequest.status) {
    case 200 : {
      this.resSessionData = customEval(voHttpRequest.responseText);
      //커넥션이 제대로 이루어졌을 경우에만 this.modified 를  false로 변경
      this.modified = false;
      break;
    }
    case 500 : {
      var voJsonError = customEval(voHttpRequest.responseText);
      var vsErrorMessage = voJsonError["scErrorMessage"];
      throw new Error("Server Error : " + vsErrorMessage);
    }
    default : {
      this.resSessionData = null;
      throw new Error("Server Connection Error");
      break;
    }
    }
  }
  };
  /**
   * client에서 변경된 세션 정보를 사용하여 server의 session정보를 update한다.
   * @return void
   * @type void
   */
  this.update = function() {
  if(this.modified == true) {
    var voJsonBuilder = new eXria.protocols.JSONBuilder();
    var vsJsonStr = voJsonBuilder.toJSONString(this.resSessionData);
    var voHttpRequest = this.getHttpRequest(vsUpdate, vsJsonStr);

    if(voHttpRequest.readyState == 4) {
    var customEval = function(psJsonStr) {
      return (new Function("", "return " + psJsonStr + ";"))();
    };

    switch(voHttpRequest.status) {
      case 200 : {
      this.modified = false;
      break;
      }
      case 500 : {
      var voJsonError = customEval(voHttpRequest.responseText);
      var vsErrorMessage = voJsonError["scErrorMessage"];
      throw new Error("Server Error : " + vsErrorMessage);
      }
      default : {
      throw new Error("Server Connection Error.");
      break;
      }
    }
    }
  }
  };
  /**
   * 파라미터로 받는 Key와 일치하는 session 정보를 읽어 리턴.
   * @param {String} psName 가져오길 원하는 데이터의 Key값
   * @return 세션의 key가 일치하는 데이터
   * @type Object
   */
  this.getAttribute = function(psName) {
  if(psName == null || psName == undefined) return;

  if(this.resSessionData) {
    return this.resSessionData[psName];
  } else {
    return null;
  }
  };
  /**
   * 파라미터로 받는 key와 value를 세션에 셋팅한다.
   * value로 실제 올 수 있는 데이터는
   * primitive, list(eXria.data.Collection), map(eXria.data.Map) Type이다.
   * @param {String} psName 추가할 데이터의 Key
   * @param {Object} poValue 추가할 데이터의 Value
   * @return void
   * @type void
   */
  this.setAttribute = function(psName, poValue) {
  if(psName == null || psName == undefined) return;

  if(poValue instanceof eXria.data.Map) {
    poValue = poValue.entries;
  } else if(poValue instanceof eXria.data.Collection){
    poValue = poValue.elements;
  }

  try {
    this.resSessionData[psName] = poValue;
  } catch (e) {
    throw new Error("Session data is null.");
  }
  this.modified = true;
  };
  /**
   * 파라미터로 넘어온 Key와 일치하는 세션 정보를 삭제한다.
   * @param {String} psName 삭제할 데이터의 Key
   * @return void
   * @type void
   */
  this.removeAttribute = function(psName) {
  if(psName == null || psName == undefined) return;
  delete this.resSessionData[psName];
  this.modified = true;
  };
};
