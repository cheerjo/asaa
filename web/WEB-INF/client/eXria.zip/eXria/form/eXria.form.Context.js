﻿/**
 * @fileoverview
 * SessionContext, CookieContext의 Interface
 */

/**
 * SessionContext, CookieContext의 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 */
eXria.form.Context = function(poPage) {
  /**
   * page
   * @type eXria.form.Page
   */
  this.page = poPage;
  /**
   * parameter로 넘어온 name과 일치하는 cookie 값을 찾아 리턴한다.
   * @param {String} psName 찾고자 하는 cookie의 name
   * @return cookie 데이터
   * @type String
   */
  this.getAttribute = null;
  /**
   * parameter로 넘어온 내용들을 cookie에 저장
   * @param {String} psName name
   * @param {String} psValue value
   * @param {Number} pnExpireDays expire days
   * @return void
   * @type void
   */
  this.setAttribute = null;
  /**
   * parameter로 넘어온 name과 일치하는 cookie 데이터를 삭제한다.
   * @param {String} psName name
   * @return void
   * @type void
   */
  this.removeAttribute = null;

};

