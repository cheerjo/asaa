﻿/**
 * @fileoverview
 * Popup Window 생성 클래스
 */

/**
 * Popup Window 생성 클래스
 * @version 1.0
 * @param {String} psUrl Page URL
 * @param {String} psId Page Id
 * @param {String} psFeature Page Open Feature
 * @param {String} poPage Parent Page Object
 * @constructor
 */
eXria.form.PopupWindow = function(psUrl, psId, psFeature, poPage) {
  /**
   * url
   * @type String
   * @private
   */
  this.url = psUrl;
  /**
   * id
   * @type String
   */
  this.id = psId;
  /**
   * feature
   * @type String
   * @private
   */
  this.feature = psFeature;
  /**
   * parent
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.parent = poPage;
  /**
   * child window
   * @type Object
   * @private
   */
  this.childWindow = null;
  /**
   * 새로운 팝업을 여는 메소드.
   * @return 생성된 popup 객체
   * @type eXria.form.PopupWindow
   * @see eXria.form.PopupWindow
   */
  this.open = function() {
  this.childWindow = this.parent.window.open(eXria.util.UrlUtil.getAbsoluteUrl(this.url), this.id, this.feature);
    return this;
  };
  /**
   * 팝업 페이지의 page 객체 리턴
   * @return 생성된 팝업 내부의 page 객체
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.getPage = function() {
  try {
    this.childWindow.page;
  } catch(e) {
    return null;
  }
  return this.childWindow.page;
  };
};