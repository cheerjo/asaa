/**
 * @fileoverview
 * Plugin Mode 사용시 시스템에 대한 로그를 사용하기 위한 클래스
 */

/**
 * Plugin Mode 사용시 시스템에 대한 로그를 사용하기 위한 클래스
 * @version 1.0
 * @param {Object} poPlugin
 * @constructor
 */
eXria.form.plugin.Logger = function(poPlugin) {
  /**
   * this.plugin
   * @private
   */
  this.plugin = poPlugin;
  /**
   * applet console logger
   * @private
   */
  this.logger = poPlugin.getLogger();
  /**
   * applet 콘솔에 지정된 레벨의 로그를 남겨주는 메소드
   * @param {String} psStr 출력 문자열
   * @param {String} psLevel 로그 출력의 기준이 될 로그 레벨(error|warn|info|debug)
   */
  this.printLog = function(psStr, psLevel) {
    if(psLevel == null) psLevel = "info";
    var voLogger = this.logger;
    switch(psLevel) {
    case "error" :
      voLogger.error(psStr);
      break;
    case "warn" :
      voLogger.warn(psStr);
      break;
    case "info" :
      voLogger.info(psStr);
      break;
    case "debug" :
      voLogger.debug(psStr);
      break;
    }
  };
};