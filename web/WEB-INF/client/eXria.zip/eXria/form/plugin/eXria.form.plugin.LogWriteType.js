/**
 * @fileoverview
 * Log 출력 모드를 상수정의 한 클래스</br>
 * enum list</br>
 * - eXria.form.plugin.LogWriteType.MEMORY</br>
 * - eXria.form.plugin.LogWriteType.FILE
 */

/**
 * Log 출력 모드를 상수정의 한 클래스
 * @author Choe, Hyeon Jong
 * @version 1.0
 * @constructor
 */
eXria.form.plugin.LogWriteType = {
  MEMORY    : 1,
  FILE    : 2
};