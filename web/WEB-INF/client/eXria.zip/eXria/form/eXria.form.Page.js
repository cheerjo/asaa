/**
 * @fileoverview
 * eXria CRE의 한 화면을 구성하는 객체로써, 화면에 보여지는 Control 및 화면에 보여지는 데이터를 관리하는 Data Component, 서버와의 통신을 위해 사용되는 Protocol 간의 연관 관계를 맺어주는 클래스
 */
/**
 * eXria CRE의 한 화면을 구성하는 객체로써, 화면에 보여지는 Control 및 화면에 보여지는 데이터를 관리하는 Data Component, 서버와의 통신을 위해 사용되는 Protocol 간의 연관 관계를 맺어주는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {String} psId Page Id
 * @constructor
 */
eXria.form.Page = function(psId) {
  /**
   * Page ID
   * @type String
   */
  this.id = psId;
  /**
   * window Object
   * @type Object
   */
  this.window = window;
  /**
   * 현재 Page에 대한 정보를 담고 있는 Object
   * @type eXria.form.PageMetadata
   */
  this.metadata = null;
  /**
   * parent Object
   * @type eXria.form.Page
   */
  this.parent = null;
  /**
   * 현재 Page에 포함되는 Canvas Object
   * @type eXria.form.Canvas
   */
  this.canvas = null;
  /**
   * 현재 Page에 포함된 model Object
   * @type eXria.form.Model
   * @see eXria.form.Model
   */
  this.model = null;
  /**
   * page의 view rendering 이전에 일어날 수 있는 컨트롤 이벤트들을 저장했다가
   * view rendering 이후에 순차적으로 수행하기 위한 이벤트 큐 객체
   * @type Array(function)
   */
  this.eventQueue = [];

  this.isRendered = false;

  this.modelType = null;


  /**
   * page metadata set
   * @return void
   * @type void
   * @private
   */
  this.setMetadata = function(poMetadata) {
    if(this.modelType != null) {
      poMetadata.modelType = this.modelType;
    }
	
	if(this.useJsonInstance != null) {
		poMetadata.useJsonInstance = this.useJsonInstance;
	}
  
  if(this.useDomPath != null) {
    poMetadata.useDomPath = this.useDomPath;
  }
    
  if(poMetadata.useJsonInstance) $createJsonInheritance();
    this.metadata = poMetadata;
  };
  /**
  * 현재 브라우저 언어를 셋팅
  * @return void
  * @type void
  * @private
  */
  this.setBrowserLanguage = function() {
    var vsLang = null;
    var voNavigator = this.window.navigator;
    var vsType = voNavigator.appName;

    if (vsType == "Netscape") {
      vsLang = voNavigator.language;
    } else {
      vsLang = voNavigator.userLanguage;
    }

    if (! vsLang) vsLang = "ko";
    this.metadata.language = vsLang;
  };
  /**
   * 로케일에 맞는 타이틀 지정
   * @param {String} psLang
   * @type void
   * @return void
   * @private
   */
  this.setMultiLangTitle = function(psLang) {
    if(this.metadata.multilingualTitle != null) {
      var vsTitle = eval('(' + ("this.metadata.multilingualTitle." + psLang) + ')');
      this.setTitle(vsTitle);
    } else {
      return;
    }
  };
  /**
   * creage model
   * @return void
   * @type void
   * @private
   */
  this.createModel = function() {
  if(this.metadata.modelType == eXria.form.ModelType.SWITCH) {
    if(this.metadata.browser.ie > 0) {
      this.metadata.modelType = eXria.form.ModelType.PLUGIN;
    } else {
      this.metadata.modelType = eXria.form.ModelType.JRE;
    }
  }
    this.model = eXria.form.ModelFactory.create(this.metadata.modelType, this);
  };
  /**
   * page lifecycle and event definitions
   * @return void
   * @type void
   * @private
   */
  this.init = function(poView) {
    this.setBrowserLanguage();
    this.setMultiLangTitle(this.metadata.eXriaLocale);
    //TODO event model에 대한 검증 필요.
//    this.window.document.body.onload = this.window.page.load;
    this.window.onbeforeunload = this.window.page.beforeunload;
    if(this.metadata.browser.ie > 0) {
      this.window.onbeforeunload = this.window.page.beforeunload;
      this.window.document.body.onunload = this.window.page.unload;
    } else {
      this.window.onunload = this.window.page.unload;
    }
    this.canvas = eXria.form.CanvasFactory.create(this.metadata.canvasType, this);

    //submission 및 instance load
    //PageMetadata의 modelUrl을 이용 XXX
    var vsPathName = this.window.location.pathname;
    var vaPath = vsPathName.split("/");
    vaPath.splice(vaPath.length - 1, 1);
    this.metadata.documentBaseUrl = vaPath.join("/") + "/";
    vsPathName = vsPathName.substring(0, vsPathName.lastIndexOf("."));
    var voMetadata = this.metadata;
    var vsUrl = voMetadata.url;
    if(vsUrl) {
      var vnIdx = vsUrl.indexOf(voMetadata.resourceBaseUrl);
      if(vnIdx != -1) voMetadata.domainUrl = vsUrl.substring(0, vnIdx) + "/";
    }

    if (this.window.page.metadata.useMultilingual == false || this.window.page.metadata.eXriaLocale == null) {
      vsPathName = vsPathName + ".xml";
    } else {
      if (page.metadata.multilingualType == "dynamic") vsPathName = vsPathName + "_" + this.metadata.eXriaLocale;
      vsPathName = vsPathName + ".xml";
    }

    var voParent = null;
    var voPage = null;
    var voDialogArguments = null;
    if(this.window.opener) voParent = this.window.opener;
    try {
      if(voParent && voParent.page) voPage = voParent.page;
    } catch(e) {
      voPage = null;
    }
    if(this.window.dialogArguments) voDialogArguments = this.window.dialogArguments;
    if(voParent && voPage && !voDialogArguments) {
      this.parent = voPage;
    } else {
      voParent = null;
      voPage = null;
      if(this.window.parent) voParent = this.window.parent;
      try {
          if(voParent && voParent.page) voPage = voParent.page;
      } catch(e) {
      voPage = null;
      }
      if(voParent && voPage && !voDialogArguments) { //iframe
        this.parent = this.window.parent.page;
      } else if(voDialogArguments) {
        if(this.metadata.browser.ie > 0 && voPage) {
          this.parent = this.window.parent.page;
        } else {
          this.parent = voDialogArguments;
        }
      }
    }

    if(eXria.util.StringUtil.startsWith(vsPathName, "/") == false) {
      vsPathName = "/" + vsPathName;
    }
    this.model.loadModel(vsPathName, poView);
  };
  /**
   * load
   * @return void
   * @type void
   * @private
   */
  this.load = function(poView) {
  var voPage = this.window.page;
  voPage.onInit();

  this.window.scrollBarWidth = this.window.getScrollBarWidth();
  //20080723 추가
  if(poView && poView.rendering) {
    poView.rendering(this);
  }
  //eventQueue 처리(20100527 추가)
  if(this.eventQueue.length > 0) {
    var vnSize = this.eventQueue.length;
    var voEvent = null;
    for(var i = 0; i < vnSize; i++) {
      voEvent = this.eventQueue[i];
      voEvent();
    }
    this.eventQueue = [];
  }
  //eventQueue 처리 종료
  if(this.metadata.useMultilingual) {
    //다국어 이용시 container control 내부의 import control 생성 문제 해결
    voPage.canvas.appendSubImp();
  }
  this.isRendered = true;
  //로딩시 첫번째 tab index로 지정된 control에 focusing
  var voCanvas = voPage.canvas;
  var voCtl = voCanvas.getFirstTabCtl(voCanvas.controls.getValueCollection());
  voCanvas.setFocusByControl(voCtl);

    if(this.metadata.loadingProgressEnabled) {
      this.model.progressAction(false);
    }
    voPage.onLoad();
  };
  /**
   * page components create
   * onInit
   * @return void
   * @type void
   * @private
   */
  this.onInit = function() {
    //
    // TO DO
    //
  };
  /**
   * onLoad
   * @return void
   * @type void
   * @private
   */
  this.onLoad = function() { //호출되지 않는다.
    //
    // TO DO
    //
  };
  /**
   * unload
   * @return void
   * @type void
   * @private
   */
  this.unload = function() {
    if(this.metadata.browser.ie == 0 && this.window.page.onUnLoad) this.window.page.onUnLoad();

    if(!(this.metadata.modelType == eXria.form.ModelType.JRE)) {
      if(!page.window) { return; }

      var voPage = this.window.page;
      var voDoc = this.window.document;
      var vnW = voDoc.body.offsetWidth;
      var vnH = voDoc.documentElement.clientHeight;
      var voCoverCtl = voPage.canvas.createControl("rectangle","coverRgt___" + this.window.page.id + "___",0,0,(vnW==0) ? 1 : vnW,(vnH==0) ? 1 : vnH);
      voCoverCtl.zIndex = 10000000;
      voCoverCtl.cursor = "auto";
      voCoverCtl.angle = "0";
      voCoverCtl.joinType = "miter";
      voCoverCtl.penStyle = "solid";
      voCoverCtl.penWeight = 0;
      voCoverCtl.penColor = "transparent";
      voCoverCtl.penOpacity = 0;
      voCoverCtl.focusDisplay = false;
      voCoverCtl.focusPenColor = "#FFFFFF";
      voCoverCtl.focusPenStyle = "solid";
      voCoverCtl.fillStartColor = "#FFFFFF";
      voCoverCtl.fillEndColor = "#FFFFFF";
      voCoverCtl.fillType = "solid";
      voCoverCtl.fillAngle = 0;
      voCoverCtl.fillOpacity = 1;

      this.window.page.canvas.appendControl(voCoverCtl);

      voCoverCtl.refresh();
    }

    this.window.page.close();
  };
  /**
   * beforeunload
   * @return void
   * @type void
   * @private
   */
  this.beforeunload = function() {
    //
    // TO DO
    //
    if(this.metadata.browser.ie > 0) {
		  if(this.window.page.onUnLoad) this.window.page.onUnLoad();
	  }
    
    var voBase = this.page;
    var voControls = voBase.canvas.controls.entries;
    var voControl = null;
    
    if(this.metadata.browser.ie < 8) {
      var voCtrl = null;
      var voParentCtrl = null;
      for(var member in voControls) {
        if(voControls[member].toString && (voControls[member].toString() == "HtmlSnippet" || voControls[member].toString() == "SubPage" || voControls[member].toString() == "ComboBox")) {
          voControl = voControls[member];
          voCtrl = voControl.ctrl;
          voParentCtrl = voCtrl.parentNode;
          if(voControl.toString() == "ComboBox"){
            voControl.clearListArea();
          }
          voParentCtrl.removeChild(voCtrl);
        }
      }
    } else {
      for(var member in voControls) {
        if(voControls[member].toString && voControls[member].toString() == "ComboBox") {
          voControl = voControls[member];
          voControl.clearListArea();
        }
      }
    }
  };
  /**
   * page components destroy
   * close
   * @return void
   * @type void
   * @private
   */
  this.close = function() {
    var voPage = this.window.page;

    if(voPage.canvas) {
      voPage.canvas.close();
    }
    if(voPage.model) {
      voPage.model.close();

    if(voPage.metadata.modelType == eXria.form.ModelType.PLUGIN) {
    var voPlugin = voPage.window.document.getElementById(voPage.model.id);
    if(voPlugin) voPlugin.parentNode.removeChild(voPlugin);
    }
    }
    if(voPage.controls) {
      voPage.controls.clear();
    }
    if(voPage.window) {
      voPage.window = null;
    }
    //
    // check
    //
    if(this.window != null && voPage != null && voPage.parent != null && voPage.parent.window != null) {
      if(!voPage.parent.window.closed) {
        voPage.parent.childPages.remove(voPage.id);
      }
    }
  };
  /**
   * 현재 page의 canvas에 포함된 Control 중 parameter로 넘어온 ID와 일치하는 Control 객체를 리턴한다
   * @param {String} psId 찾고자 하는 Control의 ID
   * @return 넘어온 ID와 일치하는 control Object
   * @type eXria.controls.Control
   */
  this.getControl = function(psId) {
     return this.canvas.getControl(psId);
  };
  /**
   * 현재 page의 canvas에 포함된 모든 Control을 refresh.
   * @return void
   * @type void
   */
  this.refresh = function() {
    if(this.canvas && this.canvas.controls) {
      var voIterator = this.canvas.controls.getValueCollection().iterator();
      var voControl = null;
      while(voIterator.hasNext()) {
        voControl = voIterator.next();
        if(voControl.parent) {
          vsControlType = voControl.parent.toString();
          if(vsControlType == "Tab" || vsControlType == "Group" || vsControlType == "FreeForm" || vsControlType == "Tab_TabPages") {
      			continue;
          }
        }
        if(voControl.refresh) {
          voControl.refresh();
        }
      }
    }
  };
  /**
   * parameter로 넘어온 Instance ID와 일치하는 Instance를 찾아 리턴.
   * @param {String} psId Instance ID
   * @return 넘어온 ID와 일치하는 Instance 객체
   * @type eXria.data.Instance
   */
  this.getInstance = function(psId) { return this.model.getInstance(psId); };
  /**
   * parameter로 넘어온 Submission ID와 일치하는 Submission을 찾아 리턴.
   * @param {String} psId 서브미션 ID
   * @return 넘어온 ID와 일치하는 Submission 객체
   * @type eXria.protocols.Submission
   * @see eXria.protocols.Submission
   */
  this.getSubmission = function(psId) { return this.model.getSubmission(psId); };
  /**
   * parameter로 넘어온 DataSet ID와 일치하는 DataSet을 찾아 리턴.
   * @param {String} psId 데이타셋 ID
   * @type eXria.data.DataSetCmd
   * @see eXria.data.DataSetCmd
   */
  this.getDataSet = function(psId) { return this.model.getDataSet(psId); };
  /**
   * Server Error Message를 반환한다.
   * @param {Boolean} pbCode 에러 코드 리턴 유무
   * @param {Boolean} pbMsg 에러 메세지 리턴 유무
   * @param {Boolean} pbSrc 에러 소스 리턴 유무
   * @type eXria.data.ArrayCollection
   * @return Error String을 담고 있는 Array 객체
   */
  this.getErrorMessage = function(pbCode, pbMsg, pbSrc) {
  return this.model.getErrorMessage(pbCode, pbMsg, pbSrc);
  };
  /**
   * Server Error Message를 전부 삭제한다.
   * @type void
   * @return void
   */
  this.clearErrorMessage = function() { this.model.clearErrorMessage(); };
  /**
   * cookie context
   * @type eXria.form.CookieContext
   * @see eXria.form.CookieContext
   * @private
   */
  this.cookieContext = null;
  /**
   * 현재 page에 포함된 Cookie를 리턴
   * @return 쿠키 Object
   * @type eXria.form.CookieContext
   * @see eXria.form.CookieContext
   */
  this.getCookieContext = function() {
    if (this.cookieContext == null) { this.cookieContext = new eXria.form.CookieContext(this); }
    return this.cookieContext;
  };
  /**
   * session context
   * @type eXria.form.SessionContext
   * @private
   */
  this.sessionContext = null;
  /**
   * 현재 페이지의 세션을 리턴
   * @return 현재 페이지의 세션 Object
   * @type eXria.form.SessionContext
   * @see eXria.form.SessionContext
   */
  this.getSessionContext = function() {
    if (this.sessionContext == null) { this.sessionContext = new eXria.form.SessionContext(this); }
    return this.sessionContext;
  };
  /**
   * 현재 페이지가 parameter로 넘어온 URL로 이동.
   * @param {String} psUrl
   * @return void
   * @type void
   */
  this.open = function(psUrl) {
    this.window.location.href = psUrl;
  };
  /**
   * 현재 page의 자식 페이지 객체들이 저장되는 Map
   * @type eXria.data.ArrayMap
   */
  this.childPages = new eXria.data.ArrayMap();
  /**
   * 현재 페이지를 기준으로 새로운 창을 여는 메소드
   * @param {String} psId page Id
   * @param {String} psUrl url
   * @param {int} pnType page type
   * @param {String} psFeature feature
   * @return 새로 생성된 Window에 대한 객체
   * @type eXria.form.Page
   */
  this.openPage = function(psId, psUrl, pnType, psFeature) {
    var voPage = null;
    switch (pnType) {
      case eXria.form.PageType.POPUP :
        voPage = (new eXria.form.PopupWindow(psUrl, psId, psFeature, this)).open();
        break;
      case eXria.form.PageType.FRAME :
        voPage = (new eXria.form.FrameWindow(psId, this)).open();
        break;
      case eXria.form.PageType.MODAL :
        voPage = (new eXria.form.ModalWindow(psUrl, psId, psFeature, this)).open();
        this.canvas.delayedKeydown.clear();
        break;
      default :
        throw new Error("No such page type : " + pnType);
    }
    this.childPages.put(psId, voPage);
    return voPage;
  };
  /**
   * 현재 페이지를 기준으로 자식페이지 중 parameter로 넘어온 ID와 일치하는 page를 리턴
   * @param {String} psId page Id
   * @return 넘어온 ID와 일치하는 page Object
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.getPage = function(psId) {
    var voPage = this.childPages.get(psId);
    if(voPage == null) {
      return null;
    }
    var voChildPage = voPage.getPage();
  if(voChildPage == null) {
      return null;
    }
    return voChildPage;
  };
  /*FrameSet*/
  /**
   * parameter로 넘어온 frame ID와 일치하는 frame을 찾아 리턴.
   * @param {String} psFrmId frame ID
   * @return frame Object
   * @type Object
   */
  this.getHtmlFrame = function(psFrmId) {
  if(psFrmId == null) { return null; }
  var resultFrm = this.searchParentHtmlFrame(psFrmId, this.window.parent);

  if(resultFrm == null) { throw new Error("Cannot find Frame."); }
  else return resultFrm;
  };
  /**
   * frame 검색시 모든 페이지에 대해 검색하기 위한 recursive 메소드
   * @return frame object
   * @type Object
   * @private
   */
  this.searchParentHtmlFrame = function(psFrmId, poParent) {
  if(poParent == null || poParent == undefined) { return null; }

  var voFrm = poParent.document.getElementById(psFrmId);
    if(voFrm != null || voFrm != undefined) {
      return voFrm;
    } else {
      if(poParent != poParent.top) {
      return this.searchParentHtmlFrame(psFrmId, poParent.parent);
      } else {
      return null;
      }
    }
  };
 /**
  * parameter로 넘어온 ID와 일치하는 프레임 내부의 page를 리턴.
  * @param {String} psFrmId frame id
  * @return page Object
  * @type eXria.form.Page
  */
  this.getPageInFrame = function(psFrmId) {
  if(psFrmId == null) { return null; }

  var voFrm = this.getHtmlFrame(psFrmId);
  var voPage = voFrm.contentWindow.page;
  if(!voPage || voPage.toString() != "eXria.form.Page") { throw new Error("Cannot find page."); }

  return voPage;
  };
  /**
   * parameter로 넘어온 ID와 일치하는 page를 찾아 리턴한다.
   * @param {String} psId page Id
   * @return page Object
   * @type eXria.form.Page
   * @see eXria.form.Page
   */
  this.searchPage = function(psId) {
    if(psId == null) { return; }
    if(this.id == psId) { return this; }

    var voFindPage = this.searchChildPage(this, psId, this.id);
    if(voFindPage != null && voFindPage != undefined) {
      return voFindPage;
    }

    if(this.parent == null) { return null; }

    if(this.parent != this) {
      voFindPage = this.searchParentPage(this.parent, psId, this.id);
    }

    if(voFindPage != null && voFindPage != undefined) {
      return voFindPage;
    } else {
      throw new Error("Cannot find page.");
    }
  };
  /**
   * 페이지 검색시 상위 페이지를 검색하기 위한 메소드
   * @return 찾은 page Object
   * @type eXria.form.Page
   * @see eXria.form.Page
   * @private
   */
  this.searchParentPage = function(poPage, psId, psNoSearchPageId) {
    if(poPage == null || poPage == null) { return; }
    if(psNoSearchPageId == null) { psNoSearchPageId = this.id; }
    if(poPage.id == psId) { return poPage; }

    var voFindPage = this.searchChildPage(poPage, psId, psNoSearchPageId);
    if(voFindPage != null && voFindPage != undefined) {
      return voFindPage;
    }

    if(poPage != poPage.parent) {
      voFindPage = this.searchParentPage(poPage.parent, psId, poPage.id);
    }

    if(voFindPage != null && voFindPage != undefined) {
      return voFindPage;
    } else {
      throw new Error("Cannot find page.");
    }
  };
  /**
   * 페이지 검색시 자식 페이지들을 검색하기 위한 recursive 메소드
   * @return page Object
   * @type eXria.form.Page
   * @see eXria.form.Page
   * @private
   */
  this.searchChildPage = function(poPage, psId, psNoSearchPageId) {
    if(poPage == null || psId == null) { return; }
    if(psNoSearchPageId == null) { psNoSearchPageId = this.id; }

    var voNodeList = poPage.childPages;

    //노드의 자식 노드가 있다면
    if(!voNodeList.isEmpty()) {
      //가진 노드들을 iterator로 리턴
      voNodeList = voNodeList.getValueCollection().iterator();
      var vnNodeCursor = voNodeList.cursor;

      while(voNodeList.hasNext()) {
        var voChildNode = voNodeList.next();
        if(voChildNode.getPage() == null){
          continue;
        }
        var vsPageId = voChildNode.getPage().id;
        if(vsPageId == psNoSearchPageId) { continue; }
        //페이지를 찾았다면 리턴
        if(vsPageId == psId) { return voChildNode.getPage(); }
      }
      //iterator의 초기 index
      voNodeList.cursor = vnNodeCursor;
      while(voNodeList.hasNext()) {
        var voChildPage = voNodeList.next();
        //찾지 말아야 할 자식 노드라면 continue
        if(voChildPage.getPage() == null) continue;
        if(psNoSearchPageId == voChildPage.getPage().id) { continue; }
        //자식 노드가 있다면 searchChildPage를 리턴
        if(!voChildPage.getPage().childPages.isEmpty()) {
          return this.searchChildPage(voChildPage.getPage(), psId, psNoSearchPageId);
        }
      }
    }
  };
  /**
   * 페이지의 타이틀을 지정
   * @param {String} vsTitle 타이틀로 지정할 문자열
   * @return void
   * @type void
   */
  this.setTitle = function(psTitle) {
    this.window.document.title = psTitle;
  };
  /**
   * 인스턴스의 데이터를 사용하여 페이지 타이틀 지정
   * @param {String} psInsId 인스턴스ID
   * @param {String} psPath XPath
   * @return void
   * @type void
   */
  this.setNodeSetTitle = function(psInsId, psPath) {
    try {
      var viIns = this.getInstance(psInsId);
      this.setTitle(viIns.getValueNode(psPath).getValue());
    } catch (e) {
      this.setTitle("");
    }
  };
  /**
   * Plugin Object를 model에 재설정한다.
   * @return void
   * @type void
   */
  this.resetPlugin = function() {
    this.model.setPlugin();
  };
  /** Class 명 리턴
   * @type String
   * @return Class 이름 리턴
   */
  this.toString = function() {
    return "eXria.form.Page";
  };
  /**
   * Java runtime 다운로드 주소를 특정 주소로 사용하고자 할 경우 지정
   * @param {String} psAddr JRE 설치 파일 주소
   * @return void
   * @type void
   */
  this.setJREAddr = function(psAddr) {
    if(!psAddr) {
      return;
    }
    this.window.page.metadata.jreDownloadAddr = psAddr;
  };
};
/**
 * Studio 스크립트 디버거 사용시 콘솔에 메세지를 출력합니다.
 * @param {String} psMsg Studio 콘솔에 출력할 메세지
 * @return void
 * @type void
 */
function xprint(psMsg) { };
/**
 * Studio 스크립트 디버거 사용시 콘솔에 메세지를 출력합니다.
 * @param {String} psMsg Studio 콘솔에 출력할 메세지
 * @return void
 * @type void
 */
function xprintln(psMsg) { };
/**
 * 동적 script include 전역 함수 2008-06-05
 * @private
 */
var eXriaGlobal = this;
/**
 * 외부 Javascript 파일을 현재 파일에 포함시킵니다.
 * @param {String} psUrl
 * @return void
 * @type void
 * @private
 */
function $include(psUrl) {
  var voRequest = eXria.form.xhtml.HttpRequestFactory.create();
  voRequest.open("GET", psUrl, false);
  voRequest.send(null);

  var vsJs = voRequest.responseText;
  if(window.execScript) { //IE
    window.execScript(vsJs);
  } else {
    var vbSafari = navigator.userAgent.match(/\Safari/i)!=null;
    if(vbSafari) { //SAFARI
      var voScript = document.createElement("script");
      voScript.appendChild(document.createTextNode(vsJs));
      document.documentElement.appendChild(voScript);
    } else { //FIREFOX, OPERA
      eXriaGlobal.eval(vsJs);
    }
  }
};
/**
 * Dynamic CSS Loading
 * @param {String} psUrl css 링크 url
 * @param {String} psCssId css 링크 태그 id(디폴트 값 : "eXriaDynamicCSS")
 * @public
 */
function $loadCSS(psUrl, psCssId) {
  var vsCSSId = psCssId;
  if(vsCSSId == null) vsCssId = "eXriaDynamicCSS";
  var voHead = document.getElementsByTagName("head")[0];
  var voCSS = document.getElementById(vsCSSId);

  if(voCSS) {
    //이미 dynamic loading 된 CSS가 있을 경우 삭제한다.
    voHead.removeChild(voCSS);
    if(psUrl == null) return;
  }
  //CSS Element 생성후 Header에 append
  var voCSSNode = document.createElement('link');
  voCSSNode.id = vsCSSId;
  voCSSNode.name = vsCSSId;
  voCSSNode.type = 'text/css';
  voCSSNode.rel = 'stylesheet';
  voCSSNode.href = psUrl;
  voCSSNode.media = 'screen';
  voHead.appendChild(voCSSNode);
};

function $createJsonInheritance() {
  eXria.controls.xhtml.Util.createInheritance(eXria.controls.JsDataRefNode, eXria.controls.DataRefNode);
  eXria.controls.xhtml.Util.createInheritance(eXria.controls.JsDataRefNodeset, eXria.controls.DataRefNodeset);
};
