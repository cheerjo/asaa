/**
 * @fileoverview
 * 현재 사용자의 Browser를 구분하는 클래스
 * @license YAHOO UI 2.4.1 (BSD)
 */

/**
 * 현재 사용자의 Browser를 구분하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 */
eXria.lang.Browser = function(poPage) {
  /**
   * 현재 Browser에 포함된 Page Obejct
   */
  this.page = poPage;
  /**
   * 사용자 Browser가 IE일 경우 IE 버전 정보를 저장.
   * @type Number
   */
  this.ie = 0;
  /**
   * 사용자 Browser가 Opera일 경우 Opera 버전 정보를 저장.
   * @type Number
   */
  this.opera = 0;
  /**
   * 사용자 Browser가 FirFox일 경우 FireFox 버전 정보를 저장.
   * @type Number
   */
  this.gecko = 0;
  /**
   * 사용자 Browser가 Safari일 경우 Safari 버전 정보를 저장.
   * @type Number
   */
  this.webkit = 0;
  /**
   * 사용자 Browser가 chrome 경우 chrome 버전 정보를 저장.
   * @type Number
   */
  this.chrome = 0;
  /**
   * 사용자 Browser가 Mobile Browser일 경우 Mobile Browser 버전 정보를 저장.
   * @type Number
   */
  this.mobile = null;
  /**
   * @private
   */
  var vsAgent = this.page.window.navigator.userAgent;
  /**
   * @private
   */
  var voInfo = null;

  // chrome
  voInfo = vsAgent.match(/Chrome\/([^\s]*)/);
  if (voInfo && voInfo [1]) {
    this.chrome = voInfo [1];
  }

  if (! this.chrome) { // not chrome
    // Modern KHTML browsers should qualify as Safari X-Grade
    if ((/KHTML/).test(vsAgent)) {
      this.webkit = 1;
    }

    // Modern WebKit browsers are at least X-Grade
    voInfo = vsAgent.match(/AppleWebKit\/([^\s]*)/);
    if (voInfo && voInfo [1]) {
      this.webkit = parseFloat(voInfo [1]);

      // Mobile browser check
      if (/ Mobile\//.test(vsAgent)) {
        this.mobile = "Apple"; // iPhone or iPod Touch
      } else {
        voInfo = vsAgent.match(/NokiaN[^\/]*/);
        if (voInfo) {
          this.mobile = voInfo [0]; // Nokia N-series, ex: NokiaN95
        }
      }
    }

    if (! this.webkit) {// not webkit
      // @todo check Opera/8.01 (J2ME/MIDP; Opera Mini/2.0.4509/1316; fi; U; ssr)
      voInfo = vsAgent.match(/Opera[\s\/]([^\s]*)/);
      if (voInfo && voInfo [1]) {
        this.opera = parseFloat(voInfo [1]);
        voInfo = vsAgent.match(/Opera Mini[^;]*/);
        if (voInfo) {
          this.mobile = voInfo [0]; // ex: Opera Mini/2.0.4509/1316
        }
      } else {
        // not opera or webkit
        voInfo = vsAgent.match(/MSIE\s([^;]*)/);
        if (voInfo && voInfo [1]) {
          this.ie = parseFloat(voInfo [1]);
        } else {
          // not opera, webkit, or ie
          voInfo = vsAgent.match(/Gecko([^\s]*)/);
          if (voInfo) {
            this.gecko = 1; // Gecko detected, look for revision
            voInfo = vsAgent.match(/rv:([^\s\)]*)/);
            if (voInfo && voInfo [1]) {
              this.gecko = parseFloat(voInfo [1]);
            }
          }
        }
      }
    }
  }

};