/**
 * @fileoverview
 * StringBuilder
 * 문자열 편집을 용이하게 하기 위한 클래스
 */

/**
 * StringBuilder
 * 문자열 편집을 용이하게 하기 위한 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.lang.StringBuilder = function() {

  /**
   * 스트링 버퍼 역할의 멤버 변수
   */
  this.buffer = "";

  /**
   * isEmpty();
   */
  this.isEmpty = function() { return (this.buffer == ""); };

  /**
   * clear
   */
  this.clear = function() {
    this.buffer = "";
    return this;
  };

  /**
   * 문자열 버퍼에 문자열을 추가하는 메소드.
   * 파라미터로 주어진 모든 객체의 문자열 표현
   * 값을 문자열 버퍼에 추가한다.
   * @param {String} poValue 문자열 표현 값으로 문자열 버퍼에 추가될 오브젝트
   * @return 클래스 오브젝트 접근자
   */
  this.append = function(poValue) {
      this.buffer += eXria.util.StringUtil.fixNull(poValue);
      return this;
  };

  /**
   * append()메소드와 기능이 유사하며 append()와는 달리 추가되는 문자열에
   * 줄바꿈 문자가 덧붙여진다.
   * @param {String} poValue 문자열 표현 값으로 뒤에 줄바꿈 문자가 덧붙여져 문자열 버퍼에 추가될 오브젝트
   * @return 클래스 오브젝트 접근자
   */
  this.appendln = function(poValue) {
      return voBuilder.append(poValue).append("\n");
  };

  /**
   * append()메소드와 기능이 유사하며 append()와는 달리 추가되는 문자열에
   * 줄바꿈 문자가 덧붙여진다.
   * @param {String} poValue 문자열 표현 값으로 뒤에 줄바꿈 문자가 덧붙여져 문자열 버퍼에 추가될 오브젝트
   * @return 클래스 오브젝트 접근자
   */
  this.indexOf = function(psValue) {
      return this.buffer.indexOf(psValue);
  };

  /**
   * append()메소드와 기능이 유사하며 append()와는 달리 추가되는 문자열에
   * 줄바꿈 문자가 덧붙여진다.
   * @param {String} poValue 문자열 표현 값으로 뒤에 줄바꿈 문자가 덧붙여져 문자열 버퍼에 추가될 오브젝트
   * @return 클래스 오브젝트 접근자
   */
  this.lastIndexOf = function(psValue) {
      return this.buffer.lastIndexOf(psValue);
  };

  /**
   * toString();
   */
  this.toString = function() { return this.buffer; };

};
