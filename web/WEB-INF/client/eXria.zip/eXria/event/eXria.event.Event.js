/**
 * @fileoverview
 * abstract Event
 */

/**
 * abstract Event
 * @author 김경태
 * @version 2.0
 * @param {HTMLEvent} e 윈도우 이벤트
 * @constructor
 **/
eXria.event.Event = function(e, poWindow) {
  /**
   * original event
   */
  // window.event를 먼저 기술해야 함. (IE가 e파라미터를 null로 보지 않아서 window.event를 더이상 쓸 수 없게 되는 현상 방지)
  this.e = poWindow ? (poWindow.event || e) : (e || null);

  /**
   * 이벤트 타입(이벤트 종류 식별 문자열).
   * readOnly
   * @type String
   */
  this.type = this.e ? this.e.type : null;

  /**
   * 누른 mouse button이 무엇인지를 나타냄
   * readOnly
   * @type String
   */
  this.mousebutton = this.e ? this.e.button : null;

  /**
   * alt key가 눌려져 있는지 여부.
   * readOnly
   * @type Boolean
   */
  this.altKey = this.e ? this.e.altKey : null;

  /**
   * ctrl key가 눌려져 있는지 여부.
   * readOnly
   * @type Boolean
   */
  this.ctrlKey = this.e ? this.e.ctrlKey : null;

  /**
   * shift key가 눌려져 있는지 여부.
   * readOnly
   * @type Boolean
   */
  this.shiftKey = this.e ? this.e.shiftKey : null;

  /**
   * 키보드에서 눌러진 키의 코드값.
   * readOnly
   * @type Number
   */
  //this.keyCode = (poWindow.event) ? this.e.keyCode : this.e.which;
  //this.keyCode = this.e ? ((poWindow.event) ? this.e.keyCode : this.e.which) : null;
  this.keyCode = this.e ? ((poWindow ? poWindow.event : null) ? this.e.keyCode : this.e.which) : null;
  /**
   * 이벤트 발생 taget 내에서의 마우스 x좌표.
   * readOnly
   * @type Number
   */
  this.clientX = this.e ? this.e.clientX : null;

  /**
   * 이벤트 발생 taget 내에서의 마우스 y좌표.
   * readOnly
   * @type Number
   */
  this.clientY = this.e ? this.e.clientY : null;

  /**
   * 전체 스크린에서의 마우스 x좌표.
   * readOnly
   * @type Number
   */
  this.screenX = this.e ? this.e.screenX : null;

  /**
   * 전체 스크린에서의 마우스 y좌표.
   * readOnly
   * @type Number
   */
  this.screenY = this.e ? this.e.screenY : null;

  /**
   * The element to which the event was originally dispatched.<br>
   * 이벤트 발생 element.
   * readOnly
   * @type HTMLElement
   * @private
   */
  this.target = this.e ? (this.e.srcElement || this.e.target) : null;

  /**
   * For mouse events, this is the element to which the mouse moved.<br>
   * 현재 버블링된 이벤트를 처리하고 있는 element
   * readOnly
   * @type HTMLElement
   * @private
   */
  this.currentTarget = this.e ? (this.e.toElement || this.e.currentTarget) : null;

  /**
   * 이벤트가 발생한 자바스크립트 객체에 대한 참조
   * readOnly
   * @type Unknown
   */
  this.object = null;

  /**
   * 이벤트가 발생한 자바스크립트 객체의 종류 (Control, item)
   * readOnly
   * @type String
   */
  this.objectType = null;

  /**
   * 이벤트가 발생한 자바스크립트 객체를 생성시킨 컨트롤 ID
   * readOnly
   * @type String
   */
  this.baseControlId = null;

  /**
   * 이벤트를 중지.
   */
  this.stopEvent = function() {
    if(this.e == null) return;
    this.stopPropagation();
    this.preventDefault();
  };

  /**
   * 이벤트 전달을 방지.
   */
  this.stopPropagation = function() {
    //      if (this.e.stopPropagation) {    // W3C 모델에서의 이벤트 버블링 방지
    //          this.e.stopPropagation();
    //      } else {                         // IE에서의 이벤트 버블링 방지
    //          this.e.cancelBubble = true;
    //      }
    //
    if(!this.e) return;
    if (this.e.stopImmediatePropagation)
      this.e.stopImmediatePropagation();
    else if (this.e.stopPropagation)
      this.e.stopPropagation();
    else
      this.e.cancelBubble = true;

  };

  /**
   * 이벤트에 대한 기본 동작을 방지
   */
  this.preventDefault = function() {
    //      if(this.e.returnValue){               // IE의 경우
    //        this.e.returnValue = false;
    //      }else if(this.e.preventDefault) {     // W3C 모델의 경우
    //          this.e.preventDefault();
    //      }
    if(this.e == null) return;
    if (this.e.preventDefault) {
      //if(this.e.cancelable) //opera error
      this.e.preventDefault();
    } else
      this.e.returnValue = false;
  };
};
