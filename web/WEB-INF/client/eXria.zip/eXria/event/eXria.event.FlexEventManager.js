﻿/**
 * @fileoverview
 * FlexEventManager
 **/

/**
 * FlexEventManager
 * @author 김경태
 * @version 1.0
 * @constructor
 */
// TODO : 향후 page 또는 canvas에 붙여서 작동시킨다. 현재는 테스트를 위해서 컨트롤별로 생성하는 구조로 되어 있음
eXria.event.FlexEventManager = function() {

  /*
   * 설정된 이벤트 수신자 정보를 보관
   */
  this.events = new eXria.data.ArrayMap();

  /*
   * 실체화 객체(DOM)의 이벤트에 대한 수신자를 연결한다.
   * @param {HTMLElement} poSource : 실체화 객체
   * @param {string} psSourceMemberName : 이벤트 이름
   * @param {function} poTargetMember : 이벤트 수신 함수
   */
  this.addListener = function(poCtrl, psEventType, poTargetMember) {
    if (!poTargetMember || !poTargetMember.call) {
      throw new Error("잘못된 함수와 이벤트 연결을 하고자 합니다.");
    } else {
      poCtrl.addEventListener(psEventType, poTargetMember);    // bubble phase의 이벤트 연결

      this.events.put(poCtrl.getName() + "." + psEventType, poTargetMember);
    }
  };

  /*
   * 실체화 객체(DOM)의 이벤트에 대한 수신자를 해제한다.
   * @param {HTMLElement} poSource : 실체화 객체
   * @param {string} psName : 이벤트 이름
   * @param {function} poTargetMember : 이벤트 수신 함수
   */
  this.removeListener = function(poCtrl, psEventType, poTargetMember) {
    if(!poTargetMember || !poTargetMember.call) {
      throw new Error("잘못된 콜백함수와의 이벤트 연결을 해제하고자 합니다.");
    } else {
      this.events.remove(poCtrl.getName() + "." + psEventType);

      poSource.removeEventListener(psEventType, poTargetMember);  // bubble phase의 이벤트 연결

    }
  };

  /*
   * 이벤트에 연결된 수신자를 리턴한다.
   */
  this.getListener = function(poCtrl, psEventType) {
    return this.events.get(poCtrl.getName() + "." + psEventType);
  };
};