﻿/**
 * @fileoverview
 * JSONParser
 */

/**
 * JSONParser
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.ResponseParser
 * @constructor
 * @private
 */
eXria.protocols.JSONParser = function(poSubmission) {
  eXria.protocols.ResponseParser.call(this, poSubmission);

  /**
   * argument로 넘어온 JavaScript Object를 넘어온 argument의 xml 태그로 변환한다.
   * @param poValue javaScript Object
   * @param psName javaScript Object Name
   * @return String xml Tag
   */
  this.toXml = function(poValue, psName) {
    var vsXml = "";

    if(poValue instanceof Array) {
      for(var i = 0; i < poValue.length; i++) {
        vsXml += this.toXml(poValue[i], psName);
      }
    } else if(typeof(poValue) == "object") {
      var vbHasChild = false;
      vsXml += "<" + psName;
      for(var vsName in poValue) {
        if(vsName.charAt(0) == "@") {
          vsXml += " " + vsName.substr(1) + "=\"" + poValue[vsName].toString() + "\"";
        } else {
          vbHasChild = true;
        }
      }
      vsXml += vbHasChild ? ">" : "/>";
      if(vbHasChild) {
        for(var vsName in poValue) {
          if(vsName == "#text") {
            vsXml += poValue[vsName];
          } else if (vsName == "#cdata") {
            vsXml += "<![CDATA[" + poValue[vsName] + "]]>";
          } else if (vsName.charAt(0) != "@") {
            vsXml += this.toXml(poValue[vsName], vsName);
          }
        }
        vsXml += "</" + psName + ">";
      }
    } else {
      vsXml += "<" + psName + ">";
      vsXml += poValue.toString();
      vsXml += "</" + psName + ">";
    }
    return vsXml;
  }
  /**
   * argument로 넘어온 JavaScript Object를 xml로 변환한다.
   * @param poJSON JavaScript Object
   * @return String xml tag
   */
  this.json2xml = function(poJSON, psRootName) {
    var vsXml = new eXria.lang.StringBuilder();
    vsXml.append("<"); //start tag
    vsXml.append(psRootName);
    vsXml.append(">");

    var voAtt = null;
    for(var vsAttNm in poJSON) {
      voAtt = poJSON[vsAttNm];
      vsXml.append(this.toXml(voAtt, vsAttNm));
    }
    vsXml.append("</"); //end tag
    vsXml.append(psRootName);
    vsXml.append(">");

    return vsXml;
  }

  this.textParse = function(psText) {
  var voResponse;
  if(!psText || psText == "") {
    voResponse = "";
  } else {
    eval('voResponse = ' + psText);
  }

  var vsRoot = null;
  for(vsRoot in voResponse) {
    voRoot = voResponse[vsRoot];
  }

  var vsXml = this.json2xml(voRoot, vsRoot); //converting

  var voResponseXML = this.text2Dom(vsXml); //parsing
  return voResponseXML;
  }

  this.parse = function(poXMLHttpRequest) {
    var vsJSON = poXMLHttpRequest.responseText; //json text
    return this.textParse(vsJSON);
  };
};