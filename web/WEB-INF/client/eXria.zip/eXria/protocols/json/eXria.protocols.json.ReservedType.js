/**
 * @fileoverview
 * JSON buildElement2Param 시 제외할 타입의 상수 클래스</br>
 * enum list</br>
 * - eXria.protocols.json.ReservedType.PARENT : JSON Instance 생성시 사용되어지는 예약어</br>
 * - eXria.protocols.json.ReservedType.NODENAME : JSON Instance 생성시 사용되어지는 예약어</br>
 */
/**
 * JSON buildElement2Param 시 제외할 타입의 상수 클래스
 * @author
 * @version 1.0
 * @constructor
 */
eXria.protocols.json.ReservedType = {
  parent : "parent",
  nodeName : "nodeName"
};