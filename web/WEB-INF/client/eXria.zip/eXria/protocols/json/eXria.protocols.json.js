/**
 * @fileoverview
 * eXria.protocols.json package
 */
/**
 * eXria.protocols.json package
 * @version 1.0
 */

/**
 * eXria.protocols
 */
eXria.protocols.json = {};
