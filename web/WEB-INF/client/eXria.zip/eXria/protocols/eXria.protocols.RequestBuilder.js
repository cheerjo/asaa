﻿/**
 * @fileoverview
 * Abstract RequestBuilder
 */

/**
 * Abstract RequestBuilder
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @constructor
 * @private
 */
eXria.protocols.RequestBuilder = function(poSubmission) {
  /**
   * Submission Object
   */
  this.submission = poSubmission;
  /**
   * Submission의 parameter 및 refs를 이용하여
   * XMLHttpRequest에서 send할때 필요한 DOMString 또는 XMLDocument를 생성하고,
   * Submission객체의 sendAction function을 호출하여 실제 submission을 send한다.
   * JSON-RPC 또는 SOAP-RPC의 경우는 서버 콜을 처리할 Proxy 객체를 생성하여 리턴한다.
   * Proxy객체는 Submission을 내부에 포함하고 있고, 서버 요청시 내부의 Submission을 이용하여
   * Submission의 sendAction function을 호출하여 실제 submission을 send한다.
   * @param
   * @return Object DOMString or XMLDocument
   */
  this.build = null;
};