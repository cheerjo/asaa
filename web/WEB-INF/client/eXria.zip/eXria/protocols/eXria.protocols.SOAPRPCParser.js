/**
 * @fileoverview
 * SOAPRPCParser
 * 서버 리턴 타입에 대하여 현재 서버는
 * primitive type과 Primitive Type Array 만을 지원한다.
 * Client에서 WebService로 지원할 리턴 타입은
 * primitive type, array, map 까지 구현
 * 보다 복잡한 타입은 지원 불가.
 * 예) Array안에 Map 또는 Map안에 Array 등
 * TODO ID를 참조하는 XML 문서의 파싱 부분 고려 예정
 */
/**
 * SOAPRPCParser
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.ResponseParser
 * @constructor
 * @private
 */
eXria.protocols.SOAPRPCParser = function(poSubmission) {
  eXria.protocols.ResponseParser.call(this, poSubmission);

  this.bind = false;

  this.parse = function(poXMLHttpRequest) { //TODO 현재 Text로 되어 있으나 향후 DOM으로 하던지 아니면 xml encoding 로직 추가
    var voResponseXML = poXMLHttpRequest.responseXML;
    if(!voResponseXML) {
      return;
    }

    var voResultList = voResponseXML.documentElement.getElementsByTagName("result");
    if(!voResultList) {
      return null;
    }

    var voResult = eXria.data.xhtml.DocumentFactory.createDocument(this.submission.model.page);
    voResult.loadXML(voResponseXML.documentElement);

    var vsReturnDataType;
    var voDocElement = voResultList[0];
    vsReturnDataType = voDocElement.attributes.getNamedItem('xsi:type').value;
    vsReturnDataType = vsReturnDataType.substring(vsReturnDataType.lastIndexOf(':') + 1);

    //TODO multi response ref 가 되면서 본 코드는 수정되어야 한다.
    //var vsRootName = this.getResponseTagName(); //get response ref instance tag name
    var vsRootName = "root";
    var vsXml = new eXria.lang.StringBuilder();

    //xml text create
    vsXml.append('<');
    vsXml.append(vsRootName);
    vsXml.append('>');

    switch(vsReturnDataType) { //parsing
      case "string" :
      case "int" :
      case "long" :
      case "double" :
      case "date" :
      case "boolean" :
        vsXml.append(String(this.getNodeValue(voDocElement, voResult)));
        break;
      case "Array" :
        for(var i = 0; i < voDocElement.childNodes.length; i++) { //item loop
          vsXml.append('<list>'); //임시로 배열일 경우 tag name을 item으로 TODO 확정 필요
          vsXml.append(this.toXml(voDocElement.childNodes[i], voResult));
          vsXml.append('</list>');
        }
        break;
      case "Map" :
        var voItemNode, vsKey, vsValue;
        for(var i = 0; i < voDocElement.childNodes.length; i++) { //item loop
          var voItem = voDocElement.childNodes[i];
          var voInnerItem;
          if(voItem.attributes && voItem.attributes.getNamedItem('href')) {
            //link item
            voInnerItem = this.getLinkElement(voItem.attributes.getNamedItem('href').value, voResult);
          } else {
            //item
            voInnerItem = voItem;
          }

          var vsKey = String(this.getNodeValue(voInnerItem.getElementsByTagName('key')[0]));
          var vsValue = String(this.getNodeValue(voInnerItem.getElementsByTagName('value')[0]));

          vsXml.append('<');
          vsXml.append(vsKey);
          vsXml.append('>');
          vsXml.append(vsValue);
          vsXml.append('</');
          vsXml.append(vsKey);
          vsXml.append('>');
        }
        break;
    }

    vsXml.append('</');
    vsXml.append(vsRootName);
    vsXml.append('>');

    var voResXML = this.text2Dom(vsXml); //parsing
    return voResXML.documentElement;
  };

  this.toXml = function(poValue, poResponseXML) { /* element, document */
    var vsReturnDataType;
    if(poValue.attributes && poValue.attributes.getNamedItem('xsi:type')) {
      vsReturnDataType = poValue.attributes.getNamedItem('xsi:type').value;
      vsReturnDataType = vsReturnDataType.substring(vsReturnDataType.lastIndexOf(':') + 1);
    } else {
      vsReturnDataType = "";
    }

    //xml text create
    var vsXml = new eXria.lang.StringBuilder();
    switch(vsReturnDataType) { //parsing
      case "string" :
      case "int" :
      case "long" :
      case "double" :
      case "date" :
      case "boolean" :
        vsXml.append(String(this.getNodeValue(poValue, poResponseXML)));
        break;
      case "Array" :
        for(var i = 0; i < poValue.childNodes.length; i++) { //item loop
          vsXml.append('<list>'); //임시로 배열일 경우 tag name을 item으로 TODO 확정 필요
          vsXml.append(this.toXml(poValue.childNodes[i], poResponseXML));
          vsXml.append('</list>');
        }
        break;
      case "Map" :
        var voItemNode, vsKey, vsValue;
        for(var i = 0; i < poValue.childNodes.length; i++) { //item loop
          var voItem = poValue.childNodes[i];
          var voInnerItem;
          if(voItem.attributes && voItem.attributes.getNamedItem('href')) {
            //link item
            voInnerItem = this.getLinkElement(voItem.attributes.getNamedItem('href').value, poResponseXML);
          } else {
            //item
            voInnerItem = voItem;
          }

          var vsKey = String(this.getNodeValue(voInnerItem.getElementsByTagName('key')[0], poResponseXML));
          var vsValue = String(this.getNodeValue(voInnerItem.getElementsByTagName('value')[0], poResponseXML));

          vsXml.append('<');
          vsXml.append(vsKey);
          vsXml.append('>');
          vsXml.append(vsValue);
          vsXml.append('</');
          vsXml.append(vsKey);
          vsXml.append('>');
        }
        break;
    }

    return vsXml;
  };

  this.getLinkElement = function(psId, poResponseXML) {
    if(eXria.util.StringUtil.startsWith(psId, "#")) {
      psId = psId.substring(1);
    }
    var vvelement = poResponseXML.selectSingleNode("//*[@id='" + psId + "']");

    return poResponseXML.selectSingleNode("//*[@id='" + psId + "']");
  };

  this.getNodeValue = function(poNode, poResponseXML) { /* element, document */
    if(poNode.attributes && poNode.attributes.getNamedItem("href")) {
      return this.toXml(this.getLinkElement(poNode.attributes.getNamedItem("href").value, poResponseXML));
    } else if(poNode.childNodes.length == 1 && poNode.childNodes[0].nodeType != 1) {
      return poNode.childNodes[0].nodeValue;
    } else if(poNode.childNodes.length == 1) {
      return this.toXml(poNode.childNodes[0], poResponseXML);
    } else if(poNode.childNodes.length > 1) {
      return this.toXml(poNode, poResponseXML);
    }
  };
};