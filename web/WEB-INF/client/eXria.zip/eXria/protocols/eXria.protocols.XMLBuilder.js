﻿/**
 * @fileoverview
 * XMLBuilder
 */
/**
 * XMLBuilder
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.RequestBuilder
 * @constructor
 * @private
 */
eXria.protocols.XMLBuilder = function(poSubmission) {

  eXria.protocols.RequestBuilder.call(this, poSubmission);

  this.build = function() {
    //url은 머를 넣을  것인가? xmlns? 이건 어떻게 정의되나?
    //Dom의 encoding 추가
    var voDomParser = eXria.data.DOMParserFactory.getParser(poSubmission.model.page);
    //root element name = 'root'
    var viRequestXml = voDomParser.parse("<?xml version=\"1.0\" encoding=\"" + this.submission.reqCharset + "\"?><root/>");
    var viRootNode = viRequestXml.documentElement;

    /**
     * XML Build
     * 1. request ref build
     * 2. parameter build
     */
    //request ref build
    var vaRefs = this.submission.getRefs();
    var voXPath;
    var viInstance;
    var viRefInstance;
    for(var i = 0; i < vaRefs.length; i++) {
      voXPath = vaRefs[i]; //eXria.protocols.Ref
      //Instance의 Id와 xpath는 eXria.protocols.Ref를 이용하여 가져온다. Submission의 Refs는 eXria.protocols.Ref를 배열로 관리한다.
      viInstance = this.submission.model.getInstance(voXPath.getId());

      viRefInstance = viInstance.document.selectSingleNode(voXPath.getPath()); //DOM Instance
      if(viRefInstance) {
        //safari는 clone하지 않으면 붙지 않는다.
        viRootNode.appendChild(viRefInstance.cloneNode(true));
      }
    }

    //parameter build
    var vaParamValue; //Array
    var viParamNode, viParamValueNode;
    for(var vsParamName in this.submission.parameters.entries) { //parameter search loop
      vaParamValue = this.submission.getParameter(vsParamName);
      for(var i = 0; i < vaParamValue.length; i++) { //parameter value loop
        viParamValueNode = viRequestXml.createTextNode(vaParamValue[i]); //text node
        viParamNode = viRequestXml.createElement(vsParamName); //element
        viParamNode.appendChild(viParamValueNode);
        //Root Node의 마지막에 Append
        viRootNode.appendChild(viParamNode);
      }
    }

    //document에 Root Element Append
    this.submission.sendAction(viRequestXml); /* must XMLDocument */
  };
};