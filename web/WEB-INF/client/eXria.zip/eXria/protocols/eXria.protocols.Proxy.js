﻿/**
 * @fileoverview
 * Proxy Interface
 */

/**
 * Abstract Proxy
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @constructor
 * @private
 */
eXria.protocols.Proxy = function(poSubmission) {
  /**
   * @private
   */
  this.submission = poSubmission;
  /**
   * Proxy에 Stub Function을 Proxy에 추가한다.
   * @param {String} paMethodNames 배열의 function명
   * @return void
   * @type void
   * @socpe private
   * @private
   */
  this.addMethods = function(paMethodNames) {
  for(var i = 0; i < paMethodNames.length; i++) {
    var poProxy = this;
    var paNames = paMethodNames[i].split(".");
    var psMethodName = paNames[paNames.length - 1]; /* real exeution method */
    var poMethod = this.createMethod(paMethodNames[i]);
    poProxy[psMethodName] = poMethod;
  }
  };
  /**
   * Function Object를 생성한다.
   * @param psMethodName String Function 명
   * @return Function Object
   * @type Object
   * @private
   */
  this.createMethod = function(psMethodName) {
    /*
     * 생성 Method의 Template.
     */
    var poFunctionTemplate = function() {
      var vaParam = new Array();
      for(var i = 0; i < arguments.length; i++) {
        vaParam[i] = arguments[i];
      }
      var voProxy = poFunctionTemplate.proxy;
      var voRequestData = voProxy.makeRequest.call(voProxy, poFunctionTemplate.methodName, vaParam);

      var voSubmission = voProxy.submission; //submission
      return voSubmission.sendAction(voRequestData);
    };
    poFunctionTemplate.proxy = this;
    poFunctionTemplate.methodName = psMethodName;
    return poFunctionTemplate;
  };

  /**
   * 하위 클래스에서 Proxy를 생성하기 위한 Processor를 구현한다.
   * @return void
   * @type void
   */
  this.buildProxy = null; //abstract
  /**
   * Request Datqa를 생성한다.
   * 각 하위 Builder는 각 Platform에 맞게 구현한다.
   * @param psMethodName 실행할 Method 명
   * @param paArgs 서버에 전달할 Argument Array
   * @param poCallback AJAX Callback Function
   * @return 서버에 전달할 Object
   * @scope protected
   * @private
   */
  this.makeRequest = null; //abstract
};