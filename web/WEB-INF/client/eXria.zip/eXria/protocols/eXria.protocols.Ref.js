/**
 * @fileoverview
 * Request 및 Response시 Submission에 포함 시킬 Reference를 포함하는 클래스
 */

/**
 * Request 및 Response시 Submission에 포함 시킬 Reference를 포함하는 클래스
 * @version 1.0
 * @param {String} psId Instance Id
 * @param {String} psPath Node XPath
 * @param {Boolean} pbReplace Element Replace 여부
 * @constructor
 * @private
 */
eXria.protocols.Ref = function(psId, psPath, pbReplace) {
  /**
   * @private
   */
  this.id = psId;
  /**
   * @private
   */
  this.path = psPath;
  /**
   * @private
   */
  this.replace = pbReplace ? pbReplace : false;
  /**
   * 현재 Ref 클래스의 Id를 리턴
   * @return Ref Class Id
   * @type String
   */
  this.getId = function() {
    return this.id;
  };
  /**
   * 현재 클래스가 저장하고 있는 Instance Path를 리턴
   * @return Instance path
   * @type String
   */
  this.getPath = function() {
    return this.path;
  };
  /**
   * Replace Type 리턴
   * @return Replace Type
   * @type Number
   */
  this.getReplace = function() {
    return this.replace;
  };
};