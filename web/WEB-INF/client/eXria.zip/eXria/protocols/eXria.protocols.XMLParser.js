﻿/**
 * @fileoverview
 * XMLParser
 */
/**
 * XMLParser
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.ResponseParser
 * @constructor
 * @private
 */
eXria.protocols.XMLParser = function(poSubmission) {
  eXria.protocols.ResponseParser.call(this, poSubmission);

  this.textParse = function(psText) {
  var voDocument = eXria.data.xhtml.DocumentFactory.createDocument(this.submission.model.page);
    voDocument.loadTXT(psText);
    return voDocument.dom;
  }

  this.parse = function(poXMLHttpRequest) {
    var vsContentType = poXMLHttpRequest.getResponseHeader("Content-Type");
    var voResponseXML = null;
    if(vsContentType && vsContentType.indexOf("xml") > -1) {
      voResponseXML = poXMLHttpRequest.responseXML;
    } else {
      voResponseXML = this.textParse(poXMLHttpRequest.responseText);
    }
    return voResponseXML;
  };
};