﻿/**
 * @fileoverview
 * SOAPRPCBuilder
 */

/**
 * SOAPRPCBuilder
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.XMLBuilder
 * @base eXria.protocols.Proxy
 * @constructor
 * @private
 */
eXria.protocols.SOAPRPCBuilder = function(poSubmission) {
  //inheritance
  eXria.protocols.XMLBuilder.call(this, poSubmission);
  eXria.protocols.Proxy.call(this, poSubmission);

  this.buildProxy = function() {
    /*
     * TODO
     * 1. WSDML 호출
     * 2. Method List Create
     * 3. Proxy 생성
     * 4. Proxy 리턴
     */
    /* WSDL 호출 */
    var voWSDL = this.sendRequest();
    if(voWSDL == null) {
      //TODO Exception or Null return
      return;
    }

    /* Proxy 생성 */
    var voDocument = eXria.data.xhtml.DocumentFactory.createDocument(this.submission.model.page);
    voDocument.loadXML(voWSDL);

    var voOperationNodeList = voDocument.selectNodes("//*[namespace-uri()='http://schemas.xmlsoap.org/wsdl/' and local-name()='operation']");

    var vnNodeSize = voOperationNodeList.getLength();
    for(var i = 0; i < vnNodeSize; i++) {
      var voNode = voOperationNodeList.item(i);
      var vsMethodName = voNode.attributes.getNamedItem("name").value; //method name xpath-> //operation/@name
      var poMethod = this.createMethod(vsMethodName);
      this[vsMethodName] = poMethod;
    }

    return this;
  };

  //TODO encoding 설정 추가
  this.soapHeader = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><soap:Body>';
  this.soapTail   = '</soap:Body></soap:Envelope>';

  /**
   * <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
   *                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
   *                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   *   <soap:Body>
   *     <tns:sampleMethod xmlns:tns="SampleService">
   *       <mystring xsi:type="xsd:string">AJAX Script를 이용한 WebService Call!!!</mystring>
   *       <count xsi:type="xsd:int">5</count>
   *     </tns:sampleMethod>
   *   </soap:Body>
   * </soap:Envelope>
   *
   * <tns:sum xmlns:tns="SampleService">
   *   <arrayofint1 xmlns:ns2="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="ns2:Array" ns2:arrayType="xsd:int[5]">
   *     <item xsi:type="xsd:int">1</item>
   *     <item xsi:type="xsd:int">2</item>
   *     <item xsi:type="xsd:int">3</item>
   *     <item xsi:type="xsd:int">4</item>
   *     <item xsi:type="xsd:int">5</item>
   *   </arrayofint1>
   * </tns:sum>
   *
   * <multiRef id="id1" xsi:type="ns11:Map" xmlns:ns11="http://xml.apache.org/xml-soap">
   *   <item>
   *     <key xsi:type="xsd:dateTime">2001-10-05T22:07:04.629Z</key>
   *     <value xsi:type="xsd:string">string value</value>
   *   </item>
   *   <item>
   *     <key xsi:type="xsd:string">stringKey</key>
   *     <value xsi:type="xsd:int">5</value>
   *   </item>
   * </multiRef>
   *
   * support type :
   * String, Number, Boolean, Date, Array, eXria.data.Map, eXria.data.ArrayMap
   */
  this.makeRequest = function(psMethodName, paArgs) {
    /*
     * TODO
     * WSDL 요청시에는 호출되지 않음.
     * Method Invoke 시 넘겨 받은 Parameter 정보를 기준으로
     * SOAP Message를 만듦
     * primitive type and complex type?
     */
    /* soap message */
    var vsSoapMsg = new eXria.lang.StringBuilder();
    /* header */
    vsSoapMsg.append(this.soapHeader);

    /* body */
    vsSoapMsg.append('<tns:' + psMethodName + ' xmlns:tns="');
    {
      var vsServiceName = this.submission.action;
      if(vsServiceName.indexOf("/") > -1) {
        vsServiceName = vsServiceName.substring(vsServiceName.lastIndexOf("/") + 1);
      }
      vsSoapMsg.append(vsServiceName + '">');
    }

    /* parameter setting */
    //TODO Parameter Setting
    //primitive, array, map
    var vsParamName = "param";
    var voParam;
    var paramSeq = 1;

    for(var i = 0; i < paArgs.length; i++) {
      vsSoapMsg.append("<" + vsParamName + paramSeq + " " + this.getXsiType(paArgs[i]) + ">");
      voParam = paArgs[i];

      //TODO Dom으로 바꾸던지 값을 encoding하던지 결정
      switch(voParam.constructor) {
        case String :  //String
        case Number :  //long or double
        case Boolean : //boolean
        case Date :    //Date
          vsSoapMsg.append(voParam);
          break;
        case Array :                     //Array
        case eXria.data.Collection :      //Array
        case eXria.data.ArrayCollection : //Array
          /* <arrayofint1 xmlns:ns2="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="ns2:Array" ns2:arrayType="xsd:int[5]">
           * <item xsi:type="xsd:int">1</item>
           * ...
           * </arrayofint1>
           */
          var vaArray;
          if(voParam.constructor == Array) {
            vaArray = voParam;
          } else {
            vaArray = voParam.elements;
          }
          if(vaArray.length > 0) {
            var vsInitiType = this.getXsiType(vaArray[0]);
            for(var i = 0; i < vaArray.length; i++) {
              vsSoapMsg.append('<item ' + vsInitiType + '>');
              vsSoapMsg.append(vaArray[0]);
              vsSoapMsg.append('</item>');
            }
          }
          break;
        case eXria.data.Map :      //Map
        case eXria.data.ArrayMap : //Map
          /* <multiRef id="id1" xsi:type="ns11:Map" xmlns:ns11="http://xml.apache.org/xml-soap">
           * <item>
           * <key xsi:type="xsd:dateTime">2001-10-05T22:07:04.629Z</key>
           * <value xsi:type="xsd:string">string value</value>
           * </item>
           * ...
           * </multiRef>
           */
          var vsValueType; /* xsd type of value */
          var voValue;     /* value in map */
          for(var vsKey in voParam.entries) {
            vsSoapMsg.append('<item>');
            vsSoapMsg.append('<key xsi:type="xsd:string">'); /* Map의 key는 string type */
            vsSoapMsg.append(vsKey);
            vsSoapMsg.append('</key>');
            voValue = voParam.entries[vsKey];
            vsValueType = this.getXsiType(voValue);
            vsSoapMsg.append('<value ' + vsValueType + '>');
            vsSoapMsg.append(voValue);
            vsSoapMsg.append('</value>');
            vsSoapMsg.append('</item>');
          }
          break;
        default :
          vsSoapMsg.append(voParam);
      }

      vsSoapMsg.append("</" + vsParamName + paramSeq + ">");
      paramSeq++; //sequence increase
    }

    vsSoapMsg.append('</tns:' + psMethodName + '>');

    /* tail */
    vsSoapMsg.append(this.soapTail);

    //Parse from String to XMLDocument
    var voDomParser = eXria.data.DOMParserFactory.getParser(poSubmission.model.page);
    var voRequestDocument = voDomParser.parse(vsSoapMsg.toString());

    return voRequestDocument;
  };

  /**
   * Support Type :
   * String, Number, Boolean, Date, Array[primitive], eXria.data.Collection[primitive], eXria.data.ArrayCollection[primitive], eXria.data.Map, eXria.data.ArrayMap
   */
  this.getXsiType = function(poParam) {
    var vsXsiType = new eXria.lang.StringBuilder();

    switch(poParam.constructor) {
      case String : //String
        vsXsiType.append('xsi:type="xsd:string"');
        break;
      case Number : //long or double
        if(new String(poParam).indexOf(".") > -1) {
          vsXsiType.append('xsi:type="xsd:double"');
        } else {
          vsXsiType.append('xsi:type="xsd:long"');
        }
        break;
      case Boolean : //boolean
        vsXsiType.append('xsi:type="xsd:boolean"');
        break;
      case Date : //Date
        vsXsiType.append('xsi:type="xsd:date"');
        break;
      case Array : //Array
      case eXria.data.Collection : //Array
      case eXria.data.ArrayCollection : //Array
        vsXsiType.append('xmlns:typens="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="typens:Array"');
        vsXsiType.append(' typens:arrayType="');

        var vaArray;
        if(poParam.constructor == Array) {
          vaArray = poParam;
        } else {
          vaArray = poParam.elements;
        }

        {
          var vnArraySize = vaArray.length;
          var vsType;
          if(vaArray.length > 0) {
            //Array의 구성요소는 기본형만 지원한다.
            vsType = this.getXsiType(vaArray[0]);
            if(vsType == null || vsType == "") {
              vsType = "xsd:string"; //default String
            } else if(vsType <= 10) {
              vsType = "xsd:string";
            } else {
              vsType = vsType.substring(10, vsType.length - 1);
            }
          } else {
            vsType = "xsd:string"; //default String
          }
          vsType += "[" + vnArraySize + "]";
          vsXsiType.append(vsType);
        }
        vsXsiType.append('"');
        break;
      case eXria.data.Map : //Map
      case eXria.data.ArrayMap : //Map
        vsXsiType.append('xmlns:typens="http://xml.apache.org/xml-soap" xsi:type="typens:Map"');
      break;
      default :
        vsXsiType.append('xsi:type="xsd:string"'); //default string
    }

    return vsXsiType.toString();
  };

  /**
   * wsdl 요청
   */
  this.sendRequest = function() {
    //get XMLHttpRequest
    var voHttpRequest = eXria.form.xhtml.HttpRequestFactory.create();

    //synchronized ajax call
    //append '?wsdl' to this.serverURL
    voHttpRequest.open("GET", this.submission.action + "?wsdl", false); //GET 으로 할까?
    voHttpRequest.onreadystatechange = function() {};

    try {
      voHttpRequest.setRequestHeader("Content-type", "text/xml");
      voHttpRequest.setRequestHeader("req-protocol", "webservice");
      voHttpRequest.setRequestHeader("res-protocol", "webservice");
    } catch(e) {}

    try {
      voHttpRequest.send(""); //WSDL요청시에는 메시지 없음.
    } catch(e) {
      throw new Error("Connection failed");
    }

    return this.handleResponse(voHttpRequest);
  };

  this.handleResponse = function(poHttpRequest) {
    /* Get request results */
    var vnStatus;     /* response status of XMLHttpRequest */
    var vsStatusText; /* response status text of XMLHttpRequest */
    var voWSDL;       /* response xml data of XMLHttpRequest */
    try {
      vnStatus = poHttpRequest.status;
      vsStatusText = poHttpRequest.statusText;
      voWSDL = poHttpRequest.responseXML;
    } catch(e) {
      throw new Error("Connection failed");
    }

    /* Unmarshall the response */
    if(vnStatus != 200) { //TODO Exception 처리 debug
      throw new Error(vsStatusText);
    }

    if(voWSDL.documentElement) {
      return voWSDL.documentElement; /* DOM Document */
    } else {
      return voWSDL; /* DOM Document */
    }
  };

  /*
   * submission's build implementation
   */
  this.build = function() {
    //start point
    return this.buildProxy();
  };
};