/**
 * @fileoverview
 * SubmissionType
 */

/**
 * Submission Type을 상수 정의하는 클래스
 * enum
 * @version 1.0
 * @constructor
 * @private
 */
eXria.protocols.SubmissionType = {
  URL_ENCODED : "urlencoded" /* request-type, response-type : urlencoded */
, JSON        : "json"       /* request-type, response-type : json */
, JSON_RPC    : "json/rpc"   /* request-type, response-type : json/rpc */
, XML         : "xml"        /* request-type, response-type : xml */
, SOAP_RPC    : "webservice" /* request-type, response-type : webservice */
, REQ_PROTOCOL_HEADER : "req-protocol"
, RES_PROTOCOL_HEADER : "res-protocol"
, MULTIPART   : "multipart/form-data"
, UNENCODED   : "unencoded"
};