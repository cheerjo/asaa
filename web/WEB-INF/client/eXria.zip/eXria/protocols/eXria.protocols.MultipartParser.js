/**
 * @fileoverview
 * MultipartParser
 */
/**
 * MultipartParser
 * @author Choe, hyeon jong
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.ResponseParser
 * @constructor
 * @private
 */
eXria.protocols.MultipartParser = function(poSubmission) {
  eXria.protocols.ResponseParser.call(this, poSubmission);
  this.complete = false;
  
  if(page.metadata.useJsonInstance) {
    this.textParse = function(psText) {
      try {
        var voResult =eval("(" + psText + ")");
        this.submission.redirectJsonLocation(voResult);
        this.submission.bindJsErrMsg(voResult);
        this.submission.bindJsInstance(voResult);
        if(this.submission.onSubmitDone) {
          this.submission.onSubmitDone(this.submission);
        }
      } catch(e) {
        if(this.submission.onSubmitError) {
          this.submission.onSubmitError(voResult);
        }
      }
    };
  } else {
    this.textParse = function(psText) {
      var voResponseParser = eXria.protocols.ProtocolParserFactory.getResponseParser(this.submission, this.submission.resProtocol);
      try {
        var voResult = voResponseParser.textParse(psText);
        this.submission.redirectLocation(voResult);
        this.submission.bindErrMsg(voResult);
        if(voResponseParser.bind) {
          this.submission.bindInstance(voResult);
        }
        if(this.submission.onSubmitDone) {
          this.submission.onSubmitDone(this.submission);
        }
      } catch(e) {
        if(this.submission.onSubmitError) {
          this.submission.onSubmitError(voResult);
        }
      }
    };
  }
  this.parse = function(poFrame, poFunc) {
	  var vsResult = null;
	  var voReadyState = poFrame.readyState;
    var vbSuccess;
	  if(voReadyState) {
	    if(voReadyState == "complete" && !this.complete) {
		    this.complete = true;
		    vsResult = this.submission.model.page.window.document.frames[poFrame.id].document.body;
		    if(vsResult != null) vsResult = vsResult.innerText;
		    try {
		      this.textParse(vsResult);
          vbSuccess = true;
        } catch(err) {
          vbSuccess = false;
        }
				if(poFunc != null) poFunc(vbSuccess);
	    }
	  } else {
	    try {
	    	vsResult = poFrame.contentWindow.document.body.firstChild.firstChild.nodeValue;
        vbSuccess = true;
	    } catch(e) {
	    	vsResult = "complete";
        vbSuccess = false;
	    }
	    this.textParse(vsResult);
			if(poFunc != null) poFunc(vbSuccess);
	  }
  };
};