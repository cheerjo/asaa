﻿/**
 * @fileoverview
 * URLEncodingParser
 */
/**
 * URLEncodingParser
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.ResponseParser
 * @constructor
 * @private
 */
eXria.protocols.URLEncodingParser = function(poSubmission) {
  eXria.protocols.ResponseParser.call(this, poSubmission);

  this.parse = function(poXMLHttpRequest) {
    var voResponseXML = poXMLHttpRequest.responseXML;
    return voResponseXML;
  };
};