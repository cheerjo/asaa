﻿/**
 * @fileoverview
 * JSONRPCBuilder
 */

/**
 * JSONRPCBuilder
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.JSONBuilder
 * @base eXria.protocols.Proxy
 * @constructor
 * @private
 */
eXria.protocols.JSONRPCBuilder = function(poSubmission) {
  //inheritance
  eXria.protocols.JSONBuilder.call(this, poSubmission);
  eXria.protocols.Proxy.call(this, poSubmission);

  //proxy build
  this.buildProxy = function() {
    /* Add standard methods */
    //this.addMethods(["system.listMethods"]);
    var voRequest = this.makeRequest("system.listMethods", []);
    var vaMethods = this.sendRequest(voRequest); /* synchronized send */
    this.addMethods(vaMethods);

    return this;
  };

  //Proxy abstract method implementation
  this.makeRequest = function(psMethodName, paArgs) {
    var poReqData = {};
    poReqData.method = psMethodName;
    poReqData.params = paArgs;

    return this.toJSONString(poReqData);
  };

  /*
   * Stub을 만들기 위한 Server Request Sender
   * synchronized ajax call
   */
  this.sendRequest = function(poRequest) {
    //get XMLHttpRequest
    var voHttpRequest = eXria.form.xhtml.HttpRequestFactory.create();

    //synchronized ajax call
    voHttpRequest.open("POST", this.submission.action, false);
    voHttpRequest.onreadystatechange = function() {};

    try {
      voHttpRequest.setRequestHeader("Content-type", "text/plain");
      voHttpRequest.setRequestHeader("req-protocol", "json/rpc");
      voHttpRequest.setRequestHeader("res-protocol", "json/rpc");
    } catch(e) {}

    try {
      voHttpRequest.send(poRequest);
    } catch(e) {
      throw new Error("Connection failed");
    }

    return this.handleResponse(voHttpRequest);
  };

  //XMLHttpRequest Response Handler
  this.handleResponse = function(poHttpRequest) {
    /* Get request results */
    var vnStatus;     /* response status of XMLHttpRequest */
    var vsStatusText; /* response status text of XMLHttpRequest */
    var vsData;       /* response data of XMLHttpRequest */
    try {
      vnStatus = poHttpRequest.status;
      vsStatusText = poHttpRequest.statusText;
      vsData = poHttpRequest.responseText;
    } catch(e) {
      throw new Error("Connection failed");
    }

    /* Unmarshall the response */
    if(vnStatus != 200) { //TODO Exception debug
      throw new Error(vsStatusText);
    }

    var voResponse;
    try {
      eval("voResponse = " + vsData);
    } catch(e) {
      throw new Exception("error parsing result");
    }
    if(voResponse.error) {
      throw new Exception(voResponse.error.msg);
    }
    var voResult = voResponse.result;

    return voResult;
  };

  /*
   * submission's build implementation
   */
  this.build = function() {
    //start point
    return this.buildProxy();
  };
};