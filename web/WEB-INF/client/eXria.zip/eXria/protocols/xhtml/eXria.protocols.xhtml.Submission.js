/**
 * @fileoverview
 * XHTML Mode 사용시 서버와의 data통신 프로세스를 담당.
 */

/**
 * XHTML Mode 사용시 서버와의 data통신 프로세스를 담당.
 * @version 1.0
 * @param {String} psId Submission Id
 * @param {eXria.form.Model} poModel eXria.form.Model
 * @constructor
 * @base eXria.protocols.Submission
 */
eXria.protocols.xhtml.Submission = function(psId, poModel) {
  eXria.protocols.Submission.call(this, psId, poModel);
  /**
   * private
   */
  this.crudData = "";

  this.uploadFileCtrls = new eXria.data.Map();
  this.dataSetIds = {};
  /**
   * submission Instance
   * @type eXria.protocols.Submission
   * @see eXria.protocols.Submission
   * @ignore
   */
  var submissionInstance = this;
  /**
   * request protocol 셋팅
   * @param {String} request protocol
   * @return void
   * @type void
   */
  this.setReqProtocol = function(psReqProtocol) {
    this.reqProtocol = psReqProtocol;
  };
  /**
   * response protocol 셋팅
   * @param {String} response protocol
   * @return void
   * @type void
   */
  this.setResProtocol = function(psResProtocol) {
    this.resProtocol = psResProtocol;
  };
  /**
   * request protocol을 리턴한다.
   * @type {String}
   * @return request protocol
   */
  this.getReqProtocol = function() {
    return this.reqProtocol;
  };
  /**
   * response protocol을 리턴한다.
   * @type {String}
   * @return request protocol
   */
  this.getResProtocol = function() {
    return this.resProtocol;
  };
  /**
   * XMLHttpRequest를 synchronized 방식으로 동작시킬지</br>
   * asynchronized로 동작시킬지를 설정한다.</br>
   * true : asynchronized, false : synchronized
   * @type Boolean
   * @default true
   * @ignore
   */
  this.async = true;
  /**
   * synchronize 유무를 결정한다.
   * @param {Boolean} pbAsync sync 유무
   * @return void
   * @type void
   * @private
   */
  this.setAsync = function(pbAsync) {
    this.async = pbAsync;
  };
  /**
   * HTTP Method (GET/POST)
   * @type String
   * @ignore
   */
  this.method = "POST"; //default POST
  /**
   * HTTP Meothod를 셋팅한다.
   * @param {String} psMethod method
   * @return void
   * @type void
   * @private
   */
  this.setMethod = function(psMethod) {
    this.method = psMethod;
  };
  /**
   * 서브미션의 action Url 지정
   * @param {String} Action
   * @return void
   * @type void
   */
  this.setAction = function(psAction) {
    var vsTmpAction = psAction;
    var vsRegAction = null;

    if(this.model.page.metadata.submitBaseUrl == null || this.model.page.metadata.submitBaseUrl == "") {
    if(eXria.util.StringUtil.startsWith(vsTmpAction, "/")) {
    vsRegAction = "." + psAction;
    } else {
    vsRegAction = psAction;
    }
    } else if(vsTmpAction.length > 4 && eXria.util.StringUtil.startsWith(vsTmpAction.toUpperCase(), "HTTP")) {
      vsRegAction = psAction;
    } else {
      if(eXria.util.StringUtil.startsWith(vsTmpAction, "/")) {
        if(eXria.util.StringUtil.endsWith(this.model.page.metadata.submitBaseUrl, "/")) {
      vsTmpAction = psAction.substring(1);
        }
        vsRegAction = this.model.page.metadata.submitBaseUrl + vsTmpAction;
    } else if(eXria.util.StringUtil.startsWith(vsTmpAction, "./")) {
    if(eXria.util.StringUtil.endsWith(this.model.page.metadata.documentBaseUrl, "/")) {
      vsTmpAction = psAction.substring(2);
        }
        vsRegAction = this.model.page.metadata.documentBaseUrl + vsTmpAction;
      } else {
        if(eXria.util.StringUtil.endsWith(this.model.page.metadata.documentBaseUrl, "/")) {
          vsRegAction = this.model.page.metadata.documentBaseUrl + psAction;
        } else {
          vsRegAction = this.model.page.metadata.documentBaseUrl + "/" + psAction;
        }
      }
    }
    this.action = vsRegAction;
  };
  /**
   * 서브미션의 action target 반환
   * @return 서브미션의 action target
   * @type String
   */
  this.getAction = function() {
    return this.action;
  };
  /**
   * Request Instance Reference Array<eXria.protocols.Ref>
   * @type Array
   * @private
   */
  this.refs = new Array();
  /**
   * Request Instance Reference Array를 리턴 한다.<br/>
   * XHTML 모드에서만 사용 가능하다.
   * @return Request Instance Reference Array
   * @type Array
   */
  this.getRefs = function() {
    return this.refs;
  };
  /**
   * Request Reference를 모두 삭제.
   * @return void
   * @type void
   */
  this.clearRef = function() {
    this.refs = [];
  };
  /**
   * Request Instance Reference Array를 추가한다.
   * @param {String} psId instance id
   * @param {String} psPath instance xpath
   * @return void
   * @type void
   */
  this.addRef = function(psId, psPath) {
    var voRef = new eXria.protocols.Ref(psId, psPath, false);
    this.refs.push(voRef);
  };
  /**
   * HttpRequest Header
   * (K : String, V : String)
   * @type eXria.data.ArrayMap
   * @private
   */
  this.headers = new eXria.data.ArrayMap();
  /**
   * HttpRequest Header 값을 리턴한다.
   * @param {String} psName Header Name
   * @return Header Value
   * @type String
   */
  this.getHeader = function(psName) {
    return this.headers.get(psName);
  };
  /**
   * HttpRequest Header를 추가한다.
   * @param {String} psName Header Name
   * @param {String} psValue Header Value
   * @return void
   * @type void
   */
  this.setHeader = function(psName, psValue) {
    this.headers.put(psName, psValue);
  };
  /**
   * HttpRequest Header를 삭제한다.
   * @param {String} psName  Header Name
   * @return header Value
   * @type String
   */
  this.removeHeader = function(psName) {
    return this.headers.remove(psName);
  };
  /**
   * HttpRequest Parameter
   * @type eXria.data.ArrayMap
   * @see eXria.data.ArrayMap
   * @private
   */
  this.parameters = new eXria.data.ArrayMap();
  /**
   * HttpRequest에 Parameter를 추가한다.
   * @param {String} psName parameter Name
   * @param {String} psValue parameter Value
   * @return void
   * @type void
   */
  this.addParameter = function(psName, psValue) {
    if(this.parameters.entries[psName]) { /* 값 추가 */
      var vaValue = this.parameters.get(psName);
      vaValue.push(psValue);
      this.parameters.remove(psName);
      this.parameters.put(psName, vaValue);
    } else {/* 값 생성 */
      this.parameters.put(psName, [psValue]);
    }
  };
  /**
   * HttpRequest에 DataSet을 추가한다.(Plugin Mode에서만 사용 가능)
   * @param {String} psId DataSet Id
   * @return void
   * @type void
   */
  this.addDataSetId = function(psId){
    this.dataSetIds[psId] = psId;
  };
  /**
   * submission에 데이타셋 CRUD 문자열 정보를 추가시켜 주는 메소드
   * @param {String} psString 서브미션 전송 시 추가로 보내고자 하는 CRUD 데이터
   * @return void
   * @type void
   */
  this.addCRUDString = function(psString) {
    this.crudData += psString;
  };
  /**
   * HttpRequest에 DataSet을 추가한다.(Plugin Mode에서만 사용 가능)
   * @param {String} psId DataSet Id
   * @return void
   * @type void
   */
  this.removeDataSetId = function(psId){
    if(this.dataSetIds[psId] != null) {
      delete this.dataSetIds[psId];
    }
  };
  /**
   * HttpRequest Parameter를 조회한다.</br>
   * 값이 여럿일 경우 가장 첫번째 값을 리턴
   * @param {String} psName parameter name
   * @return Parameter Values
   * @type Array
   */
  this.getParameter = function(psName) {
    return this.parameters.get(psName);
  };
  /**
   * HttpRequest Parameter를 삭제한다.
   * @param {String} psName Parameter Name
   * @return void
   * @type void
   */
  this.removeParameter = function(psName) {
    this.parameters.remove(psName);
  };
  /**
   * parameter를 모두 삭제한다.
   * @return void
   * @type void
   * @ignore
   */
  this.clearParameter = function() {
    if(this.parameters) {
      this.parameters.clear();
    }
  };
  //2009-03-31 최현종 추가 document -> this.doc
  /**
   * document Object
   * @type Object
   * @ignore
   */
  this.doc = this.model.page.window.document;
  // from document
  /**
   * Submit Request CharacterSet Encoding Type
   * @type String
   * @default IE, Opera, Safari : document.charset, Firefox : document.characterSet
   * @ignore
   */
  this.reqCharset = (this.doc.charset ? this.doc.charset : this.doc.characterSet);
  /**
   * Submit Response CharacterSet Encoding Type
   * @type String
   * @ignore
   */
  this.resCharset = (this.doc.charset ? this.doc.charset : this.doc.characterSet);
  /**
   * Submit Response CharacterSet Encoding Type을 설정한다.
   * @param {String} psCharset CharacterSet Name
   * @return void
   * @type void
   */
  this.setReqCharset = function(psCharset) {
    this.reqCharset = psCharset;
  };
  /**
   * Submit Response CharacterSet Encoding Type을 설정한다.
   * @param {String} psCharset CharacterSet Name
   * @return void
   * @type void
   */
  this.setResCharset = function(psCharset) {
    this.resCharset = psCharset;
  };
  /**
   * Response Data Instance XPath
   * @type Array
   * @ignore
   */
  this.resRefs = new Array();
  /**
   * Submission 완료 후 서버로 부터 받은 결과를 붙일 Instance를 추가한다.
   * @param {String} psId instance id
   * @param {String} psPath instance path
   * @param {Boolean} pbReplace instance replace 여부
   * @return void
   * @type void
   */
  this.addResRef = function(psId, psPath, pbReplace) {
    var voResRef = new eXria.protocols.Ref(psId, psPath, pbReplace);
    this.resRefs.push(voResRef);
  };
  /**
   * Response Ref의 Instance Path를 리턴한다.<br/>
   * XHTML 모드에서만 사용가능하다.
   * @return instance path
   * @type Array
   */
  this.getResRefs = function() {
    return this.resRefs;
  };
  /**
   * for AJAX
   * @type XMLHttpRequest
   * @ignore
   */
  var xmlHttpRequest = null;

  this.redirectJsonLocation = function(poJson) {
    if(!poJson) return;

    var voReLoc = null;
    voReLoc = poJson.root.EXRIAREDIRECT;
    //voReLoc = new eXria.data.json.Node(poJson).getNodeValue();
    try {
      if (!!voReLoc && voReLoc != "") {
        var vsPath = ""; //voReLocChild.nodeValue;
        vsPath = eXria.util.UrlUtil.getAbsoluteUrl(voReLoc);
        this.model.page.open(vsPath);
      }
    } catch(e) {}

  };
  /**
   * 서버에서 내려온 xml에 EXRIAREDIRECTION 노드가 있을 경우 현재 Page를 노드의 value에 해당하는 주소로 리다이렉션
   * @param {XMLNoe} poXml Dom Element
   * @return void
   * @type void
   * @private
   */
  this.redirectLocation = function(poXml) {
    if(!poXml) return;
    if(poXml.documentElement) poXml = poXml.documentElement;
    var voReLoc = null;
    if(this.model.page.metadata.browser.ie > 0) {
      voReLoc = poXml.selectSingleNode("/root/EXRIAREDIRECT");
    } else {
      var voXpe = new XPathEvaluator();
      var voNsResolver = voXpe.createNSResolver( poXml.ownerDocument == null ? poXml.documentElement : poXml.ownerDocument.documentElement);
      var voResults = voXpe.evaluate("/root/EXRIAREDIRECT", poXml, voNsResolver, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
      voReLoc = voResults.singleNodeValue;
    }
    try {
      if(voReLoc) {
        var voReLocChild = voReLoc.firstChild;
        if(voReLocChild) {
          var vsPath = voReLocChild.nodeValue;
          if(vsPath != "") {
            vsPath = eXria.util.UrlUtil.getAbsoluteUrl(vsPath);
            this.model.page.open(vsPath);
          }
        }
      }
    } catch(e) {}
  };

  /**
   * DOM Element를 Client Instance에 Binding한다.
   * @param {XMLNode} poXml DOM Element
   * @return void
   * @type void
   * @ignore
   */
  this.bindInstance = function(poXml) {
  if(!poXml) return;
    if(poXml.documentElement) {
      poXml = poXml.documentElement;
    }

    var voDocMap = eXria.data.DomDocumentFactory.getDomDocObj();
    if(this.model.page.metadata.browser.ie > 0) {
      var voRef = null;
      var voDomDoc = null;
      var voInstanceDom = null;
      var voResDom = null;
      var voOrgDom = null;

      for(var i = 0, vnResRefSize = this.resRefs.length ; i < vnResRefSize ; i++) {
        voRef = this.resRefs[i];
        voDomDoc = voDocMap.get(voRef.getId());

        voInstanceDom = voDomDoc.cloneNode(true);

        try {
          voResDom = poXml.selectSingleNode(voRef.getPath()).cloneNode(true);
        } catch(e) {
          var vsPath = voRef.getPath();
          vsPath = vsPath.substring(vsPath.lastIndexOf("/"), vsPath.length);
          var vsXPath = "/root" + vsPath;
          try {
            voResDom = poXml.selectSingleNode(vsXPath).cloneNode(true);
          } catch(e) {
            continue;
          }
        }

        voInstanceDom.loadXML(voResDom.xml);

        voOrgDom = new eXria.data.xhtml.Node(voDomDoc.selectSingleNode(voRef.getPath()));
        eXria.util.DomUtil.load(voOrgDom, new eXria.data.xhtml.Node(voInstanceDom.documentElement), voRef.getReplace());
      }
    } else {
      var node = new eXria.data.xhtml.Node(poXml);
      //결과 node의 childnode를 순차적으로 조회하면서
      //responseref의 path의 element nodename과 비교하여
      //일치하는 node에 붙여 넣는다.
      var voResNode = new eXria.data.xhtml.CollectionNode(node);
      var vnNodeSize = voResNode.size();
      var vnResRefSize = this.resRefs.length;
      for(var i = 0; i < vnNodeSize; i++) {
        var voNode = voResNode.get(i);
        var vsNodeName = voNode.getNodeName();
        var voOriginalInstance = null;
        var voRef = null;

        for(var j = 0; j < vnResRefSize; j++) {
          voRef = this.resRefs[j];

          if(eXria.util.StringUtil.endsWith(voRef.getPath(), "/" + vsNodeName)) {
            voOriginalInstance = this.model.getInstance(voRef.getId());
            break;
          }
        }
        if(voOriginalInstance && voOriginalInstance != null) {
          var voParent = voOriginalInstance.selectSingleNode(voRef.getPath());
        //var voOriNode = new eXria.data.xhtml.CollectionNode(voParent);
        //voOriNode.clear();
          eXria.util.DomUtil.load(voOriginalInstance.selectSingleNode(voRef.getPath()), voNode, voRef.getReplace());
        }
    }
  }
  };
  /**
   * DOM Element를 Client Instance에 Binding한다.
   * @param {XMLNode} poXml DOM Element
   * @return void
   * @type void
   * @ignore
   */
  this.bindJsInstance = function(poJson) {
    if(!poJson) return;

    var voRef = null;
    var voResInstance = new eXria.data.json.Instance(this.id + "ResInst", this.model);
    voResInstance.instObj = poJson;
    var voOrgInstance = null;
    var voResObj = null;
    var voOrgObj = null;
    var voPage = this.model.page;
    var vsRefPath = "";
    for(var i = 0, vnResRefSize = this.resRefs.length ; i < vnResRefSize ; i++) {
      voRef = this.resRefs[i];
      voOrgInstance = this.model.page.getInstance(voRef.getId());
      voOrgObj = voOrgInstance.getInstObj(voRef.getPath());
      if(!voOrgObj){
        var vsParentPath = voRef.getPath().substring(0, voRef.getPath().lastIndexOf("/"));
        var voParentObj = voOrgInstance.getInstObj(vsParentPath);
        var vsNodeName = voRef.getPath().substring(voRef.getPath().lastIndexOf("/") + 1, voRef.getPath().length);
        var voNodeObj = voParentObj.createElement(vsNodeName);
        voParentObj.appendChild(voNodeObj);
        voOrgObj = voOrgInstance.getInstObj(voRef.getPath());
      }
      vsRefPath = "/root" + voRef.getPath().substring(voRef.getPath().lastIndexOf("/"), voRef.getPath().length);
      voResObj = voResInstance.getInstObj(vsRefPath);
      if(voResObj == null || voOrgObj == null) continue;
      if(voRef.getReplace()) { //혜란수정
        voOrgObj.parentNode[voOrgObj.name] = voResObj.node;
      } else {
        if(voResObj.node instanceof Array && voOrgObj.node instanceof Array) {
          voOrgObj.parentNode[voOrgObj.name] = voOrgObj.node.concat(voResObj.node);
        } else if(voResObj.node instanceof Array) {
          voOrgObj.parentNode[voOrgObj.name] = voResObj.node;
        } else if(voOrgObj.getNodeType() == 1 && voResObj.getNodeType() == 1) {
          var voOrgObjNode = voOrgObj.node;
          var voResObjNode = voResObj.node;
          for(var attr in voResObjNode) {
            voOrgObjNode[attr] = voResObjNode[attr];
          }
        }
       }
     }

  };
  /**
   * Submission send 후 error 코드가 내려왔을 경우 error 메세지를 바인딩.
   * @return void
   * @type void
   * @private
   */
  this.bindErrMsg = function(poXml) {
  if(!poXml) return;
  if(poXml.documentElement) poXml = poXml.documentElement;

  var voDefInst = this.model.getInstance(this.model.defaultInstanceId);
    var voErr = voDefInst.selectSingleNode("/root/EXRIAERRMSG");
    var voResErr = null;

    if(this.model.page.metadata.browser.ie > 0) {
      voResErr = poXml.selectSingleNode("/root/EXRIAERRMSG");
    } else {
      var voXpe = new XPathEvaluator();
        var voNsResolver = voXpe.createNSResolver( poXml.ownerDocument == null ? poXml.documentElement : poXml.ownerDocument.documentElement);
        var voResults = voXpe.evaluate("/root/EXRIAERRMSG", poXml, voNsResolver, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        voResErr = voResults.singleNodeValue;
    }
    if(voResErr == null) return;
    var vnErrLen = voResErr.childNodes.length;
    for(var i = 0 ; i < vnErrLen ; i++) {
      voErr.appendChild((voResErr.childNodes[i]).cloneNode(true));
    }
  };
  /**
   * Submission send 후 error 코드가 내려왔을 경우 error 메세지를 바인딩.
   * @return void
   * @type void
   * @private
   */
  this.bindJsErrMsg = function(poJson) {
    var voDefInst = this.model.getInstance(this.model.defaultInstanceId);
    var voErr = voDefInst.selectSingleNode("/root/EXRIAERRMSG");
    if(voErr.hasChildNodes()) {
      voErr.parentNode["EXRIAERRMSG"] = "";
//      var voErrList = voErr.getChildNodes();
//      var vnLen = voErrList.getLength(); 
//      var voNode = null;
//      for(var i = vnLen-1 ; i >= 0 ; i--) {
//        voNode = voErrList.item(i);
//        voErr.removeChild(voNode);
//      }
    }
    if(!poJson) return;
    if(!poJson.root.EXRIAERRMSG) return;

    var voResErr = null;
    voResErr = new eXria.data.json.Node(poJson.root.EXRIAERRMSG);
//    if(this.model.page.metadata.browser.ie > 0) {
//      voResErr = new eXria.data.json.Node(poJson.root.EXRIAERRMSG);
//    } else {
//      var voXpe = new XPathEvaluator();
//      var voNsResolver = voXpe.createNSResolver( poJson.ownerDocument == null ? poJson.documentElement : poJson.ownerDocument.documentElement);
//      var voResults = voXpe.evaluate("/root/EXRIAERRMSG", poJson, voNsResolver, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
//      voResErr = voResults.singleNodeValue;
//    }
    var voResErrNode = voResErr.getChildNodes();
    var vnErrLen = voResErrNode.getLength();
    for(var i = 0 ; i < vnErrLen ; i++) {  
      voErr.appendChild((voResErrNode.item(i)).cloneNode(true));
    }
  };
  /**
   * Submission Send
   * @return Proxy
   * @type Object
   */
  this.send = function(poFunc) {
    //onSubmit callback call
    if(this.onSubmit) {
      this.onSubmit(submissionInstance);
    }
    //일반 Submission의 경우 데이터 머지 후 서버 콜
    //JSON-RPC 또는 SOAP-RPC의 경우 서버 서비스 정보 콜 또는 wsdl 다운로드 파싱 후 Proxy를 생성해서 리턴
    //Application에서는 Proxy를 받아서 Proxy의 method 실행
    //RequestBuilder
    var voRequestBuilder = eXria.protocols.ProtocolParserFactory.getRequestBuilder(this);
    //전송 타입이 JSON-RPC, SOAP-RPC일 경우 Builder에서 서버와 통신하여 Proxy를 생성하여 리턴
    //기타 경우 Builder에서는 서버에 전송할 전송데이터를 Building하여 Submission의
    //sendAction function을 call한다.
    if(poFunc == null && this.callback) poFunc = this.callback;
    var voResult = voRequestBuilder.build(poFunc);
    var vbSuccess;
    if(voResult == null) {
      vbSuccess = false;
    } else {
      vbSuccess = true;
    }
    return vbSuccess;
  };
  
  this.sendAsync = function(poFunc, psTranId) {
    var vaAsyncEventQueue = this.model.asyncEventQueue;
    if(psTranId != null) vaAsyncEventQueue = this.model.asyncEventQueueMap.get(psTranId);
    vaAsyncEventQueue.push(this);
    this.callBySendAsync = true;
    this.callback = poFunc;
    this.tranId = psTranId;
    return this.send();
  };
  /**
   * RequestBuilder 또는 Proxy에 의해 호출되는 CallBack Function
   * 실제 서버 Call이 수행된다.
   * @param poBuildData 서버로 전송할 DOMString 또는 XMLDocument
   * @return callback function
   * @type Object
   * @ignore
   */
  this.sendAction = function(poBuildData) {
    var voDs, vsCudStr = "";
    for(var m in this.dataSetIds) {
      voDs = this.model.getDataSet(m);
      vsCudStr = vsCudStr + voDs.getAutoCRUDString();
    }
    
    if((vsCudStr != "" || this.crudData != "") && this.reqProtocol == "urlencoded") {
      poBuildData = poBuildData + this.crudData + vsCudStr;
    }

    //AJAX XMLHttpRequest
    xmlHttpRequest = eXria.form.xhtml.HttpRequestFactory.create();

    var vbAsync = this.async;
    if(this.callBySendAsync) vbAsync = true;
    this.callBySendAync = null;
    xmlHttpRequest.open(this.method, this.action, vbAsync);
    
    /* HTTP REQUEST HEADER 설정 Start */
    {
      //async 방식의 callback function
      //Header put
      for(var member in this.headers.entries) {
        xmlHttpRequest.setRequestHeader(member, this.headers.entries[member]);
      }
      //content-type 설정
      xmlHttpRequest.setRequestHeader("Content-Type", eXria.protocols.ProtocolParserFactory.getContentType(this));
      //request-type 설정
      //xmlHttpRequest.setRequestHeader("Request-Type", this.type);
      xmlHttpRequest.setRequestHeader(eXria.protocols.SubmissionType.REQ_PROTOCOL_HEADER, this.reqProtocol);
      xmlHttpRequest.setRequestHeader(eXria.protocols.SubmissionType.RES_PROTOCOL_HEADER, this.resProtocol);
      //exria version 설정
      if(this.model.page.metadata.version && this.model.page.metadata.version != 'null') {
      xmlHttpRequest.setRequestHeader("eXria-Version", this.model.page.metadata.version);
      }
      //put characterset encoding type header
      //request characterset encoding type과 response characterset encoding type을 분리
      if(typeof poBuildData == 'string') { //data가 string 타입일때는 utf-8
        xmlHttpRequest.setRequestHeader("req-charset" , "UTF-8");
      } else { //data가 XMLDocument 타입일때는 정의된 인코딩 타입으로
        xmlHttpRequest.setRequestHeader("req-charset" , this.reqCharset);
      }
      xmlHttpRequest.setRequestHeader("res-charset", this.resCharset);
    }
    /* HTTP REQUEST HEADER 설정 End */
    if(vbAsync) { //asynchronized
      //EventHandler Registration
      xmlHttpRequest.onreadystatechange = this.responseCallBack;
      if(poBuildData) {
        xmlHttpRequest.send(poBuildData);
      } else {
        xmlHttpRequest.send(null);
      }
      return "";
    } else { //synchronized
      if(poBuildData) {
        xmlHttpRequest.send(poBuildData);
      } else {
        xmlHttpRequest.send(null);
      }
      //synchronized 방식일 경우 임의로 callBack function을 실행한다
      return this.responseCallBack();
    }
  };
  /**
   * 서버의 결과를 받아서 결과 값이 처리완료 이면</br>
   * ResponseParser를 생성. 서버 결과 데이터를 처리하고</br>
   * 처리 결과를 responseRef에 replace or append 시킨다
   * @return 서버에서 내려온 XML Element
   * @type XMLNode
   * @ignore
   */
  this.responseCallBack = function() {
    var voResult = null;
    if(xmlHttpRequest.readyState == 4) { /* Done */
      var vnStatus = xmlHttpRequest.status;
      if(vnStatus == 200) { /* OK */
        submissionInstance.responseState = true;
        //ResponseParser
        var vsResProtocolType = xmlHttpRequest.getResponseHeader(eXria.protocols.SubmissionType.RES_PROTOCOL_HEADER);
        if(vsResProtocolType == "" && page.metadata.useJsonInstance) vsResProtocolType = submissionInstance.resProtocol;
        var voResponseParser = eXria.protocols.ProtocolParserFactory.getResponseParser(submissionInstance, vsResProtocolType);
        //페이지 리다이렉트 2010.9.2 추가
        if(page.metadata.useJsonInstance) {
          voResult = xmlHttpRequest.responseText;
          voResult = (voResult == "") ? voResult : eval("(" + voResult + ")");
          submissionInstance.redirectJsonLocation(voResult);
          submissionInstance.bindJsErrMsg(voResult);
          if(voResponseParser.bind) {
            submissionInstance.bindJsInstance(voResult);
          }
        } else {
          voResult = voResponseParser.parse(xmlHttpRequest);
          submissionInstance.redirectLocation(voResult);
          submissionInstance.bindErrMsg(voResult);
          if(voResponseParser.bind) {
            submissionInstance.bindInstance(voResult); //Instance replace or append
          }
        }
        if(submissionInstance.onSubmitDone) { //application callback
          //application callback event handler call
          submissionInstance.onSubmitDone(submissionInstance);
        }
        submissionInstance.crudData = "";
      } else { /* Error */
        submissionInstance.responseState = false;
        try { //parse and bind
          var voResponseParser = eXria.protocols.ProtocolParserFactory.getResponseParser(submissionInstance, xmlHttpRequest.getResponseHeader(eXria.protocols.SubmissionType.RES_PROTOCOL_HEADER));
          voResult = voResponseParser.parse(xmlHttpRequest); //result of parsing(XML DOMElement)
        //페이지 리다이렉트 2010.9.2 추가
          submissionInstance.redirectLocation(voResult);
          submissionInstance.bindErrMsg(voResult);
        } catch(e) {
          voResult = xmlHttpRequest.responseText;
        }
        //Application ErrorHandler
        if(submissionInstance.onSubmitError) {
          //submissionInstance.onSubmitError(vnStatus);
          //error result data parsing and toss
          submissionInstance.onSubmitError(voResult); //event drive
        } else {
          var vsResponseMsg = xmlHttpRequest.responseText;
          //debug mode 일때 서버에서 받은 메시지를 출력해야 하는데...
          //client의 debug mode를 어디서 설정하지? TODO
          //alert(vsResponseMsg);
          //throw new Error(vsResponseMsg);
        }
      }
      var voModel = submissionInstance.model;
      var vsTranId = submissionInstance.tranId;
      var vbGonnaRunCallbacks = voModel.gonnaRunCallbacks;
      if(vsTranId) vbGonnaRunCallbacks = voModel.runningStateMap.get(vsTranId);
      if(vbGonnaRunCallbacks) {
        if(voModel.checkLastInQueue(vsTranId)) voModel.excuteAndClearCallbacks(vsTranId);
      }
    }
    
    delete xmlHttpRequest;
    return voResult;
  };
  /**
   * Header Attribute 값을 리턴한다.
   * @param {String} psAttrName 리턴 받을 Attribute Name
   * @return Attribute Value
   * @type String
   * @return Attribute Value
   */
  this.getAttrStr = function(psAttrName) {
  return null;
  };
  /**
   * Header Attribute 값을 설정한다. 만약 해당 Attribute가 있다면 해당 값으로 덮어씌운다.
   * @param {String} psAttrName 설정 Attribute Name
   * @param {String} psValue 설정할 Attribute 값
   * @type void
   * @return void
   */
  this.setAttrStr = function(psAttrName, psValue) {
  return null;
  };
  /**
   * Header의 Content-type을 재설정한다.
   * @type void
   * @return void
   */
  this.initReqType = function() {
  return null;
  };
  /**
   * Submission에서 서버로 보낼 데이터를 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return Submission Send 시 서버로 보낼 데이터 문자열
   * @type String
   */
  this.getSubmitData = function() {
    throw new Error("not support method.");
  };
  /**
   * 파라미터로 넘어온 문자열을 Submission의 Response Ref에 지정한 Node에 바인딩 한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psData 바인딩하고자 하는 데이터 문자열
   * @type void
   * @return void
   */
  this.bindUserData = function(psData) {
    throw new Error("not support method.");
  };
  /**
   * 파라미터로 넘어온 데이터를 서버로 보낸다.<br/>
   * 해당 메소드를 사용할 경우 Submission에 바인딩 된 Request 데이터는 모두 무시 되며<br/>
   * 오로지 파라미터로 넘긴 문자열에 대해서만 처리한다.<br/>
   * 또한 서버로부터 내려온 데이터는 인스턴스에 바인딩 되지 않으며 문자열로 리턴 된다.<br/>
   * (Plugin Mode 에서만 사용 가능)
   * @param psData 서버로 보낼 데이터 문자열
   * @type String
   * @return 서버로부터 내려온 데이터 문자열
   */
  this.sendUserData = function(psData) {
    throw new Error("not support method.");
  };
  /**
   * Response Reference를 String 형태로 리턴한다.<br/>
   * (ex. instaceId:XPath;instanceId2:XPath;)
   * @type String
   * @return Response Reference 문자열
   */
  this.getResponseRefString = function() {
    var voRef = null;
    var s = "";
    for(var i = 0, len = this.resRefs.length ; i < len ; i++) {
      voRef = this.resRefs[i];
      s = s + voRef.getId();
      s = s + ":";
      s = s + voRef.getPath();
      s = s + ";";
    }
    return s;
  };
  /**
   * Request Reference를 String 형태로 리턴한다.<br/>
   * (ex. instaceId:XPath;instanceId2:XPath;)
   * @type String
   * @return Request Reference 문자열
   */
  this.getRequestRefString = function() {
    var voRef = null;
    var s = "";
    for(var i = 0, len = this.refs.length ; i < len ; i++) {
      voRef = this.refs[i];
      s = s + voRef.getId();
      s = s + ":";
      s = s + voRef.getPath();
      s = s + ";";
    }

    if(s.length > 0) {
      s = s.substring(0, s.length - 1);
    }
    return s;
  };
  /**
   * Request Parameter의 Key를 String 형태로 리턴한다.<br/>
   * (ex. ParamKey1,ParamKey2,ParamKey3)
   * @type String
   * @return Request Parameter Key 문자열
   */
  this.getParameterKeyString = function() {
    var s = "";
    var voKeys = this.parameters.getKeyCollection().iterator();
    while(voKeys.hasNext()) {
      s = s + voKeys.next();
      s = s + ",";
    }

    if(s.length > 0) {
      s = s.substring(0, s.length - 1);
    }

    return s;
  };
  /**
   * Request CharSet을 리턴한다.<br/>
   * @type String
   * @return Request CharSet
   */
  this.getReqCharSet = function() {
    return this.reqCharset;
  };
  /**
   * Response CharSet을 리턴한다.<br/>
   * @type String
   * @return Request CharSet
   */
  this.getResCharSet = function() {
    return this.resCharset;
  };
  /**
   * Request DataSet의 ID를 String 형태로 리턴한다.<br/>
   * (ex. dst1,dst2,dst3)
   * @type String
   * @return Request DataSet의 ID 문자열
   */
  this.getDataSetIdString = function() {
    var voIds = [];
    for(var m in this.dataSetIds) {
      voIds.push(m);
    }
    return voIds.join(",");
  };

  /**
   * Request Protocol Type을 String 형태로 리턴한다.<br/>
   * (ex. zip;base64)
   * @type String
   * @return  Request Protocol Type에 해당하는 문자열
   */
  this.getReqType = function() {
    return this.reqType;
    //throw new Error("not support method.");
  };
  /**
   * Response Protocol Type을 String 형태로 리턴한다.<br/>
   * (ex. zip;base64)
   * @type String
   * @return  Response Protocol Type에 해당하는 문자열
   */
  this.getResType = function() {
    return this.resType;
    //throw new Error("not support method.");
  };
  /**
   * Request Protocol Type을 지정한다.<br/>
   * (ex. zip;base64)
   * @param {String} psResType Request Protocol Type
   * @type void
   * @return void
   */
  this.setReqType = function(psReqType) {
    this.reqType = psReqType;
    //throw new Error("not support method.");
  };
  /**
   * Response Protocol Type을 지정한다.<br/>
   * (ex. zip;base64)
   * @param {String} psResType Response Protocol Type
   * @type void
   * @return void
   */
  this.setResType = function(psResType) {
    this.resType = psResType;
    //throw new Error("not support method.");
  };
  /**
   * wait cursor 사용 유무를 리턴한다.
   * @return wait cusor 사용 유무
   * @type Boolean
   */
  this.isWaitCursor = function() {
    throw new Error("not support method.");
  };
  /**
   * Server로 MultiPart 데이터를 전송할 때 파일을 설정 하는 함수로 클라이언트(Client) 파일의 절대경로를 설정한다.
   * @param {String} psFilePath Upload 대상 File Path
   * @return void
   * @type void
   */
  this.setUpLoadFileCtrls = function(psCtrlIds) {
    var vaCtrls = psCtrlIds.split(";");
    for(var i in vaCtrls){
      if(vaCtrls[i] == null) return;
      this.uploadFileCtrls.put(vaCtrls[i], vaCtrls[i]);
    }
  };

  this.getUpLoadCtrlsMap = function(){
    return this.uploadFileCtrls;
  };
  
  /**
   * 초기에 만들어진 해당 서브미션에 request-ref에 정보를 동적으로 삭제 할 때 사용한다.<br/>
   * 두번째 인자는 XPath를 넣으면 첫째 인자의 ID를 인스턴스의 아이디로 정하고 공문자열일 경우 DataSetID로 처리한다.
   * @param {String} psId 삭제할 request-ref에 등록한 InstanceID 또는 DataSetID
   * @param {String} psXPath 삭제할 reqeust-ref에 등록한 InstanceID에 XPath
   * @type void
   * @return void
   */
  this.removeRef = function(psId, psXPath) {
    var voRefs = this.getRefs();
    var vnSize = voRefs.length;
    var voRef ;
    for(var i = vnSize-1; i >= 0; i--){
      voRef = voRefs[i];
      if((voRef.getId() == psId) && (voRef.getPath() == psXPath)) {
        voRefs.splice(i, 1);
      }
    }
    
  };
    /**
   * 현재 Submission에 addCRUDString으로 설정 되어진 추가 정보를 초기화 하는 메소드.<br/>
   * add CRUDString만 하고 resetCRUDString을 사용하지 않으면 초기화 되지 않고 계속 서브미션을 수행 할 때 마다. 설정한 값이 전송 되어 진다.
   * @return void
   * @type void
   */
  this.resetCRUDString = function() {
    this.crudData = "";
  };
};
