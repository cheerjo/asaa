/**
 * @fileoverview
 * Node Data Reference class(노드 데이타 레퍼런스 기본 클래스)
 * @author 조동일
 */

/**
 * @class Node Data Reference classs.<br>
 * 노드 데이타 레퍼런스 기본 클래스.
 * @version 1.0
 * @constructor
 * @base eXria.controls.DataRef
 * @param {Object} poControl page의 Instance가 참조 가능한 컨트롤 객체
 * @return 새로운 eXria.controls.DataRefNode 객체
 * @type eXria.controls.DataRefNode
 */
eXria.controls.DataRefNode = function(poControl) {
  if(page.metadata.useJsonInstance) {
    eXria.controls.JsDataRefNode.call(this, poControl);
    return;
  }

  eXria.controls.DataRef.call(this);
  /**
   * DataRefNode를 연결할 Control
   * @type Object
   */
  this.control = poControl;
  /**
   * Control에 연결된 Instance의 ID
   * @type String
   */
  this.instanceId;
  /**
   * 해당 Instance에서 Control이 사용하는 Node의 XPath
   * @type String
   */
  this.instancePath;
  /**
   * 한번 가져온 Instance를 보관하기 위한 Map
   * @type eXria.data.Map
   * @private
   */
  this.instanceMap = new eXria.data.Map();
  /**
   * setData 발생 시 상위 노드에 업데이트 플래그를 설정할 지 여부
   * @type Boolean
   * @private
   */
  this.markUpdateAbove = false;
  /**
   * 다른 페이지의 인스턴스 공유 시 해당 인스턴스를 갖는 페이지를 참조하기 위한 속성
   * @type eXria.form.Page;
   * @private
   */
  this.instPage = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.DataRef, eXria.controls.DataRefNode);
/**
 * @ignore
 */
eXria.controls.DataRefNode.prototype.setPage = function(poPage) {
  this.instPage = poPage;
  if(this.control && this.control.controls) {
    var voCollection = this.control.controls;
    var vcCtl = null;
    var vnSize = voCollection.size();
    for(var i = 0; i < vnSize; i++) {
      vcCtl = voCollection.get(i);
      if(vcCtl.data) {
        vcCtl.data.setPage(poPage);
      }
    }
  }
};
/**
 * @ignore
 */
eXria.controls.DataRefNode.prototype.setRef = function(psInstanceId, psPath, psParentPath) {
  this.instanceId = psInstanceId;
  if(psPath == null) {
    this.instancePath = null;
    return;
  }
  if(psParentPath) {
    this.instancePath = psParentPath + "/" + psPath;
  } else {
    this.instancePath = psPath;
  }
};
/**
 * @ignore
 */
eXria.controls.DataRefNode.prototype.getNodeData = function() { /* helper function */
  var viInstance = this.getInstance();
  if(viInstance) {
    var voInstanceNode = viInstance.selectSingleNode(this.instancePath);
    if(voInstanceNode) return new eXria.data.xhtml.ValueNode(voInstanceNode);
    else return null;
  } else {
    return null;
  }
};
/**
 * 설정된 노드의 상위 노드 DOM 객체 리턴.
 * @type Object
 * @private
 */
eXria.controls.DataRefNode.prototype.getParentNode = function() { /* helper function */
  var viInstance = this.getInstance();
  var voParent = null;
  if(viInstance) {
    var vsInstancePath = this.instancePath;
    if(vsInstancePath != null && vsInstancePath != "/") {
      vsInstancePath = vsInstancePath.substr(0, vsInstancePath.lastIndexOf("/"));
    }
    voParent = viInstance.selectSingleNode(vsInstancePath);
  }
  return voParent;
};
/**
 * @ignore
 */
eXria.controls.DataRefNode.prototype.getInstance = function() {
  var voPage = this.instPage;
  var voNode = null;
  if(voPage) {
    voNode = voPage.getInstance(this.instanceId);
  } else {
    voNode = this.instanceMap.get(this.instanceId);
  }
  if(voNode == null) {
    if(voPage == null) voPage = this.control.canvas.page;
    voNode = voPage.getInstance(this.instanceId);
    this.instanceMap.put(this.instanceId, voNode);
  }
  return voNode;
};
/**
 * @ignore
 */
eXria.controls.DataRefNode.prototype.getData = function() {
  if(this.instancePath == null) return "";
  var voParentNode = this.getParentNode();
  if(voParentNode == null) return "";
  var vaPath = this.instancePath.split("/");
  var vsTagName = vaPath[vaPath.length - 1];
  var voChildren = voParentNode.getElementsByTagNameFromChildNodes(vsTagName);

  var vaData = [];
  var voChild = 0;
  var vnChildLength = voChildren.size();
  for(var i = 0; i < vnChildLength; i++) {
    voChild = voChildren.get(i);
    vaData.push(String(voChild.getNodeValue())); //20100406
  }
  if(vaData.length > 1) return vaData;
  else return vaData[0];
};
/**
 * @ignore
 */
eXria.controls.DataRefNode.prototype.setData = function(psData) {
  if(this.instancePath == null) return;
  if(psData == null) psData = "";

  var voParentNode = this.getParentNode();
  if(voParentNode == null) return;
  var voDocument = voParentNode;
  var vaPath = this.instancePath.split("/");
  var vsTagName = vaPath[vaPath.length - 1];
  var voChild = null;

  var voChildNodes = voParentNode.getElementsByTagNameFromChildNodes(vsTagName);
  for(var i = 0, vnLen = voChildNodes.size() ; i < vnLen ; i++) {
    voParentNode.removeChild(voChildNodes.get(i));
  }

  var voFirstChild = voParentNode.getFirstChild();
  var voPage = this.instPage;
  if(voPage == null) voPage = this.control.canvas.page;
  var vnModelType = voPage.metadata.modelType;
  var vnXHTMLType = eXria.form.ModelType.XHTML;

  if(psData instanceof Array == false) {
    if(typeof(psData) == "string") {
      psData = psData.split("\r\n").join("\n");
    }
    if(vnModelType == vnXHTMLType) {
      voChild = voDocument.createElement(vsTagName);
      voChild.appendChild(voDocument.createTextNode(psData));
    } else {
      voChild = voDocument.createElement(vsTagName, psData);
    }
    if(voFirstChild != null) {
      voParentNode.insertBefore(voChild, voFirstChild);
      voFirstChild = voChild;
    } else {
      voParentNode.appendChild(voChild);
    }
  } else {
    if(psData.length == 0) psData.push("");
    var vsData = null;
    for(var j = 0, vnSubLen = psData.length; j < vnSubLen; j++) {
      vsData = psData[j];
      if(typeof(vsData) == "string") {
        vsData = vsData.split("\r\n").join("\n");
      }
      if(vnModelType == vnXHTMLType) {
        voChild = voDocument.createElement(vsTagName);
        voChild.appendChild(voDocument.createTextNode(vsData));
      } else {
        voChild = voDocument.createElement(vsTagName, vsData);
      }
      if(voFirstChild != null) {
        voParentNode.insertBefore(voChild, voFirstChild);
        voFirstChild = voChild;
      } else {
        voParentNode.appendChild(voChild);
      }
    }
  }
  if(this.markUpdateAbove) {
    var vsStatus = voParentNode.getAttribute("status");
    if(vsStatus == null) vsStatus = "";
    if(vsStatus.indexOf("U") == -1) voParentNode.setAttribute("status", vsStatus + "U");
  }
};
/**
 * Control이 단일 값을 가질 경우 넘겨진 값을 매핑된 Data Instance에 값으로 차환하는 메소드.
 * 멀티 값을 갖는 컨트롤은 setData를 사용해야 함.
 * @param psData Data Instance에 입력할 String Value
 */
eXria.controls.DataRefNode.prototype.replaceData = function(psData) {
  var voNodeData = this.getNodeData();
  voNodeData.setValue(psData);
};
/**
 * 인스턴스 패스가 절대 패스 인지 여부 리턴.
 * @return 인스턴스 패스가 절대 패스 인지 여부
 * @type Boolean
 */
eXria.controls.DataRefNode.prototype.isRelativeRef = function() {
  var vbRelative = false;
  if(this.instancePath.indexOf("/") != 0) vbRelative = true;

  return vbRelative;
};
