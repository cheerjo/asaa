﻿/**
 * Abstract InputBox Control
 * @작성자 : 김경태
 * @version 1.0

/**
 * InputBox
 */
eXria.controls.InputBox = function(psId, poCanvas, pnLeft, pnTop, pnWidth, pnHeight) {

  vnLeft = pnLeft || 0;
  vnTop = pnTop || 0;
  vnWidth = pnWidth || 100;
  vnHeight = pnHeight || 20;

  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.UIControl.call(this, psId, poCanvas, vnLeft, vnTop, vnWidth, vnHeight);

  /*
   * Data 연동 객체를 생성한다. (싱글 노드 연동)
   */
  this.data = new eXria.controls.DataRefNode(this);

  //////////////////////////////////////////////////////////////////
  // 속성
  this.value = "";
  this.maxLength = null;
  this.minLength = null;
  this.fontFamily = null;
  this.fontSize = null;
  this.fontWeight = null;      // 글자의 굵기 (normal/lighter/bold/bolder 또는 100/200/300/400/500/600/700/800/900 으로 설정 -> 400은 normal, 700은 bold에 해당)
  this.fontStyle = null;       // 글자의 스타일 (normal/italic/oblique)
  this.textDecoration = null;  // 글자를 장식하는 속성(none,underline,overline,line-through)
  this.textTransform = null;   // 텍스트의 대소문자를 지정할때(none/capitalize,uppercase,lowercase)
  this.nullable = true;        // 사용자 정의

  //////////////////////////////////////////////////////////////////
  // 메소드
  /*
   * 문자열 값을 설정한다.
   */
  this.setValue = null;

  /*
   * 문자열 값을 리턴한다.
   */
  this.getValue = null;

  /*
   * 지정한 객체의 정보를 리턴한다.
   */
  this.toString = function() {
    return "InputBox";
  };
};