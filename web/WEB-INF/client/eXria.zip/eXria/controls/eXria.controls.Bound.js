﻿/**
 * abstract Bound
 * @작성자 : 김경태
 * @version 1.0

/**
 * Bound (추상클래스)
 * 화면에서 차지하는 영역 정보를 보관하는 기본 클래스
 * @param poParent : Bound 영역을 가진 객체가 포함된 상위 객체
 */
eXria.controls.Bound = function(poContol, pnLeft, pnTop, pnWidth, pnHeight) {
  //////////////////////////////////////////////////////////////////
  // 속성
  // Bound의 초기값 설정
  if(poContol == null || poContol == undefined) {
    this.left = pnLeft || 0;
    this.top = pnTop || 0;
    this.width = pnWidth || 100;
    this.height = pnHeight || 50;
  } else {
    this.left = pnLeft || poContol.getDefaultControl("left");
    this.top = pnTop || poContol.getDefaultControl("top");
    this.width = pnWidth || poContol.getDefaultControl("width");
    this.height = pnHeight || poContol.getDefaultControl("height");
  }

  //////////////////////////////////////////////////////////////////
  // 메소드
  this.getInt = function(psPos) { return parseInt(psPos, 10); };

  this.cloneBound = function() {
    return new eXria.controls.Bound(
      this.left != null ? new Number(this.left) : null
      , this.top != null ? new Number(this.top) : null
      , this.width != null ? new Number(this.width) : null
      , this.height != null ? new Number(this.height) : null
    );
  };

  this.copyBound = function(poBound) {
    this.left = poBound.left != null ? new Number(poBound.left) : null;
    this.top = poBound.top != null ? new Number(poBound.top) : null;
    this.width = poBound.width != null ? new Number(poBound.width) : null;
    this.height = poBound.height != null ? new Number(poBound.height) : null;
  };
};