﻿/**
 * Abstract DateInput Control
 * @작성자 : 김경태
 * @version 1.0

/**
 * DateInput
 */
eXria.controls.DateInput = function(psId, poCanvas, pnLeft, pnTop, pnWidth, pnHeight) {

  vnLeft = pnLeft || 0;
  vnTop = pnTop || 0;
  vnWidth = pnWidth || 100;
  vnHeight = pnHeight || 80;

  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.UIControl.call(this, psId, poCanvas, vnLeft, vnTop, vnWidth, vnHeight);

  /*
   * Data 연동 객체를 생성한다. (싱글 노드 연동)
   */
  this.data = new eXria.controls.DataRefNode(this);

  /*
   * calendar 컨트롤을 생성한다.
   */
  this.calendar = new eXria.controls.xhtml.Calendar(psId+"calendar", poCanvas, vnLeft+vnWidth, vnTop+vnHeight, 260, 130);

  //////////////////////////////////////////////////////////////////
  // 속성
  this.fontFamily = null;
  this.fontSize = null;
  this.fontWeight = null;           // 글자의 굵기 (normal/lighter/bold/bolder 또는 100/200/300/400/500/600/700/800/900 으로 설정 -> 400은 normal, 700은 bold에 해당)
  this.fontStyle = null;            // 글자의 스타일 (normal/italic/oblique)
  this.textDecoration = null;       // 글자를 장식하는 속성(none,underline,overline,line-through)
  this.calendarEnable = true;       // DateInput에 속한 calendar 컨트롤의 활성화 여부 (true/false)
  this.dateFormat = null;           // Date의 포맷 (String)
  this.maskPrompt = null;           // 날짜 입력란에 표시될 문자를 지정한다. (Underscore/WhiteSpace/Asterisk/Dash 등을 지정)
  this.minDate = null;              // 날짜의 최소치
  this.maxDate = null;              // 날짜의 최대치
  this.calendarImageUrl = null;     // calendar 이미지의 url
  this.noDigits = null;             // 숫자가 아닌 정규식 표현
  this.blank = null;                // 공백 문자 정규식 표현
  this.regDateMask = null;          // YYMMDD의 정규식 표현

  //////////////////////////////////////////////////////////////////
  // 메소드
  /*
   * 날짜를 리턴한다
   */
  this.getDate = null;

  /*
   * 날짜를 설정한다
   */
  this.setDate = null;

  /*
   * 지정한 객체의 정보를 리턴한다.
   */
  this.toString = function() {
    return "DateInput";
  };
};