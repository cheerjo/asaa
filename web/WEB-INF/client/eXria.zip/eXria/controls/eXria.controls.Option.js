﻿/**
 * @fileoverview
 * Abstract Option
 */

/**
 * xtm.controls.Option
 * @autho 김경태
 * @version 1.0
 * @param {String} psId 옵션식별자
 * @param {Object} poParent 상위컨트롤
 * @param {String} psLabelText 옵션에 표시될 문자열
 * @param {String} psValue 옵션에 할당될 값
 * @param {Number} pnLeft 옵션 좌상단 점 x좌표
 * @param {Number} pnLeft 옵션 좌상단 점 y좌표
 * @param {Number} pnWidth 옵션의 가로 길이
 * @param {Number} pnWidth 옵션의 세로 길이
 * @constructor
 */
eXria.controls.Option = function(psId, poParent, psLabelText, psValue, pnLeft, pnTop, pnWidth, pnHeight) {
  var base = this;

  //////////////////////////////////////////////////////////////////
  // 속성

  // html5(web 2.0) 속성
  /**
   * 컨트롤 식별자
   * @type String
   */
  this.id = psId;

  /**
   * 상위 컨트롤 객체.
   * 읽기 전용 속성
   * @type Object
   */
  this.parent = poParent;

  /**
   * 디폴트로 이 옵션 객체가 선택될 지 여부 지정
   * @type Boolean
   */
  this.defaultSelected = false;

  /**
   * 컨트롤에 표시될 문자열 값 저장
   * @type String
   */
  this.text = psLabelText;

  /**
   * 상위 컨트롤에서 option들 상호간에 식별자역할 속성.
   * 읽기 전용 속성
   * @type Number
   */
  this.index = null;

  /**
   * 옵션의 활성화 여부 지정
    * @type Boolean
   */
  this.disabled = false;

  /**
   * 옵션이 선택되었는지 여부 지정
   * @type Boolean
   */
  this.selected = true;

  /**
   * 옵션에 할당된 String value값 저장
   * @type String
   */
  this.value = psValue;

  /**
   * 옵션의 디스플레이 타입 지정.
   * none/radio/check
   * @type String
   */
  this.type = "none";

  /**
   * 옵션의 하위 label object 저장
   * @type Object
   */
  this.label = null;

  /**
   * 옵션의 하위 selector object 저장
   * @type Object
   */
  this.selector = null;

  /**
   * 라벨의 상대 위치를 지정 - left/right/top/bottom
   * @type String
   */
  this.labelPos = "right";

  /**
   * 옵션의 가로 정렬 left/center/right
   * @type String
   */
  this.align = "center";

  /**
   * 옵션의 세로 정렬 top/middle/bottom
   * @type String
   */
  this.verticalAlign = "middle";

  /**
   * 옵션의 좌측 시작 x좌표
   * @type Number
   */
  this.left = pnLeft || 0;

  /**
   * 옵션의 상단 시작 y좌표
   * @type Number
   */
  this.top = pnTop || 0;

  /**
   * 옵션의 넓이 - number
   * @type Number
   */
  this.width = pnWidth || 200;

  /**
   * 옵션의 높이 - number
   * @type Number
   */
  this.height = pnHeight || 20;

  /**
   * 글자색
   * @type String
   */
  this.color = null;

  /**
   * 글자 크기
   * @type Number
   */
  this.fontSize = null;

  /**
   * 옵션의 배경색
   * @type String
   */
  this.backgroundColor = null;

  /**
   * border의 폭 - number
   * @type Number
   */
  this.borderWidth = null;

  /**
   * border 스타일.
   * none/hidden/dotted/dashed/solid/double/groove/ridge/inset/outset
   * @type String
   */
  this.borderStyle = null;

  /**
   * border색
   * @type String
   */
  this.borderColor = null;

  //////////////////////////////////////////////////////////////////
  // 메소드
  /**
   * 옵션의 실체화 컨트롤 생성
   * @ignore
   */
  this.createCtrl = null;

  /**
   * 옵션의 실체화 컨트롤 하위 요소 생성
   * @ignore
   */
  this.createSubCtrl = null;

  /**
   * 옵션에 할당된 값 반환
   * @return 옵션에 할당된 값
   * @type String
   */
  this.getValue = function(){
    return this.value;
  };

};