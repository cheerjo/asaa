﻿/**
/**
 * @fileoverview
 * Abstract Label Control
 */

/**
 * Abstract Label Control
 * @author 김경태
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @constructor
 * @base eXria.controls.UIControl
 */
eXria.controls.Label = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  if(pnLeft == null) pnLeft = 20;
  if(pnTop == null) pnTop = 20;
  pnWidth = pnWidth || 100;
  pnHeight = pnHeight || 30;

  eXria.controls.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동)
   */
  this.data = new eXria.controls.DataRefNode(this);

  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 라벨 텍스트의 fontFamily값
   * @type String
   */
  this.fontFamily = null;

  /**
   * 라벨 텍스트의 fontSize값
   * @type Number
   */
  this.fontSize = null;

  /**
   * 라벨 텍스트의 fontStyle값
   * @type String
   */
  this.fontStyle = null;

  /**
   * 라벨 텍스트의 fontWeight값
   * @type String
   */
  this.fontWeight = null;

  /**
   * 컨트롤에 표시될 문자열 지정
   * @type String
   */
  this.value = null;

  /**
   * 컨트롤에 표시될 문자열의 가로정렬 형태 지정
   * @type String
   */
  this.textAlign = null;

  /**
   * 컨트롤에 표시될 문자열의 수직정렬 형태 지정
   * @type String
   */
  this.verticalAlign = null;

  /**
   * 문자열을 표시하는 영역의 오버플로우 형태 지정
   * @type String
   */
  this.overflow = null;

  /**
   * 컨트롤에 표시될 문자열을 자동 줄바꿈할지 여부 지정
   * @type Boolean
   */
  this.wordWrap = null;

  //////////////////////////////////////////////////////////////////
  // 메소드
  /**
   * 컨트롤에 표시될 문자열 설정
   * @ignore
   */
  this.setValue = function() {};

  /**
   * 컨트롤에 표시된 문자열 값 반환
   * @ignore
   */
  this.getValue = function() {};

  /**
   * 클래스 명을 반환한다.
   * @return "Label"
   * @type String
   */
  this.toString = function() {
    return "Label";
  };

}; // End of Label