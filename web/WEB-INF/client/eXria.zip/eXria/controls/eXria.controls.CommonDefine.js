﻿/**
 * @fileoverview
 * Abstract CommonDefine(공통적으로 사용하는 예약어를 정의하는 패키지).
 * @author 김경태
 * @version 1.0
 */

/**
 * 공통적으로 사용하는 예약어를 정의하는 패키지
 */
eXria.controls.CommonDefine = {};


/**
 * 옵저버 객체에 대한 통지 형태를 정의
 */
eXria.controls.CommonDefine.Notice = {
  APPLY_ATTRIBUTE : "APPLY_ATTRIBUTE",
  REMOVE_ATTRIBUTE : "REMOVE_ATTRIBUTE",
  REFRESH : "REFRESH"
};