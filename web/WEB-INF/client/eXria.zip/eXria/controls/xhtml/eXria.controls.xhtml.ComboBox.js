/**
 * @fileoverview
 * Concreate xhtml ComboBox(XHTML 콤보박스 컨트롤)
 * @author 조영진
 */

/**
 * 콤보 컨트롤 드롭다운 리스트의 아이템 요소를 구성하는 클래스.
 * @version 2.0
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {eXria.controls.xhtml.ComboBox} poControl
 * @constructor
 */
eXria.controls.xhtml.ComboItem = function(psName, poValue, poControl) {
  /**
   * 아이템 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 아이템 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = "3px";
  /**
   * 아이템 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 아이템 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 아이템 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 아이템 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * * 아이템 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * @type Number
   * @private
   */
  this.cellSpacing = 0;
  /**
   * @type Number
   * @private
   */
  this.cellPadding = 0;
  /**
   * 아이템 배경 색상.
   * @type String
   */
  this.backgroundColor = poControl.listarea.backgroundColor;
  /**
   * 아이템 텍스트 색상.
   * @type String
   */
  this.color = poControl.listarea.color;
  /**
   * 아이템 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 아이템 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 아이템 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 아이템 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 아이템 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 아이템 라벨 명.
   * @type String
   */
  this.name = psName;
  /**
   * 아이템 설정 값.
   * @type String
   */
  this.value = poValue;
  /**
   * ComboBox Control 참조 변수.
   * @type eXria.controls.xhtml.ComboBox
   */
  this.parent = poControl;
  /**
   * 아이템 선택 여부.
   * @type Boolean
   */
  this.selected = false;
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   * @private
   */
  this.data = new eXria.controls.DataRefNode(this.parent);
};
/**
 * 실체화 컨트롤 생성.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.ComboItem.prototype.create = function(poDocument) {
  if (poDocument == null) poDocument = this.document;
  var voCtrl = this.parent.getCtrl(poDocument);
  var voList = this.parent.subElement.list;
  var voTable = this.parent.subElement.table;
  var voTbody = voTable.childNodes[0];
  var voTr = null;
  var voTd = null;
  var voDiv = null;
  var voInput = null;
  var vsType = null;
  var vsInputId = null;
  var voText = null;
  var vsKey = null;
  var voParent = this.parent;
  var voParentItemgroupDf = voParent.itemgroup;
  var voParentListareaDf = voParent.listarea;

  if (voParentListareaDf.appearance == "radio") {
    vsType = "radio";
    vsInputId = voParent.id + "_radio_";

  } else if (voParentListareaDf.appearance == "checkbox") {
    vsType = "checkbox";
    vsInputId = voParent.id + "_checkbox_";
  }

  voTr = poDocument.createElement("tr");
  var voStyle = voTr.style;
  voStyle.backgroundColor = this.backgroundColor;
  voStyle.color = this.color;

  voTd = poDocument.createElement("td");
  voDiv = poDocument.createElement("div");
  voDiv.name = voParent.id + "_option";
  this.id = voParent.id + "_option_" + voParent.seqNum++;
  voDiv.setAttribute("id", this.id);
  this.ctrl = voDiv;

  this.setDefault(voDiv, poDocument);

  var voInnerTable = poDocument.createElement("table");
  voParent.setAttrCtrl("cellSpacing", "0", voInnerTable);
  voParent.setAttrCtrl("cellPadding", "0", voInnerTable);
  voParent.setAttrCtrl("backgroundColor", this.backgroundColor, voDiv);
  voParent.setAttrCtrl("color", this.color, voInnerTable);
  var voInnerTbody = poDocument.createElement("tbody");
  var voInnerTr = poDocument.createElement("tr");
  var voInnerTd = poDocument.createElement("td");
  var vnWidth = voParent.innerWidth - parseInt(this.borderLeftWidth)
      - parseInt(this.borderRightWidth) - 2 * voParentListareaDf.cellSpacing;
  var vnHeight = voParentItemgroupDf.height - parseInt(this.borderTopWidth)
      - parseInt(this.borderBottomWidth);
  var voOption = null;
  if (voParent.isScrolled()) {
    vnWidth -= voParent.listarea.scrollbarWidth;
    if (voParent.listarea.bScrolled == false) {
      for ( var i = 0; i < voTable.rows.length; i++) {
        voOption = voTable.rows[i].cells[0].childNodes[0];
        voParent.setAttrCtrl("width", vnWidth, voOption);
      }
      voParent.setAttrCtrl("width", voParent.innerWidth, voTable);
      voParent.listarea.bScrolled = true;
    }
  }
  
  voParent.setAttrCtrl("width", vnWidth, voDiv);
  voParent.setAttrCtrl("height", vnHeight, voInnerTd);
  voParent.setAttrCtrl("height", vnHeight, voDiv);
  voParent.setAttrCtrl("width", voParent.innerWidth, voTd);
  voParent.setAttrCtrl("height", voParentItemgroupDf.height, voTd);
  if (voParentListareaDf.appearance != "normal") {
    voInput = poDocument.createElement("input");
    voInput.setAttribute("type", vsType);
    if (voParentListareaDf.appearance == "radio")
      voInput.setAttribute("name", vsInputId);
    var vnIndex = voTable.rows.length;
    voInput.setAttribute("id", vsInputId + vnIndex);
    voParent.setAttrCtrl("width", voParentItemgroupDf.selectorWidth + "px", voInput);
    voInnerTd.appendChild(voInput);
  }
  voText = poDocument.createTextNode(this.name);
  voInnerTd.appendChild(voText);
  voInnerTr.appendChild(voInnerTd);
  voInnerTbody.appendChild(voInnerTr);
  voInnerTable.appendChild(voInnerTbody);
  voDiv.appendChild(voInnerTable);
  if (this.disabled) voDiv.disabled = true;
  voTd.appendChild(voDiv);

  // [Set page context unselective]
  if (typeof voTd.onselectstart != "undefined") {
    voTr.onselectstart = function(e) {
      return false;
    };
  } else {
    voTr.onmousedown = function(e) {
      return false;
    };
  }
  // end of [Set page context unselectable]
  if (this.disabled != true) {
    voTr.onclick = function(e) {
      this.control.listarea.selectList(e);
    };
    voTr.control = voParent;
  }
  voTr.appendChild(voTd);
  voTbody.appendChild(voTr);

  // if(voParent.listarea.heightBySize) {
  vnHeight = parseInt(voParentItemgroupDf.height);
  var vnSize = voParent.getVisibleItemCount();
  if (voParentListareaDf.size != null && voParentListareaDf.size < vnSize) {
    vnHeight = voParentListareaDf.size
        * (vnHeight + voParentListareaDf.cellSpacing)
        + voParentListareaDf.cellSpacing;
    voParent.setAttrCtrl("height", vnHeight, voList);
  } else {
    vnHeight = vnSize * (vnHeight + voParentListareaDf.cellSpacing)
        + voParentListareaDf.cellSpacing;
    voParent.setAttrCtrl("height", vnHeight, voList);
  }
  // }

  if (voParent.isScrolled())
    voParent.setAttrCtrl("overflowY", "scroll", voList);
  else
    voParent.setAttrCtrl("overflowY", "hidden", voList);

  this.setAttrs(voDiv, poDocument);
};

/**
 * 실체화 컨트롤 생성 innerHTML 반환.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 실체화 컨트롤 생성 innerHTML
 * @type String
 * @private
 */
eXria.controls.xhtml.ComboItem.prototype.getInnerHTML = function(poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var voParent = this.parent;
  var voParentDf = voParent;
  var voParentListareaDf = voParent.listarea;
  var vaStrBuf = null;
  var vsType = null;
  var vsInputId = null;
  var voPage = null;

  if (voParentListareaDf.appearance == "radio") {
    vsType = "radio";
    vsInputId = voParent.id + "_radio_";

  } else if (voParentListareaDf.appearance == "checkbox") {
    vsType = "checkbox";
    vsInputId = voParent.id + "_checkbox_";
  }
  if(this["id"] == null) {
    var vsName = voParent.id + "_option";
    this["id"] = vsName + "_" + voParent.seqNum++;
  }

  var vsItemGroupClass = "";
  if (voParent.itemgroup.className) {
    vsItemGroupClass = " class='" + voParent.itemgroup.className + "'";
  }

  vaTemplate.push("<tr onselectstart=\"return false;\"><td><div id=");
  vaTemplate.push(this["id"]);
  vaTemplate.push(" name=");
  vaTemplate.push(vsName);
  vaTemplate.push(" style='");
  vaTemplate.push("@cssStrBuf"); // 5
  vaTemplate.push("'");

  vaStrBuf = [];
  
  var vaStrBuffer = function(){
    vaStrBuf.push(" onmousedown=\"");
    vaStrBuf.push(voParent.getEHandler(voParent.id, "atmousedown"));
    vaStrBuf.push("\"");
    vaStrBuf.push(" onclick=\"");
    vaStrBuf.push(voParent.getEHandler(voParent.id, "listarea.selectEventList"));
    vaStrBuf.push("\"");
    vaStrBuf.push(" onmouseover=\"");
    vaStrBuf.push(voParent.getEItemHandler(voParent.id, this.id, "listarea.atmouseover"));
    vaStrBuf.push("\"");
  }
  var vaGetEHandler = function(psId, psFuncName){
    var vaStrBuff = [];
    vaStrBuff.push("getControl('");
    vaStrBuff.push(psId);
    vaStrBuff.push("').");
    vaStrBuff.push(psFuncName);
    vaStrBuff.push("(event);");
  
    var vsRet = vaStrBuff.join("");
    vaStrBuff = null;
    return vsRet;
  };
  var vaGetEventHandler = function(psId, psItemId, psFuncName) {
    var vaStrBuff = [];
    vaStrBuff.push("getControl('");
    vaStrBuff.push(psId);
    vaStrBuff.push("').");
    vaStrBuff.push(psFuncName);
    vaStrBuff.push("(event,'");
    vaStrBuff.push(psItemId);
    vaStrBuff.push("');");
  
    var vsRet = vaStrBuff.join("");
    vaStrBuff = null;
    return vsRet;
  };
  
  if(this.disabled != true) {
    if(!!page.parent){
      voPage = page.parent;
    }else{
      voPage = page;
    }
    if(!voParent.window.frameElement){
      vaStrBuffer.apply(this);  
    }else{
      if(!voPage.getPage(voParent.window.frameElement.id)){
        vaStrBuffer.apply(this);
      }else if(!!voPage.getPage(voParent.window.frameElement.id).getControl(this.parent.id)){
        vaStrBuf.push(" onmousedown=\"");     
        vaStrBuf.push("page.getPage('");
        vaStrBuf.push(voParent.window.frameElement.id);
        vaStrBuf.push("')."); 
        vaStrBuf.push(vaGetEHandler(voParent.id, "atmousedown"));
        vaStrBuf.push("\"");
        vaStrBuf.push(" onclick=\"");
        vaStrBuf.push("page.getPage('");
        vaStrBuf.push(voParent.window.frameElement.id);
        vaStrBuf.push("').");
        vaStrBuf.push(vaGetEHandler(voParent.id, "listarea.selectEventList"));
        vaStrBuf.push("\"");
        vaStrBuf.push(" onmouseover=\"");
        vaStrBuf.push("page.getPage('");
        vaStrBuf.push(voParent.window.frameElement.id);
        vaStrBuf.push("').");
        vaStrBuf.push(vaGetEventHandler(voParent.id, this.id, "listarea.atmouseover"));
        vaStrBuf.push("\"");
      }else{
        vaStrBuffer.apply(this);
      }       
    }
  }
  
  vaTemplate.push(vaStrBuf.join(""));
  vaTemplate.push("/><table " + vsItemGroupClass + "cellSpacing=0 width=100% cellPadding=0 style='");
  vaTemplate.push("@cssStrBuf"); // 9
  vaTemplate.push("'><tbody><tr><td style='");
  vaTemplate.push("@cssStrBuf"); // 11
  vaTemplate.push("'>");

  vaStrBuf = [];
  if(voParentListareaDf.appearance != "normal") {
    vaStrBuf.push("<input ");
    vaStrBuf.push("type=");
    vaStrBuf.push(vsType);

    if(voParentListareaDf.appearance == "radio") {  //2009-03-23 ehj
      vaStrBuf.push(" name=");
      vaStrBuf.push(vsInputId);
    }
    vaStrBuf.push(" style='");
    voParent.setCssStrBuf(vaStrBuf, "width", voParent.itemgroup.selectorWidth, "px");
    vaStrBuf.push("'>");  //2009-03-23 ehj
  }

  vaTemplate.push(vaStrBuf.join(""));
  vaTemplate.push("@innStrBuf"); // 14
  vaTemplate.push("</td></tr></tbody></table></div></td></tr>");

  this.setDefault(null, voParent.document);
  this.setAttrsInn(null, null);

  var vsRet = vaTemplate.join("");
  vaStrBuf = null;
  vaTemplate = null;
  this.template = null;
  return vsRet;
};
/**
 * setDefault
 * @param {HTMLDiv} poCtrl 실체화 컨트롤.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ComboItem.prototype.setDefault = function(poCtrl, poDocument) {
  this.verticalAlign = this.parent.getAttrValue("verticalAlign", this.verticalAlign);
  var voData = this.data;
  if(voData.instanceId && voData.instancePath) {
    this.name = voData.getData();
  }
};
/**
 * setAttrs
 * @param {HTMLDiv} poCtrl 실체화 컨트롤.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ComboItem.prototype.setAttrs = function(poCtrl, poDocument) {
  var voDiv = poCtrl;
  var voParent = this.parent;
  if (voDiv == null)
    voDiv = this.getCtrl(poDocument);
  voParent.setAttrCtrl("color", this.color, voDiv);
  voParent.setAttrCtrl("borderStyle", this.borderStyle, voDiv);
  voParent.setAttrCtrl("borderColor", this.borderColor, voDiv);
  voParent.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voDiv);
  voParent.setAttrCtrl("borderRightWidth", this.borderRightWidth, voDiv);
  voParent.setAttrCtrl("borderTopWidth", this.borderTopWidth, voDiv);
  voParent.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voDiv);
  var voInnerTable = voDiv.childNodes[0];
  voParent.setAttrCtrl("fontFamily", this.fontFamily, voInnerTable);
  voParent.setAttrCtrl("fontSize", this.fontSize, voInnerTable);
  voParent.setAttrCtrl("fontStyle", this.fontStyle, voInnerTable);
  voParent.setAttrCtrl("fontWeight", this.fontWeight, voInnerTable);
  var voInnerTd = voInnerTable.rows[0].cells[0];
  //voParent.setAttrCtrl("textAlign", this.textAlign, voInnerTd);
  voParent.setAttrCtrl("verticalAlign", this.verticalAlign, voInnerTd);
  voParent.setAttrCtrl("paddingLeft", this.paddingLeft, voInnerTd);
  voParent.setAttrCtrl("paddingRight", this.paddingRight, voInnerTd);
  voParent.setAttrCtrl("paddingTop", this.paddingTop, voInnerTd);
  voParent.setAttrCtrl("paddingBottom", this.paddingBottom, voInnerTd);
};
/**
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboItem.prototype.setAttrsInn = function(poCtrl, poDocument) {
  var voParent = this.parent;
  var vaTemplate = this.template;
  var vaAttStrBuf = null;
  var vaCssStrBuf = null;
  var vaInnStrBuf = null;
  var vfcSetAttStrBuf = voParent.setAttStrBuf;
  var vfcSetCssStrBuf = voParent.setCssStrBuf;
  var vnWidth = voParent.innerWidth - this.borderLeftWidth - this.borderRightWidth - 2 * voParent.listarea.cellSpacing;
  if (vnWidth < 0) vnWidth = 0;
  var vnHeight = voParent.itemgroup.height - this.borderTopWidth - this.borderBottomWidth;
  var vnHeight = voParent.itemgroup.height;
  if(vnHeight !== null){
    if(this.borderTopWidth !== null) vnHeight = vnHeight - this.borderTopWidth;
    if(this.borderBottomWidth !== null) vnHeight = vnHeight - this.borderBottomWidth;
    if (vnHeight < 0)  vnHeight = 0;
  }
  if (voParent.scrolled) {
    vnWidth -= voParent.listarea.scrollbarWidth;
  }
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", "100%");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth,  "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth,  "px");
  vaTemplate[5] = vaCssStrBuf.join("");

  // table 영역
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  if(this.disabled) vfcSetCssStrBuf(vaCssStrBuf, "color", this.disabledColor);
  // 2009.10.30 yhkim itemgroup설정을 개개별 아이템에 설정
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", voParent.itemgroup.cursor);
  //var vsClass = this.parent.getCSSClass(this.parent, 1, "itemgroup" );
  //alert(vsClass);

  vaTemplate[9] = vaCssStrBuf.join("");

  // td 영역
  vaCssStrBuf = [];
  // vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.verticalAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  //yhkim test (for wordwrap)
  vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  vaTemplate[11] = vaCssStrBuf.join("");

  vaInnStrBuf = [];
  vaInnStrBuf.push(this.name);

  vaTemplate[14] = vaInnStrBuf.join("");

  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaInnStrBuf = null;
  vaTemplate = null;
};
/**
 * 아이템 새로고침 수행.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboItem.prototype.refresh = function(poDocument) {
  var voCtrl = this.parent.getCtrl(poDocument);
  if (voCtrl == null)
    return;
  this.removeAttrDefault(voCtrl, poDocument);
  this.setAttrs(voCtrl, poDocument);
};
/**
 * removeAttrDefault
 * @param {HTMLDiv} poCtrl 실체화 컨트롤.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboItem.prototype.removeAttrDefault = function(poCtrl,
    poDocument) {
  var voDiv = this.getCtrl(poDocument);
  var voParent = this.parent;
  voParent.setAttrCtrl("borderWidth", "", voDiv);
  voParent.setAttrCtrl("borderStyle", "", voDiv);
  voParent.setAttrCtrl("borderColor", "", voDiv);
  var voInnerTable = voDiv.childNodes[0];
  voParent.setAttrCtrl("fontFamily", "", voInnerTable);
  voParent.setAttrCtrl("fontSize", "", voInnerTable);
  voParent.setAttrCtrl("fontStyle", "", voInnerTable);
  voParent.setAttrCtrl("fontWeight", "", voInnerTable);
  var voInnerTd = voInnerTable.rows[0].cells[0];
  this.setAttrCtrl("verticalAlign", this.verticalAlign, voInnerTd);
};
/**
 * 아이템의 실체화 객체 반환.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 실체화 객체
 * @type HTMLDiv
 */
eXria.controls.xhtml.ComboItem.prototype.getCtrl = function(poDocument) {
  // if(poDocument == null) poDocument = document;
  // var voCtrl = poDocument.getElementById(this.id);
//  var voParent = this.parant;
  var voParent = this.parent;
  var voCtrl = voParent.lookup(this.id);
  return voCtrl;
};
/**
 * 아이템 실체화 컨트롤에 적용될 세부 속성 값을 반환하는 메소드.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboItem.prototype.makeSpecificAttrValue = function(poCtrl, poCssStyle, psAttrName, psCtrlAttrName) {
  var vaAttrName = psAttrName.split(".");
  var voAttr = null;

  if (voAttr != null) { // 사용자 지정 속성값이 있을 경우
    return voAttr;
  } else { // 사용자 지정 속성값이 없을 경우
    if (poCssStyle != null) { // 지정된 CSS가 있을 경우
      if (psCtrlAttrName == null)
        psCtrlAttrName = vaAttrName[vaAttrName.length - 1];
      if (poCssStyle[psCtrlAttrName] != null
          && poCssStyle[psCtrlAttrName] != "") {
        return poCssStyle[psCtrlAttrName];
      } else { // CSS에 해당 속성 값이 없을 경우
        return this.getSpecificDefaultValue(psAttrName);
      }
    } else { // 지정된 CSS가 없을 경우
      return this.getSpecificDefaultValue(psAttrName);
    }
  }
};
/**
 * 상위 컨트롤의 itemgroup에 할당된 속성 값을 얻어오기 위한 메소드.
 * @param {String} psAttrName 상위 컨트롤의 itemgroup에서 값을 가져올 속성명
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ComboItem.prototype.getSpecificDefaultValue = function(
    psAttrName) {
  var voRet = null;
  var voParent = this.parent;
  if (voParent.itemgroup[psAttrName] != null) {
    voRet = voParent.itemgroup[psAttrName];
  }
  return voRet;
};
/**
 * 아이템의 스타일 속성값을 일괄적으로 변경하기 위한 메소드.
 * @param {Object} poStyleObject 변경될 속성값을 담은 오브젝트
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboItem.prototype.setItemStyle = function(poStyleObject) {
  var vsAttr = null;
  for (vsAttr in poStyleObject) {
    this[vsAttr] = poStyleObject[vsAttr];
  }
};

/**
 * ComboBox 컨트롤 드롭다운 리스트 박스의 속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.ComboBox_listarea = function(poParent) {
  /**
   * ComboBox 인스턴스.
   * @type eXria.controls.xhtml.ComboBox
   */
  this.parent = poParent;
  /**
   * 다중선택 여부.
   * @type Boolean
   */
  this.multiSelect = null;
  /**
   * normal, radio, checkbox (보여지는 option의 형태 : 라디오, 리스트, 콤보).
   * @type String
   */
  this.appearance = null;
  /**
   * 이전까지 컨트롤의 다중선택 여부.
   * @private
   * @type Boolean
   */
  this.oldMultiSelect = null;
  /**
   * 이전까지 컨트롤의 선택 버튼 형태.
   * @private
   * @type String
   */
  this.oldAppearance = null;
  /**
   * 아이템 리스트에 보여지는 아이템 개수.
   * @type Number
   */
  this.size = null;
  /**
   * 리스트 영역의 세로길이.
   * @type Number
   */
  this.height = null;
  /**
   * 리스트 영역의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 리스트 영역의 텍스트 색상.
   * @type String
   */
  this.color = null;
  /**
   * 아이템에 포커스 위치시에 아이템 배경 색상.
   * @type String
   */
  this.focusBackgroundColor = null;
  /**
   * 아이템에 마우스오버 위치시에 아이템 배경색상.
   * @type String
   */
  this.hoverBackgroundColor = null;
  /**
   * 아이템에 포커스 위치시에 아이템 텍스트 색상.
   * @type String
   */
  this.focusColor = null;
  /**
   * 아이템 사이의 간격.
   * @type Number
   */
  this.cellSpacing = null;
  /**
   * 리스트 영역의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 리스트 영역의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 현재 리스트의 스크롤바가 표시되어 있는지 여부 체크.
   * @private
   * @type Boolean
   */
  this.bScrolled = false;
  /**
   * 리스트 영역의 오버플로우 타입.<br>
   * 'scroll' | 'hidden' | 'auto'
   * @type String
   */
  this.overflow = null;
  /**
   * 리스트 영역의 세로 오버플로우 타입.
   * @type String
   */
  this.overflowY = null;
  /**
   * 리스트 영역의 가로 오버플로우 타입.
   * @type String
   */
  this.overflowX = "hidden";//null
  /**
   * 리스트 영역 계산 시 사용될 스크롤 버튼의 가로 길이.
   * @type Number
   * @private
   */
  this.scrollbarWidth = 19;
  /**
   * 리스트 영역에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 리스트 영역의 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 리스트 영역의 크기를 아이템 개수를 기준으로 할지 여부.
   * @type Boolean
   */
  this.heightBySize = true;
  /**
   * 리스트 영역의 크기를 아이템 최대 길이를 기준으로 할지 여부.
   * @type Boolean
   */
  this.widthByMaxLength = true;
  /**
   * listarea의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};

/**
 * @private
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.selectEventList = function(event) {
  var voEvent = null;
  if (event.type == "click") {
    voEvent = new eXria.event.Event(event, this.parent.window);
    this.selectList(voEvent);
  } else {
    voEvent = event;
    this.selectListKeyDown(voEvent);
  }
};

/**
 * 리스트 아이템 선택 시 호출된는 메소드
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.selectList = function(poEvent) {
  var voParent = this.parent;
  //var voEvent = new eXria.event.Event(e, voParent.window);
  voParent.isCallByKeyIn = false;
  voParent.isComboMousedown = false;
  poEvent.object = voParent;
  var voTr = null;
  var voDiv = null;
  var voInput = null;

  voParent.unselectListItem(poEvent, poEvent.ctrlKey || poEvent.shiftKey);

  voDiv = poEvent.target;
  while (voDiv.nodeName.toLowerCase() != "div") {
    voDiv = voDiv.parentNode;
  }
  if (voDiv == null || voDiv.id.indexOf(voParent.id + "_option") == -1)
    return;
  voTr = voDiv.parentNode.parentNode;

  var vnCurrentIdx = voTr.rowIndex;
  var vnLastIdx = voParent.selectedIndex;
  var vnFirstIdx = voParent.getFirstItemIndex();

  if (voParent.selectedIndex != vnCurrentIdx
      || voParent.listarea.appearance == "checkbox"){
      voParent.bRowChanged = true;
//      voParent.doitemchange(poEvent, voParent);
  }
  else
    voParent.bRowChanged = false;

  var voItem = voParent.getItem(vnCurrentIdx);
  voParent.itemChanged = voItem;
  if (voParent.listarea.appearance != "normal")
    voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;

  if(poEvent.shiftKey && voParent.selectedItems.size() != 0){
    if(!voParent.bRowChanged)return;  //마지막에 선택한 아이템과 동일한 아이템을 선택했을 때 리턴

      voParent.clearSelected();
      var vnTemp = vnFirstIdx;
      var vbChk = false;

      while(vnCurrentIdx != vnTemp){
        if(vbChk){
          if(vnCurrentIdx > vnTemp)++vnTemp;
          else --vnTemp;
        }

        if (voInput != null)
          voInput.checked = true;
        if(voParent.selectedItems.get(vnTemp) == undefined){
          voParent.selectedItems.put(vnTemp, "");
        }

        voParent.getItem(vnTemp).selected = true;

        voParent.selectedIndex = vnTemp;

        voParent.changeRowColorByIndex(vnTemp);
        vbChk = true;
      }

      if(vnFirstIdx == vnCurrentIdx){
        if (voInput != null)
          voInput.checked = true;

        voParent.getItem(vnFirstIdx).selected = true;

        voParent.selectedIndex = vnFirstIdx;
      }
  }else{
    if (voParent.selectedItems.get(vnCurrentIdx) == undefined) {//이전에 선택이 안되어 있는 아이템일 경우
      if (voInput != null)
        voInput.checked = true;
      voParent.selectedItems.put(voTr.rowIndex, "");
      voItem.selected = true;
      voParent.selectedIndex = vnCurrentIdx;
      voParent.changeRowColor(voDiv);

    } else {//이전에 선택이 되어 있는 아이템 선택 해제
      if (voInput != null)
        voInput.checked = false;
      voParent.selectedItems.remove(vnCurrentIdx);
      voItem.selected = false;
      voParent.restoreRowColor(voDiv);
    }
  }

  voParent.checkSelected();
  if (voParent.listarea.multiSelect == false
      || ((voParent.listarea.appearance == "normal" && poEvent.ctrlKey == false)
      && (voParent.listarea.appearance == "normal" && poEvent.shiftKey == false)))
    voParent.showList(false);

  if (voParent.bRowChanged)
  {
    voParent.focusedItemCtrl = voDiv;
    voParent.doitemchange(poEvent, voParent);
    voParent.dochange(poEvent, voParent);
  }
};

/**
 * 리스트 아이템 선택 시 호출된는 메소드(키보드로 선택)
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.selectListKeyDown = function(poEvent) {
  var voParent = this.parent;
  //var voEvent = new eXria.event.Event(e, voParent.window);
  poEvent.object = voParent;
  var voTr = null;
  var voDiv = null;
  var voInput = null;

  voParent.unselectListItem(poEvent, poEvent.shiftKey);

  voDiv = poEvent.target;
  while (voDiv.nodeName.toLowerCase() != "div") {
    voDiv = voDiv.parentNode;
  }
  if (voDiv == null || voDiv.id.indexOf(voParent.id + "_option") == -1)
    return;
  voTr = voDiv.parentNode.parentNode;
  if (voParent.selectedIndex != voTr.rowIndex
      || voParent.listarea.appearance == "checkbox"){
      voParent.bRowChanged = true;
      voParent.doitemchange(poEvent, voParent);
  }
  else
    voParent.bRowChanged = false;

  var voItem = voParent.getItem(voTr.rowIndex);

  if (voParent.listarea.appearance != "normal")
    voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;

  if (voParent.selectedItems.get(voTr.rowIndex) == undefined ) {
    if (voInput != null)
      voInput.checked = true;
    voParent.selectedItems.put(voTr.rowIndex, "");
    voParent.changeRowColor(voDiv);
    voItem.selected = true;
    voParent.selectedIndex = voTr.rowIndex;
  } else {
    if (voInput != null)
      voInput.checked = false;

    if(poEvent.shiftKey == true ){
      voParent.getItem(voParent.selectedIndex).selected = false;
      voParent.selectedItems.remove(voParent.selectedIndex);
      voParent.restoreRowColorByIndex(voParent.selectedIndex);
    }else{
      voParent.selectedItems.remove(voTr.rowIndex);
      //this.restoreRowColor(voDiv);
      voItem.selected = false;
    }

    if(poEvent.shiftKey == true){
      voParent.selectedIndex = voTr.rowIndex;//2009-03-30 hajubal ctrl 오류때문에 수정
    }
  }



  voParent.checkSelected();
  if (voParent.listarea.multiSelect == false
      || (voParent.listarea.appearance == "normal" && poEvent.shiftKey == false))
    voParent.showList(false);

  if (voParent.bRowChanged)
    voParent.dochange(poEvent, voParent);
};

/**
 * 리스트 아이템 마우스 오버시 호출된는 메소드
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.atmouseover = function(e, psItemId) {
  var voParent = this.parent;
  
  voParent.eventType = "item";
  voParent.eventObject = voParent.getItemById(psItemId);
  if (voParent.eventType == "item" && voParent.eventObject != null) {
    var voDocument = voParent.getComboboxCtrl("document");
    var voItem = voParent.eventObject;
    var voItemCtrl = voDocument.getElementById(voItem.id);
    var voStyle = voItemCtrl.style;
    var vbSelected = false;
    var voTable = voParent.subElement.table

    var vnIdx = voItem.id;
    vnIdx = vnIdx.substring((voParent.id + "_option_").length);
    vnIdx = parseInt(vnIdx);
    if(voParent.selectedItems.get(vnIdx) != null) {
      vbSelected = true;
    }
    if (!vbSelected) {
      this.mouseOver(e, psItemId);
      voStyle.backgroundColor = voParent.listarea.hoverBackgroundColor;// eXria.controls.xhtml.Default.ListBox.focusBackgroundColor;//"#F1F1EB";//voParent.focusBackgroundColor;
      voStyle.color = voParent.listarea.focusColor;
    }
    voParent.focusedItemCtrl = voItemCtrl;
  }
};

/**
 * 리스트 아이템 마우스 오버시 호출된는 메소드
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.mouseOver = function(e, psItemId) {
  var voParent = this.parent;

  voParent.eventType = "item";
  voParent.eventObject = voParent.getItemById(psItemId);

  if(voParent.arrowKeyMode == "select") {
    var voDiv = null;
    var voData = null;
    var voTable = voParent.subElement.table;

    voParent.nonSelectedRestoreColor(voTable);
  } else if(voParent.arrowKeyMode == "focus") {
    if(voParent.focusedItemCtrl) {
      var vnIdx = voParent.focusedItemCtrl.id;
      vnIdx = vnIdx.substring((voParent.id + "_option_").length);
      vnIdx = parseInt(vnIdx);
      if(voParent.selectedItems.get(vnIdx) == null) voParent.restoreRowColor(voParent.focusedItemCtrl);
      voParent.focusedItemCtrl = null;
    }
  }
};

/**
 * 지정된 라벨과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스 반환.
 * @param {String} psName 아이템 라벨 명
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.getIndex = function(psName) {
  var voControl = this.parent;
  var voIterator = voControl.frontItems.getKeyCollection().iterator();
  var vsKey = null;
  var i = -1;
  while (voIterator.hasNext()) {
    i++;
    vsKey = voIterator.next();
    if (vsKey == psName) {
      return i;
    }
  }
  voIterator = voControl.itemset.getKeyCollection().iterator();
  while (voIterator.hasNext()) {
    i++;
    vsKey = voIterator.next();
    if (vsKey == psName) {
      return i;
    }
  }
  voIterator = voControl.backItems.getKeyCollection().iterator();
  while (voIterator.hasNext()) {
    i++;
    vsKey = voIterator.next();
    if (vsKey == psName) {
      return i;
    }
  }
  return -1;
};
/**
 * 지정된 라벨과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스 반환.
 * @param {String} psValue 아이템 value
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.getIndexByVal = function(psValue) {
  var voParent = this.parent;
  var voIterator = voParent.frontItems.getValueCollection().iterator();
  var voItem = null;
  var i = 0;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.value == psValue)
      return i;
    i++;
  }
  voIterator = voParent.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.value == psValue)
      return i;
    i++;
  }
  voIterator = voParent.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.value == psValue)
      return i;
    i++;
  }
  return -1;
};
/**
 * 지정된 index를 통해 리스트 아이템을 선택하기 위한 메소드.
 * @param {Array(Number)} paIndex 선택될 아이템들의 인덱스를 저장하는 배열
 * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox_listarea.prototype.select = function(paIndex,
    poCtrl, poDocument) {
  var voParent = this.parent;
  voParent.isChanged = false;
  if (poCtrl == null)
    poCtrl = voParent.getCtrl(poDocument);
  var voList = voParent.subElement.list;
  var voTable = voParent.subElement.table;
  var voDiv = null;
  var voInput = null;

  if(voTable.rows.length == 0) return;

  // TODO : voParent.showList(true);
//  for ( var i = 0; i < voTable.rows.length; i++) {
//    voDiv = voTable.rows[i].cells[0].childNodes[0];
//    if (voParent.listarea.appearance != "normal") {
//      voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
//      voInput.checked = false;
//    } else {
//      voParent.restoreRowColor(voDiv);
//    }
//  }
  var voCollection = voParent.selectedItems.getKeyCollection();
  var vnLoop = voCollection.size();
  var vnRowIdx = null;
  for(var i = 0; i < vnLoop; i++) {
    vnRowIdx = voCollection.get(i);
    vnRowIdx = parseInt(vnRowIdx);
    voDiv = voTable.rows[vnRowIdx].cells[0].childNodes[0];
    if (voParent.listarea.appearance != "normal") {
      voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
      voInput.checked = false;
    } else {
      voParent.restoreRowColor(voDiv);
    }
  }
  voParent.selectedItems.clear();
  if (paIndex == null || paIndex.length == 0) {

    voParent.selectedIndex = -1;
    if(voParent.value == null) voParent.value = [];
    voParent.subElement.input.value = (voParent.value[0] == null ? "" : voParent.value[0]);
    return;
  }


  var voItem = null;
  // 마우스 이벤트에 의해 voParent.selectedIndex가 지정되었는지 여부를 체크
  // multiSelect에 경우 마지막으로 선택된 아이템을 selectedIndex로 지정하나
  // 메소드 콜에 의해 아이템 선택시 이 순서를 자체적으로 체크할 수 없기 때문에 사용됨
  var vbSelected = false;
  for ( var i = 0; i < paIndex.length; i++) {
    if (paIndex[i] == voParent.selectedIndex)
      vbSelected = true;
    voDiv = voTable.rows[paIndex[i]].cells[0].childNodes[0];
    voItem = voParent.getItem(paIndex[i]);
    if (voItem)
      voItem.selected = true;
    voParent.selectedItems.put(paIndex[i], "");
    if (voParent.listarea.appearance == "normal") {
      voParent.changeRowColor(voDiv);
    } else {
      voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
      voInput.checked = true;
    }
    if (voParent.listarea.multiSelect == false)
      break;
  }

  if (vbSelected == false && voParent.bMultiSelectKeyDown == false) {
    voParent.selectedIndex = paIndex[paIndex.length - 1];
  }

  var vsOldVal = voParent.value;
  if(vsOldVal instanceof Array) vsOldVal = vsOldVal.join();
  var vsNewVal = voParent.getSelectedValue(true, poCtrl);
  if(vsNewVal instanceof Array) vsNewVal = vsNewVal.join();
  voParent.value = voParent.getSelectedValue(true, poCtrl);
  var voText = voParent.subElement.input;
  voParent.oldText = voText.value;
  if (voParent.value == null) voParent.value = "";
  if(vsOldVal != vsNewVal) {
    voParent.data.setData(voParent.value);
  }
};

/**
 * ComboBox 컨트롤 아이템의 공통 속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.ComboBox_itemgroup = function() {
  /**
   * 아이템의 세로 길이.
   * @type Number
   */
  this.height = null;
  /**
   * 선택 버튼의 가로 길이.
   * @type Number
   */
  this.selectorWidth = null;
  /**
   * 아이템의 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 아이템의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 아이템의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 아이템에 표시될 텍스트의 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 아이템에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * itemgroup의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */

  this.cursor = "null";

  this.df = {};
  this.textAlign = null;
};

/**
 * @class Concreate xhtml ComboBox.<br>
 *        XHTML 콤보박스 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.ComboBox 객체
 * @type eXria.controls.xhtml.ComboBox
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.ComboBox = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 200 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth,
      pnHeight);

  // 데이타 연동 관련
  /**
   * Data 연동 객체(노드 셋 연동).
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * 인스턴스로 부터 라벨 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.labelTagName = "label";
  /**
   * 인스턴스로 부터 value 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.valueTagName = "value";
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  // 데이타 연동 관련 End
  /**
   * 텍스트 영역의 읽기전용 여부.
   * @type Boolean
   */
  this.readOnly = null;
  /**
   * 선택된 아이템의 인덱스 번호.
   * @type Number
   */
  this.selectedIndex = null;
  /**
   * 인스턴스로 부터 가져올 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.itemset = new eXria.data.ArrayMap();
  /**
   * 앞쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.frontItems = new eXria.data.ArrayMap();
  /**
   * 뒤쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.backItems = new eXria.data.ArrayMap();
  /**
   * 선택된 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.selectedItems = new eXria.data.ArrayMap();
  /**
   * 마우스 오버된 아이템 리스트
   * @type eXria.data.ArrayMap
   */
  this.mouseOverItems = new eXria.data.ArrayMap();
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트의 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 텍스트 박스를 둘러싼 보더의 두께.
   * @private
   * @type Number
   */
  this.subBorderWidth = 0;
  /**
   * 리스트 아이템 아이디에 사용될 번호.
   * @private
   * @type Number
   */
  this.seqNum = 0;
  /**
   * 컨트롤에 설정된 값.
   * @type String
   */
  this.value = null;
  /**
   * 리스트 박스에 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.ComboBox_listarea
   */
  this.listarea = new eXria.controls.xhtml.ComboBox_listarea(this);
  this.listarea.bScrolled = false;
  /**
   * 아이템의 공통 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.ComboBox_itemgroup
   */
  this.itemgroup = new eXria.controls.xhtml.ComboBox_itemgroup();
  /**
   * 드롭다운 버튼의 가로 길이.
   * @type Number
   */
  this.btnWidth = null;
  /**
   * 드롭다운 버튼의 배경 색상.
   * @type String
   */
  this.btnBackgroundColor = null;
  /**
   * 드롭다운 버튼의 텍스트 색상.
   * @type String
   */
  this.btnColor = null;
  /**
   * 드롭다운 버튼의 cursor 타입.
   * @type String
   * @private
   */
  this.btnCursor = null;
  /**
   * 드롭다운 버튼에 표시될 배경 이미지.
   * @type String
   */
  this.expandImage = null;
  /**
   * 드롭다운 되었을 때 버튼에 표시될 배경 이미지.
   * @type String
   */
  this.collapseImage = null;
  /**
   * 위 아래 화살표 키 동작 모드(select|focus).
   * select - listarea의 아이템을 선택
   * focus - listarea의 아이템을 포커싱하면서 탐색
   * @type String
   */
  this.arrowKeyMode = "select";
  /**
   * 리스트 목록을 새로 고침할지 여부(리스트 항목 추가/삭제 등으로 인해).
   * @private
   * @type Boolean
   */
  this.bReloadList = false;
  /**
   * css를 통해 지정된 폰트 사이즈.
   * @private
   * @type Number
   */
  this.cssFontSize = null;
  /**
   * 텍스트 박스의 좌우 여백(단위 px).
   * @private
   * @type Number
   */
  this.hPadding = 2;
  /**
   * 선택된 아이템이 변경 되었는지 여부(change이벤트 발생에 이용).
   * @private
   * @type Boolean
   */
  this.bRowChanged = false;
  /**
   * 이전까지 텍스트 박스에 입력된 문자열 값.
   * @type String
   * @private
   */
  this.oldText = null;
  /**
   * 컨트롤이 포커싱 되었는지 여부.
   * @type Boolean
   * @private
   */
  this.focused = false;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트.
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들.
   * @private
   */
  this.subElement = {};

  /**
   * multiselect key down 여부.
   * @type Boolean
   * @private
   */
  this.bMultiSelectKeyDown = false;

  /*
   *  사용자 정의
   */
  this.maxLength = null;
  /*
   *  사용자 정의
   */
  this.minLength = null;
  /*
   *  사용자 정의
   */
  this.nullable = true;
  /*
   *  사용자 정의
   */
  this.maxByteLength = null;
  /*
   *  사용자 정의
   */
  this.minByteLength = null;
  /**
   * 드럽다운 버튼 커서
   * @type String
   */
  this.btnCursor = null;
  /**
   * 드럽다운 방향설정
   * @type String
   */
  this.listDirection = null;
  /*
   * @ignore
   */
  this.scrolled = false;
  /**
   * input element ime-mode 설정 속성
   * @type String
   */
  this.imeMode = null;

  this.itemIdxMap = null;

  this.itemNmMap = null;

  this.itemValMap = null;

  this.itemIdMap = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl,
    eXria.controls.xhtml.ComboBox);
/**
 * 이벤트 키값.
 * @type Object
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.constKey = {
  LEFT :37,
  UP :38,
  RIGHT :39,
  DOWN :40,
  ENTER :13,
  TAB :9,
  BACKSPACE :8,
  DEL :46,
  HAN_ENG :21,
  CTRL :17
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  voCtrl["tabIndex"] = 0;

  this.ctrl = voCtrl;
  this.document = poDocument;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.setTemplate = function(poCtrl, poDocument) {
  if (this.listarea.appearance == null)
    this.listarea.appearance = "normal";

  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<input type='text' class='" + vsClass + "' id='");
  vaTemplate.push(this.id);
  // 사용자  css에서 class 형태로 높이를 잡아준다 하지만 input은 동적으로 폰트에 따라 맞춰줘야
  vaTemplate.push("_text' style='position:absolute;margin:0px;");
  vaTemplate.push("@cssStrBuf"); // 0 번째 input 스타일
  vaTemplate.push("' ");
  vaTemplate.push("@attStrBuf"); // 1번째 input Attribute
  vaTemplate.push(">");

  var vsBtnClass = this.getCSSClass(this, 1, "Button");
  vaTemplate.push("<input class='" + vsBtnClass + "' type='button' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_btn' ");
  vaTemplate.push("@attStrBuf"); // 2
  var vsButtonCursor = "";
  // yhkim 2009. 11 버튼의 커서설정이 필요
  if(this.btnCursor)
    vsButtonCursor = "cursor:" + this.btnCursor + ";";
  vaTemplate.push("style=\"position:absolute;margin:0px;padding:0px;top:0px;right:0px;background-repeat:no-repeat;background-position:center center;" + vsButtonCursor);
  vaTemplate.push("@cssStrBuf"); // 3번째 voBtn 스타일
  vaTemplate.push("\" onclick=\"");
  vaTemplate.push(this.getEHandler(this.id, "showList"));
  vaTemplate.push("\">");

  vaTemplate.push("<div id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_listarea' ");
  vaTemplate.push("@attStrBuf"); // 4 voList 클래스 지정
  vaTemplate.push(" style='position:absolute;display:none;");
  vaTemplate.push("@cssStrBuf"); // 5 voList 스타일값 추가
  vaTemplate.push("@cssStrBuf"); // 6 loadData 이후의 높이 값을 설정하기 위한 용도
  vaTemplate.push("'>");
  vaTemplate.push("<table id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_listarea_table' width='100%' cellPadding=0 style='");
  vaTemplate.push("@cssStrBuf"); // 7 voList 스타일값 추가
  vaTemplate.push(" '");
  vaTemplate.push("@attStrBuf"); // 8 voListTable attribute 값 추가
  vaTemplate.push(">");
  vaTemplate.push("<tbody>");
  vaTemplate.push("@innStrBuf"); // 9
  vaTemplate.push("</tbody></table></div>");
  // 사용자  css에서 class 형태로 높이를 잡아준다 하지만 input은 동적으로 폰트에 따라 맞춰줘야
  vaTemplate.push("<span class='" + vsClass + "' style=\"position:absolute;visibility:hidden;");
  vaTemplate.push("@cssStrBuf"); // 10
  vaTemplate.push("\"/>")

  this.templateIndexMap = eXria.controls.xhtml.Util
      .getTemplateIndexMap(vaTemplate);

  this.bReloadList = true;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.refreshSubStyle = function(poCtrl,
    poDocument) {
  this.setSubCtrlStyles(poCtrl);
};

eXria.controls.xhtml.ComboBox.prototype.clearListArea = function() {
  var voDocument = this.getComboboxCtrl("document");
  var voList = voDocument.getElementById(this.id + "_listarea");
  var voCanvasCtrl = this.getComboboxCtrl();
  var voParentElement = null;
  
  if(voList){
    voParentElement = voList.parentElement;
    if(voParentElement.id != this.id){
      voCanvasCtrl.removeChild(voList);
    }
  }else return;
};

/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.setSpecificDefaults = function(poCtrl,
    poDocument) {
  var voDf = this.df;
  var voListareaDf = this.listarea;
  var voItemgroupDf = this.itemgroup;
  var voUserAttr = null;
  if(this.userAttr == "") this.userAttr = null;
  this.userAttr = this.getAttrValue("userAttr", this.userAttr);
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if (this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if (this.innerHeight < 0)  this.innerHeight = 0;

  this.selectedIndex = this.getAttrValue("selectedIndex", this.selectedIndex);
  this.btnWidth = this.getAttrValue("Button.btnWidth", this.btnWidth);
  this.value = this.getAttrValue("value", this.value);
  if (this.value == null)  this.value = [];
  this.expandImage = this.getAttrValue("Button.expandImage", this.expandImage);
  this.collapseImage = this.getAttrValue("Button.collapseImage", this.collapseImage);
  this.btnBackgroundColor = this.getAttrValue("btnBackgroundColor",  this.btnBackgroundColor);
  this.btnColor = this.getAttrValue("btnColor", this.btnColor);
  this.btnCursor = this.getAttrValue("btnCursor", this.btnCursor);
  this.readOnly = this.getAttrValue("readonly", this.readOnly);
  this.arrowKeyMode = this.getAttrValue("arrowKeyMode", this.arrowKeyMode);
  this.maxCanvasWidth = this.getAttrValue("maxCanvasWidth", this.maxCanvasWidth);
  this.maxCanvasHeight = this.getAttrValue("maxCanvasHeight", this.maxCanvasHeight);
  this.listDirection = this.getAttrValue("listDirection", this.listDirection);
  this.type = this.getAttrValue("type", this.type);
  if(voUserAttr) {
    if(voUserAttr.btn) {
      this.btnFontSize = voUserAttr.btn.fontSize;
      this.btnBorderStyle = voUserAttr.btn.borderStyle;
    }
    this.labelName = voUserAttr.labelName;
    if(voUserAttr.arrowKeyMode) this.arrowKeyMode = voUserAttr.arrowKeyMode;
    if(voUserAttr.defaultIndex) this.defaultIndex = voUserAttr.defaultIndex;
    if(voUserAttr.type) this.type = voUserAttr.type;
  }
  if(this.type == "searchable_list") this.arrowKeyMode = "focus";

  voListareaDf.className = this.getAttrValue("listarea.className", this.listarea.className);
  voListareaDf.appearance = this.getAttrValue("listarea.appearance",this.listarea.appearance);
  voListareaDf.multiSelect = this.getAttrValue("listarea.multiSelect",this.listarea.multiSelect);
  voListareaDf.cellSpacing = this.getAttrValue("listarea.cellSpacing",this.listarea.cellSpacing);
  voListareaDf.size = this.getAttrValue("listarea.size", this.listarea.size);
  voListareaDf.heightBySize = this.getAttrValue("listarea.heightBySize",this.listarea.heightBySize);
  var voWidthByMaxLength = this.getAttrValue("listarea.widthByMaxLength",this.listarea.widthByMaxLength);
  voListareaDf.widthByMaxLength = (voWidthByMaxLength == null || voWidthByMaxLength == "undefine")?true:voWidthByMaxLength;

  voListareaDf.focusColor = this.getAttrValue("listarea.focusColor",this.listarea.focusColor);
  voListareaDf.focusBackgroundColor = this.getAttrValue("listarea.focusBackgroundColor", this.listarea.focusBackgroundColor);
  var voHoverColor = this.getAttrValue("listarea.hoverBackgroundColor", this.listarea.hoverBackgroundColor);
  voListareaDf.hoverBackgroundColor = ( voHoverColor == null || voHoverColor == "undefine")?"#F0F0F0":voHoverColor
  this.listarea.oldMultiSelect = voListareaDf.multiSelect;
  this.listarea.oldAppearance = voListareaDf.appearance;

  // voItemgroupDf.className이 계속적으로 중첩되서 늘어나서 메모리 릭 문제로 Default_ComboBox_itemgroup_Class와 같이
  // 조합이 이미 이루어진 경우와  this.itemgroup.className이름이 동적(refresh도 이 함수를 탐) 으로 순수하게 바뀐경우를 대비해서 search문을 추가함
  var vbComposited = false;
  if(voItemgroupDf.className) {
    if(voItemgroupDf.className.search(/Default_ComboBox_itemgroup_Class/) != -1)
      vbComposited = true;
  }

  if(vbComposited == false) {
    //voItemgroupDf.className = this.getAttrValue("itemgroup.className",this.itemgroup.className);
    var vsClass = this.getCSSClass(this, 1, "itemgroup");
    //if(voItemgroupDf.className) vsClass = vsClass + " " + voItemgroupDf.className;
    voItemgroupDf.className = vsClass;
  }

  voItemgroupDf.selectorWidth = this.getAttrValue("itemgroup.selectorWidth",this.itemgroup.selectorWidth);
  voItemgroupDf.verticalAlign = this.getAttrValue("itemgroup.verticalAlign",this.itemgroup.verticalAlign);
  voItemgroupDf.textAlign = this.getAttrValue("itemgroup.textAlign",this.itemgroup.textAlign);
  // list Item Extended 속성추가
  voItemgroupDf.height = this.getAttrValue("itemgroup.height",this.itemgroup.textHeight);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voListareaDf = this.listarea;
  var voItemgroupDf = this.itemgroup;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;
  var vnWidth = 0;
  var vnHeight = 0;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if (this.visible == false)  vaCssStrBuf.push("display:none;");
  else  vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth,  "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth,  "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  // voText
  vaCssStrBuf = [];
  var vnWidth = this.innerWidth;
  if(this.btnWidth !== null) vnWidth = vnWidth - this.btnWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  if (vnWidth < 0) vnWidth = 0;
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", this.subBorderWidth);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  if (this.readOnly)
    vaAttStrBuf.push("readOnly ");
  vaTemplate[voIndexMap.get(1)] = vaAttStrBuf.join("");
  // voBtn
  vaAttStrBuf = [];
  if (this.expandImage) {
    vfcSetAttStrBuf(vaAttStrBuf, "value", "");
  } else {
    vfcSetAttStrBuf(vaAttStrBuf, "value", "▼");
  }
  vaTemplate[voIndexMap.get(2)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.btnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.btnBackgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.btnColor);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.btnCursor);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.btnFontSize);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.btnBorderStyle);
  if (this.expandImage) {
    vfcSetCssStrBuf(vaCssStrBuf, "border-style", "none");
    vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.expandImage);
  }
  vaTemplate[voIndexMap.get(3)] = vaCssStrBuf.join("");
  // voList
  //TODO
  vnHeight = voListareaDf.height;
  if (vnHeight) {
    vnHeight = vnHeight - voListareaDf.borderTopWidth  - voListareaDf.borderBottomWidth;
    if (vnHeight < 0)
      vnHeight = 0;
  }
  if (voListareaDf.appearance == "radio") {
    this.listarea.multiSelect = false;
    voListareaDf.multiSelect = false;
  }

  vaAttStrBuf = [];
  var vsClass = this.getCSSClass(this, 1, "listarea");
  if(voListareaDf.className) vsClass = vsClass + " " + voListareaDf.className;
  vfcSetAttStrBuf(vaAttStrBuf, "class", vsClass); // TODO
  vaTemplate[voIndexMap.get(4)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voListareaDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "color", voListareaDf.color);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", voListareaDf.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", voListareaDf.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width",  voListareaDf.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", voListareaDf.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", voListareaDf.borderTopWidth,
      "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width",  voListareaDf.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "left", -voListareaDf.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top",  (parseInt(this.innerHeight, 10) + parseInt(this.borderBottomWidth, 10)), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", voListareaDf.overflowX);
  // vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", voListareaDf.overflowY);
  vaTemplate[voIndexMap.get(5)] = vaCssStrBuf.join("");
  // voListTable
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voItemgroupDf.textAlign);
  vaTemplate[voIndexMap.get(7)] = vaCssStrBuf.join("");
  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "cellSpacing", voListareaDf.cellSpacing);
  vaTemplate[voIndexMap.get(8)] = vaAttStrBuf.join("");
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(10)] = vaCssStrBuf.join("");
  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
};
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.input = this.getSubCtrl("input", voCtrl, poDocument);
  voSubElement.btn = voCtrl.childNodes[1];
  voSubElement.list = voCtrl.childNodes[2];
  voSubElement.table = this.getSubCtrl("table", voCtrl);
  voSubElement.span = this.getSubCtrl("span", voCtrl);

};

/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.dochange = function(poEvent, poControl) {
  if (poControl.atchange) {
    poControl.atchange(poEvent);
  }
  if (poControl.cochange) {
    poControl.cochange(poEvent);
  }
  if (poControl.onchange) {
    poControl.onchange(poEvent);
  }
  if (poControl.changeEventCallback) {
    poControl.changeEventCallback(poEvent);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.doitemchange = function(poEvent, poControl) {
  if (poControl.atitemchange) {
    poControl.atitemchange(poEvent);
  }
  if (poControl.coitemchange) {
    poControl.coitemchange(poEvent);
  }
  if (poControl.onitemchange) {
    poControl.onitemchange(poEvent);
  }
  if (poControl.itemchangeEventCallback) {
    poControl.itemchangeEventCallback(poEvent);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.dofocus = function() {
  if (this.listShowed)
    return;
  var voCtrl = this.ctrl;
  var voInput = this.getSubCtrl("input", voCtrl);
  try { voInput.focus(); }catch(err) {}
};
/**
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.atkeydown = function(e) {
  this.keyDownEvent(e);
};
/**
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.atclick = function(poEvent) {
  if(this.itemChanged) {
    poEvent.objectType = "item";
    poEvent.object = this.itemChanged;
  }
};
/**
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.finalclick = function(poEvent) {
  this.itemChanged = null;
};
/**
 * 키다운 이벤트 처리 메소드.
 * @param {eXria.event.Event} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.keyDownEvent = function(e){
  var vnKeyCode = e.keyCode;

  var voEvent = new eXria.event.Event(e, this.window);
  var vnItemSize = this.selectedItems.size();

  if(voEvent.target.id === (this.id+'_text'))
   this.isComboMousedown = false;


  if(vnKeyCode == '16' || vnKeyCode == '17')
    this.bMultiSelectKeyDown = true;

  if(vnKeyCode == '38' || vnKeyCode == '40'){//↑↓
    if(!this.listShowed) return;
    if(this.arrowKeyMode == "select") {
      if(vnItemSize > 0){ //선택된 아이템이 있는 경우

        //현재 선택되어 있는 아이템 얻기
        var voNextTarget = this.getLastSelectTr(voEvent);

        if(vnKeyCode == '38'){// ↑
          voNextTarget = voNextTarget.previousSibling;
        }else{  //↓
          voNextTarget = voNextTarget.nextSibling;
        }
        if (voNextTarget != null) {
          var vbChek = true;
          var vnCnt = 0;
          while (vbChek) {
            if (vnCnt > 0 && voNextTarget.nodeName.toUpperCase() == "TD") {
              vbChek = false;
              continue;
            }else if(voNextTarget.nodeName.toUpperCase() == "TD"){
              ++vnCnt;
            }

            voNextTarget = voNextTarget.firstChild;
          }

          voEvent.target = voNextTarget;
          this.isCallByArrowKeySelect = true;
          this.listarea.selectEventList(voEvent);
        }
      }
    } else if(this.arrowKeyMode == "focus") {
      var voListCtrl = this.subElement.list;
      var voItemHeight = this.itemgroup.height
      var vnScrollTop = voListCtrl.scrollTop;
      var vnIdx = this.selectedIndex;
      if(vnIdx == null) vnIdx = -1;
      if(this.focusedItemCtrl) {
        vnIdx = this.focusedItemCtrl.id;
        vnIdx = vnIdx.substring((this.id + "_option_").length);
        vnIdx = parseInt(vnIdx);
      }
      if(vnKeyCode == '38') {// ↑
        vnIdx--;
        if(vnIdx * voItemHeight - voListCtrl.scrollTop < 0) vnScrollTop = vnIdx * voItemHeight;
      } else {  //↓
        vnIdx++;
        if((vnIdx + 1) * voItemHeight - voListCtrl.scrollTop > voListCtrl.clientHeight) vnScrollTop += voItemHeight;
      }
      var voTable = this.subElement.table;
      var vnListCnt = voTable.rows.length;
      if(vnIdx < 0) {
        vnIdx = vnListCnt - 1;
        vnScrollTop = vnIdx * voItemHeight;
      } else if(vnIdx >= vnListCnt) {
        vnIdx = 0;
        vnScrollTop = 0;
      }
      var vsId = this.id + "_option_" + vnIdx;
      this.listarea.mouseOver(null, vsId);
      this.atmouseover(null);
      voListCtrl.scrollTop = vnScrollTop;
    }
  }else if(vnKeyCode == '13'){  //enter
    if(this.listShowed) {
      if(this.arrowKeyMode == "focus" && this.focusedItemCtrl) {
        vnIdx = this.focusedItemCtrl.id;
        vnIdx = vnIdx.substring((this.id + "_option_").length);
        vnIdx = parseInt(vnIdx);
        var vbChanged = false;
        if(this.selectedIndex != vnIdx) vbChanged = true;
        this.selectedIndex = vnIdx;
        this.listarea.select([vnIdx]);
        this.isCallByItemEnter = true;
        if(vbChanged) {
          var voEvent = new eXria.event.Event(null, this.window);
          voEvent.object = this.getItem(vnIdx);
          voEvent.objectType = "item";
          this.doitemchange(voEvent, this);
          this.dochange(voEvent, this);
        }
      }
      if(this.type == "searchable_list") {
        if(!this.focusedItemCtrl) {
          var vbChanged = this.isChanged;
          e.target.value = "";
          this.clearSelected();
          this.setValue(null);
          if(vbChanged) {
            voEvent.object = this;
            if(this.onchange) {
              this.onchange(voEvent);
            }
            if(this.changeEventCallback) this.changeEventCallback(voEvent);
          }
        }
      }
      this.showList(false);
    } else {
      this.showList(true);
    }
    voEvent.stopEvent();
  }
};
/**
 * 이전에 선택된 Tr 정보 얻기
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.getLastSelectTr = function(poEvent) {
  // 이전에 선택된 아이템 정보 얻기

  var voSelectItem = null;

  voSelectItem = this.getItem(this.selectedIndex);

  var voDiv = null;

  //voDiv = voDiv.firstChild.nextSibling.nextSibling.firstChild;
  voDiv = this.subElement.table;

  while (voDiv.nodeName.toUpperCase() != "DIV") {
    voDiv = voDiv.firstChild;
  }

  if (voDiv == null || voDiv["id"].indexOf(this.id + "_option") == -1)
    return;

  var voTr = this.subElement.table.firstChild.firstChild;
  //voDiv = voTr.firstChild.firstChild;

  var vbCheck = true;
  while (vbCheck) {
    if (voSelectItem.id == voDiv.id) {
      vbCheck = false;
      continue;
    } else {
      voTr = voTr.nextSibling;
      voDiv = voTr.firstChild.firstChild;
    }
  }

  return voTr;

};

/**
 * 컨트롤 내부적이 mouseover 이벤트 처리 메소드.
 * @param {eXria.event.Event} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.atmouseover = function(e) {

  if(this.eventType == "item" && this.eventObject != null) {
    var voDocument = this.getComboboxCtrl("document");
    var voItem = this.eventObject;
    var voItemCtrl = voDocument.getElementById(voItem.id);
    var voStyle = voItemCtrl.style;
    var vbSelected = false;

    var vnIdx = voItem.id;
    vnIdx = vnIdx.substring((this.id + "_option_").length);
    vnIdx = parseInt(vnIdx);
    if(this.selectedItems.get(vnIdx) != null) {
      vbSelected = true;
    }
    if (!vbSelected) {
      voStyle.backgroundColor = this.listarea.hoverBackgroundColor;// eXria.controls.xhtml.Default.ListBox.focusBackgroundColor;//"#F1F1EB";//this.focusBackgroundColor;
    }
    this.focusedItemCtrl = voItemCtrl;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.atmouseout = function(e) {
  var voCanvas = this.canvas;
  var voTarget = e.target;
  var voBtnCtrl = this.subElement.btn;
  var voInputCtrl = this.subElement.input;
  var vnLeft = 0;
  if(voTarget == voBtnCtrl) {
    if(voCanvas.page.metadata.browser.ie) {
      vnLeft = e.e.offsetX;
    } else {
      var voElement = e.target;
      while(voElement.offsetParent) {
        vnLeft += voElement.offsetLeft;
        voElement = voElement.offsetParent ;
      };
      vnLeft = e.e.pageX - vnLeft ;
    }
    if(vnLeft <= 0) this.skipCustomEvent = true;
  }
  if(voTarget == voInputCtrl) {
    if(voCanvas.page.metadata.browser.ie) {
      vnLeft = e.e.offsetX;
    } else {
      var voElement = e.target;
      while(voElement.offsetParent) {
        vnLeft += voElement.offsetLeft;
        voElement = voElement.offsetParent ;
      };
      vnLeft = e.e.pageX - vnLeft ;
    }
    var vnLen = parseInt(voInputCtrl.style.width);
    if(vnLeft >= vnLen) this.skipCustomEvent = true;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.atmousedown = function() {
  this.isComboMousedown = true;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.atchange = function(poEvent) {
  if(this.type == "searchable_list") {
    if(this.focusedItemCtrl) {
      var voDiv = this.focusedItemCtrl;
      vnIdx = voDiv.id;
      vnIdx = vnIdx.substring((this.id + "_option_").length);
      vnIdx = parseInt(vnIdx);
      this.selectedIndex = vnIdx;
      this.listarea.select([vnIdx]);
      this.showList(false);
      this.focusedItemCtrl = voDiv;
    } else {
      this.subElement.input.value = "";
      this.clearSelected();
      this.setValue(null);
    }
    return;
  }

  if(this.isCallByKeyIn) return;
//  var voText = this.subElement.input;
//  if (this.selectedIndex == -1) this.setValue(voText.value);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.atfocus = function(poEvent) {
  // this.selectText();
  if (this.focused == false) {
    this.selectText();
    this.focused = true;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.atblur = function(e) {
  if(!!this.isComboMousedown) {
    this.isComboMousedown = false;
    return;
  }
  if(!!this.isCallByArrowKeySelect) {
    this.isCallByArrowKeySelect = false;
    return;
  }

  var vaSelectItem = this.getSelectedItems();
  var voText = this.subElement.input;

  if(this.value !== voText.value && this.isChanged){
    this.unselectListItem(null, this.bMultiSelectKeyDown);
    this.setValue(voText.value);
  }else{
    return;
  }

  this.setInputHeight();
  this.focused = false;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.doblur = function() {
  var voInput = this.subElement.input;
  voInput.blur();
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.refreshSpecificAttrs = function(poCtrl,
    poDocument) {
  this.bReloadList = true;
  this.setSpecificAttrs(poCtrl, poDocument);
  this.clearListArea();
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.removeSpecificDefaults = function(
    poCtrl, poDocument) {
  this.df = {};
//  this.itemgroup.df = {};
  this.template = null;
  this.templateIndexMap = null
  // var voTable = this.subElement.table;
  // if(voTable) {
  // var voDiv = null;
  // for(var i=0; i < voTable.rows.length; i++) {
  // voDiv = voTable.rows[i].cells[0].firstChild;
  // voDiv.onclick = null;
  // }
  // }
  // var voText = this.subElement.input;
  // var voEventManager = this.eventManager;
  // voEventManager.removeListener(voText, "onblur", this.mediateEvent);
  // voEventManager.removeListener(voText, "onchange", this.mediateEvent);
  // voEventManager.removeListener(voText, "onfocus", this.mediateEvent);
  // voEventManager.removeListener(voText, "onselect", this.mediateEvent);
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.setAttrSubCtrl = function(psAttrName,
    psAttrValue, poCtrl) {
  if (poCtrl.id != this.id)
    return;
  var voDf = this.df;
  var voText = this.subElement.input;
  var voBtn = this.subElement.btn;
  var voList = this.subElement.list;
  var voListTable = this.subElement.table;
  var voSpan = this.subElement.span;
  var voInput = this.subElement.input;

  switch (psAttrName) {
  case "width":
    var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    if (vnWidth < 0)
      vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voInput);
    this.setAttrCtrl("width", this.innerWidth, voList);
    break;
  case "height":
    this.setAttrCtrl("height", this.innerHeight, voBtn);
    this.setVerticalAlign(voText, poCtrl, this.verticalAlign);
    break;
  }
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.applyAttrRebuild = function(psAttrName,
    psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voText = this.subElement.input;
  var voBtn = this.subElement.btn;
  var voList = this.subElement.list;
  var voTable = this.subElement.table;
  var voSpan = this.subElement.span;
  var voStyle = null;
  var vsSubAttrName = null;
  var voDf = this.df;
  var voListAreaDf = this.listarea;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for ( var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if (voObj.df)  voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch (psAttrName) {
  case "visible":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
    break;
  case "disabled":
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "backgroundColor":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setAttrCtrl(psAttrName, psAttrValue, voText);
    break;
  case "color":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setAttrCtrl(psAttrName, psAttrValue, voText);
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "textDecoration":
  case "textTransform":
    this.setAttrCtrl(psAttrName, psAttrValue, voText);
    this.setAttrCtrl(psAttrName, psAttrValue, voSpan);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
    break;
  case "fontFamily":
  case "fontSize":
  case "fontStyle":
  case "fontWeight":
    this.setAttrCtrl(psAttrName, psAttrValue, voText);
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    this.setAttrCtrl(psAttrName, psAttrValue, voSpan);
    this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
    var voDiv = null;
    var voInnerTable = null;
    for ( var i = 0; i < voTable.rows.length; i++) {
      voDiv = voTable.rows[i].cells[0].childNodes[0];
      voInnerTable = voDiv.childNodes[0];
      this.setAttrCtrl(psAttrName, psAttrValue, voInnerTable);
    }
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
    break;
  case "verticalAlign":
    this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
    break;
  case "left":
  case "top":
    this.setAttrCtrl(psAttrName, psAttrValue);
    break;
  case "width":
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if (this.innerWidth < 0)
      this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    var vnWidth = this.innerWidth;
    if(this.btnWidth !== null) vnWidth = vnWidth - this.btnWidth
    if (vnWidth < 0)
      vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voTable);
    this.setInputWidth();
    break;
  case "height":
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if (this.innerHeight < 0)
      this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl("top", (parseInt(this.innerHeight, 10) + parseInt(this.borderBottomWidth, 10)), voList);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
    break;
  case "borderWidth":
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if (this.innerWidth < 0)
      this.innerWidth = 0;
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if (this.innerHeight < 0)
      this.innerHeight = 0;
    // border
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    // width
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    var vnWidth = this.innerWidth;
    if(this.bntWidth !== null) vnWidth = vnWidth - this.btnWidth;
    if (vnWidth < 0)
      vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voTable);
    this.setInputWidth();
    // height
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl("top", (parseInt(this.innerHeight, 10) + parseInt(this.borderBottomWidth, 10)), voList);
    break;
  case "borderLeftWidth":
  case "borderRightWidth":
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if (this.innerWidth < 0)
      this.innerWidth = 0;
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    var vnWidth = this.innerWidth;
    if(this.btnWidth !== null) vnWidth = vnWidth - this.btnWidth;
    if (vnWidth < 0)
      vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voTable);
    this.setInputWidth();
    break;
  case "borderTopWidth":
  case "borderBottomWidth":
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if (this.innerHeight < 0)
      this.innerHeight = 0;
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl("top", (parseInt(this.innerHeight, 10) + parseInt(this.borderBottomWidth, 10)), voList);
    break;
  case "btnWidth":
    var vnWidth = this.innerWidth;
    if(this.btnWidth !== null) vnWidth = vnWidth - this.btnWidth;
    if(this.subBorderWidth !== null) vnWidth = vnWidth - 2 * this.subBorderWidth;
    if (vnWidth < 0) vnWidth = 0;
    vnWidth = this.innerWidth;
    if(this.btnWidth !== null) vnWidth = vnWidth - this.bntWidth;
    this.setAttrCtrl("left", vnWidth, voBtn);
    this.setAttrCtrl("width", this.btnWidth, voBtn);
    this.setInputWidth();
    break;
  case "listarea.size":
  case "listarea.cellSpacing":
    if (voListAreaDf.heightBySize) {
      var vnSize = this.getVisibleItemCount();
      if (voListAreaDf.size < vnSize)
        vnSize = voListAreaDf.size;
      var vnHeight = vnSize
          * (this.itemgroup.height + voListAreaDf.cellSpacing)
          + voListAreaDf.cellSpacing;
      this.setAttrCtrl("height", vnHeight, voList);
    }
    if (psAttrName == "listarea.cellSpacing") {
      voTable.setAttribute("cellSpacing", voListAreaDf.cellSpacing);
    }
    break;
  case "listarea.backgroundColor":
  case "listarea.color":
    this.setAttrCtrl(psAttrName, psAttrValue, voList);
    var voDiv = null;
    for ( var i = 0; i < voTable.rows.length; i++) {
      voDiv = voTable.rows[i].cells[0].childNodes[0];
      if (this.selectedItems.get(i) == null) {
        this.restoreRowColor(voDiv);
      }
    }
    break;
  case "listarea.borderWidth":
    voListAreaDf.borderLeftWidth = voListAreaDf.borderWidth;
    voListAreaDf.borderRightWidth = voListAreaDf.borderWidth;
    voListAreaDf.borderTopWidth = voListAreaDf.borderWidth;
    voListAreaDf.borderBottomWidth = voListAreaDf.borderWidth;
    this.setAttrCtrl("left", (-voListAreaDf.borderLeftWidth), voList);
    this.setAttrCtrl("borderLeftWidth", voListAreaDf.borderLeftWidth, voList);
    this.setAttrCtrl("borderRightWidth", voListAreaDf.borderRightWidth, voList);
    this.setAttrCtrl("borderTopWidth", voListAreaDf.borderTopWidth, voList);
    this.setAttrCtrl("borderBottomWidth", voListAreaDf.borderBottomWidth,
        voList);
    break;
  case "listarea.borderLeftWidth":
    this.setAttrCtrl("left", (-voListAreaDf.borderLeftWidth), voList);
  case "listarea.borderRightWidth":
  case "listarea.borderTopWidth":
  case "listarea.borderBottomWidth":
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voList);
    break;
  case "listarea.focusBackgroundColor":
  case "listarea.focusColor":
    var voDiv = null;
    for ( var i = 0; i < voTable.rows.length; i++) {
      voDiv = voTable.rows[i].cells[0].childNodes[0];
      if (this.selectedItems.get(i) != null) {
        this.changeRowColor(voDiv);
      }
    }
    break;
  case "itemgroup.borderWidth":
  case "itemgroup.borderLeftWidth":
  case "itemgroup.borderRightWidth":
  case "itemgroup.borderTopWidth":
  case "itemgroup.borderBottomWidth":
  case "itemgroup.height":
  case "itemgroup.padding":
  case "itemgroup.paddingLeft":
  case "itemgroup.paddingRight":
  case "itemgroup.paddingTop":
  case "itemgroup.paddingBottom":
  case "itemgroup.selectorWidth":
  case "itemgroup.verticalAlign":
    this.refreshList(voCtrl, poDocument);
    break;
  case "multiSelect":
    voListAreaDf.multiSelect = psAttrValue;
    if (voListAreaDf.appearance == "radio")
      voListAreaDf.multiSelect = false;
    if (voListAreaDf.multiSelect != this.listarea.oldMultiSelect) {
      this.refreshList(voCtrl, poDocument);
    }
    break;
  case "appearance":
    if (voListAreaDf.appearance == "radio")
      voListAreaDf.multiSelect = false;
    if (voListAreaDf.appearance != this.listarea.oldAppearance) {
      this.refreshList(voCtrl, poDocument);
    }
    break;
  case "readOnly" :
    this.setAttrCtrl("readOnly", psAttrValue, voText);
    break;
  default:
    this.refresh(poDocument);
    break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.loadData = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  this.itemset.clear();
  this.selectedItems.clear();

  if (this.datasetId == null) {
    this.loadDataFromInstance(voCtrl, poDocument);
  } else {
    this.loadDataFromDataSet(voCtrl, poDocument);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.loadDataFromInstance = function(poCtrl,  poDocument) {
  if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    this.loadDataFromPluginInstance(poCtrl, poDocument);
    return;
  }
  var vaValue = [];
  var vsRefValue = this.value;
  if (this.data.instanceId && this.data.instancePath)
    vsRefValue = this.data.getData();
  if (vsRefValue != null) {
    this.selectedIndex = -1;
    if (vsRefValue instanceof Array)
      vaValue = vsRefValue;
    else
      vaValue.push(vsRefValue);
  }
  this.value = vaValue;
  if (this.data.nodesetInstanceId == null
      || this.data.nodesetInstancePath == null)
    return;
  var voCollectionNode = this.data.getNodesetData2();
  if (voCollectionNode) {
    var vnLoop = voCollectionNode.getLength();
    var voMapNode = null;
    var vsLabelNode = null;
    var vsValueNode = null;
    var voItem = null;
    for ( var i = 0; i < vnLoop; i++) {
      voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
      vsLabelNode = voMapNode.get(this.labelTagName);
      vsValueNode = voMapNode.get(this.valueTagName);
      voItem = this.addToItemset(vsLabelNode, vsValueNode, poDocument);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.loadDataFromPluginInstance = function(poCtrl, poDocument) {
  var vaValue = [];
  var vsRefValue = this.value;
  if (this.data.instanceId && this.data.instancePath)
    vsRefValue = this.data.getData();
  if (vsRefValue != null) {
    this.selectedIndex = -1;
    if (vsRefValue instanceof Array)
      vaValue = vsRefValue;
    else
      vaValue.push(vsRefValue);
  }
  this.value = vaValue;
  if (this.data.nodesetInstanceId == null
      || this.data.nodesetInstancePath == null)
    return;
  var voCollectionNode = this.data.getNodesetStr();
  if(voCollectionNode) voCollectionNode = eval(voCollectionNode);
  if (voCollectionNode) {
    var vnLoop = voCollectionNode.length;
    var voMapNode = null;
    var vsLabelNode = null;
    var vsValueNode = null;
    var voItem = null;
    for ( var i = 0; i < vnLoop; i++) {
      voMapNode = voCollectionNode[i];
      vsLabelNode = voMapNode[this.labelTagName];
      vsValueNode = voMapNode[this.valueTagName];
      voItem = this.addToItemset(vsLabelNode, vsValueNode, poDocument);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.loadDataFromDataSet = function(poCtrl, poDocument) {
  var voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
  if (voDataSet == null)
    return;
  // voDataSet.setDataSync(true);
  voDataSet.rebuild(false);

  var vsLabelNode = null;
  var vsValueNode = null;
  var voItem = null;
  var vnLoop = voDataSet.getRowCnt();
  for ( var i = 1; i <= vnLoop; i++) {
    vsLabelNode = voDataSet.get(i, this.labelTagName);
    vsValueNode = voDataSet.get(i, this.valueTagName);
    voItem = this.addToItemset(vsLabelNode, vsValueNode, poDocument);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.loadComplete = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;
  var vaTemplate = this.template;
  var voListareaDf = this.listarea;
  var voItemgroupDf = this.itemgroup;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var voIndexMap = this.templateIndexMap;

  //this.scrolled = this.isScrolled();
  this.seqNum = 0;
  if (this.value.length > 0) {
    this.clearSelected();
  }
  var vnHeight = voListareaDf.height;
  if (vnHeight) {
    vnHeight = vnHeight - voListareaDf.borderTopWidth - voListareaDf.borderBottomWidth;
    if (vnHeight < 0)
      vnHeight = 0;
  }
  if (voListareaDf.heightBySize) {
    vnHeight = parseInt(voItemgroupDf.height);
    var vnSize = this.getVisibleItemCount();
    if (voListareaDf.size != null && voListareaDf.size < vnSize) {
      vnHeight = voListareaDf.size * (vnHeight + voListareaDf.cellSpacing) + voListareaDf.cellSpacing;
    } else {
      vnHeight = vnSize * (vnHeight + voListareaDf.cellSpacing)  + voListareaDf.cellSpacing;
    }
  }
  vaCssStrBuf = [];
  if (this.scrolled)
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", "scroll");
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", voListareaDf.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px"); // 스크롤 높이 잡아준다
  if(this.listDirection == "top") { // 원래 위치에 맞게 조정
    var vnTop = parseInt(this.getStyleCurrentValue(voCtrl, "top", "top"), 10);
    vnTop = vnTop - vnHeight;
    vfcSetCssStrBuf(vaCssStrBuf, "top", vnTop, "px"); // 스크롤 높이 잡아준다
  }

  vaTemplate[voIndexMap.get(6)] = vaCssStrBuf.join("");
  vaTemplate[voIndexMap.get(9)] = this.getListInnerHTML();

  if((this.value.length == 0 || (this.value.length == 1 && this.value[0] == "")) && this.defaultIndex != null) {
    var voItem = this.getItem(this.defaultIndex);
    if(voItem) voItem.selected = true;
  }
  this.skipEvent = true;
  voCtrl.innerHTML = vaTemplate.join("");
  this.skipEvent = false;
  voIndexMap.clear();
  vaCssStrBuf = null;
  // vaTemplate = null;
  // this.template = null;
  // this.templateIndexMap = null;

  this.setSubElement(poDocument);
//  this.setEvnets(voCtrl);
  // var voSpan = poDocument.createElement("span");
  // voSpan.style.visibility = "hidden";
  // voCtrl.appendChild(voSpan);
  //
  // // voSpan
  // this.setAttrCtrl("fontFamily", this.fontFamily, voSpan);
  // this.setAttrCtrl("fontStyle", this.fontStyle, voSpan);
  // this.setAttrCtrl("fontSize", this.fontSize, voSpan);
  // this.setAttrCtrl("fontWeight",this.fontWeight, voSpan);

  var voText = this.subElement.input;
  this.eventManager.addListener(voText, "onblur", this.mediateEvent);
  this.eventManager.addListener(voText, "onchange", this.mediateEvent);
  this.eventManager.addListener(voText, "onfocus", this.mediateEvent);
  this.eventManager.addListener(voText, "onselect", this.mediateEvent);
  this.eventManager.addListener(voText, "onitemchange", this.mediateEvent);

  voText.control = this;

  this.bReloadList = false;
  this.checkSelected(voCtrl, poDocument);
  if (this.selectedIndex == -1) {
    if (this.value instanceof Array) {
      var vsStr = "";
      for ( var i = 0; i < this.value.length; i++) {
        //vsStr += eXria.controls.xhtml.Util.parseLang(this.value[i]);
        vsStr += this.value[i];
        if (i != this.value.length - 1)
          vsStr += ";";
      }
      voText.value = vsStr;
    } else if (this.value) {
//      voText.value = eXria.controls.xhtml.Util.parseLang(this.df.value);
      voText.value = this.getItemByVal(this.value) ? this.getItemByVal(this.value).name : this.value;
    }
  }
  this.oldText = voText.value;

  // yhkim 2009.10.09  선택된 아이템은 있는데 selectedIndex가 null인경우
  if(this.selectedIndex == null && this.getSelectedIndexes().length > 0) {
    var vnIndexes = this.getSelectedIndexes();
    this.selectedIndex = vnIndexes[0];
  }

  this.setInputHeight(voCtrl);
  this.setInputWidth();
  this.setVerticalAlign(voText, voCtrl, this.verticalAlign);  // UIControl 호출
  if(this.readOnly) {
    var voBase = this;
    voText.onclick = function(e) {
      var voEvent = new eXria.event.Event(e, voBase.window);
      voBase.showList();
      voEvent.stopPropagation();
    }
  } else {
    voText.onclick = null;
  }
};
/**
 * 로딩된 아이템을 새로고침하기 위한 메소드.(아이템들을 리로딩 하지 않는다는 점에서 refresh메소드와 구별됨)
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.repaint = function(poDocument) {
  if (poDocument == null)
    poDocument = this.document;
  var voCtrl = this.getCtrl(poDocument);

  this.removeUIGeneralDefaults(voCtrl, poDocument);
  this.removeSpecificDefaults(voCtrl, poDocument);
  this.refreshTemplate(voCtrl, poDocument);
  this.refreshUIGeneralDefaults(voCtrl, poDocument);
  this.refreshSpecificDefaults(voCtrl, poDocument);
  this.refreshSpecificAttrs(voCtrl, poDocument);
  this.loadComplete(poDocument);
};

/**
 * @ignore
 * shift로 다중선택된 아이탬중 기준이 되는 처음 선택된 아이템 index
 */
eXria.controls.xhtml.ComboBox.prototype.getFirstItemIndex = function(){
  var voIterator = this.selectedItems.getKeyCollection().iterator();
  var vnIdx = null;

  if(voIterator.hasNext()){
    vnIdx = voIterator.next();

    if(vnIdx == this.selectedIndex)
      vnIdx = voIterator.collection[voIterator.collection.length-1];
  }

  return vnIdx;
};


/**
 * @ignore
 * 기존선택 되어있던 아이템 선택 해제
 */
eXria.controls.xhtml.ComboBox.prototype.unselectListItem = function(poEvent, pbMultiSelectKey){
  var voTr = null;
  var voDiv = null;
  var voInput = null;

  if (this.listarea.multiSelect == false
      || this.listarea.appearance != "normal"
      || (this.listarea.appearance == "normal" && pbMultiSelectKey == false)
      || this.selectedItems.size() == 0) {
    var voTable = this.lookup(this.id + "_listarea_table", this.getComboboxCtrl("document"));
    if (this.listarea.multiSelect == false
        || (this.listarea.appearance == "normal" && pbMultiSelectKey == false)
        || this.selectedItems.size() == 0) {
      this.clearSelected();
//      this.selectedItems.clear();
      if (this.listarea.appearance != "normal") {
        for ( var i = 0; i < voTable.rows.length; i++) {
          voDiv = voTable.rows[i].cells[0].childNodes[0];
          voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
          voInput.checked = false;
        }
      }
    }
    this.nonSelectedRestoreColor(voTable);
  }

};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.reloadData = function(poCtrl,
    poDocument) {
  this.loadData(poDocument);
  this.loadComplete(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.refreshData = function(poCtrl, poDocument) {
  if(poDocument == null) poDocument = this.document;
  if(poCtrl == null) poCtrl = this.ctrl;
  this.refreshTemplate(poCtrl, poDocument);
  this.refreshSpecificAttrs(poCtrl, poDocument);
  this.reloadData(poCtrl, poDocument);
};

/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.setInputHeight = function(poCtrl) {
  var voInput = this.subElement.input;
  var vsText = voInput.value;
  var voSpan = this.subElement.span;
  voSpan.innerHTML = "&nbsp;";
//  if (vsText == "") voSpan.innerHTML = "&nbsp;";
//  else voSpan.innerHTML = vsText;


  var vnHeight = voSpan.offsetHeight;
  this.setAttrCtrl("height", vnHeight, voInput);

};

/**
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.setInputWidth = function() {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement.input;
  var vnPaddingLeft = parseInt(this.getStyleCurrentValue(voSubElement, "padding-left", "paddingLeft"), 10);
  var vnPaddingRight = parseInt(this.getStyleCurrentValue(voSubElement, "padding-right", "paddingRight"), 10);
  var vnBorderLeft = parseInt(this.getStyleCurrentValue(voCtrl, "border-left-width", "borderLeftWidth"), 10);
  var vnBorderRight = parseInt(this.getStyleCurrentValue(voCtrl, "border-right-width", "borderRightWidth"), 10);
  vnPaddingLeft = vnPaddingLeft == null ? 0 : vnPaddingLeft;
  vnPaddingRight = vnPaddingRight == null ? 0 : vnPaddingRight;
  vnBorderLeft = vnBorderLeft == null ? 0 : vnBorderLeft;
  vnBorderRight = vnBorderRight == null ? 0 : vnBorderRight;
  var vnWidth = voCtrl.offsetWidth - vnBorderLeft - vnBorderRight - 1;
  vnWidth = vnWidth - (vnPaddingLeft + vnPaddingRight);
  if(vnWidth < 0) vnWidth = 0;
  if(this.btnWidth) vnWidth = vnWidth - this.btnWidth;
  this.setAttrCtrl("left", vnPaddingLeft, voSubElement);
  this.setAttrCtrl("width", vnWidth, voSubElement);
  this.setAttrCtrl("paddingLeft", "0px", voSubElement);
  this.setAttrCtrl("paddingRight", "1px", voSubElement);
};

/**
 * 컨트롤 텍스트 수직정렬 재설정.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.refreshVerticalAlign = function() {
  var voCtrl = this.ctrl;
  if (voCtrl == null)
    return;
  var voDf = this.df;
  var voInput = this.getSubCtrl("input", voCtrl);
  this.setInputHeight();
  this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
};

/**
 * combobox가 속한 page 객체, dom 객체 가져오는 메서드.
 */
eXria.controls.xhtml.ComboBox.prototype.getComboboxCtrl = function(poDiv) {
  var vbSpbFlag = false;
  var voCanvasCtrl = null;
  var vsReferrer = null;
  var vsFrameId = null;
  var voTarget = this;
  var voPage = voTarget.canvas.page;
  
  if(voTarget.window.frameElement) vsFrameId = voTarget.window.frameElement.id;
  while(voPage){
    if(voPage.getPage)  if(!!voPage.getPage(vsFrameId)) vbSpbFlag = true;
    if(vbSpbFlag) {
      vsReferrer = this.document.referrer;
      break;
    }else {
      vsReferrer = this.document.location.pathname;
      if(!voPage.parent? false : voPage.id == voPage.parent.id) break;
      else voPage = voPage.parent;
    }
  }
  if(!vsReferrer) vsReferrer = this.document.location.pathname;
  var vsMainPage = vsReferrer.substring(vsReferrer.lastIndexOf("/")+1, (vsReferrer.length-4));
  voPage = voTarget.canvas.page;
  
  while(voPage.parent) {
    if(voPage.id.indexOf(vsMainPage) > -1)  break;
    voPage = voPage.parent;
  }
  if(poDiv == "document") voCanvasCtrl = voPage.canvas.ctrl.parentNode.ownerDocument;
  else voCanvasCtrl = voPage.canvas.ctrl.parentNode;
  return voCanvasCtrl;
};

/**
 * 드롭다운 리스트 표시 여부 설정 메소드.
 * @param {Boolean} pbShow 리스트 표시 여부 설정
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.showList = function(pbShow, poDocument) {
  var voDf = this.df;
  var voCanvas = this.canvas;
  var voCtrl = this.getCtrl(poDocument);
  var voList = this.subElement.list;
  var voBtn = this.subElement.btn;
  var voStyle = null;
  var voCanvasCtrl = this.getComboboxCtrl();
  var voPage = this.getComboboxCtrl();
  this.eventType = null;
  this.eventObject = null;
//  if(pbShow == false) {
  this.focusedItemCtrl = null;
//  }

  if(voCanvas.collapseControl && voCanvas.collapseControl.id != this.id) {
    voCanvas.doCollapseControl(voCanvas);
  }
  if(voList != null) {
    voStyle = voList.style;
    var voParent = null;
    var vnZIndex = null;
    if(pbShow == true) {
      voStyle.display = "block";
      this.setAttrCtrl("zIndex", 50000, voCtrl);
      voParent = this.parent;
      while(voParent) {
        if(voParent.ctrl) this.setAttrCtrl("zIndex", 50000, voParent.ctrl);
        voParent = voParent.parent;
      }
      this.listShowed = true;
      voCanvas.collapseControl = this;
    } else if(pbShow == false) {
      voStyle.display = "none";
      //this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
      //2010.05.07
      //this.zIndex가 doCollapseControl 을 타고 올경우
      //null이 되므로 null 처리 추가
      this.setAttrCtrl("zIndex", this.zIndex === null ? 0: this.zIndex, voCtrl);

      voParent = this.parent;
      while(voParent) {
        if(voParent.ctrl) {
          vnZIndex = voParent.zIndex == null ? 0 : voParent.zIndex;
          this.setAttrCtrl("zIndex", vnZIndex, voParent.ctrl);
        }
        voParent = voParent.parent;
      }
      this.listShowed = false;
      voCanvas.collapseControl = null;
      this.clearListArea();
    } else {
      if(voStyle.display == "none") {
        voStyle.display = "block";
        this.setAttrCtrl("zIndex", 50000, voCtrl);
        //listarea zindex 부여
        voStyle.zIndex = 50000;
        voParent = this.parent;
        while(voParent) {
          if(voParent.ctrl) this.setAttrCtrl("zIndex", 50000, voParent.ctrl);
          voParent = voParent.parent;
        }
        this.listShowed = true;
        voCanvas.collapseControl = this;
      } else {
        voStyle.display = "none";
        this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
        var voParent = this.parent;
        while(voParent) {
          if(voParent.ctrl) {
            vnZIndex = voParent.zIndex == null ? 0 : voParent.zIndex;
            this.setAttrCtrl("zIndex", vnZIndex, voParent.ctrl);
          }
          voParent = voParent.parent;
        }
        this.listShowed = false;
        voCanvas.collapseControl = this;
      }
    }
    if(pbShow == true || voStyle.display == "block"){
      var voTarget = this;
      var voFrameElement = voTarget.window.frameElement;
      var vnLeft = null;
      var vnTop = null;
      var vsMainPage = "";
      var vsSrc = "";
      if(!!voFrameElement && voFrameElement.id.indexOf("sbp") > -1){
        vsMainPage = voFrameElement.src;
        vsSrc = vsMainPage.substring(vsMainPage.lastIndexOf("/")+1, (vsMainPage.length-4));
        if(vsSrc.indexOf(".xrf") > -1){
          vsSrc = vsSrc.substr(0, vsSrc.indexOf(".xrf"));
        }
        vsSrc = vsSrc+"_canvas";
        
        if(vsSrc != voPage.id){
          while(voFrameElement.id){
            if(!isNaN(voFrameElement.offsetTop)) vnTop = vnTop + voFrameElement.offsetTop;
            if(!isNaN(voFrameElement.offsetLeft)) vnLeft = vnLeft + voFrameElement.offsetLeft;
            voFrameElement = voFrameElement.parentNode;
          }
        }
      }
      
      if(!!voTarget.ctrl.parentNode) {
        var voParentCtl = voTarget.ctrl.parentNode;
        vnTop = vnTop + voTarget.height + voTarget.top + voTarget.borderTopWidth;
        vnLeft = vnLeft + voTarget.left + voTarget.borderLeftWidth;
        
        if(!!voFrameElement && voFrameElement.id.indexOf("sbp") > -1){
          vnTop = vnTop + voFrameElement.offsetTop;
          vnLeft = vnLeft + voFrameElement.offsetLeft;
        }
        
        while(voParentCtl.parentNode.id){
          if(!isNaN(voParentCtl.offsetTop)) vnTop = vnTop + voParentCtl.offsetTop;
          if(!isNaN(voParentCtl.offsetLeft)) vnLeft = vnLeft + voParentCtl.offsetLeft;
          voParentCtl = voParentCtl.parentNode;
        }
      }else{
        vnLeft = this.left;
        vnTop = this.top;
      }
      
      voList.style.top = vnTop + "px";
      voList.style.left = vnLeft + "px";
      
      var voParent = this.canvas;
      var vnParentTop = voPage.offsetHeight;
    
    //  if(this.parent && this.parent.overflow != "visible") { voParent = this.parent; }
    //  if(this.parent) {
    //    var vbVisible = this.getStyleCurrentValue(this.parent.ctrl, "overflow", "overflow");
    //    if(this.parent.overflow != null)
    //    vbVisible = this.parent.overflow;
    //    if(vbVisible != "visible") {
    //      voParent = this.parent;
    //      vnParentTop = voParent.top + voParent.height;
    //    }
    //  }
      //listdirection 값 top,bottom,auto 일때 위치값 수정
      if(this.listDirection == "top"){
        voList.style.top = (parseInt(voList.style.top) - (this.borderTopWidth + this.height + parseInt(voList.style.height))) + "px";
      }
      else if(this.listDirection == "bottom"){
        voList.style.top = vnTop;
      }
//      else {
//        if((vnTop + this.height + voList.offsetHeight) > vnParentTop){
//          voList.style.top = (parseInt(voList.style.top) - (this.borderTopWidth + this.height + parseInt(voList.style.height))) + "px";
//        }
//        if((this.left + voList.offsetWidth) > voParent.width) {
//          voList.style.top = vnTop;
//        }
//        if(!!this.maxCanvasWidth) {
//          if((this.left + voList.offsetWidth) > this.maxCanvasWidth) {
//            voList.style.top = (parseInt(voList.style.top) - (this.borderTopWidth + this.height + parseInt(voList.style.height))) + "px";
//          }
//        }
//      }  
      voCanvasCtrl.appendChild(voList);
    }
  }
//to-do  
  if(voStyle.display == "block") {
//    if(this.bReloadList) {
//      this.refreshList(poDocument);
//    }
    var voTable = this.subElement.table;
    var voDiv = null;
    for(var i = 0; i < voTable.rows.length; i++) {
      voDiv = voTable.rows[i].cells[0].childNodes[0];
      this.restoreRowColor(voDiv);
    }

    var voIterator = this.selectedItems.getKeyCollection().iterator();
    var vnIndex = -1;
    while(voIterator.hasNext()) {
      vnIndex = voIterator.next();
      voDiv = voTable.rows[vnIndex].cells[0].childNodes[0];
      this.changeRowColor(voDiv);
    }
    if(vnIndex != null) {
      var voItemGroupDf = this.itemgroup;
      var vnScrollTop = vnIndex * voItemGroupDf.height;
      voList.scrollTop = vnScrollTop;
    }
    if(this.collapseImage) {
      this.setAttrCtrl("backgroundImage", this.collapseImage, voBtn);
      voBtn["value"] = "";
    } else {
      this.setAttrCtrl("backgroundImage", "", voBtn);
      voBtn["value"] = "▲";
    }
  } else {
    if(this.expandImage) {
      this.setAttrCtrl("backgroundImage", this.expandImage, voBtn);
      voBtn["value"] = "";
    } else {
      this.setAttrCtrl("backgroundImage", "", voBtn);
      voBtn["value"] = "▼";
    }
  }
//  var vnListWidth = this.innerWidth - parseInt(this.listarea.df.borderLeftWidth) - parseInt(this.listarea.df.borderRightWidth) - 2 * this.listarea.df.cellSpacing;
  var vnListWidth = this.innerWidth - 2 * this.listarea.cellSpacing;

  if(vnListWidth < this.innerWidth) vnListWidth = this.innerWidth;  //2009-03-10 ehj
  var vnOffsetWidth = 0;

  // 2009.08.24 yhkim
  if(this.isScrolled())
    this.scrolled = true;
  else
    this.scrolled = false;

  if(this.scrolled) {
    vnListWidth = vnListWidth - this.listarea.scrollbarWidth;
  }

  voTable = this.subElement.table;

  if(this.listarea.widthByMaxLength){//아이템 길이에 따라 listarea가 변하는 경우
    for(var j = 0; j < voTable.rows.length; j++) {
      voDiv = voTable.rows[j].cells[0].childNodes[0];
      voOption = voDiv.childNodes[0];
  //    if(voOption.offsetWidth > vnListWidth) vnListWidth = voOption.offsetWidth;
  //  }

    //2009-03-10 ehj
      vnOffsetWidth = voOption.offsetWidth + 2 * this.listarea.cellSpacing;
       // 2009.08.24 yhkim
      if(this.scrolled)
        vnOffsetWidth = vnOffsetWidth - this.listarea.scrollbarWidth;
      if(vnOffsetWidth > vnListWidth) vnListWidth = vnOffsetWidth;
    }
  }else{//아이템 길이에 따라 listarea가 변하지 않는 경우
    //TODO
  }

   // 2009.08.24 yhkim
   if(this.scrolled == true) {
    this.subElement.list.style.overflowY = "auto";
    voTable.style.width = vnListWidth + "px";
    voList.style.width = (vnListWidth + this.listarea.scrollbarWidth) + "px";
  } else {
    this.subElement.list.style.overflowY = "hidden";
    voTable.style.width = vnListWidth + "px";
    voList.style.width = vnListWidth + "px";
  }
  
};
/**
 * listarea의 가로길이 설정
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.setListWidth = function() {
  var voTable = this.subElement.table;
  if (this.isScrolled()) {
    voTable.style.width = (this.innerWidth - this.listarea.scrollbarWidth)
        + "px";
  } else {
    voTable.style.width = this.innerWidth + "px";
  }
};
/**
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.getOffsetWidth = function() {
  var vnListWidth = this.subElement.list.style.width;
  voTable = this.subElement.table;

  for ( var j = 0; j < voTable.rows.length; j++) {
    voDiv = voTable.rows[j].cells[0].childNodes[0];
    vsOption = voDiv.childNodes[0];
    if (vsOption.offsetWidth > vnListWidth)
      vnListWidth = vsOption.offsetWidth;
  }

  return parseInt(vnListWidth);
};
/**
 * 드롭다운 버튼에 click 이벤트 발생 메소드.
 * @param {HTMLInput(button)} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.click = function(poDocument) {
  this.lookup(this.id + "_btn", poDocument).click();
};
/**
 * itemset에 아이템 추가 메소드.
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ComboItem
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.addToItemset = function(psName,
    poValue, poDocument) {
  var voComboItem = new eXria.controls.xhtml.ComboItem(psName, poValue, this);
  this.itemset.put(poValue, voComboItem);
  return voComboItem;
};
/**
 * frontItems혹은 backItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psType 아이템 타입
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ComboItem
 * @example addItem("front", "라벨명", "value", 3);
 */
eXria.controls.xhtml.ComboBox.prototype.addItem = function(psType, psName,
    poValue, pnIndex, poDocument) {
  var voComboItem = new eXria.controls.xhtml.ComboItem(psName, poValue, this);
  var voItems = null;
  if (psType == "front")
    voItems = this.frontItems;
  else
    voItems = this.backItems;

  if (pnIndex == null) {
    voItems.put(poValue, voComboItem);
  } else {
    var voNewItems = new eXria.data.ArrayMap();
    var vnIndex = 0;
    var voIterator = voItems.getKeyCollection().iterator();
    var vsKey = null;
    while (voIterator.hasNext()) {
      if (vnIndex == pnIndex)
        voNewItems.put(poValue, voComboItem);
      vsKey = voIterator.next();
      voNewItems.put(vsKey, voItems.get(vsKey));
      vnIndex++;
    }
    if (psType == "front")
      this.frontItems = voNewItems;
    else
      this.backItems = voNewItems;
  }

  // var voCtrl = this.getCtrl(poDocument);
  // if(voCtrl != null) {
  // voComboItem.create(poDocument);
  // }

  return voComboItem;
};
/**
 * frontItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ComboItem
 * @example addItemFront("라벨명", "value", 3);
 */
eXria.controls.xhtml.ComboBox.prototype.addItemFront = function(psName,
    poValue, pnIndex, poDocument) {
  var voItem = this.addItem("front", psName, poValue, pnIndex, poDocument);
  return voItem;
};
/**
 * backItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ComboItem
 * @example addItemBack("라벨명", "value", 3);
 */
eXria.controls.xhtml.ComboBox.prototype.addItemBack = function(psName, poValue,
    pnIndex, poDocument) {
  var voItem = this.addItem("back", psName, poValue, pnIndex, poDocument);
  return voItem;
};
/**
 * 지정된 인덱스에 해당하는 아이템 반환.
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @return 인덱스에 해당하는 아이템
 * @type eXria.controls.xhtml.ComboItem
 */
eXria.controls.xhtml.ComboBox.prototype.getItem = function(pnIndex) {
//  var voIterator = null;
//  var vnIndex = 0;
//  var voItem = null;
//
//  voIterator = this.frontItems.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.visible == false)
//      continue;
//    if (pnIndex == vnIndex)
//      return voItem;
//    vnIndex++;
//  }
//  voIterator = this.itemset.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.visible == false)
//      continue;
//    if (pnIndex == vnIndex)
//      return voItem;
//    vnIndex++;
//  }
//  voIterator = this.backItems.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.visible == false)
//      continue;
//    if (pnIndex == vnIndex)
//      return voItem;
//    vnIndex++;
//  }
//
//  return null;
    return this.itemIdxMap[pnIndex];
};
/**
 * @param {String} psName 아이템 라벨 문자.
 * @return 지정된 라벨에 해당하는 아이템
 * @type eXria.controls.xhtml.ComboItem
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.getItemByName = function(psName) {
//  var voItems = null;
//  var voItem = null;
//  var voRet = null;
//  var vbBreak = false;
//  var vaItems = [ this.frontItems, this.itemset, this.backItems ];
//  for ( var i = 0; i < vaItems.length; i++) {
//    voItems = vaItems[i];
//    for ( var j = 0; j < voItems.size(); j++) {
//      voItem = voItems.get(j);
//      if (voItem.name == psName) {
//        voRet = voItem;
//        vbBreak = true;
//        break;
//      }
//    }
//    if (vbBreak)
//      break;
//  }
//
//  return voRet;
    return this.itemNmMap[psName];
};
/**
 * @param {String} psId 아이템 라벨 문자.
 * @return 지정된 라벨에 해당하는 아이템
 * @type eXria.controls.xhtml.ComboItem
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.getItemById = function(psId) {
//  var voIterator = null;
//  var voItem = null;
//
//  voIterator = this.frontItems.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.visible == false)
//      continue;
//    if (voItem.id == psId)
//      return voItem;
//
//  }
//  voIterator = this.itemset.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.visible == false)
//      continue;
//    if (voItem.id == psId)
//      return voItem;
//  }
//  voIterator = this.backItems.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.visible == false)
//      continue;
//    if (voItem.id == psId)
//      return voItem;
//  }
//
//  return null;
    return this.itemIdMap[psId];
};
/**
 * 지정된 값을 포함한 아이템 얻어오기 위한 메소드
 * @param {String} psValue 검색할 값
 * @return 지정된 값을 포함한 아이템
 * @type eXria.controls.xhtml.ComboItem
 */
eXria.controls.xhtml.ComboBox.prototype.getItemByVal = function(psValue) {
//  var voItem = null;
//  var voIterator = this.frontItems.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.value == psValue)
//      return voItem;
//  }
//  voIterator = this.itemset.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.value == psValue)
//      return voItem;
//  }
//  voIterator = this.backItems.getValueCollection().iterator();
//  while (voIterator.hasNext()) {
//    voItem = voIterator.next();
//    if (voItem.value == psValue)
//      return voItem;
//  }
//  return null;
    return this.itemValMap[psValue];
};
/**
 * checkSelected
 * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 성공여부
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.checkSelected = function(poCtrl,
    poDocument) {
  var voCtrl = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  var vaIndex = [];
  var i = -1;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    i++;
    if (voItem.selected == true)
      vaIndex.push(i);
    else
      this.restoreRowColorByIndex(i);
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    i++;
    if (voItem.selected == true)
      vaIndex.push(i);
    else
      this.restoreRowColorByIndex(i);
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    i++;
    if (voItem.selected == true)
      vaIndex.push(i);
    else
      this.restoreRowColorByIndex(i);
  }

//2009-04-03 hajubal 한개남은 체크박스 해제시 해제 안되는 문제 때문에 주석처리
//  if (vaIndex.length == 0 && this.df.selectedIndex != -1) {
//    if (this.getVisibleItemCount() > this.df.selectedIndex)
//      vaIndex.push(this.df.selectedIndex);
//  }
  this.listarea.select(vaIndex, poCtrl, poDocument);

  if (vaIndex.length > 0)
    return true;
  return false;
};
/**
 * 리스트 영역의 스크롤 버튼이 표시되었는지 여부 반환.
 * @return 리스트 영역의 스크롤 버튼이 표시되었는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.ComboBox.prototype.isScrolled = function() {
  var vbScrolled = false;
  var voListAreaDf = this.listarea;
  if (voListAreaDf.overflow == "scroll")
    return true;
  if (voListAreaDf.overflow == "hidden")
    return false;
  var vnSize = this.getVisibleItemCount();
  if (voListAreaDf.heightBySize) {
    if (voListAreaDf.size != null && voListAreaDf.size < vnSize)
      vbScrolled = true;
  } else {
    var vnListHeight = (this.itemgroup.height + voListAreaDf.cellSpacing)
        * vnSize;
    if (vnListHeight)
      vnListHeight += voListAreaDf.cellSpacing;
    var vnHeight = voListAreaDf.height - voListAreaDf.borderTopWidth
        - voListAreaDf.borderBottomWidth;
    if (vnHeight < 0)
      vnHeight = 0;
    if (vnHeight < vnListHeight)
      vbScrolled = true;
  }

  return vbScrolled;
};
/**
 * 리스트 아이템 제거.
 * @param {String} psVal 아이템 값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.removeItem = function(psVal,
    poDocument) {
  var vnIdx = this.listarea.getIndexByVal(psVal);
  this.bReloadList = true;
  this.frontItems.remove(psVal);
  this.itemset.remove(psVal);
  this.backItems.remove(psVal);
  this.selectedItems.remove(vnIdx);
//  var voList = this.subElement.list;
//  var voStyle = voList.style;
//  if (voStyle.display != "none") {
    this.refreshList(poDocument);
//  }
};
/**
 * 모든 리스트 아이템 제거.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.removeAll = function(poDocument) {
  this.bReloadList = true;
  this.frontItems.clear();
  this.itemset.clear();
  this.backItems.clear();
  // var voList = this.subElement.list;
  // var voStyle = voList.style;
  // if(voStyle.display != "none") {
  this.refreshList(poDocument);
  // }
};
/**
 * clearSelected
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.clearSelected = function() {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voComboItem = null;
  while (voIterator.hasNext()) {
    voComboItem = voIterator.next();
    voComboItem.selected = false;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voComboItem = voIterator.next();
    voComboItem.selected = false;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voComboItem = voIterator.next();
    voComboItem.selected = false;
  }
  this.selectedItems.clear();
};
/**
 * 리스트 영역 새로 고침.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.refreshList = function(poCtrl,
    poDocument) {
  this.repaint(poDocument);
};
/**
 * 리스트 영역 innerHTML 반환.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 영역 innerHTML
 * @type String
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.getListInnerHTML = function(poCtrl, poDocument) {
  var voDf = this.df;
  this.bScrolled = false;
  this.oldMultiselect = this.multiSelect;
  this.oldAppearance = this.apprearance;

  if (this.apprearance == "radio") {
    this.multiSelect = false;
  }

  var vaStrBuf = [];
  var vsKey = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voListItem = null;
  this.itemIdxMap = {};
  this.itemNmMap = {};
  this.itemValMap = {};
  this.itemIdMap = {};
  var vnIdx = 0;
  var vaValue = [];
  if(this.value instanceof Array) vaValue = this.value;
  else vaValue.push(this.value);
  while (voIterator.hasNext()) {
    voListItem = voIterator.next();
    if (voListItem.visible == false)
      continue;
    this.itemIdxMap[vnIdx++] = voListItem;
    this.itemNmMap[voListItem.name] = voListItem;
    this.itemValMap[voListItem.value] = voListItem;
    vaStrBuf.push(voListItem.getInnerHTML());
    this.itemIdMap[voListItem.id] = voListItem;
    for ( var j = 0; j < vaValue.length; j++) {
      if (vaValue[j] == voListItem.value) {
        voListItem.selected = true;
        break;
      }
    }
  }

  if(this.seqNum !== vnIdx) this.seqNum = vnIdx;

  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voListItem = voIterator.next();
    if (voListItem.visible == false)
      continue;
    this.itemIdxMap[vnIdx++] = voListItem;
    this.itemNmMap[voListItem.name] = voListItem;
    this.itemValMap[voListItem.value] = voListItem;
    vaStrBuf.push(voListItem.getInnerHTML());
    this.itemIdMap[voListItem.id] = voListItem;
    for ( var j = 0; j < vaValue.length; j++) {
      if (vaValue[j] == voListItem.value) {
        voListItem.selected = true;
        break;
      }
    }
  }

  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voListItem = voIterator.next();
    if (voListItem.visible == false)
      continue;
    this.itemIdxMap[vnIdx++] = voListItem;
    this.itemNmMap[voListItem.name] = voListItem;
    this.itemValMap[voListItem.value] = voListItem;
    vaStrBuf.push(voListItem.getInnerHTML());
    this.itemIdMap[voListItem.id] = voListItem;
    for ( var j = 0; j < vaValue.length; j++) {
      if (vaValue[j] == voListItem.value) {
        voListItem.selected = true;
        break;
      }
    }
  }
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;

  return vsRet;

};
/**
 * 아이템의 배경 색상 변경.
 * @param {HTMLDiv} poDiv 아이템의 실체화 객체
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.changeRowColor = function(poDiv) {
  var voTable = this.subElement.table;
//  alert(this.listarea.focusBackgroundColor + "\n" + this.listarea.focusColor, voTable);
  this.setAttrCtrl("backgroundColor", this.listarea.focusBackgroundColor,  poDiv);
  // yhkim 2009.09.04
  //this.setAttrCtrl("color", this.listarea.focusColor, voTable);
  this.setAttrCtrl("color", this.listarea.focusColor, poDiv);
};

/**
 * 아이템의 배경 색상 변경.
 * @param {HTMLDiv} pnIndex 아이템의 인덱스
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.changeRowColorByIndex = function(pnIndex) {
  var voDiv = null;
  var voTable = this.lookup(this.id + "_listarea_table", this.getComboboxCtrl("document"));

  voDiv = voTable.rows[pnIndex].cells[0].childNodes[0];

  this.changeRowColor(voDiv);
};

/**
 * 변경된 아이템의 색상을 원래대로 되돌림.
 * @param {HTMLDiv} pnIndex 아이템의 인덱스
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.restoreRowColorByIndex = function(pnIndex) {
  var voDiv = null;
//  var voTable = this.lookup(this.id + "_listarea_table");
  var voTable = this.subElement.table;
  if(voTable.rows.length == 0) return;
  var voRowCtrl = voTable.rows[pnIndex];
  if(voRowCtrl) {
    voDiv = voRowCtrl.cells[0].childNodes[0];
    this.restoreRowColor(voDiv);
  }
};
/**
 * 변경된 아이템의 색상을 원래대로 되돌림.
 * @param {HTMLDiv} poDiv 아이템의 실체화 객체
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.restoreRowColor = function(poDiv) {
  var voTable = this.subElement.table;
  if(this.listarea.backgroundColor) this.setAttrCtrl("backgroundColor", this.listarea.backgroundColor, poDiv);
  else this.setAttrCtrl("backgroundColor", "", poDiv);
  // yhkim 2009.09.04
  //if(this.listarea.color) this.setAttrCtrl("color", this.listarea.color, voTable);
  //else this.setAttrCtrl("color", "", voTable);
  if(this.listarea.color) this.setAttrCtrl("color", this.listarea.color, poDiv);
  else this.setAttrCtrl("color", "", poDiv);
};

/**
 * 선택된 아이템을 제외한 변경된 아이템의 색상을 원래대로 되돌림.
 * @param {HTMLTable} poTable
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.nonSelectedRestoreColor = function(poTable){
  var voData = null;
  var voDiv = null;
  var voCollection = this.selectedItems.getKeyCollection()
  var vnLoop01 = poTable.rows.length;
  var vnLoop02 = voCollection.size();
  var vnIndex = null;
  var voItem = null;
  for ( var i = 0; i < vnLoop01; i++) {
    voDiv = poTable.rows[i].cells[0].childNodes[0];

    var vbSelected = false;

    for( var j = 0; j < vnLoop02; j++) {
      vnIndex = voCollection.get(j)
      voItem = this.getItem(vnIndex);

      if (voItem.id == voDiv.id) {
        vbSelected = true;
        break;
      }
    }

    if (!vbSelected) this.restoreRowColor(voDiv);
  }

};
/**
 * 선택된 리스트 아이템 값 반환.
 * @param {Boolean} pbUpdateText 텍스트 박스 갱신여부
 * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 선택된 리스트 아이템 값
 * @type String|Array(String)
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.getSelectedValue = function(
    pbUpdateText, poCtrl, poDocument) {
  if (poCtrl == null)
    poCtrl = this.getCtrl(poDocument);
  var voSbLabel = new eXria.lang.StringBuilder();
  var vnIndex = null;
  var vsLabel = null;
  var vaValue = [];

  var voIterator = this.selectedItems.getKeyCollection().iterator();
  var voComboItem = null;
  while (voIterator.hasNext()) {
    vnIndex = voIterator.next();
    voComboItem = this.getItem(vnIndex);
    //voSbLabel.append(eXria.controls.xhtml.Util.parseLang(voComboItem.name));
    voSbLabel.append(voComboItem.name);
    voSbLabel.append(";");
    vaValue.push(voComboItem.value);
  }

  vsLabel = voSbLabel.toString();
  if (vsLabel.lastIndexOf(";") == vsLabel.length - 1) {
    vsLabel = vsLabel.substring(0, vsLabel.length - 1);
  }
  if (pbUpdateText) {
    var voText = this.subElement.input;
    voText.value = vsLabel;
  }

  if (vaValue.length > 1)
    return vaValue;
  else
    return vaValue[0];
};
/**
 * 선택된 리스트 아이템들을 반환.
 * @return 선택된 리스트 아이템 배열
 * @type Array(eXria.controls.xhtml.ComboItem)
 */
eXria.controls.xhtml.ComboBox.prototype.getSelectedItems = function() {
  var vnIndex = null;
  var vaItem = [];

  var voIterator = this.selectedItems.getKeyCollection().iterator();
  var voListItem = null;
  while (voIterator.hasNext()) {
    vnIndex = voIterator.next();
    voListItem = this.getItem(vnIndex);
    vaItem.push(voListItem);
  }

  return vaItem;
};

/**
 * 선택된 리스트 아이템들을 반환.
 * @return 선택된 리스트 아이템 index
 * @type Array(eXria.controls.xhtml.ComboItem)
 */
eXria.controls.xhtml.ComboBox.prototype.getSelectedIndexes = function() {
  var vnIndex = null;
  var vaItem = [];

  var voIterator = this.selectedItems.getKeyCollection().iterator();
  var voListItem = null;
  while (voIterator.hasNext()) {
    vnIndex = voIterator.next();
    vaItem.push(vnIndex);
  }
  return vaItem;
};


/**
 *
 * @param e
 * @return
 * @private
 */
eXria.controls.xhtml.ComboBox.prototype.finalkeydown = function(e){

  var voEvent = new eXria.event.Event(e, this.window);
  var vnKeyCode = e.keyCode;

  if(vnKeyCode == '38' || vnKeyCode == '40' ||vnKeyCode == '16' || vnKeyCode == '17')//화살표 위, 아래, shift, ctrl
    voEvent.stopEvent();
};

/**
 * 텍스트 박스에 텍스트 입력 시 아이템 리스트에 입력된 값과 일치하는 아이템이 있는지를 체크. Firefox에서는 텍스트 박스에서 포커스
 * out시에도 이벤트가 발생함.
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.atkeyup = function(e) {
  if(e.target != this.subElement.input) return;
  var vnKeyCode = e.keyCode;

  if(vnKeyCode == '16' || vnKeyCode == '17'){
    this.bMultiSelectKeyDown = false;
    return;
  }
  if(vnKeyCode == '38' || vnKeyCode == '40')//화살표 위, 아래
    return;
  if(vnKeyCode == '13' && this.isCallByItemEnter) {
    this.isCallByItemEnter = false;
    return;
  }

  // vnKeyCode == 229 조건에 Firefox에서는 텍스트 박스에서 포커스 out에 대한 체크
  if (vnKeyCode == 229 || vnKeyCode == this.constKey["CTRL"]
      || vnKeyCode == this.constKey["TAB"]) {
    return;
  }
  var voText = this.subElement.input;

  if (voText.value == this.oldText || this.readOnly == true)
    return;

  this.oldText = voText.value;
  this.isChanged = true;
//  this.selectedItems.clear();
//  this.selectedIndex = -1;

  var vsOption = null;
  var voTable = null;
  var voDiv = null;
  var vsText = null;
  var voTable = this.subElement.table;
  var voList = this.subElement.list;
  var vnItemHeight = this.itemgroup.height;
  // 옵션리스트의 diaplay가 none이 아니여야지만 옵션리스트의 하위 옵션리스트테이블이 lookup가능
  this.focusedItemCtrl = null;
  for ( var j = 0; j < voTable.rows.length; j++) {
    voDiv = voTable.rows[j].cells[0].childNodes[0];
    if(!voDiv.childNodes[0].rows[0].cells[0].lastChild) continue;

    vsOption = voDiv.childNodes[0].rows[0].cells[0].lastChild.data;
    if (voText.value.length > 0 && vsOption.indexOf(voText.value) != -1) {
//      if(this.selectedIndex == -1) {
//        this.selectedIndex = vsOption.indexOf(voText.value);
//      }
      this.isCallByKeyIn = true;
      this.showList(true);

      var vbDeselected = true; // 한 번의 loop문 사용으로 row 색상의 변경과 복원을 수행하기 위한 플래그 값
      voTable = this.lookup(this.id + "_listarea_table", this.getComboboxCtrl("document"));
      for ( var i = 0; i < voTable.rows.length; i++) {
        voDiv = voTable.rows[i].cells[0].childNodes[0];
        if(!voDiv.childNodes[0].rows[0].cells[0].lastChild) continue;
        vsText = voDiv.childNodes[0].rows[0].cells[0].lastChild.data;
        this.restoreRowColor(voDiv);
        if (vbDeselected && vsText == vsOption) {
          this.changeRowColor(voDiv);
          this.focusedItemCtrl = voDiv;
          vbDeselected = false;
          voList.scrollTop = i * vnItemHeight;
        }
      }
      return;
    }
  }
  var voTd = null;
  for ( var i = 0; i < voTable.rows.length; i++) {
    voTd = voTable.rows[i].cells[0];
    this.restoreRowColor(voTd);
  }
  this.focused = false;
  this.showList(false);
};
/**
 * 텍스트를 선택상태로 만들어주는 메소드
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.selectText = function() {
  var voCtrl = this.getCtrl();
  var voInput = this.getSubCtrl("input", voCtrl);
  var vnPos = voInput.value.length;
  if (vnPos == 0) {
    // voInput.focus();
  } else {
    if (voInput.createTextRange) {
      var range = voInput.createTextRange();
      range.collapse(true);
      range.moveEnd('character', vnPos);
      range.moveStart('character', 0);
      range.select();
    } else if (voInput.selectionEnd) {
      voInput.selectionStart = 0;
      voInput.selectionEnd = vnPos;
    }
  }
};
/**
 * 컨트롤에 값을 설정.
 * @param {String} psValue 설정될 값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.setValue = function(psValue, poDocument) {
  this.isChanged = false;
  var voDf = this.df;
  var vaValue = [];
  var vaItemVal = this.getItemByVal(psValue);
  if(vaItemVal){
    var voEvent = new eXria.event.Event(null, this.window);
    voEvent.object = vaItemVal;
    voEvent.objectType = "item";
    if(this.getItemByVal(this.value) != this.getItemByVal(psValue)) this.doitemchange(voEvent, this);
  }
  this.selectedIndex = -1;
  if (psValue instanceof Array) {
    vaValue = psValue
  } else {
    if (psValue != null) vaValue.push(psValue);
  }
  var vsOldVal = this.value;
  if(vsOldVal instanceof Array) vsOldVal = vsOldVal.join();
  var vsNewVal = vaValue.join();
  if(vsOldVal != vsNewVal) {
    this.value = vaValue;
    this.data.setData(psValue);
    this.reloadData(null, poDocument);
  }
};

/**
 * 텍스트 영역을 빈 문자열로 초기화.
 * @param {HTMLDocument} poDocument 윈도우 document 객체
 * @return void
 * @type void
 */
eXria.controls.xhtml.ComboBox.prototype.clearText = function(poDocument) {
  var voText = this.subElement.input;
  voText.value = "";
};
/**
 * 컨트롤에 설정된 값을 반환.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 컨트롤 value 속성 값.
 * @type String
 */
eXria.controls.xhtml.ComboBox.prototype.getValue = function(poDocument) {
  return this.value;
};

/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 해당 속성명의 디폴트 속성 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.ComboBox.prototype.getSpecificDefaultValue = function(
    psAttrName) {
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if (vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.ComboBox[psAttrName];
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.ComboBox[vaAttrName[0]][vaAttrName[1]] != null ? eXria.controls.xhtml.Default.ComboBox[vaAttrName[0]][vaAttrName[1]]
        : vsDefaultValue;
  }
  if (vsDefaultValue === undefined) {
    // alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 보여지는 아이템 개수를 반환
 * @return 보여지는 아이템 개수
 * @type Number
 * @public
 */
eXria.controls.xhtml.ComboBox.prototype.getVisibleItemCount = function() {
  var vnCnt = 0;
  var voIterator = null;
  var voItem = null;
  voIterator = this.frontItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    vnCnt++;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    vnCnt++;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    vnCnt++;
  }

  return vnCnt;
};

/**
 * 현재 선택된 Label값을 가져옴
 * @return Label 텍스트
 * @type String
 */
eXria.controls.xhtml.ComboBox.prototype.getText = function() {
  var voCtrl = this.getCtrl();
  var voInput = this.getSubCtrl("input", voCtrl);
  return voInput.value;
};
/**
 * 클래스 명을 반환.
 * @return "ComboBox"
 * @type String
 */
eXria.controls.xhtml.ComboBox.prototype.toString = function() {
  return "ComboBox";
};

/*************************************************
 * ComboBox 확장 메소드
 *************************************************/
/**
 * 콤보박스 컨트롤 필터링(확장메소드)
 * @member eXria.controls.xhtml.ComboBox
 * @param {String} psExpression 필터링 조건식 문자열
 * @type void
 * @example cbbUnitSystem.filterExt("system_id='NGEN'");
 * @author SUL at 12. 11. 28 오후 2:34
 */
eXria.controls.xhtml.ComboBox.prototype.filterExt = function(psExpression) {  
  //필터링 해제를 위한 Original-Path
  if(!this.hasOwnProperty("oldNodesetInstancePath")){
    this.oldNodesetInstancePath = this.data.nodesetInstancePath;
  }
  //필터링
  this.data.setNodesetRef(this.data.nodesetInstanceId, this.oldNodesetInstancePath+"["+psExpression+"]");
  this.refresh();
  
  //첫번째 아이템 자동선택
  if(this.getVisibleItemCount() > 0){
    this.listarea.select([0]);
  }
};

/**
 * 콤보박스에 적용된 필터를 취소한다.
 * @member eXria.controls.xhtml.ComboBox
 * @type void
 * @example cbbUnitSystem.cancleFilterExt();
 * @author SUL at 12. 11. 28 오후 2:35
 */
eXria.controls.xhtml.ComboBox.prototype.cancleFilterExt = function() {  
  if(this.hasOwnProperty("oldNodesetInstancePath")){
    this.data.setNodesetRef(this.data.nodesetInstanceId, this.oldNodesetInstancePath);
  }else{
    this.data.setNodesetRef(this.data.nodesetInstanceId, this.data.nodesetInstancePath);
  }
  this.refresh();
  
  //첫번째 아이템 자동선택
  if(this.getVisibleItemCount() > 0){
    this.listarea.select([0]);
  }
};
