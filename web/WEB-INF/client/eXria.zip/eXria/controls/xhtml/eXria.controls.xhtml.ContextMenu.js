﻿/**
 * @fileoverview
 * Concreate xhtml ContextMenu(XHTML ContextMenu 컨트롤)
 * @author 김경태
 */

/**
 * @class Concreate xhtml ContextMenu
 * XHTML ContextMenu 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표(개발 편의를 위한 좌표)
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표(개발 편의를 위한 좌표)
 * @param {Number} pnWidth 컨트롤의 가로 길이(개발 편의를 위한 좌표)
 * @param {Number} pnHeight 컨트롤의 세로 길이(개발 편의를 위한 좌표)
 * @return 새로운 eXria.controls.xhtml.ContextMenu 객체
 * @type eXria.controls.xhtml.ContextMenu
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.ContextMenu = function(psId, pnLeft, pnTop, pnWidth, pnHeight){
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight); // UIControl을 상속받는다.

  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * DataRef 생성 연결.
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * 전체 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.items = new eXria.data.ArrayMap();
  /**
   * 선택된 아이템.
   * @type Object
   */
  this.selectedItem = null;
  /**
   * 컨텍스트 메뉴를 활성화시킨 컨트롤.
   * @type String
   */
  this.baseControlId = null;
  /**
   * 서브 메뉴를 보여주고 있는 Item.
   * @type String
   */
  this.showedItem = null;
  /**
   * 컨트롤의 z 인덱스.
   * @type Number
   */
  this.zIndex = 1100000;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = null;
  /**
   * 컨텍스트 메뉴 그림자의 표시 여부.
   * @type Boolean
   */
  this.shadowEnable = null;
  /**
   * 아이콘 영역의 공통 속성 (아이콘 영역 생성 시 기본값 적용).
   * @type Object
   */
  this.iconarea = {
    width: null,
    backgroundColor: null,
    className: null, // CSS 클래스 이름 - string
    verticalAlign: null
  };
  /**
   * 아이템의 공통 속성 (아이템 생성 시 기본 값 적용).
   * height : 아이템의 높이 - Number<br>
   * width : 아이템의 넓이 - Number
   * textIndent : 아이템의 들여쓰기 - Number
   * textAlign : 아이템의 가로 정렬 - String(left/center/right)
   * verticalAlign : 아이템의 세로 정렬 - String(top/middle/bottom)
   * borderWidth : border의 폭 - Number
   * borderStyle : border 스타일 - String(none/hidden/dotted/dashed/solid/double/groove/ridge/inset/outset)
   * borderColor : border색 - String
   * fontFamily : 폰트패밀리 - String
   * fontSize : 폰트사이즈 - Number
   * fontStyle : 폰트스타일 - String
   * fontWeight : 폰트굵기 - String
   * color : 아이템의 글자색 - String
   * backgroundColor : 아이템의 배경색 - String
   * focusColor : 포커스시의 아이템의 글자색 - String
   * focusBackgroundColor : 포커스시의 아이템의 배경색 - String
   * separatorColor : 구분선의 색 - String
   * separatorHeight : 구분선의 높이 - Number
   * className : CSS 클래스 이름 - string
   * @type Object
   */
  this.itemgroup = {
    height: null,
    width: null,
    textIndent: null,
    textAlign: null,
    verticalAlign: null,
    borderWidth: null,
    borderStyle: null,
    borderColor: null,
    fontFamily: null,
    fontSize: null,
    fontStyle: null,
    fontWeight: null,
    color: null,
    backgroundColor: null,
    focusColor: null,
    focusBackgroundColor: null,
    separatorColor: null,
    separatorHeight: null,
    className: null
  };
  /**
   * 컨텍스트 메뉴의 그림자를 표시하기 위한 속성
   * backgroundColor : 그림자 배경 색상 - String
   * borderWidth : 그림자 영역 테두리 두께 - Number
   * borderStyle : 그림자 영역 테두리 종류 - String
   * borderColor : 그림자 영역 테두리 색상 - String
   * filter : 투명도 설정 값(ie용) - String
   * opacity : 그림자 영역 투명도 - Number
   * left : 좌측 상단의 x좌표 - Number
   * top : 좌측 상단의 y좌표 - Number
   */
  this.shadow = {
    backgroundColor : null,
    borderWidth : null,
    borderStyle : null,
    borderColor : null,
    filter : null,
    opacity : null,
    left : null,
    top : null
  };
  /**
   * @ignore
   */
  this.df = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.ContextMenu);
//////////////////////////////////////////////////////////////////
// 메소드

eXria.controls.xhtml.ContextMenu.prototype.createCtrl = function(poDocument) {
  var voCtrl = this.createMenuCtrl(poDocument, this.id);
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};

eXria.controls.xhtml.ContextMenu.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voItemgroupDf = this.itemgroup;

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  // CSS가 적용되지 않는 속성에 대한 초기값 설정(main 컨트롤)
  this.shadowEnable = this.getAttrValue("shadowEnable", this.shadowEnable);
  this.value = this.getAttrValue("value", this.value);
};

eXria.controls.xhtml.ContextMenu.prototype.setSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  //poCtrl["className"] = this.getCSSClass(this, 1);
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(voDf.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(voDf.visible == false) {
    vaCssStrBuf.push("display:none;");
  } else {
    if(this.isShowing) vaCssStrBuf.push("display:block;");
    else vaCssStrBuf.push("display:none;");
  }
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  poCtrl.style.cssText = vaCssStrBuf.join("");
};

eXria.controls.xhtml.ContextMenu.prototype.setSpecificEvents = function(poCtrl) {};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.atclick = function(poEvent) {
  this.focused = true;
  if(this.selectedItem) {
     poEvent.objectType = "item";
     poEvent.object = this.selectedItem;
     poEvent.baseControlId = this.baseControlId;
   }
 };
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  this.setSpecificDefaults(poCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.setAttrCtrl("height", "", poCtrl);
  this.setAttrCtrl("width", "", poCtrl);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.reloadData = function(poCtrl, poDocument) {};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl){
  switch (psAttrName) {
    case "disabled":
      for (var i = 0; i < poCtrl.childNodes.length; i++) {
        poCtrl.childNodes[i].disabled = psAttrValue;
        for (var j = 0; j < poCtrl.childNodes[i].childNodes.length; j++) {
          poCtrl.childNodes[i].childNodes[j].disabled = psAttrValue;
        }
      }
      break;
    default:
      //      poCtrl.childNodes[i].setAttribute(psAttrName, psAttrValue);
      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.applyAttrRefresh = function(psAttrName, psAttrValue, poDocument){
  var vsAttrName = psAttrName.split('.');
//  if(psAttrName == "visible"){
//    if(this.isShowing == false) return;
//  }
  if (vsAttrName.length == 1) {
    this.setAttr(psAttrName, psAttrValue);
    this.setAttrCtrl(psAttrName, psAttrValue);
    this.refresh(poDocument);
  }
  else if (vsAttrName.length == 2) {
    if (vsAttrName[0] == "itemgroup" || vsAttrName[0] == "iconarea") {
      if (this.setAttr(psAttrName, psAttrValue)) {
        this.refreshItems(poDocument);
      }
    }
  }
};

eXria.controls.xhtml.ContextMenu.prototype.setDisable = function(poCtrl, psValue) {
  this.disabled = psValue;
  if(psValue == true){
    if(poCtrl.tagName == "TR")  {
      poCtrl.style.color = this.disabledColor;
    }

    if(poCtrl.childNodes) {
      var voChild = null;
      for(var i = 0; i < poCtrl.childNodes.length; i++) {
        voChild = poCtrl.childNodes[i];
        this.setDisable(voChild, psValue);
      }
    }
  }else{
    if(poCtrl.disabled != undefined) poCtrl.removeAttribute("disabled");

    if(poCtrl.childNodes) {
      var voChild = null;
      for(var i = 0; i < poCtrl.childNodes.length; i++) {
        voChild = poCtrl.childNodes[i];
        this.setDisable(voChild, psValue);
      }
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.createMenuCtrl = function(poDocument, psId) {
  var voMenuDiv = poDocument.createElement("div");
  voMenuDiv["id"] = psId;
  voMenuDiv["tabIndex"] = 0;
  if(this.canvas.page.metadata.browser.ie > 0) voMenuDiv["hideFocus"] = true;
  return voMenuDiv;
};
/**
 * mouseover 시에 호출되어 하위 메뉴를 보여줌
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {eXria.controls.xhtml.MenuItem} poItem mouseover된 아이템 객체
 * @privatre
 */
eXria.controls.xhtml.ContextMenu.prototype.showSubMenu = function(poDocument, poItem) {
  var voDocument = this.document;
  if(poItem.parentControl.visible == false) return;
  var voSubMenuDiv = voDocument.getElementById(poItem.id + "_SubMenu");
  if(voSubMenuDiv !== undefined && voSubMenuDiv != null) {
    //this.clearCtrlNode(voSubMenuDiv);
    voSubMenuDiv.parentNode.removeChild(voSubMenuDiv);
  }

  voSubMenuDiv = this.createMenuCtrl(poDocument, poItem.id + "_SubMenu");
  this.setMainCtrlStyles(voSubMenuDiv, poDocument);
  this.setSpecificDefaults(voSubMenuDiv, poDocument);
  this.setSpecificAttrs(voSubMenuDiv, poDocument);

  var voChildItem = null;
  var vnIndex = 0;
  var vnHIndex = 0;
  var voParent = poItem.parent;
  var voPosItem = poItem;
  var voIterator = null;
  while(voParent) {
      vnHIndex++;
      voIterator = voParent.items.getValueCollection().iterator();
      var i = 0;
      while(voIterator.hasNext()) {
        voChildItem = voIterator.next();
        if((voChildItem != voPosItem) && (voChildItem.toString() == "MenuItem") && voChildItem.value != "-") {
          i++;
        } else {
          break;
        }
      }
      vnIndex += i;
      voPosItem = voParent;
      voParent = voParent.parent
  }
  var voStyle = voSubMenuDiv.style;
  voStyle.left = (this.getCtrl().offsetLeft + vnHIndex * this.getCtrl().offsetWidth - 10) + "px";
  voStyle.top = (this.getCtrl().offsetTop) + (vnIndex * poItem.height) + "px";
  voStyle.zIndex = 1100000;

  voDocument.getElementById(this.canvas.id).appendChild(voSubMenuDiv);

  this.showedItem = poItem;

  var vaStrBuf = [];
  var voChildItem = null;
  var voIterator = poItem.items.getValueCollection().iterator();
  vaStrBuf.push("<table cellSpacing=0 cellPadding=0 ");
  vaStrBuf.push("style='left:0px;top:0px'>");
  vaStrBuf.push("<tbody>");
  while (voIterator.hasNext()) {
    voChildItem = voIterator.next();
    vsType = voChildItem.toString();
    if(vsType== "MenuItem") {
      vaStrBuf.push(voChildItem.getInnerHTML(voParent))
    } else if(vsType == "MenuItemSet") {
      voChildItem.items.clear();
      voChildItem.loadData();
      vaStrBuf.push(voChildItem.getInnerHTML(voParent));
    }
  }
  vaStrBuf.push("</tbody>");
  vaStrBuf.push("</table>");
  voSubMenuDiv.innerHTML = vaStrBuf.join("");

  var voParentCtrl = voDocument.getElementById(poItem.id);
  var vnLeft = 0;
  var vnTop = 0;
  if(this.getPositionLeft(voSubMenuDiv, voParentCtrl) > 0) vnLeft = this.getPositionLeft(voSubMenuDiv, voParentCtrl);
  if(this.getPositionTop(voSubMenuDiv, voParentCtrl) > 0) vnTop = this.getPositionTop(voSubMenuDiv, voParentCtrl);
  voStyle.left = vnLeft + "px";
  voStyle.top = vnTop + "px";

  this.createShadow(voSubMenuDiv);

  vaStrBuf = null;
};
/**
 * 하위 메뉴를 숨김
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {eXria.controls.xhtml.MenuItem} poItem mouseover된 아이템 객체
 * @privatre
 */
eXria.controls.xhtml.ContextMenu.prototype.hideSubMenu = function(poDocument, poItem) {
  var voDocument = this.document;
  var voSubMenuDiv = voDocument.getElementById(poItem.id + "_SubMenu");
  if(voSubMenuDiv !== undefined && voSubMenuDiv != null) {
    //this.clearCtrlNode(voSubMenuDiv);
    voSubMenuDiv.parentNode.removeChild(voSubMenuDiv);
    this.showedItem = null;
  }
  var voIterator = poItem.items.getValueCollection().iterator();
  var voChildItem = null;
  while (voIterator.hasNext()) {
    voChildItem = voIterator.next();
    this.hideSubMenu(poDocument, voChildItem);
  }
};
/**
 * 컨텍스트 메뉴에 추가할 아이템을 생성.
 * @param {String} psLabel 아이템 라벨명
 * @param {String} psValue 아이템 값
 * @param {String} psImage 이미지 경로
 * @param {String} psHotKey 단축키 값
 * @return 생성된 메뉴 아이템
 * @type eXria.controls.xhtml.MenuItem
 * @example page.getControl("contextmenu").createMenuItem("제목", "value", ".img/icon_new.png", "F3");
 */
eXria.controls.xhtml.ContextMenu.prototype.createMenuItem = function(psLabel, psValue, psImage, psHotKey) {
  var voItem = new eXria.controls.xhtml.MenuItem(psLabel, psValue, psImage, psHotKey, this);
  var voItemgroup = this.itemgroup;

  // 메뉴아이템의 공통 속성에 대한 기본값 설정
  voItem.height = this.getAttrValue("itemgroup.height", voItemgroup.height);
//  voItem.backgroundColor = this.getAttrValue("itemgroup.backgroundColor", voItemgroup.backgroundColor);
  voItem.backgroundColor = voItemgroup.backgroundColor;
  voItem.borderWidth = voItemgroup.borderWidth;
  voItem.borderStyle = voItemgroup.borderStyle;
  voItem.borderColor = voItemgroup.borderColor;
  voItem.textAlign = voItemgroup.textAlign;
  voItem.verticalAlign = voItemgroup.verticalAlign;
  voItem.focusBackgroundColor = voItemgroup.focusBackgroundColor;

  // 컨트롤이 가진 속성을 메뉴아이템에 전달
  voItem.disabled = this.disabled;
  voItem.color = this.color;

  return voItem;
};
/**
 * 컨텍스트 메뉴에 아이템 추가.
 * @param {eXria.controls.xhtml.MenuItem} poItem 컨텍스트 메뉴에 추가할 아이템.
 * @example
 * var item = page.getControl("contextmenu").createMenuItem("제목", "value", ".img/icon_new.png", "F3");<br>
 * page.getControl("contextmenu").addChild(item);
 */
eXria.controls.xhtml.ContextMenu.prototype.addChild = function(poItem) {
  this.items.put(this.items.size(), poItem);
  poItem.parent = this;
};
/**
 * 컨텍스트 메뉴의 아이템들 전체 삭제.
 */
eXria.controls.xhtml.ContextMenu.prototype.removeAll = function() {
  this.items.clear();
};
/**
 * 지정된 id를 갖는 아이템을 얻어오기 위한 메소드.
 * @param {String} psId 검색할 아이디
 * @param {eXria.data.ArrayMap} poItems 검색할 아이템 맵, 생략시 현재 contextmenu item
 * @return 지정된 값을 포함한 아이템
 * @type eXria.controls.xhtml.Item
 */
eXria.controls.xhtml.ContextMenu.prototype.getItemById = function(psId, poItems) {
  if(poItems == null) poItems = this.items;
  var vsKey = null;
  var voItem = null;
  var vsType = 0;
  var voIterator = poItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    vsType = voItem.toString();
    if(vsType == "MenuItem") {
      if(voItem.id == psId) {
        return voItem;
      } else {
        voItem = this.getItemById(psId, voItem.items);
        if(voItem) return voItem;
      }
    } else if(vsType == "MenuItemSet") {
      voItem = this.getItemById(psId, voItem.items);
      if(voItem) return voItem;
    }
  }
  return null;
};
/**
 * 컨텍스트 메뉴에 추가할 아이템셋을 생성.
 * @param {String} psLabelPath 아이템 라벨명 경로
 * @param {String} psValuePath 아이템 값 경로
 * @param {String} psImagePath 아이템 이미지 경로
 * @param {String} psHotKeyPath 단축키 경로
 * @param {String} psParentPath 부모아이템 경로
 * @param {String} psInstanceId 인스턴스 아이디
 * @param {String} psNodeSet 노드셋 경로
 * @return 생성된 메뉴 아이템
 * @type eXria.controls.xhtml.MenuItemSet
 * @example
 * var item = page.getControl("contextmenu").createMenuItemSet("label", "value", "img", "hotkey", null);<br>
 * item.data.setNodesetRef("instance", "/root/ct/list");
 */
eXria.controls.xhtml.ContextMenu.prototype.createMenuItemSet = function(psLabelPath, psValuePath, psImagePath, psHotKeyPath, psParentPath, psInstanceId, psNodeSet) {
  var voItemSet = new eXria.controls.xhtml.MenuItemSet(psLabelPath, psValuePath, psImagePath, psHotKeyPath, psParentPath, psInstanceId, psNodeSet, this);
  return voItemSet;
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  var vaAttrName = psAttrName.split(".");
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.ContextMenu[psAttrName];
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.ContextMenu[vaAttrName[0]][vaAttrName[1]];
  }
  if(vsDefaultValue === undefined) { return null;}
  return vsDefaultValue;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.getPositionLeft = function(poCtrl, poParent){
  var vnLeft = poCtrl.offsetLeft;
  var vnWidth = poCtrl.offsetWidth;
  var vnParentWidth = null;

  if(poParent){
    vnParentWidth = poParent.offsetWidth;
    vnLeft = poParent.offsetWidth + poParent.parentNode.parentNode.parentNode.offsetLeft;

    if((vnLeft + vnWidth) > this.canvas.width) vnLeft = vnLeft - vnWidth - vnParentWidth + 10;
    else vnLeft -= 10;
  } else {
    if((vnLeft + vnWidth) > this.canvas.width) vnLeft = vnLeft - vnWidth + 2;
  }

  return vnLeft;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.getPositionTop = function(poCtrl, poParent){
  var vnTop = poCtrl.offsetTop;
  var vnHeight = poCtrl.offsetHeight;

  if(poParent){
    var vnParentHeight = poParent.offsetHeight;
    vnTop = poParent.offsetTop + poParent.parentNode.parentNode.parentNode.offsetTop;

    if((vnTop + vnHeight) > this.canvas.height) vnTop = vnTop - vnHeight + vnParentHeight - 5;
    else vnTop += 5;
  } else {
    if((vnTop + vnHeight) > this.canvas.height) vnTop = vnTop - vnHeight + 2;
  // FF에서 최초 Event가 발생한 cursor의 position에서 position이 바뀌게 되는 객체의 영역이 벗어나면 객체의 display가 none으로 바뀜
  // cursor의 positon과 객체의 position을 맞춰주기 위하여 -1을 함
  }

  return vnTop;
};

eXria.controls.xhtml.ContextMenu.prototype.loadData = function(poDocument) {
  var voCtrl = this.ctrl;
  voCtrl.innerHTML = this.getInnerHTML(voCtrl);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.loadComplete = function(poDocument) {
  var voCtrl = this.ctrl;
  var vnLeft = 0;
  var vnTop = 0;
  if(this.getPositionLeft(voCtrl) > 0) vnLeft = this.getPositionLeft(voCtrl);
  if(this.getPositionTop(voCtrl) > 0) vnTop = this.getPositionTop(voCtrl);
  voCtrl.style.left = vnLeft + "px";
  voCtrl.style.top = vnTop + "px";
  this.createShadow(voCtrl);
};

eXria.controls.xhtml.ContextMenu.prototype.reloadData = function(poDocument){
  this.loadData(poDocument);
  this.loadComplete(poDocument);
}
/**
 * data를 표시한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {eXria.controls.xhtml.MenuItem|eXria.controls.xhtml.MenuItemSet} poItems 컨텍스트 메뉴를 구성할 메뉴 객체 collection
 * @private
 */
eXria.controls.xhtml.ContextMenu.prototype.display = function(poDocument, poCtrl, poItems) {
  var vsKey = null;
  var voValue = null;
  var vsType = 0;
  var voIterator = poItems.getKeyCollection().iterator();

  while (voIterator.hasNext()) {
    vsKey = voIterator.next();
    voValue = poItems.get(vsKey);
    vsType = voValue.toString();
    if(vsType== "MenuItem") {
      var voItemCtrl = voValue.createCtrl(poDocument);
      poCtrl.childNodes[0].childNodes[0].appendChild(voItemCtrl);
    } else if(vsType == "MenuItemSet") {
      voValue.loadData(poDocument);
      voValue.display(poDocument, poCtrl.childNodes[0].childNodes[0]);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.getInnerHTML = function(poCtrl) {
  var vsKey = null;
  var voItem = null;
  var vsType = 0;
  var voIterator = this.items.getValueCollection().iterator();
  var vaStrBuf = [];
  var vsCss = this.getCSSClass(this, 1);
  //TODO get ItemgroupClass
  vaStrBuf.push("<table class='" + vsCss + "' cellSpacing=0 cellPadding=0 ");
  vaStrBuf.push("style='left:0px;top:0px'>");
  vaStrBuf.push("<tbody>");
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    vsType = voItem.toString();
    if(vsType== "MenuItem") {
      vaStrBuf.push(voItem.getInnerHTML(poCtrl))
    } else if(vsType == "MenuItemSet") {
      voItem.items.clear();
      voItem.loadData();
      vaStrBuf.push(voItem.getInnerHTML(poCtrl));
    }
  }
  vaStrBuf.push("</tbody>");
  vaStrBuf.push("</table>");

  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ContextMenu.prototype.createShadow = function(poCtrl){
  if(!this.shadowEnable) return;

//  this.shadow.backgroundColor = this.getAttrValue("shadow.backgroundColor",this.shadow.backgroundColor);
//  this.shadow.borderWidth = this.getAttrValue("shadow.borderWidth",this.shadow.borderWidth);
//  this.shadow.borderStyle = this.getAttrValue("shadow.borderStyle",this.shadow.borderStyle);
//  this.shadow.borderColor = this.getAttrValue("shadow.borderColor",this.shadow.borderColor);
//  this.shadow.filter = this.getAttrValue("shadow.filter",this.shadow.filter);
//  this.shadow.opacity = this.getAttrValue("shadow.opacity",this.shadow.opacity);
  this.shadow.left = this.getAttrValue("shadow.left",this.shadow.left);
  this.shadow.top = this.getAttrValue("shadow.top",this.shadow.top);

  var voDocument = this.document;
  var vsClass = this.getCSSClass(this, 1, "Shadow");
  var voShadow = voDocument.createElement("div");
  voShadow.className = vsClass;
  var voStyle = voShadow.style;
  voStyle.position = "absolute";
//  voStyle.backgroundColor = this.shadow.backgroundColor;
//  voStyle.borderWidth = this.shadow.borderWidth;
//  voStyle.borderStyle = this.shadow.borderStyle;
//  voStyle.borderColor = this.shadow.borderColor;
//  voStyle.filter = this.shadow.filter;
//  voStyle.opacity = this.shadow.opacity;
  voStyle.zIndex = "-1";
  voStyle.left = this.shadow.left;
  voStyle.top = this.shadow.top;
  voStyle.width = poCtrl.offsetWidth + "px";
  voStyle.height = poCtrl.offsetHeight + "px";

  poCtrl.appendChild(voShadow);
};
/**
 * 클래스 명을 반환.
 * @return "ContextMenu"
 * @type String
 */
eXria.controls.xhtml.ContextMenu.prototype.toString = function(){
  return "ContextMenu";
};
