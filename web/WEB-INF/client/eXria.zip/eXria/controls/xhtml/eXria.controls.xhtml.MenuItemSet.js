/**
 * @fileoverview
 * Concreate xhtml MenuItemSet(XHTML MenuItemSet 컨트롤)
 * @author 김경태
 */

/**
 * @class Concreate xhtml MenuItemSet.<br>
 * ContextMenu 컨트롤을 구성하는 아이템의 속성정보를 담당하는 클래스.
 * 아이템의 실체화는 ContextMenu에서 담당.
 * @version 2.0
 * @return 새로운 eXria.controls.xhtml.MenuItemSet 객체
 * @type eXria.controls.xhtml.MenuItemSet
 * @constructor
 */
//eXria.controls.xhtml.MenuItemSet = function(psLabelPath, psValuePath, psImagePath, psHotKeyPath, psParentPath, poParentControl) {
eXria.controls.xhtml.MenuItemSet = function(psLabelPath, psValuePath, psImagePath, psHotKeyPath, psParentPath, psInstanceId, psNodeSet, poParentControl) {
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * @ignore
   */
  this.parentControl = poParentControl;
  /**
   * 메뉴 아이템 이름 인스턴스 패스.
   * @type String
   */
  this.labelPath = psLabelPath;
  /**
   * 메뉴 아이템 값 인스턴스 패스.
   * @type String
   */
  this.valuePath = psValuePath;
  /**
   * 메뉴 아이템 이미지 인스턴스 패스.
   * @type String
   */

  this.imagePath = psImagePath;
  /**
   * 메뉴 아이템 단축키 인스턴스 패스.
   * @type String
   */
  this.hotKeyPath = psHotKeyPath;
  /**
   * 부모 메뉴 아이템 인스턴스 패스.
   * @type String
   */
  this.parentPath = psParentPath;
  /**
   * 부모 메뉴 아이템.
   * @type eXria.controls.xhtml.MenuItem
   */
  this.parent = null;
  /**
   * 전체 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.items = new eXria.data.ArrayMap();
  /**
   * 데이타 연동 객체
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset();
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItemSet.prototype.loadData = function(poDocument) {
  if(this.parentControl == null || (this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null)) return;
  this.data.control = this.parentControl;

  var vsRefValue = null;
  if(this.data.instanceId != null) vsRefValue = this.data.getData();
  var voCollectionNode = this.data.getNodesetData2();
  if(voCollectionNode == null) return;
  var vnLoop = voCollectionNode.getLength();
  var voMapNode = null;
  var vsLabel = null;
  var vsValue = null;
  var vsImage = null;
  var vsHotKey = null;
  var vsParent = null;
  for(var i = 0; i < vnLoop; i++) {
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
    vsLabel = voMapNode.get(this.labelPath);
    vsValue = voMapNode.get(this.valuePath);
    vsImage = voMapNode.get(this.imagePath);
    vsHotKey = voMapNode.get(this.hotKeyPath);
    vsParent = voMapNode.get(this.parentPath);

    var voItem = this.parentControl.createMenuItem(vsLabel, vsValue, vsImage, vsHotKey);
    this.checkParent(voItem, vsParent);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItemSet.prototype.checkParent = function(poItem, psParent, poItems) {
  //if(psParent == null) psParent = "";
  if(psParent == null || psParent == "") {
    poItem.parent = this.parent;
    this.items.put(this.items.size(), poItem);
  } else {
    if(poItems == null) poItems = this.items;
    var voIterator = poItems.getValueCollection().iterator();
    var voParent = null;
    while(voIterator.hasNext()) {
      voParent = voIterator.next();
      if(voParent.value == psParent) {
        voParent.addChild(poItem);
        break;
      } else if(voParent.items.size() > 0) {
        this.checkParent(poItem, psParent, voParent.items);
      }
    }
  }

};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItemSet.prototype.display = function(poDocument, poCtrl) {
  var vsKey = null;
  var voValue = null;
  var vsType = 0;
  var voIterator = this.items.getKeyCollection().iterator();

  while (voIterator.hasNext()) {
    vsKey = voIterator.next();
    voValue = this.items.get(vsKey);
    vsType = voValue.toString();
    if(vsType== "MenuItem") {
      var voItemCtrl = voValue.createCtrl(poDocument);
      poCtrl.appendChild(voItemCtrl);
    } else if(vsType == "MenuItemSet") {
      voValue.loadData(poDocument);
      voValue.display(poDocument, poCtrl);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItemSet.prototype.getInnerHTML = function() {
  var vsKey = null;
  var voItem = null;
  var vsType = 0;
  var voIterator = this.items.getKeyCollection().iterator();
  var vaStrBuf = [];
  while (voIterator.hasNext()) {
    vsKey = voIterator.next();
    voItem = this.items.get(vsKey);
    vsType = voItem.toString();
    if(vsType == "MenuItem") {
      vaStrBuf.push(voItem.getInnerHTML());
    } else if(vsType == "MenuItemSet") {
      voItem.items.clear();
      voItem.loadData(poDocument);
      vaStrBuf.push(voItem.getInnerHTML());
    }
  }
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItemSet.prototype.addChild = function(poItem) {
  this.items.put(this.items.size(), poItem);
  poItem.parent = this;
};
/**
 * data 속성으로 부터 DOM 데이타를 얻어옴.
 * @return data 속성으로 부터 얻어온 DOM 데이타
 * @type XMLElement
 * @private
 */
eXria.controls.xhtml.MenuItemSet.prototype.getInstanceData =function() {
  var viInstance = this.data.getNodesetInstance();
  var voDataNode = null;
  if(viInstance) voDataNode = viInstance.selectSingleNode(this.data.nodesetInstancePath);
  return voDataNode;
};
/**
 * 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 디폴트 속성값
 * @type String
 */
eXria.controls.xhtml.MenuItemSet.prototype.getItemAttrValue = function(psAttrName, psAttrValue) {
  if (psAttrValue != null) return psAttrValue;
  else return this.getItemDefaultValue(psAttrName);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 */
eXria.controls.xhtml.MenuItemSet.prototype.getItemDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.ContextMenu.itemgroup[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;
};
/**
 * 클래스 명을 반환.
 * @return "TreeNodes"
 * @type String
 */
eXria.controls.xhtml.MenuItemSet.prototype.toString = function() {
  return "MenuItemSet";
};

