/**
 * @fileoverview
 * Concreate xhtml Output(XHTML Output 컨트롤)
 * @author 이종녕
 */

/**
 * @class 텍스트필드를 화면상에 보여주는 컨트롤을 생성하는 class입니다. <br />
 * eXria.controls.xhtml.Label과 비슷하지만 포멧을 가진다는점이 다릅니다.<br />
 * XHTML Output Control.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Output 객체
 * @type eXria.controls.xhtml.Output
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Output = function(psId, pnLeft, pnTop, pnWidth, pnHeight){

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 초기값을 null로 지정 시에 IE에서 null 자체가 문자로 표시됨.
   * @type String
   */
  this.value = null;
  /**
   * format을 지정하면 형식대로 출력된다 .. ex> ##-#,xx년xx월   #-숫자 , x-문자.
   * @type String
   */
  this.format = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 글꼴 사이의 간격 ex> 0.5em
   * @type Number
   */
  this.letterSpacing = null;
  /**
   * 줄 간격 ex> 14pt
   * @type Number
   */
  this.lineHeight = null;
  /**
   * 폰트에 밑줄 넣기.
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * #,x 가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noMaskVal = /[^\#x]/g;
  /**
   * 숫자가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noDigits = /[^\d]/gi;
  /**
   * 문자가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noString = /[^A-Za-z]/g;
  /**
   * 공백 문자 정규식 표현.
   * @type String
   * @private
   */
  this.blank = /\s/g;
  /**
   * 컨트롤의 안쪽 여백(단위 px).
   * @type Number
   * @private
   */
  this.padding = null;
  /**
   * 컨트롤의 안쪽 상단여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingTop = null;
  /**
   * 컨트롤의 안쪽 우측여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingRight = null;
  /**
   * 컨트롤의 안쪽 하단여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingBottom = null;
  /**
   * 컨트롤의 안쪽 좌측여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingLeft = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};

  this.cursor = null;
  /**
   * format 형태 분류 문자열("string"/"number"/"date");
   * @type String
   */
  this.formatType = null;
  /**
   * @private
   */
  this.editMask = new eXria.controls.xhtml.EditMask();
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Output);
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  voCtrl["accesskey"] = this.accessKey;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;

  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.setTemplate = function(poCtrl, poDocument){
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<div id='" + this.id + "_label' class='" + vsClass + "' style=\"");
  vaTemplate.push("@cssStrBuf"); //0
  vaTemplate.push("\">");
  vaTemplate.push("@innStrBuf"); //1
  vaTemplate.push("</div>");
//  vaTemplate.push("<span style=\"position:absolute;visibility:hidden;");
//  vaTemplate.push("@cssStrBuf"); //2
//  vaTemplate.push("\"/>")

  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.verticalAlign = this.getAttrValue("verticalAlign",this.verticalAlign);
  this.value = this.getAttrValue("value",this.value);
  this.formatType = this.getAttrValue("formatType", this.formatType);
  this.format = this.getAttrValue("format", this.format);
  if(this.formatType == "date") {
    if(this.regFormat == null || this.regFormat == "") {
      this.regFormat = "yyyy-MM-dd";
    }
  }
};



/**
* @ignore
*/
eXria.controls.xhtml.Output.prototype.setSpecificAttrs = function(poCtrl, poDocument){
var voDf = this.df;
var vaCssStrBuf = null;
var vaAttStrBuf = null;
var vaTemplate = this.template;
// 반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
// 단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
var vfcSetCssStrBuf = this.setCssStrBuf;
var vfcSetAttStrBuf = this.setAttStrBuf;
var voIndexMap = this.templateIndexMap;

poCtrl["tabIndex"] = this.tabIndex;
poCtrl["tooltip"] = this.tooltip;
if(this.disabled) poCtrl["disabled"] = true;

vaCssStrBuf = [];
vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
if(this.visible == false) vaCssStrBuf.push("display:none;");
else vaCssStrBuf.push("display:block;");
vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
poCtrl.style.cssText = vaCssStrBuf.join("");

vaCssStrBuf = [];
vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;");
vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight,"px");
vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
vfcSetCssStrBuf(vaCssStrBuf, "width", (this.innerWidth - this.paddingLeft - this.paddingRight), "px");
vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
vfcSetCssStrBuf(vaCssStrBuf, "letter-spacing", this.letterSpacing, "px");
vfcSetCssStrBuf(vaCssStrBuf, "line-height", this.lineHeight, "px");
vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");
vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");
var vsValue = this.value;
if(vsValue != null && vsValue != ""){
  switch(this.formatType) {
  case "number":
    break;
  case "date":
    vsValue = this.getDate(vsValue).getTime();
    break;
  case "string":
    break;
  }
  vsValue = TGP.GetString(vsValue, this.formatType, this.regFormat);
} else {
  vsValue = "";
}
vaTemplate[voIndexMap.get(1)] = vsValue;

poCtrl.innerHTML = vaTemplate.join("");
voIndexMap.clear();
vaCssStrBuf = null;
vaAttStrBuf = null;
vaTemplate = null;
this.template = null;

this.setSubElement(poDocument);
};

/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Output.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.div = this.getSubCtrl("div", voCtrl, poDocument);
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Output.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voDf = this.df;
  var voDiv = this.subElement.div;
  switch(psAttrName) {
  case "width" :
    var vnWidth = this.innerWidth - this.paddingLeft - this.paddingRight;
    if(vnWidth < 0) vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voDiv);
    break;
  case "height" :
    this.setVerticalAlign(voDiv, poCtrl, this.verticalAlign);
    break;
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Output.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
var voDf = this.df;
var voDivCtrl = this.subElement.div;
var vaCssStrBuf = null;
var vfcSetCssStrBuf = this.setCssStrBuf;

this.setDetailBorder(this);

poCtrl["tabIndex"] = this.tabIndex;
poCtrl["tooltip"] = this.tooltip;
if(this.disabled) poCtrl["disabled"] = true;

vaCssStrBuf = [];
vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
if(this.visible == false) vaCssStrBuf.push("display:none;");
else vaCssStrBuf.push("display:block;");
vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
poCtrl.style.cssText = vaCssStrBuf.join("");

vaCssStrBuf = [];
vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;");
vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight,"px");
vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
vfcSetCssStrBuf(vaCssStrBuf, "width", (this.innerWidth - this.paddingLeft - this.paddingRight), "px");
vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
vfcSetCssStrBuf(vaCssStrBuf, "letter-spacing", this.letterSpacing, "px");
vfcSetCssStrBuf(vaCssStrBuf, "line-height", this.lineHeight, "px");
vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");
vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
voDivCtrl.style.cssText = vaCssStrBuf.join("");

var vsValue = this.value;
if(vsValue != null && vsValue.length != 0) {
  switch(this.formatType) {
  case "number":
    break;
  case "date":
    vsValue = this.getDate(vsValue).getTime();
    break;
  case "string":
    break;
  }
  vsValue = TGP.GetString(vsValue, this.formatType, this.regFormat);
} else {
  vsValue = "";
}
voDivCtrl.innerHTML = vsValue;
};

/**
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};

/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Output.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voDiv = this.subElement.div;
  var voDf = this.df;
  var vaAttrName = psAttrName.split(".");

  this.setAttr(psAttrName, psAttrValue);
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }

  switch(psAttrName) {
    case "visible" :
      this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
      this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
      break;
    case "disabled" :
      this.setDisable(voCtrl, psAttrValue);
      break;
    case "left" :
    case "top" :
      voCtrl.style[psAttrName] = psAttrValue + "px";
      break;
    case "width" :
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      break;
    case "height" :
      this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      break;
    case "borderWidth" :
      this.borderLeftWidth = this.borderWidth;
      this.borderRightWidth = this.borderWidth;
      this.borderTopWidth = this.borderWidth;
      this.borderBottomWidth = this.borderWidth;
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
      this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
      this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
      this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      break;
   case "borderLeftWidth" :
   case "borderRightWidth" :
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
      break;
   case "borderTopWidth" :
   case "borderBottomWidth" :
      this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
      break;
   case "padding" :
      this.paddingTop = this.padding;
      this.paddingRight = this.padding;
      this.paddingBottom = this.padding;
      this.paddingLeft = this.padding;
      this.setAttrCtrl("paddingTop", this.paddingTop + "px", voDiv);
      this.setAttrCtrl("paddingRight", this.paddingRight + "px", voDiv);
      this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voDiv);
      this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voDiv);
      var vnWidth = this.innerWidth - this.paddingLeft - this.paddingRight;
      if(vnWidth < 0) vnWidth = 0;
      this.setAttrCtrl("width", vnWidth, voDiv);
      this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
      break;
    case "paddingTop" :
    case "paddingBottom" :
      this.setAttrCtrl(psAttrName, psAttrValue + "px", voDiv);
      this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
      break;
    case "paddingLeft" :
    case "paddingRight" :
      this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voDiv);
      var vnWidth = this.innerWidth - this.paddingLeft - this.paddingRight;
      if(vnWidth < 0) vnWidth = 0;
      this.setAttrCtrl("width", vnWidth, voDiv);
      break;
    case "textAlign":
      this.setAttrCtrl(psAttrName, psAttrValue, voDiv);
      break;
    case "fontFamily" :
    case "fontSize" :
    case "fontStyle" :
    case "fontWeight" :
    case "textDecoration":
      this.setAttrCtrl(psAttrName, psAttrValue, voDiv);
      this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
      break;
    case "letterSpacing" :
    case "lineHeight":
      this.setAttrCtrl(psAttrName, psAttrValue + "px", voDiv);
      this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
      break;
    case "verticalAlign" :
      this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
      break;
    case "formatType" :
      break;
    case "format" :
      if(this.formatType == "date") {
        if(this.format == null || this.format == "") this.format = "yyyyMMdd";
      }
      this.setValue(this.value);
//      this.applyFormat(psAttrValue, voDiv);
      break;
    case "value" :
      this.setValue(psAttrValue);
      break;
    case "outerClassName" :
    case "className" :
      this.refresh(poDocument);
      break;
    default :
      this.refresh(poDocument);
      break;
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Output.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;
  var vsRefData = this.data.getData();
  this.setValue(vsRefData);
};


/**
 * loadComplete
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Output.prototype.loadComplete = function(poDocument) {
  var voCtrl = this.ctrl;
  var voDiv = this.subElement.div;
  this.setVerticalAlign(voDiv, voCtrl, this.df.verticalAlign);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
  this.loadComplete(poDocument);
};


/**
 * 컨트롤에 값을 설정해 줍니다.
 * @param {String} psValue 설정값
 */
eXria.controls.xhtml.Output.prototype.setValue = function(psData) {
var voDiv = this.subElement.div;
var vbChanged = false;
if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psData) {
  vbChanged = true;
}
this.onchangeInitValue = psData;
this.value = psData;
if(vbChanged) this.data.setData(this.value);
if(psData != null && psData != "") {
  switch(this.formatType) {
  case "number":
    break;
  case "date":
    psData = this.getDate(psData).getTime();
    break;
  case "string":
    break;
  }
  psData = TGP.GetString(psData, this.formatType, this.regFormat);
} else {
  psData = "";
}
this.setText(voDiv, psData);
this.refreshVerticalAlign();
};
/**
 * 컨트롤에 설정된 값을 반환합니다.
 * @return 컨트롤 value 속성 값
 * @type String
 */
eXria.controls.xhtml.Output.prototype.getValue = function() {
  return this.value;
};
/**
 * 컨트롤 설정 값에 출력 포맷을 지정해 줍니다.
 * @param {String} psFormat 포맷 문자열
 * @param {HTMLTd} poCtrl 출력 포맷이 적용될 실체화 객체
 * @return 작업수행 성공 여부
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.Output.prototype.applyFormat = function(psFormat, poCtrl){
  // 개체의 값 얻어오기
  var vsValue = this.value;
  var regVal = psFormat;
  //if(regVal == null) return null;
  vsValue = eXria.controls.xhtml.Util.parseLang(vsValue);
  //공백제거...
//  vsValue = vsValue.replace(this.blank,"");
  //데이터를 포맷형식으로 바꿈..
  if(regVal != null){
//    var vsFormat = vsValue.replace(this.blank,"");
//    vsFormat = vsFormat.replace(this.noDigits,"x");
//    vsFormat = vsFormat.replace(this.noString,"#");
//    //포맷 형식...
//    var vsCheck = regVal.replace(this.noMaskVal,"");
//    //데이터 포맷과 실제값이 형식이 일치 하지 않으면 반환...
//    if( vsCheck != vsFormat){
//      this.df.value = null;
//      this.value = null;
//      this.subElement.div.innerHTML = "";
//      alert(this.toString()+": 출력형식과 실제 데이터 값이  같지 않습니다.");
//      return false;
//    }
      if(/(YYYY)|(MM)|(DD)/g.test(regVal)) {
        this.formatType = "date";
        var vsYear = vsValue.substring(0, 4);
        var vsMonth = vsValue.substring(4, 6);
        var vsDate = vsValue.substring(6, 8);

        regVal = regVal.replace(/YYYY/, vsYear);
        regVal = regVal.replace(/MM/, vsMonth);
        regVal = regVal.replace(/DD/, vsDate);
      } else if(/x/.test(regVal) == false){
        var voEditMask = this.editMask;
        voEditMask.mask = regVal;
        regVal = voEditMask.setNumber(vsValue, true);
      } else {
        for(var i=0;i < vsValue.length;i++) {
          regVal = regVal.replace(/[#x]/i, vsValue.charAt(i));
        }
      }
  }else regVal = vsValue;
  this.setText(poCtrl, regVal);
  return true;
};
/**
 * refreshVerticalAlign
 * 컨트롤 텍스트 수직정렬을 새로고침 합니다.
 */
eXria.controls.xhtml.Output.prototype.refreshVerticalAlign = function() {
  var voCtrl = this.ctrl;
  if(voCtrl == null) return;
  var voDf = this.df;
  var voDiv = this.subElement.div;
  this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
};
/**
 * 각 속성에 따른 디폴트 값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Output[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Output.prototype.setSpecificEvents = function(poCtrl) {
  var voDiv = this.subElement.div;
  this.eventManager.addListener(voDiv, "onblur", this.mediateEvent);
  this.eventManager.addListener(voDiv, "onfocus", this.mediateEvent);
  voDiv.control = this;
};
/**
 * 클래스 명을 반환합니다.
 * @return "Output"
 * @type String
 */
eXria.controls.xhtml.Output.prototype.toString = function() {
  return "Output";
};
