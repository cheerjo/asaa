/**
 * @fileoverview
 * Concreate xhtml SecretBox(XHTML SecretBox 컨트롤)
 * @author 이종녕
 */

/**
 * @class 암호 입력필드이며 입력받은 모든문자를 *로 나타내어주는 컨트롤을 생성하는 class입니다.<br />
 * @XHTML SecretBox Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.SecretBox 객체
 * @type eXria.controls.xhtml.SecretBox
 * @constructor
 * @base eXria.controls.xhtml.InputCommon
 */

eXria.controls.xhtml.SecretBox = function(psId, pnLeft, pnTop, pnWidth, pnHeight){

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.InputCommon.call(this, psId,pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * 사용자정의 Max Byte 길이
   * @type Number
   */
  this.maxByteLenth = null;
  /**
   * 사용자정의 Min Byte 길이
   * @type Number
   */
  this.minByteLenth = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.InputCommon, eXria.controls.xhtml.SecretBox);
////////////////////////////////////////////////////////
////  메소드
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.setTemplate = function(poCtrl, poDocument){
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<input class='" + vsClass + "' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_secret' type='password' ");
  vaTemplate.push("@attStrBuf"); //0
  vaTemplate.push("style=\"");
  vaTemplate.push("@cssStrBuf");  //1
  vaTemplate.push("\"/>");
  vaTemplate.push("<span class='" + vsClass + "'" + " style=\"");
  vaTemplate.push("@cssStrBuf"); //2
  vaTemplate.push("\"/>");
  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  // loadcomplate에서 처리
  //if(this.textAlign == "right" && this.paddingRight == 0) this.paddingRight = 2;
  this.verticalAlign = this.getAttrValue("verticalAlign",this.verticalAlign);
  this.maxLength = this.getAttrValue("maxLength",this.maxLength);
  this.minLength = this.getAttrValue("minLength",this.minLength);
  this.value = this.getAttrValue("value",this.value);
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.setSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "value", this.value);
  if(this.readOnly) vfcSetAttStrBuf(vaAttStrBuf, "readOnly", this.readOnly);
  vfcSetAttStrBuf(vaAttStrBuf, "maxLength", this.maxLength);
  vfcSetAttStrBuf(vaAttStrBuf, "minLength", this.minLength);
  vaTemplate[voIndexMap.get(0)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;top:0px;left:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-transForm", this.textTransform);
  vfcSetCssStrBuf(vaCssStrBuf, "text-direction", this.dir);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  // loadcomplete에서 처리
  /*var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");*/
  vaTemplate[voIndexMap.get(1)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(2)] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");
  voIndexMap.clear();
  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  this.template = null;
  this.templateIndexMap = null;

  this.setSubElement(poDocument);
};

/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.SecretBox.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.input = this.getSubCtrl("input", voCtrl, poDocument);
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.SecretBox.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voDf = this.df;
  var voSecret = this.subElement.input;
  var voSpan = this.subElement.span;
  switch(psAttrName) {
  case "width" :
    this.setInputWidth();
    break;
  case "height" :
    this.setVerticalAlign(voSecret, poCtrl, voDf.verticalAlign);
    break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.dofocus = function() {
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  try { voInput.focus(); }catch(err) {}
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.atchange = function(poCtrl){

  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  var vsValue = voInput.value;
  this.setValue(vsValue);
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.atkeydown = function(e){
  if(e.keyCode == 13) {
    this.isEnter = true;
    var voInput = this.subElement.input;
    var vsValue = voInput.value;
    this.setValue(vsValue);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.atfocus = function(e) {
  if(this.focused != true) this.selectText();
  this.focused = true;
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.atblur = function(e) {
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  var vsValue = voInput.value;

  if(!!this.inputMode){
  vsValue = eXria.controls.xhtml.Util.getValueFromInputMode(String(vsValue), this.inputMode);
  voInput.value = vsValue;
  }


  this.setValue(vsValue);
//  var voCtrl = page.getControl();
//  this.setVerticalAlign(voCtrl);
  this.focused = false;
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.atclick = function(e){
  var voDocument = this.document;
  this.focused = true;
  var voInput = this.subElement.input;
  if(e.target == voInput) {
    if(voDocument.selection && voDocument.selection.createRange) {
      this.textRange = voDocument.selection.createRange();
    }
  } else {
    if(this.textRange) {
      this.textRange.select();
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.dofocus = function() {
  var voInput = this.subElement.input;
  if(this.focused == false) {
    try { voInput.focus(); }catch(err) {}
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;
  var voInputCtrl = this.subElement.input;
  var voSpanCtrl = this.subElement.span;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  var vsInputValue = this.value;
  if(vsInputValue == null) vsInputValue = "";
  voInputCtrl["value"] = vsInputValue;
  if(this.readOnly) voInputCtrl["readOnly"] = this.readOnly;
  if(this.maxLength != null) voInputCtrl["maxLength"] = this.maxLength;
  if(this.minLength != null) voInputCtrl["minLength"] = this.minLength;

  if(this.className != null) voInputCtrl.className = this.getCSSClass(this, 1);

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;top:0px;left:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-transForm", this.textTransform);
  vfcSetCssStrBuf(vaCssStrBuf, "text-direction", this.dir);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  // 아래에서 setInputWidth에서 처리
  /*var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  voInputCtrl.style.cssText = vaCssStrBuf.join("");*/

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  voSpanCtrl.style.cssText = vaCssStrBuf.join("");

  this.setInputWidth();
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.SecretBox.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  var vaAttrName = psAttrName.split(".");
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
  case "disabled" :
    if(psAttrValue == true) this.doblur();
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "textAlign" :
    this.setAttrCtrl(psAttrName, psAttrValue, voInput);
    this.setInputWidth();
    break;
  case "readOnly" :
  case "maxLength" :
  case "minLength" :
  case "value" :
  case "color" :
    this.setAttrCtrl(psAttrName, psAttrValue, voInput);
    break;
  case "verticalAlign":
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
  case "fontFamily" :
  case "fontSize" :
  case "fontStyle" :
  case "fontWeight" :
  case "textDecoration":
  case "textTransform":
    this.setAttrCtrl(psAttrName, psAttrValue, voInput);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
  case "outerClassName":
  case "className":
    this.refresh(poDocument);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setInputWidth();
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setInputWidth();
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    this.setInputWidth();
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "padding" :
    this.paddingTop = this.padding;
    this.paddingRight = this.padding;
    this.paddingBottom = this.padding;
    this.paddingLeft = this.padding;
    this.setAttrCtrl("paddingTop", this.paddingTop + "px", voInput);
    this.setAttrCtrl("paddingRight", this.paddingRight + "px", voInput);
    this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voInput);
    this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voInput);
    this.setInputWidth();
    break;
  case "paddingTop" :
  case "paddingBottom" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voInput);
    //this.setVerticalAlign(voInput, voCtrl, voDf.verticalAlign);
    break;
  case "paddingRight":
  case "paddingLeft" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voInput);
    this.setInputWidth();
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * 컨트롤에 값을 설정합니다.
 * @param {String} psData 설정할 값
 */
eXria.controls.xhtml.SecretBox.prototype.setValue = function(psData){
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psData) {
    vbChanged = true;
  }
  this.onchangeInitValue = psData;
  this.value = psData;
  var voSecret = this.subElement.input;
  voSecret.value = psData;
  if(vbChanged) {
    this.data.setData(this.value);
    var voEvent = new eXria.event.Event(null);
    voEvent.object = this;
    if(this.onchange) this.onchange(voEvent);
    if(this.changeEventCallback) this.changeEventCallback(voEvent);
  }
};
/**
 * 각 속성에 따른 디폴트 값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.SecretBox.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.SecretBox[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "SecretBox"
 * @type String
 */
eXria.controls.xhtml.SecretBox.prototype.toString = function() {
  return "SecretBox";
};
