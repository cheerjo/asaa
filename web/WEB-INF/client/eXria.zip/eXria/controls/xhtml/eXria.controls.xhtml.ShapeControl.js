/**
 * @fileoverview
 * Concreate Shape UIControl(ShapeControl 컨트롤에 대한 xhtml 기본 클래스)
 * @author 이종녕
 */

/**
 * @class Concreate Shape UIControl.<br>
 * ShapeControl 컨트롤에 대한 xhtml 기본 클래스.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.ShapeControl 객체
 * @type eXria.controls.xhtml.ShapeControl
 * @constructor
 * @base eXria.controls.xhtml.Control
 */
eXria.controls.xhtml.ShapeControl = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  /**
   * 컨트롤 아이디.
   * @type String
   */
  this.id = psId;
  //this.left = pnLeft;
  //this.top =  pnTop;
  //this.width = pnWidth;
  //this.height = pnHeight;

  eXria.controls.xhtml.Control.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  ////////////////////////////////////////////////////////////////////////////////////
  // 속성
  /**
   * @ignore
   */
  this.disabled = null //적용안됨...
  /**
   * 툴팁 문자열.
   * @type String
   */
  this.tooltip = null;
  /**
   * tooltip 표시 여부.
   * @type Boolean
   */
  this.tooltipDisplay = null;
  /**
   * 컨트롤 이동 시 사용될 pane의 불투명도.
   * @type Number
   */
  this.paneOpacity = 30;
  /**
   * 컨트롤 이동가능 여부.<br>
   * this.setMove메소드에 의해서만 값 설정.
   * @type Boolean
   * @private
   */
  this.movable = null;
  /**
   * 컨트롤 화면 디스플레이 여부.
   * @type Boolean
   */
  this.visible = null;
  /**
   * 폼에서 컨트롤의 겹침 순서 지정.<br>
   * @type Number
   */
  this.zIndex = null;
  /**
   * 상위 컨트롤과의 위치 관계(absolute | relative | static).<br>
   * absolute : 상위 컨트롤의 좌상단 점을 원점으로 left, top 지정.<br>
   * relative : 상위 컨트롤이 컨트롤을 자동 위치시킨 상태에서의 left, top 이동값 지정.<br>
   * @type String
   */
  this.position = "absolute";
  /**
   * 컨트롤 위에 마우스 위치시에 마우스 커서 타입.<br>
   * "all-scroll" | "col-resize" | "crosshair" | "default" | "hand" | "help" | "move" | "no-drop" | "not-allowed" | "row-resize" | "text" | "url" | "vertical-text" | "wait" | "NW-resize" | "NE-resize" | "progerss" | "pointer" (초기값 : default)
   * @type String
   */
  this.cursor = "default";
  /**
   * 라인 양 끝단의 타입 지정.<br>
   * "flat" | "round" | "square"  (default:round)
   * @type String
   */
  this.penCap = null;
  /**
   * 라인 스타일.<br>
   * "solid" | "dot" | "dash"  (default:solid)
   * @type String
   */
  this.penStyle = null;
  /**
   * 라인 두께.
   * @type Number
   */
  this.penWeight = null;
  /**
   * 라인 색상.
   * @type String
   */
  this.penColor = null;
  /**
   * 라인의 불투명도.
   * @type unknown
   */
  this.penOpacity = null;
  /**
   * 선과 선이 만났을 때 만나는 부분 처리 유형.<br>
   * "miter" | "round" | "bevel"  (default:round)
   * @type String
   */
  this.joinType = null;
  /**
   * 도형 회전 각.
   * @type Number
   */
  this.angle = null;
  /**
   * left 좌표.
   * @type Number
   */
  this.left = pnLeft;
  /**
   * top 좌표.
   * @type Number
   */
  this.top = pnTop;
  /**
   * 가로 길이.
   * @type Number
   */
  this.width = pnWidth;
  /**
   * 세로 길이.
   * @type Number
   */
  this.height = pnHeight;
  /**
   * 마우스 위치를 기준으로 left 경계와의 거리.
   * @type Number
   * @private
   */
  this.leftOffset = -1;
  /**
   * 마우스 위치를 기준으로 top 경계와의 거리.
   * @type Number
   * @private
   */
  this.topOffset = -1;
  /**
   * 마우스 위치를 기준으로 right 경계와의 거리.
   * @type Number
   * @private
   */
  this.rightOffset = -1;
  /**
   * 마우스 위치를 기준으로 bottom 경계와의 거리.
   * @type Number
   * @private
   */
  this.bottomOffset = -1;
  /**
   * 경계 부근에서 무시되는 거리.
   * @type Number
   * @ignore
   */
  this.adjustOffset = 20;
  /**
   * 포커스가 위치했을 때의 색상 변경 적용 여부.
   * @type Boolean
   */
  this.focusDisplay = false;
  /**
   * 컨트롤에 포커스 위치 시 라인 두께.<br>
   * 포커스 효과 관련
   * @type Number
   */
  this.focusPenWeight = null;
  /**
   * 컨트롤에 포커스 위치 시 라인 색상.<br>
   * 포커스 효과 관련
   * @type String
   */
  this.focusPenColor = null;
  /**
   * 컨트롤에 포커스 위치 시 라인 스타일.
   * @type String
   */
  this.focusPenStyle = null;
  /**
   * 포커싱에 의해 컨트롤 라인 두께 변경 시 원본 값 저장.
   * @private
   * @type Number
   */
  this.oldPenWeight = null;
  /**
   * 포커싱에 의해 컨트롤 라인 색상 변경 시 원본 값 저장.
   * @private
   * @type String
   */
  this.oldPenColor = null;
  /**
   * 포커싱에 의해 컨트롤 라인 스타일 변경 시 원본 값 저장.
   * @private
   * @type String
   */
  this.oldPenStyle = null;

  this.initUIGeneral();

};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Control, eXria.controls.xhtml.ShapeControl);
///////////////////////////////////////////////////////////////////////////
// 메소드
/**
 * Ctrl(실체화 컨트롤)을 생성한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치할 Doucment에 대한 참조
 * @return 실체화 컨트롤에 대한 참조
 * @type object
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.create = function(poDocument, poDiv) {
  if(poDocument == null) poDocument = this.document;
  this.documentMode = poDocument.documentMode;
  if(this.documentMode == null) this.documentMode = 0;
  var voCtrl = null;

  if(this.createCtrl) { voCtrl = this.createCtrl(poDocument); };                                      // 1. Main Ctrl 생성
  if(this.createSubCtrl && voCtrl) { this.createSubCtrl(voCtrl, poDocument); };                       // 2. Composite Child Ctrl 생성

  if(this.setMainCtrlStyles && voCtrl) { this.setMainCtrlStyles(voCtrl, poDocument); };               // 3. Main Style 적용
  if(this.setSubCtrlStyles && voCtrl) { this.setSubCtrlStyles(voCtrl, poDocument); };                 // 4. Composite Child Style 적용

  if(this.setFormDefaults && voCtrl) { this.setFormDefaults(voCtrl, poDocument); };
  if(this.setUIGeneralDefaults && voCtrl) { this.setUIGeneralDefaults(voCtrl, poDocument); };         // 5. 공통 초기값 설정
  if(this.setSpecificDefaults && voCtrl) { this.setSpecificDefaults(voCtrl, poDocument); };           // 6. 개별 초기값 설정

  if(this.setFormAttrs && voCtrl) { this.setFormAttrs(voCtrl, poDocument); };
  if(this.setGeneralAttrs && voCtrl) { this.setGeneralAttrs(voCtrl, poDocument); };                   // 7. 공통 Attrs 적용
  if(this.setUIGeneralAttrs && voCtrl) { this.setUIGeneralAttrs(voCtrl, poDocument); }                // 8. UI 공통 Attrs 적용
  if(this.setSpecificAttrs && voCtrl) { this.setSpecificAttrs(voCtrl, poDocument); }                  // 9. 개별 Attrs 적용

  if(!this.printMode) {
    if(this.setGeneralEvents && voCtrl) { this.setGeneralEvents(voCtrl); }                            // 10. 공통 Events 적용
    if(this.setUIGeneralEvents && voCtrl) { this.setUIGeneralEvents(voCtrl); }                        // 11. UI 공통 Events 적용
    if(this.setSpecificEvents && voCtrl) { this.setSpecificEvents(voCtrl); }                          // 12. 개별 Events 적용
  }

  return voCtrl;
};
/**
 * Main Ctrl을 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 컨트롤을 둘러싸는 최외곽 Div 객체
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.createCtrl = function(poDocument) {};
/**
 * setUIGeneralDefaults.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setUIGeneralDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;
  voDf.position = this.getShapeAttrValue("position",this.position);
  voDf.visible =  this.getShapeAttrValue("visible",this.visible);
  voDf.movable =  this.getShapeAttrValue("movable",this.movable);
  voDf.zIndex =  this.getShapeAttrValue("zIndex", this.zIndex);
  voDf.cursor = this.getShapeAttrValue("cursor", this.cursor);
  voDf.tooltip = this.getShapeAttrValue("tooltip", this.tooltip);
  voDf.tooltipDisplay = this.getShapeAttrValue("tooltipDisplay",this.tooltipDisplay);
  voDf.penCap = this.getShapeAttrValue("penCap",this.penCap);
  voDf.penStyle = this.getShapeAttrValue("penStyle", this.penStyle);
  voDf.penWeight = this.getShapeAttrValue("penWeight",this.penWeight);
  voDf.penColor = this.getShapeAttrValue("penColor",this.penColor);
  voDf.penOpacity = this.getShapeAttrValue("penOpacity",this.penOpacity);
  voDf.joinType = this.getShapeAttrValue("joinType",this.joinType);
  voDf.angle = this.getShapeAttrValue("angle",this.angle);
};
/**
 * setUIGeneralAttrs.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setUIGeneralAttrs = function(poCtrl, poDocument) {
  this.setAttrCtrl("visible",this.df.visible, poCtrl);
//  this.setAttrCtrl("tooltip", this.df.tooltip, poCtrl);
  this.setAttrCtrl("zIndex", this.df.zIndex, poCtrl);
  this.setAttrCtrl("position", this.df.position, poCtrl);
  this.setAttrCtrl("left", this.left, poCtrl);
  this.setAttrCtrl("top", this.top, poCtrl);
  this.setAttrCtrl("width", this.width, poCtrl);
  this.setAttrCtrl("height", this.height, poCtrl);
  this.setAttrCtrl("cursor",this.df.cursor, poCtrl);
};
/**
 * setUIGeneralEvents.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setUIGeneralEvents = function(poCtrl) {
  var voShapeCtrl = poCtrl.childNodes[0].childNodes[0].childNodes[0];
  this.eventManager.addListener(voShapeCtrl, "onclick", this.mediateEvent);
  this.eventManager.addListener(voShapeCtrl, "ondblclick", this.mediateEvent);
  this.eventManager.addListener(voShapeCtrl, "onmousedown", this.mediateEvent);
  this.eventManager.addListener(voShapeCtrl, "onmouseup", this.mediateEvent);
  this.eventManager.addListener(voShapeCtrl, "onmouseover", this.mediateEvent);
  this.eventManager.addListener(voShapeCtrl, "onmousemove", this.mediateEvent);
  this.eventManager.addListener(voShapeCtrl, "onmouseout", this.mediateEvent);
  voShapeCtrl.control = this;
};
/**
 * 개별 초기값을 설정합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setSpecificDefaults = function(poCtrl, poDocument) {};
/**
 * 컨트롤 별 속성들에 속성값을 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setSpecificAttrs = function(poCtrl, poDocument) {};
/**
 * 컨트롤 별 Events를 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setSpecificEvents = function(poCtrl) {};
/**
 * 컨트롤 별 초기값으로 지정된 속성값을 제거합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {};
/**
 * 컨트롤(Control)에 설정된 최신 정보로 실체화 컨트롤(Ctrl)을 새로고침한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.ShapeControl.prototype.refresh = function(poDocument) {
  if(poDocument == null) poDocument = this.document;
  voCtrl = this.getCtrl(poDocument);

  if(this.removeUIGeneralDefaults) { this.removeUIGeneralDefaults(voCtrl, poDocument); };           // 공통 초기값으로 지정된 속성값을 제거
  if(this.removeSpecificDefaults) { this.removeSpecificDefaults(voCtrl, poDocument); };             // 개별 초기값으로 지정된 속성값을 제거

  if(this.refreshTemplate) { this.refreshTemplate(voCtrl, poDocument); };
  if(this.refreshMainStyles) { this.refreshMainStyles(voCtrl, poDocument); };                       // Main Style 새로고침
  if(this.refreshSubStyles) { this.refreshSubStyles(voCtrl, poDocument); };                         // Composite Child Style 새로고침

  if(this.refreshUIGeneralDefaults) { this.refreshUIGeneralDefaults(voCtrl, poDocument); };         // 공통 초기값으로 새로고침
  if(this.refreshSpecificDefaults) { this.refreshSpecificDefaults(voCtrl, poDocument); };           // 개별 초기값으로 새로고침

  if(this.refreshUIGeneralAttrs) { this.refreshUIGeneralAttrs(voCtrl, poDocument); };
  if(this.refreshSpecificAttrs) { this.refreshSpecificAttrs(voCtrl, poDocument); };                 // 개별 속성으로 새로고침

  if(this.refreshUIGeneralEvents) { this.refreshUIGeneralEvents(voCtrl); };                       // UI 공통 Events로 새로고침
  if(this.refreshSpecificEvents) { this.refreshSpecificEvents(voCtrl); };                           // 개별 Events로 새로고침

  if(this.reloadData) { this.reloadData(voCtrl, poDocument); };                                   // Data 새로고침
  if(this.refreshComplete) {this.refreshComplete(voCtrl, poDocument); };                            // 새로고침 최종 처리
};
/**
 * 컨트롤 별 속성들에 대한 새로고침을 수행합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {};
/**
 * 새로고침 최종 처리
 * @param {HTMLDiv} voCtrl 실체화 객체 최외곽 Div
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshComplete = function(poCtrl, poDocument) {
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
};
/**
 * checks if a right-click occurred
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.isRClick = function(e) {
  return (e.mousebutton == 2) ? true : false;
};
/**
 * check if the event happened in the selected element
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.inElement = function(e, psControlId) {
  var voCtrl = e.target;
  while (voCtrl) {
    if(voCtrl.id == psControlId) {
      return true;
    } else if(voCtrl.parentNode) {
      voCtrl = voCtrl.parentNode;
    } else {
      return false;
    }
  }
};


/**
 * positions and shows the context menu
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.showContextMenu = function(x,y) {
  this.canvas.showContextMenu(this.id, this.contextMenuId, x, y);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.atfocus = function(e) {
  if(this.tooltip != "" && this.tooltip != null) {
    if(this.displayTooltip) this.displayTooltip();
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.coclick = function(e) {
  if(this.canvas) this.canvas.setFocusByControl(this, null, e.target);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.comousedown = function(e) {
  if(this.document == null) return;
  var voCanvas = this.canvas;
  // 컨트롤 이동을 처리
  if(this.movable) {
    if(this.document.ondragstart !== "undefined")
    {
      this.document.ondragstart = function() { return false; };
    }
    this.startMove(e);
    e.stopEvent();
  } else {
    if(voCanvas.page.metadata.browser.opera) {
    } else {
      this.document.ondragstart = function() { this.body.dragDrop(); };
    }
  }
////컨텍스트 메뉴를 처리
//  if (!this.inElement(e, this.id))
//     return true;
//  if (!this.isRClick(e)) {
//     return true;
//  } else {
//    var posx=0,posy=0;
//    if(e.pageX || e.pageY) {
//      posx=e.pageX; posy=e.pageY;
//    } else if(e.clientX || e.clientY) {
//      if(document.documentElement.scrollTop) {
//        posx=e.clientX+document.documentElement.scrollLeft;
//        posy=e.clientY+document.documentElement.scrollTop;
//      } else {
//        posx=e.clientX+document.body.scrollLeft;
//        posy=e.clientY+document.body.scrollTop;
//      }
//    }
//    this.showContextMenu(posx,posy);
//    if(this.contextMenuId) e.stopEvent();       // TODO : 향후 변경할것
//  }
};

/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.finalmouseup = function(e) {
  // 컨텍스트 메뉴를 처리
  var voDocument = this.document;
  var voCanvas = this.canvas;
  voCanvas.doCollapseForAllFrame();
  if (!this.inElement(e, this.id))
     return;
  if (!this.isRClick(e)) {
     return;
  } else {
    var posx=0,posy=0;
    if(e.pageX || e.pageY) {
      posx=e.pageX; posy=e.pageY;
    } else if(e.clientX || e.clientY) {
      if(voDocument.documentElement.scrollTop) {
        posx=e.clientX + voDocument.documentElement.scrollLeft;
        posy=e.clientY + voDocument.documentElement.scrollTop;
      } else {
        posx=e.clientX + voDocument.body.scrollLeft;
        posy=e.clientY + voDocument.body.scrollTop;
      }
    }
    this.showContextMenu(posx,posy);
    if(this.contextMenuId) e.stopEvent();       // TODO : 향후 변경할것
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.comouseover = function(e) {
  if(this.df.tooltipDisplay) {
    this.tooltipHandler.show(e);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.comouseout = function(e) {
  if(this.df.tooltipDisplay) this.tooltipHandler.hide(e);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.comousemove = function(e) {
  if(this.df.tooltipDisplay) this.tooltipHandler.show(e);
};
/**
 * 이벤트를 연결한다.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.mediateEvent = function(e) {
  //base.runEvent(e, base);
  var vcCtl = this.control;
  if(vcCtl == null || (e == null && page.metadata.browser.ie == 0)) return;
  vcCtl.runEvent(e, vcCtl);
};
/**
 * Ctrl의 속성 값을 설정한다.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setAttrCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(); }

  if(psAttrValue == null) return;
  if(psAttrName == "visible") {
    psAttrValue == true ? poCtrl.style.display = "block" : poCtrl.style.display = "none"
  } else if(psAttrName == "tooltip") {
    this.tooltipHandler.setCtrl();
  } else if(psAttrName == "cursor") {
    poCtrl.style["cursor"] = psAttrValue;
  } else if(poCtrl.style[psAttrName] == undefined) {
    poCtrl[psAttrName] = psAttrValue;
  } else if(psAttrName == "left" || psAttrName == "top" || psAttrName == "width" || psAttrName == "height") {
    if(psAttrValue == "" || psAttrValue == null) {
      poCtrl.style[psAttrName] = psAttrValue;
    } else {
      if(psAttrValue < 0) psAttrValue = 0;
      poCtrl.style[psAttrName] = psAttrValue + "px";
    }
  } else {
    poCtrl.style[psAttrName] = psAttrValue;
  }
  if(poCtrl[psAttrName] != undefined) { poCtrl[psAttrName] = psAttrValue; }

  // Sub Ctrl이 있어 속성 값을 하위로 전달해야 되는 경우
  if(this.setAttrSubCtrl) { this.setAttrSubCtrl(psAttrName, psAttrValue, poCtrl); }
};
/**
 * Ctrl의 속성 값을 구한다.
 * @param {String} psAttrName 속성명
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return Ctrl의 속성 값.
 * @type String
 */
eXria.controls.xhtml.ShapeControl.prototype.getAttrValueCtrl = function(psAttrName, poCtrl, poDocument) {
  var vsAttrValue = null;
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  if(poCtrl.style[psAttrName] == undefined) {
    vsAttrValue = poCtrl.getAttribute(psAttrName);
  } else {
    vsAttrValue = poCtrl.style[psAttrName];
  }
  if(vsAttrValue == undefined) { vsAttrValue = null; }

  return vsAttrValue;
};
/**
 * Ctrl의 속성을 제거한다.
 * @param {String} psAttrName 속성명
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return void
 * @type void
 */
eXria.controls.xhtml.ShapeControl.prototype.removeAttrCtrl = function(psAttrName, poCtrl, poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  if(this[psAttrName] != null) { this[psAttrName] = null; }
  poCtrl.removeAttribute(psAttrName);
};
/**
 * 기존에 설정된 UI의 공통 초기값을 제거한다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.removeUIGeneralAtrrDefault = function(poCtrl, poDocument) {
    this.setAttrCtrl("display", "", poCtrl);
    this.setAttrCtrl("zIndex", "", poCtrl);
    this.setAttrCtrl("position", "", poCtrl);
    this.setAttrCtrl("cursor", "", poCtrl);
};
/**
 * setMainCtrlStyles.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
  poCtrl.className = this.getCSSClass(this, 0);
};
/**
 * refreshMainStyles.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshMainStyles = function(poCtrl, poDocument) {
  this.setMainCtrlStyles(poCtrl, poDocument);
};
/**
 * refreshUIGeneralDefaults.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshUIGeneralDefaults = function(poCtrl, poDocument) {
  this.setUIGeneralDefaults(poCtrl, poDocument);
};
/**
 * refreshSpecificDefaults.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  if(this.setSpecificDefaults)this.setSpecificDefaults(poCtrl, poDocument);
};
/**
 * Control에 설정된 공통 UI 정보로 Ctrl을 새로고침한다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshUIGeneralAttrs = function(poCtrl, poDocument) {
  this.setUIGeneralAttrs(poCtrl);
};
/**
 * refreshUIGeneralEvents.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshUIGeneralEvents = function(poCtrl, poDocument) {
  this.setUIGeneralEvents(poCtrl);
};
/**
* 서브 컨트롤 실체화 객체를 반환.
* @param {String} psTagName 서브 영역 실체화 객체 TabName
* @param {HTMLDiv} poCtrl 실체화 컨트롤
* @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
* @return {Object} 해당 TagName을 갖는 서브 영역 실체화 객체 TabName
* @private
*/
eXria.controls.xhtml.ShapeControl.prototype.getSubCtrl = function(psTagName, poCtrl, poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  var subCtrl = poCtrl.getElementsByTagName(psTagName)[0];
  return subCtrl;
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.getSpecificDefaultValue = function(psAttrName) {};
/**
 * 투명도 퍼센트 계산 메소드.
 * @param {Number} pnPercent 투명도 퍼센트
 * @return 투명도 퍼센트
 * @type Number
 */
eXria.controls.xhtml.ShapeControl.prototype.toPercent = function(pnPercent) {
  var vnFloat = pnPercent/100;
  return vnFloat;
};
/**
 * 지정된 라인 끝단 스타일을 속성 지정이 가능한 Number형 값으로 변환하는 메소드.
 * @param {String} psAttrName 속성명
 * @return unknown
 * @type Number
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.toConstPencap = function(psAttrName) {
  switch(psAttrName) {
    case "flat":
      return 0;
    case "round":
      return 1;
    case "square":
      return 2;
    default:
      return 1;
  }
};
/**
 * 지정된 라인 스타일을 속성 지정이 가능한 Number형 값으로 변환하는 메소드.
 * @param {String} psAttrName 속성명
 * @return unknown
 * @type Number
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.toConstPenstyle = function(psAttrName) {
  switch(psAttrName) {
    case "solid":
      return 0;
    case "dot":
      return 1;
    case "dash":
      return 2;
    default:
      return 0;
  }
};
/**
 * 지정된 라인 접합부분 스타일을 속성 지정이 가능한 Number형 값으로 변환하는 메소드.
 * @param {String} psAttrName 속성명
 * @return unknown
 * @type Number
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.toConstJointype = function(psAttrName) {
  switch(psAttrName) {
    case "miter":
      return 0;
    case "round":
      return 1;
    case "bevel":
      return 2;
    default:
      return 1;
  }
};
/**
 * Shape Control의 속성명을 일반 Control의 속성명으로 변경.
 * @param {String} psAttrName 속성명
 * @return 변경된 속성명
 * @type String
 */
eXria.controls.xhtml.ShapeControl.prototype.convertAttrName = function(psAttrName) {
  switch(psAttrName) {
    case "focusPenWeight" :
      return "focusBorderWidth";
    case "focusPenColor" :
      return "focusBorderColor";
    case "focusPenStyle" :
      return "focusBorderStyle";
    default :
      return psAttrName;
  }
};


/**
 * Control의 속성값을 Shape Control의 속성값으로 변경.
 * @param {String} psAttrValue 속성값
 * @return 변경된 속성값
 * @type String
 */
eXria.controls.xhtml.ShapeControl.prototype.convertAttrValue = function(psAttrValue) {
  vsAttrValue = psAttrValue;
  switch(psAttrValue) {
    case "dotted" :
      if(gCore.browser.msie && this.documentMode < 9) vsAttrValue = "dot";
      else vsAttrValue = "1, " + parseInt(this.getShapeAttrValue("focusPenWeight",this.focusPenWeight)) * 2;
      return vsAttrValue;
    case "dashed" :
      if(gCore.browser.msie && this.documentMode < 9) vsAttrValue = "dash";
      else vsAttrValue = "15, " + parseInt(this.getShapeAttrValue("focusPenWeight",this.focusPenWeight)) * 2;
      return vsAttrValue;
    default :
      return vsAttrValue;
  }
};
/**
 * 불투명도를 설정한다.
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {String} psFilter 필터종류
 * @param {String} psOpacity 불투명도
 * @return void
 * @type void
 */
eXria.controls.xhtml.ShapeControl.prototype.setOpacity = function(poCtrl, psFilter, psOpacity) {
  var voStyle = poCtrl.style;
  voStyle.filter = psFilter;
  voStyle.KHTMLOpacity = psOpacity;
  voStyle.MozOpacity = psOpacity;
  voStyle.opacity = psOpacity;
};

/**
 * 컨트롤의 이동 또는 크기 변경시에 윤곽선을 나타내주는 DIV 객체.
 * @ignore
 */
eXria.controls.xhtml.ShapeControl_paneHandler = function(poParent) {
  this.parent = poParent;
 };
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl_paneHandler.prototype.createPane = function() {
  var voParent = this.parent;
  var voDocument = voParent.window.document;
  var voCtrl = voParent.getCtrl();
  var voParentNode = voCtrl.parentNode;
  var thisStyle = voCtrl.style;
  var voPane = voDocument.createElement("div");
  voPane.setAttribute("id", voParent.id + "_pane");

  var voStyle = voPane.style;
  voStyle.position = "absolute";
  voStyle.left = thisStyle.left;
  voStyle.top = thisStyle.top;
  var vnBorderWidth = voParent.borderWidth;
  if(voParent.borderStyle == null || voParent.borderStyle == "none") vnBorderWidth = 0;
  voStyle.width = (voParent.width + 2 * vnBorderWidth) + "px";
  voStyle.height = (voParent.height + 2 * vnBorderWidth) + "px";
  voStyle.backgroundColor = "yellow";
  voStyle.opacity = voParent.paneOpacity / 100;
  voStyle.filter = "alpha(opacity=" + voParent.paneOpacity + ")";
  voStyle.zIndex = 1000010; //Number(thisStyle.zIndex) + 1;
  voStyle.borderColor ="black";
  voStyle.borderStyle ="dotted";
  voStyle.borderWidth = "1px";
  // TODO : voStyle.display = "none";
  voParentNode.appendChild(voPane);
  return voPane;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl_paneHandler.prototype.getStyle = function() {
  var voParent = this.parent;
  var voDocument = voParent.document;
  var voPane = voDocument.getElementById(voParent.id + "_pane");
  return voPane.style;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl_paneHandler.prototype.getCtrl = function() {
  var voParent = this.parent;
  var voDocument = voParent.document;
  var voPaneCtrl = voDocument.getElementById(voParent.id + "_pane");
  return voPaneCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl_paneHandler.prototype.removePane = function() {
  var voParent = this.parent;
  var voParentNode = voParent.getCtrl().parentNode;
  var voPaneCtrl = voParent.paneHandler.getCtrl();
  voPaneCtrl.style.display = "none";
  voParentNode.removeChild(voPaneCtrl);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl_paneHandler.prototype.applyAttrCtrl = function(psAttrName, psAttrValue) {
  var voParent = this.parent;
  var voPaneCtrl = voParent.paneHandler.getCtrl();
  if(voPaneCtrl.style[psAttrName] == undefined) {
    voPaneCtrl.setAttribute(psAttrName, psAttrValue);
  } else {
    voPaneCtrl.style[psAttrName] = psAttrValue;
  }
};

/**
 * 공통 초기화 수행
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.initUIGeneral = function() {
  this.tooltipHandler = new eXria.controls.xhtml.UIControl_tooltipHandler(this);                            // tooltipHandler에 컨트롤 참조를 설정
  this.paneHandler = new eXria.controls.xhtml.ShapeControl_paneHandler(this);
  this.dragDropHandler = new eXria.controls.xhtml.UIControl_dragDropHandler(this);
};
/**
 * 컨트롤 이동 관련
 * @return 0
 * @type Number
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.getClientAbsLeft = function() { return 0; };
/**
 * 컨트롤 이동 관련
 * @return 0
 * @type Number
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.getClientAbsTop = function() { return 0; };
/**
 * 컨트롤의 동적 위치 이동 허용여부 지정.
 * @param {Boolean} pbMove 위치이동 가능 여부
 * @return void
 */
eXria.controls.xhtml.ShapeControl.prototype.setMove = function(pbMove) {
  var voDocument = this.document;
  var voCtrl = this.getCtrl();
  if(voCtrl == null) return;

  if(pbMove) {
    this.movable = true;
  } else {
    this.movable = false;
    voDocument.onmousemove = null;
    voDocument.onmouseup = null;
  }
};
/**
 * startMove<br>
 * 컨트롤 동적 위치 이동이 가능한 경우 컨트롤에 mousedown이벤트 발생 시 처리 수행
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.startMove = function(e) {
  if (this.disabled == true) { return; }

  var voDocument = this.document;
  var voCtrl = this.getCtrl();
  var voParentNode = voCtrl.parentNode;
  var voPane = this.paneHandler.createPane();
  var voPaneStyle = voPane.style;
  var voParentStyle = voParentNode.style;

  var voEvent = new eXria.event.Event(e, this.window);
  var voTarget = voEvent.target;
  this.mode = voTarget.style.cursor;

  this.clientAbsLeft = this.getClientAbsLeft();
  this.clientAbsTop = this.getClientAbsTop();

  var vnMouseX = voEvent.e.clientX - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY - this.clientAbsTop;

  var vnPaneLeft = parseInt(voPaneStyle.left);
  var vnPaneTop = parseInt(voPaneStyle.top);
  this.leftOffset = vnPaneLeft - vnMouseX;
  this.topOffset = vnPaneTop - vnMouseY;

  voPaneStyle.display = "block";
  voDocument.body.style.cursor = "move";
  this.getCtrl().style.cursor = "move";

  voPane.onmousemove = function(e) { this.control.onMove(e); };
  voPane.onmouseup = function(e) { this.control.stopMove(e); };
  voPane.control = this;
  voDocument.onmousemove =  function(e) { this.control.onMove(e); };
  voDocument.onmouseup =  function(e) { this.control.stopMove(e); };
  voDocument.control = this;
};
/**
 * 컨트롤 동적 위치 이동 시 마우스 드래그 상태에서의 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.onMove = function(e) {
  var voCtrl = this.getCtrl();
  var voParentNode = voCtrl.parentNode;
  var voPaneCtrl = this.paneHandler.getCtrl();
  if(voCtrl == null || voPaneCtrl == null) {
      return;
  }

  var voStyle = voPaneCtrl.style;

  var voEvent = new eXria.event.Event(e, this.window);
  var vnMouseX = voEvent.e.clientX; // - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY; // - this.clientAbsTop;

  var vnNewLeft = vnMouseX + this.leftOffset;
  var vnNewTop = vnMouseY + this.topOffset;

/*
  var vnWidth = parseInt(voStyle.width);
  var vnHeight = parseInt(voStyle.height);

  var voClientStyle = voCtrl.style;
  var vnClientWidth = parseInt(voClientStyle.width);
  var vnClientHeight = parseInt(voClientStyle.height);

  if (vnNewLeft < this.adjustOffset) {
      vnNewLeft = 0;
  } else {
      vnNewLeft = vnClientWidth - vnWidth;
  }

  if (vnNewTop < this.adjustOffset) {
      vnNewTop = 0;
  } else {
      vnNewTop = vnClientHeight - vnHeight;
  }
*/
if(voParentNode.style.left == null || voParentNode.style.left == "") voParentNode.style.left = 0;
if(voParentNode.style.top == null || voParentNode.style.top == "") voParentNode.style.top = 0;
  voStyle.left = vnNewLeft - parseInt(voParentNode.style.left) + "px";
  voStyle.top = vnNewTop - parseInt(voParentNode.style.top) + "px";
};
/**
 * 컨트롤 동적 위치 이동 시 mouseup 이벤트에서의 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.stopMove = function(e) {
  if (this.disabled == true) { return; }

  var voDocument = this.document;
  var voCtrl = this.getCtrl();
  var voParentNode = voCtrl.parentNode;
  var voPane = this.paneHandler.getCtrl();
  var voPaneStyle = voPane.style;
  var voParentStyle = voParentNode.style;

  this.left = parseInt(voPaneStyle.left);
  this.top = parseInt(voPaneStyle.top);
  // TODO : this.width = parseInt(voPaneStyle.width);
  // TODO : this.height = parseInt(voPaneStyle.height);
  this.refresh();
  this.paneHandler.removePane();

  // Check
  voDocument.body.style.cursor = "auto";
  voCtrl.style.cursor = "auto";

  voPane.onmousemove = null;
  voPane.onmouseup = null;
  voDocument.onmousemove = null;
  voDocument.onmouseup = null;

  this.mode = null;
  this.leftOffset = -1;
  this.topOffset = -1;
  this.rightOffset = -1;
  this.bottomOffset = -1;
};
/**
 * 포커스 변경에 따른 style 변경 처리.
 * @param {Boolean} pbFocus 포커스 in/out 여부
 * @return void
 * @type void
 */
eXria.controls.xhtml.ShapeControl.prototype.setFocusStyle = function(pbFocus) {
  var voCtrl = this.getCtrl();
  var voShapeCtrl = voCtrl.childNodes[0].childNodes[0].childNodes[0];

  var vsStrokeWeight = null;
  var vsStrokeColor = null;
  var vsStrokeStyle = null;

  if(gCore.browser.msie && this.documentMode < 9){
    var voStrokeColorObj = null;
    var voStrokeStyleObj = null;
    if(gCore.browser.msie < 8.0) {
      vsStrokeWeight = voShapeCtrl.getAttribute("strokeweight");
      voStrokeColorObj = voShapeCtrl.getAttribute("strokecolor");
      vsStrokeWeight = (vsStrokeWeight == null) ? voShapeCtrl["strokeweight"] : vsStrokeWeight;
      voStrokeColorObj = (voStrokeColorObj == null) ? voShapeCtrl["strokecolor"] : voStrokeColorObj;
    } else {
      vsStrokeWeight = voShapeCtrl["strokeweight"];
      voStrokeColorObj = voShapeCtrl["strokecolor"];
    }
    voStrokeStyleObj = voShapeCtrl.stroke.dashstyle;
    vsStrokeColor = voStrokeColorObj.value;
    vsStrokeStyle = voStrokeStyleObj.value;
  }else{
    vsStrokeWeight = voShapeCtrl.getAttribute("stroke-width");
    vsStrokeColor = voShapeCtrl.getAttribute("stroke");
    vsStrokeStyle = voShapeCtrl.getAttribute("stroke-dasharray");
  }

  if(this.oldPenWeight == null) {
    this.oldPenWeight = vsStrokeWeight;
    this.oldPenColor = vsStrokeColor;
    this.oldPenStyle = vsStrokeStyle;
  }

  if(pbFocus && this.focusDisplay) {
    var vsFocusBorderWidth = this.getShapeAttrValue("focusPenWeight",this.focusPenWeight);
    if(vsFocusBorderWidth) {
      if(vsFocusBorderWidth == "auto") {
        vsStrokeWeight = this.getShapeAttrValue("penWeight", this.penWeight) + "px";
      } else {
        vsStrokeWeight = vsFocusBorderWidth + "px";
      }
    }
    vsStrokeColor = this.getShapeAttrValue("focusPenColor", this.focusPenColor);
    vsStrokeStyle = this.getShapeAttrValue("focusPenStyle", this.focusPenStyle);

    if(gCore.browser.msie && this.documentMode < 9){
      if(vsStrokeStyle == "none" || vsFocusBorderWidth == 0) voShapeCtrl.stroke.on = "false";
      else voShapeCtrl.stroke.on = "true";
      voShapeCtrl.strokeweight = vsStrokeWeight;
      voShapeCtrl.strokecolor = vsStrokeColor;
      voShapeCtrl.stroke.dashstyle = vsStrokeStyle;
    }else{
      if(vsStrokeStyle == "none" || vsFocusBorderWidth == 0) vsStrokeWeight = "0";
      voShapeCtrl.setAttribute("stroke-width", vsStrokeWeight);
      voShapeCtrl.setAttribute("stroke", vsStrokeColor);
      voShapeCtrl.setAttribute("stroke-dasharray", vsStrokeStyle);
    }
  } else {
    vsStrokeWeight = "";
    vsStrokeStyle = "";
    vsStrokeColor = "";
    if(gCore.browser.msie && this.documentMode < 9){
      if(this.oldPenStyle == "none" || this.oldPenWeight == 0) voShapeCtrl.stroke.on = "false";
      else voShapeCtrl.stroke.on = "true";
      voShapeCtrl.strokeweight = this.oldPenWeight ? this.oldPenWeight : vsStrokeWeight;
      voShapeCtrl.strokecolor = this.oldPenColor ? this.oldPenColor : vsStrokeColor;
      voShapeCtrl.stroke.dashstyle = this.oldPenStyle ? this.oldPenStyle : vsStrokeStyle;
    }else{
      voShapeCtrl.setAttribute("stroke-width", this.oldPenWeight ? this.oldPenWeight : vsStrokeWeight);
      voShapeCtrl.setAttribute("stroke", this.oldPenColor ? this.oldPenColor : vsStrokeColor);
      voShapeCtrl.setAttribute("stroke-dasharray", this.oldPenStyle ? this.oldPenStyle : vsStrokeStyle);
    }
  }
};
/**
 * 디폴트 속성값을 구함.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 디폴트 속성값
 * @type String
 */
eXria.controls.xhtml.ShapeControl.prototype.getAttrValue = function(psAttrName, psAttrValue) {
  psAttrName = this.convertAttrName(psAttrName);

  if(psAttrValue != null) {
    return psAttrValue;
  } else {
    var vsAttrValue = null;
    if(this.canvas)  vsAttrValue = this.canvas.getFormExtendAttrValue(psAttrName);
    if(vsAttrValue != null) {
      vsAttrValue = this.convertAttrValue(vsAttrValue);
      return vsAttrValue;
    } else {
      vsAttrValue = this.getSpecificDefaultValue(psAttrName);
      if(vsAttrValue == null) vsAttrValue = this.getShapeDefaultValue(psAttrName);
      return vsAttrValue;
    }
  }

};
/**
 * 도형 속성의 디폴트 값을 구함.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 UI관련 속성의 디폴트 값
 * @type String
 */
eXria.controls.xhtml.ShapeControl.prototype.getShapeAttrValue = function(psAttrName, psAttrValue) {
  psAttrName = this.convertAttrName(psAttrName);

  if(psAttrValue != null) {
    return psAttrValue;
  } else {
    var vsAttrValue = this.canvas.getFormExtendAttrValue(psAttrName);
    if(vsAttrValue != null) {
      vsAttrValue = this.convertAttrValue(vsAttrValue);
      return vsAttrValue;
    } else {
      vsAttrValue = this.getSpecificDefaultValue(psAttrName);  // TODO : 위의 소스로 교체할것
      if(vsAttrValue == null) vsAttrValue = this.getShapeDefaultValue(psAttrName);
      return vsAttrValue;
    }
  }
};
/**
 * 도형의 디폴트 값을 구함.
 * @param {String} psAttrName 속성명
 * @return 해당 속성의 공통 디폴트 값
 * @type String
 */
eXria.controls.xhtml.ShapeControl.prototype.getShapeDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.ShapeControl[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;
};
/**
 * toolip의 디폴트 값을 구함.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 toolip 디폴트 값
 * @type String
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.getTooltipAttrValue = function(psAttrName, psAttrValue) {
  if(psAttrValue != null) return psAttrValue;
  else return this.getTooltipDefaultValue(psAttrName);
};
/**
 * toolip의 공통 디폴트 값을 구함.
 * @param {String} psAttrName 속성명
 * @return 해당 속성의 toolip 공통 디폴트 값
 * @type String
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.getTooltipDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.ToolTip[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;
};
/**
 * 컨트롤에 데이타 로딩 작업 수행.
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.load = function() {
  if(this.loadCanvasConfig) this.loadCanvasConfig();
  if(this.data && this.loadData) this.loadData(this.document);
  if(this.loadComplete) this.loadComplete(this.document);
};
/**
 * 컨트롤이 page에 load 될때 Canvas 객체의 속성을 참조해야될 작업 수행
 * @private
 */
eXria.controls.xhtml.ShapeControl.prototype.loadCanvasConfig = function() {
  var voDocument = this.document;
  this.tooltipHandler.document = voDocument;
  this.paneHandler.document = voDocument;
  this.dragDropHandler.document = voDocument;

  if(this.canvas && this.tooltip != null && this.tooltip.length != 0) {
//    this.tooltipHandler.arrowImage = "url('" + this.canvas.page.metadata.resourceBaseUrl + "eXria/controls/xhtml/images/arrow.gif')";
//    this.document.getElementById(this.id + "_TooltipArrow").style.backgroundImage = "url('" + this.canvas.page.metadata.resourceBaseUrl + "eXria/controls/xhtml/images/arrow.gif')";
    this.tooltipHandler.setCtrl();
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ShapeControl.prototype.applyAttrSimple = null;
/**
 * CSS Class 명을 반환한다.
 * @param poCtrl
 * @param pnType 0 : OuterClass, 1 : Class
 * @return String
 */
eXria.controls.xhtml.ShapeControl.prototype.getCSSClass = function(poCtrl, pnType, psSubClass){
  var vsPreFix = "Default";
  var vsType = this.toString();
  if(pnType === null || pnType === undefined) pnType = 0;
  var vsSubClass = "";
  var voClassObj = this;
  var vaSubObj = null;
  if(psSubClass){
    voClassObj = voClassObj[psSubClass];
    vsSubClass = "_" + psSubClass.split(".").join("_");
  }

  var vsUIControlClass = vsPreFix + "_ShapeControl_" + ["OuterClass", "Class"][pnType];
  var vsControlClass = "";
  if(this.control){
    vsControlClass = vsPreFix + "_" + this.control.toString() + "_" +  vsType + "s" + vsSubClass + "_" + ["OuterClass", "Class"][pnType];
  }else{
    vsControlClass = vsPreFix + "_" + vsType + vsSubClass + "_" + ["OuterClass", "Class"][pnType];
  }

  var vsUserClass = null;
  if(pnType === 0 && voClassObj != null){
    if(voClassObj.outerClassName) vsUserClass = voClassObj.outerClassName;
  }else if(pnType === 1 && voClassObj != null){
    if(voClassObj.className) vsUserClass = voClassObj.className;
  }
  if(vsUserClass == null){
    vsUserClass = "";
  }
  return vsSubClass == "" ? vsUIControlClass + " " + vsControlClass + " " + vsUserClass : vsControlClass + " " + vsUserClass;
};
/**
 * 컨트롤 위치 및 크기를 재설정하기 위한 메소드
 */
eXria.controls.xhtml.ShapeControl.prototype.resize = function() {
  if(this.isResize === false) this.refreshPos();
  else this.refresh();
};
/**
 * left, top 속성 설정에 의해 변경된 컨트롤 위치 값을 실체화 객체에 반영하는 메소드
 */
eXria.controls.xhtml.ShapeControl.prototype.refreshPos = function() {
  var voCtrl = this.ctrl;
  voCtrl.style.left = this.left + "px";
  voCtrl.style.top = this.top + "px";
};
// End of Control