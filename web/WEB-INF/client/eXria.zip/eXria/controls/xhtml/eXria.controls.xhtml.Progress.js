/**
 * @fileoverview
 * Concreate xhtml Progress(XHTML Progress 컨트롤)
 * @author 이종녕
 */

/**
 * @class 시간이 지남에따라 반응하는 프로그래스바 컨트롤을 생성하는 class입니다.<br>
 * XHTML Progress Control.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Progress 객체
 * @type eXria.controls.xhtml.Progress
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Progress = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 200 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 진행 표시 Bar의 색.
   * @type String
   */
  this.progressColor = null;
  /**
   * 한번에 증가되는 크기.
   * @type Number
   */
  this.step = null;
  /**
   * 맨처음 시작되는 Range상의 위치.
   * @type Number
   */
  this.startPos = null;
  /**
   * 진행바의 현재 위치 값.
   * @type Number
   * @private
   */
  this.currentPos = null;
  /**
   * Timer를 통한 동작 주기 (단위 milisecond = 1/1000초).
   * @type Number
   */
  this.interval = null;
  /**
   * 최소 범위.
   * @type Number
   */
  this.min = null;
  /**
   * 최대 범위.
   * @type Number
   */
  this.max = null;
  /**
   * 구동중인 Time ID.
   * @type String
   * @private
   */
  this.timeId = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 일시정지부울값.
   * @type Boolean
   * @private
   */
  this.mbpause = null;
  /**
   * 투명도 설정.
   * @type Number
   */
  this.opacity = 0.2;
  /**
   * 대기 모드 상태 여부
   * @type Boolean
   * @private
   */
  this.mbwaiting = null;
  /**
   * 실체화 컨트롤 객체 참조 변수
   * @type HTMLDiv
   * @private
   */
  this.loading_div = null;

  /**
   * 연계될 컨트롤 id.
   * @type String
   * @private
   */
  this.target = null;

  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};

  /**
   * 진행상태를 표시할때 나타내는 단위 문자
   * @member eXria.controls.xhtml.Progress
   * @type String
   * @private
   */
  this.unitStr = "%";

  this.cursor = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Progress);
//////////////////////////////////////////////////////////////////
// 메소드

/**
 * ProgressBar 의 최소값을 설정
 * @member eXria.controls.xhtml.Progress
 * @param {Number} min 최소값
 * @type void
 */
eXria.controls.xhtml.Progress.prototype.setMin = function(min){
  this.min = min;
}

/**
 * ProgressBar 의 최대값을 설정
 * @member eXria.controls.xhtml.Progress
 * @param {Number} max 최대값
 * @type void
 */
eXria.controls.xhtml.Progress.prototype.setMax = function(max){
  this.max = max;
}

/**
 * ProgressBar 의 진행상태를 나타내는 표시 단위 설정
 * @member eXria.controls.xhtml.Progress
 * @param {String} unit 표시단위 문자열
 * @type void
 */
eXria.controls.xhtml.Progress.prototype.setUnitStr = function(unit){
  this.unitStr = unit;
}

/**
 * ProgressBar 의 진행상태를 특정 위치만큼 이동
 * @member eXria.controls.xhtml.Progress
 * @param {Number} pos 이동할 위치 또는 현재까지의 진행상태 값
 * @type void
 */
eXria.controls.xhtml.Progress.prototype.setCurrentPos = function(pos){
  if (typeof(this.id) != undefined) {
      var voLabel = this.getSubCtrl("label");
      var voBar = this.getSubCtrl("div");

      // 프로그래스 바의 진행 표시...
    var prsPos = pos * this.width / this.max;

    if(prsPos >= this.innerWidth ) {
      prsPos = this.innerWidth;
      pos = this.max;
    }

    innerStr = commify(pos) + " / " + commify(this.max) + " " + this.unitStr;
      voLabel.innerHTML = innerStr;
      voBar.style.width = prsPos;
  }
}


function commify(n) {
  var reg = /(^[+-]?\d+)(\d{3})/;   // 정규식
  n += '';                          // 숫자를 문자열로 변환

  while (reg.test(n))
    n = n.replace(reg, '$1' + ',' + '$2');

  return n;
}

/**
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.createCtrl = function(poDocument){
  var voCtrl = poDocument.createElement("div");

  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.setTemplate = function(poCtrl, poDocument){
  // 진행수치  라벨 구성..
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<label class='" + vsClass + "' ");
  vaTemplate.push("@attStrBuf"); //1
  vaTemplate.push("style='position:absolute;z-index:2;background-color:transparent;");
  vaTemplate.push("@cssStrBuf");  //3
  vaTemplate.push("'>");
  vaTemplate.push("loading..");
  vaTemplate.push("</label>");

  // Progress bar 구성
  //vaTemplate.push("<div style='position:absolute;z-index:1;");
  // 2009.09.15 텍스트 겹치는 현상
  vaTemplate.push("<div style='position:absolute;z-index:1;");
  vaTemplate.push("border-width:1px;left:0px;top:0px;");
  vaTemplate.push("@cssStrBuf");  //9
  vaTemplate.push("'/>");
};
/**
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;
  this.startPos = this.getAttrValue("startPos", this.startPos);
  var vsClass = this.getCSSClass(this, 1);
  poCtrl.className = poCtrl.className + " " + vsClass;
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.step = this.getAttrValue("step",this.step);
  this.startPos = this.getAttrValue("startPos",this.startPos);
  this.interval = this.getAttrValue("interval",this.interval);
  this.min = this.getAttrValue("min",this.min);
  this.max = this.getAttrValue("max",this.max);
  this.progressColor = this.getAttrValue("progressColor",this.progressColor);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.setSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  if(this.disabled) vaAttStrBuf.push("disabled ")
  vaTemplate[1] = vaAttStrBuf.join("");
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  //vfcSetCssStrBuf(vaCssStrBuf, "left", this.innerWidth / 2 - 7, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "left", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", "center");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vaTemplate[3] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.per_to_num(this.startPos), "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "width", this.width, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.progressColor);
  vaTemplate[9] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");

  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Progress.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voBar = this.getSubCtrl("div",poCtrl);
  var voLabel = this.getSubCtrl("label",poCtrl);

  switch(psAttrName) {
    case "disabled" :
    case "cursor":
      this.setAttrCtrl(psAttrName,psAttrValue, voLabel);
      break;
    case "width" :
      this.setAttrCtrl("width", this.per_to_num(this.startPos), voBar);
      this.setAttrCtrl("left", (this.innerWidth / 2 - 7), voLabel);
      break;
    case "height" :
      this.setAttrCtrl("height", this.innerHeight, voBar);
      this.setAttrCtrl("top", (this.innerHeight / 2 - 7), voLabel);
      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  this.setSpecificAttrs(poCtrl, poDocument);
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Progress.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voBar = this.getSubCtrl("div",voCtrl);
  var voLabel = this.getSubCtrl("label",voCtrl);
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }

  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
//  case "borderTopWidth" :
//  case "borderTopHeight" :
//    this.innerHeight = this.width - this.borderTopWidth - this.borderBottomWidth;
//    if(this.innerHeight < 0) this.innerHeight = 0;
//    this.setAttrCtrl("height", this.innerHeight, voCtrl);
//    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
//    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
     this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
     if(this.innerHeight < 0) this.innerHeight = 0;
     this.setAttrCtrl("height", this.innerHeight, voCtrl);
     this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
     break;
  case "backgroundColor":
    this.setAttrCtrl("backgroundColor", psAttrValue, voBar);
    this.refresh(poDocument);
    break;
  case "color" :
    this.setAttrCtrl("backgroundColor", psAttrValue, voLabel);
    break;
  case "outerClassName" :
  case "className" :
    this.refresh(poDocument);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
* 서브 컨트롤 실체화 객체를 얻어옵니다.
* @param {String} psTagName 얻어올 테그네임
* @return subControl 실체화 객체
* @type Object
* @private
*/
eXria.controls.xhtml.Progress.prototype.getSubCtrl = function(psTagName,poCtrl,poDocument){
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  var subCtrl = poCtrl.getElementsByTagName(psTagName)[0];
  return subCtrl;
};
/**
 * 바를 실행시킵니다.
 * @private
 */
eXria.controls.xhtml.Progress.prototype.startbar = function(psId){
  var voControl = this.canvas.page.getControl(psId);
  if (voControl.currentPos >= 100) voControl.currentPos = 100;
  voControl.moveProgress(voControl.currentPos);
  if (voControl.currentPos == 100) voControl.stop();
  voControl.currentPos = voControl.currentPos + voControl.step;
}
/**
 * 퍼센트를 숫자로 계산합니다.
 * @private
 */
eXria.controls.xhtml.Progress.prototype.per_to_num = function(per){
  var num = (this.innerWidth / 100) * per;
  //return num + "px";
  return num;
};
/**
 * 프로그래스의 진행 표시를 이동시킵니다.
 * @param {Number} pnStep 진행률
 */
eXria.controls.xhtml.Progress.prototype.moveProgress = function(pnStep){
  //로딩 되어 있는지 확인한다..
  if (typeof(this.id) != "undefined") {
    var voDocument = this.document;
    var voLabel = this.getSubCtrl("label");
    var voBar = this.getSubCtrl("div");
    // 프로그래스 바의 진행 표시...
//    voLabel.innerHTML = pnStep + "%";
    voLabel.removeChild(voLabel.firstChild);
    voLabel.appendChild(voDocument.createTextNode(pnStep + "%"));
    voBar.style.width = this.per_to_num(pnStep) + "px";
  }
};
/**
 * 프로그래스를 시작합니다.
 * @param {String} psId 컨트롤 식별자
 */
eXria.controls.xhtml.Progress.prototype.start = function(psId){
  this.stop();
  this.target = psId;
  if(psId)this.startWaiting(psId);
  this.mbpause = true;
  this.currentPos = this.startPos;
  // setInterval함수로 구현
  var vaStrBuf = [];
  vaStrBuf.push("page.getControl('");
  vaStrBuf.push(this.id);
  vaStrBuf.push("').startbar('");
  vaStrBuf.push(this.id);
  vaStrBuf.push("');")

  this.timeId = this.window.setInterval(vaStrBuf.join(""), this.interval);
  vaStrBuf = null;
};
/**
 * 프로그래스를 일시정지상태로 만들어줍니다.
 */
eXria.controls.xhtml.Progress.prototype.pause = function(){
  if(this.mbpause == null)
    return null;
  var voWindow = this.window;
  if (this.mbpause) {
    voWindow.clearInterval(this.timeId);
    this.mbpause = false;
  }
  else{
    var vaStrBuf = [];
    vaStrBuf.push("page.getControl('");
    vaStrBuf.push(this.id);
    vaStrBuf.push("').startbar('");
    vaStrBuf.push(this.id);
    vaStrBuf.push("');")
    this.timeId = voWindow.setInterval(vaStrBuf.join(""), this.interval);
    this.mbpause = true;
  }
};
/**
 * 포로그래스 동작을 멈춥니다.
 */
eXria.controls.xhtml.Progress.prototype.stop = function(){
  this.window.clearInterval(this.timeId);
  this.stopWaiting(this.target);
  this.timeId = null;
  this.mbpause = null;
};
/**
 * 대기 모드를 시작합니다.
 * @param {String} element 적용 대상 실체화 객체 id
 * @private
 */
eXria.controls.xhtml.Progress.prototype.startWaiting = function(element) {
  if (typeof element == 'string') element = this.lookup(element);
  this.mbwaiting = true;
  var voStyle = null;

  if (!this.loading_div) {
    var voCtrl = this.document.createElement('div');
    voStyle = voCtrl.style;
    element.parentNode.appendChild(voCtrl);
    try {voStyle.opacity = this.opacity;} catch(e) {}
    try {voStyle.MozOpacity = this.opacity;} catch(e) {}
    try {voStyle.filter = 'alpha(opacity='+Math.round(this.opacity * 100)+')';} catch(e) {}
    try {voStyle.KhtmlOpacity = this.opacity;} catch(e) {}
  }
  var width = element.offsetWidth;
  var height = element.offsetHeight;
  var left = element.offsetLeft;
  var top = element.offsetTop;
  voStyle = voCtrl.style;
  voStyle.position = 'absolute';
  voStyle.backgroundImage = 'url('+ this.canvas.page.metadata.resourceBaseUrl + 'eXria/controls/xhtml/images/bigWaiting.gif)';
  voStyle.backgroundRepeat = "no-repeat";
  voStyle.backgroundPosition = "center center";
  voStyle.backgroundColor = "yellow";
  voStyle.left = left+'px';
  voStyle.top = top+'px';
  voStyle.width = width+'px';
  voStyle.height = height+'px';
  voStyle.display = 'inline';
  this.loading_div = voCtrl;
};
/**
 * 대기 모드를 해제합니다.
 * @param {String} element 적용 대상 실체화 객체 id
 */
eXria.controls.xhtml.Progress.prototype.stopWaiting = function(element) {
  if (typeof element == 'string') element = this.lookup(element);
  if (this.mbwaiting) {
    this._waiting = false;
    if(this.loading_div) element.parentNode.removeChild(this.loading_div);
    this.loading_div = null;
  }
};
/**
 * oldclear
 * @private
 */
eXria.controls.xhtml.Progress.prototype.oldclear = eXria.controls.xhtml.Progress.prototype.clear;
/**
 * clear
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.clear = function(){
  this.stop();
  this.oldclear();
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Progress[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "Progress"
 * @type String
 */
eXria.controls.xhtml.Progress.prototype.toString = function() {
  return "Progress";
};
/**
 * loadComplete
 * @ignore
 */
eXria.controls.xhtml.Progress.prototype.loadComplete = function(poDocument) {
  var voLabel = this.getSubCtrl("label");
  if(voLabel && this.ctrl)
    this.setVerticalAlign(voLabel, this.ctrl, this.verticalAlign);
}