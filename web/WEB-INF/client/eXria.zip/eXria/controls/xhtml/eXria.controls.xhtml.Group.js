/**
 * @fileoverview
 * Concreate xhtml Group(XHTML Group 컨트롤)
 * @author 조영진
 */

/**
 * @class Concreate xhtml Group.<br>
 * XHTML Group 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Group 객체
 * @type eXria.controls.xhtml.Group
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 * @base eXria.controls.Group
 */
eXria.controls.xhtml.Group = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pbTableLayout) {
  if(pbTableLayout != true && page.tableLayoutMap && page.tableLayoutMap[psId] != null) {
    this.inheritTableLayout(psId, pnLeft, pnTop, pnWidth, pnHeight);
    return;
  }
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight =  pnHeight == null ? 300 : pnHeight;

  eXria.controls.Group.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight); // UIControl을 상속받는다.
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 그룹에 담긴 컨트롤이 영역을 벗어날때 스크롤 처리.
   * @type String
   */
  this.overflow = null;
  /**
   * 그룹에 담긴 컨트롤이 영역을 벗어날때 횡 스크롤 처리.
   * @type String
   */
  this.overflowX = null;
  /**
   * 그룹에 담긴 컨트롤이 영역을 벗어날때 종 스크롤 처리.
   * @type String
   */
  this.overflowY = null;
  /**
   * 하위 컨트롤들의 readOnly 여부 설정
   * @type Boolean
   */
  this.readOnly = null;
  /**
   * 컨트롤이 디스플레이 되는 document
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 하위 컨트롤 id에 붙일 suffix 문자열
   * @type String
   * @private
   */
  this.idSuffix = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};

  this.cursor = null;
  /**
  * @private
  */
  this.impList = new eXria.data.Collection();
  
  /**
   * 그룹 컨트롤의 하위컨트롤에 대한 refresh여부
   * @type Boolean
   */
   this.childRefresh = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Group);
eXria.controls.xhtml.Util.createInheritance(eXria.controls.Group, eXria.controls.xhtml.Group);
//////////////////////////////////////////////////////////////////
// 메소드

eXria.controls.xhtml.Group.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsEventCallback = vsType + "EventCallback";
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;
//if(vsType == "change")debugger
  switch(vsType) {
  case "mousedown" :
    break;
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }

  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(poControl[vsEventCallback]) { poControl[vsEventCallback](voEvent); }
  if(poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }

  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};

eXria.controls.xhtml.Group.prototype.atmousedown = function(e) {
  if(!e.target || !e.target.control) return;
  var voCanvas = e.target.control.canvas;
  eXria.form.xhtml.Canvas.prototype.doCollapseControl(voCanvas);
};

eXria.controls.xhtml.Group.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;

  this.ctrl = voCtrl;
  this.document = poDocument;
  return voCtrl;
};

eXria.controls.xhtml.Group.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
};

eXria.controls.xhtml.Group.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var vsClass = this.getCSSClass(this, 1);
  poCtrl.className = poCtrl.className + " " + vsClass;

  var voDf = this.df;
  var vaCssStrBuf = null;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.10.12 동적인 코드에서는 disabled를 제어하지 않으며 FF에서는 없는 속성이다
  //if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "tooltip", this.tooltip);
  vfcSetCssStrBuf(vaCssStrBuf, "disabled", this.disabled);
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = null;
};

eXria.controls.xhtml.Group.prototype.refreshTemplate = function(poCtrl, poDocument, pbChildRefresh) {
  if(this.setTemplate) this.setTemplate(poCtrl, poDocument);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.refreshTemplate && pbChildRefresh == true) voChild.refreshTemplate(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.Group.prototype.refreshSpecificDefaults = function(poCtrl, poDocument, pbChildRefresh) {
  this.setSpecificDefaults(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(pbChildRefresh == true) voChild.refreshSpecificDefaults(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.Group.prototype.refreshSpecificAttrs = function(poCtrl, poDocument, pbChildRefresh) {
  this.setSpecificAttrs(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(pbChildRefresh == true) voChild.refreshSpecificAttrs(voChild.ctrl, voChild.document);
  }
};

 eXria.controls.xhtml.Group.prototype.reloadData = function(poCtrl, poDocument, pbChildRefresh) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.reloadData && pbChildRefresh == true) voChild.reloadData(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.Group.prototype.refreshComplete = function(poCtrl, poDocument, pbChildRefresh) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(pbChildRefresh == true) voChild.refreshComplete(voChild.ctrl, voChild.document);
  }
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  this.setDisable(poCtrl, this.disabled);
  this.hideFocusLine(poCtrl, true);
};

eXria.controls.xhtml.Group.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.Group.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;

  var voTable = poCtrl.childNodes[0];

  switch(psAttrName) {
    case "disabled" :
      poCtrl.disabled = psAttrValue;
      this.applyAttrToChildren("disabled", psAttrValue);
      break;
    //case "borderWidth" :
    //  this.innerWidth = this.width - 2 * this.borderWidth;
    //  this.innerHeight = this.height - 2 * this.borderWidth;
    //  poCtrl.style.width = this.innerWidth + "px";
    //  poCtrl.style.height = this.innerHeight + "px";
    //  break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Group.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
    break;
  case "className" :
  case "outerClassName" :
  case "overflow" :
    this.refresh(poDocument);
    break;
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue)
    this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
    var voChild = null;
    var voIterator = this.controls.iterator();
    while(voIterator.hasNext()) {
      voChild = voIterator.next();
      if(voChild.refreshVerticalAlign) {
        voChild.refreshVerticalAlign();
      }
    }
    break;
  case "readOnly" :
    this.setReadOnly(psAttrValue);
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  }
};

eXria.controls.xhtml.Group.prototype.clear = function() {
  this.removeChildren();
  this.clearCtrl();
  this.clearControl();
};
/**
 * @ignore
 */
eXria.controls.xhtml.Group.prototype.loadComplete = function() {
  this.createChildren();
  if(this.readOnly != null) this.setReadOnly(this.readOnly);
};
/**
 * 컨트롤에 하위 컨트롤를 추가합니다.
 * @param {eXria.controls.xhtml.Control} poControl 추가 대상 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document(생략가능)
 */
eXria.controls.xhtml.Group.prototype.addChild = function(poControl, poDocument) {
  if(poDocument == null) poDocument = this.document;
  var voCanvas = this.canvas;
  poControl.parent = this;
  poControl.canvas = voCanvas;
  poControl.window = this.window;
  poControl.document = this.document;
  this.addItem(poControl);
  if(voCanvas) voCanvas.registerControl(poControl);
  var voCtrl = this.getCtrl(poDocument);
  if((this.visible || this.visible == null) && voCtrl) {
    voCtrl.appendChild(poControl.create(poDocument));
    poControl.load(poDocument);
  // TODO 추후 수정
    var name = poControl.toString();
    if(name == "Rectangle" || name == "Roundrect" || name == "Ellipse" ) {poControl.getCtrl(poDocument).blur();};
  }
};
/**
 * 하위 컨트롤을 제거 시킵니다.
 * @param {String} psId 제거대상 컨트롤 id
 */
eXria.controls.xhtml.Group.prototype.removeChild = function(psId) {
  var vnIndex = this.getIndex(psId);
  var voControl = this.controls.remove(vnIndex);
  voControl.clear();
};
/**
 * 하위 컨트롤 id에 매칭되는 컨트롤 식별 인덱스 번호를 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 하위 컨트롤 식별 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.Group.prototype.getIndex = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vnIndex = -1;
  while(voIterator.hasNext()) {
    vnIndex++;
    voControl = voIterator.next();
    if (voControl.id == psId) break;
  }
  return vnIndex;
};
/**
 * 지정된 id에 해당하는 하위 컨트롤을 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 지정된 id에 해당하는 하위 컨트롤 객체
 * @type eXria.controls.xhtml.Control
 */
eXria.controls.xhtml.Group.prototype.get = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    if (voControl.id == psId) { return voControl; }
  }
  return null;
};
/**
 * 포함된 하위 컨트롤의 실체화 객체를 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {String} psIdSuffix 실체화된 컨트롤 id에 따라붙을 문자열
 * @private
 */
eXria.controls.xhtml.Group.prototype.createChildren = function(poDocument, psIdSuffix) {
  if(poDocument == null) poDocument = this.document;
  if(psIdSuffix == null && this.idSuffix) psIdSuffix = this.idSuffix;
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vsId = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    vsId = voControl.id;
    if(psIdSuffix != null) voControl.id += psIdSuffix;
    if(voControl.canvas == null) {
      voControl.canvas = this.canvas;
      voControl.window = this.window;
      voControl.document = this.document;
      this.canvas.registerControl(voControl);
    }
    if(voControl.toString() != "Timer") {
      this.appendChild(voControl.create(poDocument), poDocument);
      //voControl.refresh(poDocument);
      voControl.load(this.document);
    }
    voControl.id = vsId;
  }
};
/**
 * 하위 컨트롤에 일괄적으로 속성을 적용합니다.
 * @param {String} psAttrValue 지정된 속성값
 * @param {String} psAttrName 속성명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.Group.prototype.applyAttrToChildren = function(psAttrName, psAttrValue, poDocument) {
  if(this.getCtrl(poDocument) == null) return;

  var voIterator = this.controls.iterator();
  var voControl = null;
  var voCtrl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    voCtrl = voControl.getCtrl(poDocument);
    if(voCtrl) voControl.applyAttr(psAttrName, psAttrValue, poDocument);
  }
};
/**
 * 모든 하위 컨트롤을 제거 시킵니다.
 */
eXria.controls.xhtml.Group.prototype.removeChildren = function() {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    this.canvas.unregisterControl(voControl.id);
    if(voControl.toString() == "SubPage") {
//      var voWindow = voControl.ctrl.contentWindow;
//      if(voWindow) {
//        voWindow.close();
//      }
        voControl.setSrc("javascript:false");
    }
    voControl.clear();
  }
  this.controls.clear();
};

eXria.controls.xhtml.Group.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Group[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 하위 컨트롤의 readOnly속성을 설정
 * @param {String} pbEnable readOnly속성을 활성화할지 여부
 */
eXria.controls.xhtml.Group.prototype.setReadOnly = function(pbEnable) {
  var voIterator = this.controls.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.readOnly !== undefined) voChild.applyAttr("readOnly", pbEnable);
  }
};
/*
 * @ignore
 */
eXria.controls.xhtml.Group.prototype.resize = function() {
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.ctrl.style["left"] = this.left + "px";
  this.ctrl.style["top"] = this.top + "px";
  this.ctrl.style["width"] = this.innerWidth + "px";
  this.ctrl.style["height"] = this.innerHeight + "px";
};
/**
 * 클래스 명을 반환합니다.
 * @return "Group"
 * @type String
 */
eXria.controls.xhtml.Group.prototype.toString = function() {
  return "Group";
};
/**
 * TableLayout 상속.
 * @private
 */
eXria.controls.xhtml.Group.prototype.inheritTableLayout = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  eXria.controls.xhtml.TableLayout.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  var parentProto = eXria.controls.xhtml.TableLayout.prototype;
  for(psAttr in parentProto) {
    this[psAttr] = parentProto[psAttr];
  }
};