/**
 * @fileoverview
 * Concreate xhtml Select(XHTML Select 컨트롤)
 * @author 김경태
 */

/**
 * @class 아이템의 공통 속성을 저장하기 위한 오브젝트입니다.
 * @type eXria.controls.xhtml.Select
 * @version 2.0
 * @constructor
 */
eXria.controls.xhtml.Select_itemgroup = function(){
  /**
   * 라벨의 상대 위치를 지정
   * left/right/top/bottom
   * @type String
   */
  this.labelPos = null;
  /**
   * 아이템의 높이
   * @type number
   */
//  this.height = null; // 아이템의 높이 - number
  /**
   * 아이템의 넓이
   * @type number
   */
//  this.width = null; // 아이템의 넓이 - number
  /**
   * 아이템의 가로 정렬
   * "left"|"center"|"right"
   * @type String
   */
  this.textAlign = null;
  /**
   * 아이템의 세로 정렬
   * top/middle/bottom
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 아이템의 글자색
   * @type String
   */
  this.color = null; // 아이템의 글자색
  /**
   * 아이템의 배경색
   * @type String
   */
  this.backgroundColor = null;
  /**
   * border의 폭
   * @type Number
   */
  this.borderWidth = null;
  /**
   * border의 스타일
   * none/hidden/dotted/dashed/solid/double/groove/ridge/inset/outset
   * @type String
   */
  this.borderStyle = null;
  /**
   * border의 색상
   * @type String
   */
  this.borderColor = null;
  /**
   * 텍스트 폰트패밀리
   * @type String
   */
  this.fontFamily = null;
  /**
   * 텍스트 폰트사이즈
   * @type Number
   */
  this.fontSize = null;
  /**
   * 텍스트 폰트스타일
   * @type String
   */
  this.fontStyle = null;
  /**
   * 텍스트 폰트두께
   * @type String
   */
  this.fontWeight = null;
  /**
   * CSS 클래스 이름
   * @type String
   */
  this.className = null;

  /**
   * border의 bottom폭
   * @type number
   */
  this.borderBottomWidth = null;
  /**
   * border의 top폭
   * @type number
   */
  this.borderTopWidth = null;
  /**
   * border의 left폭
   * @type number
   */
  this.borderLeftWidth = null;
  /**
   * border의 right폭
   * @type number
   */
  this.borderRightWidth = null;
  /**
   * @private
   */
  this.cursor = null;

  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflow = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflowX = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflowY = null;

  /**
   * css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};

/**
 * @class Concreate xhtml Select
 * XHTML Select 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Select 객체
 * @type eXria.controls.xhtml.Select
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Select = function(psId, pnLeft, pnTop, pnWidth, pnHeight){

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight); // UIControl을 상속받는다.
  this.data = new eXria.controls.DataRefNodeset(this); // DataRef 생성 연결
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 수평 또는 수직 모드를 지정 - horizontal/vertical.
   * @type String
   */
  this.displayMode = null;
  /**
   * 해당 모드에서의 옵션 수.
   * @type Number
   */
  this.displayNum = null;
  /**
   * 선택 버튼 타입.
   * readonly
   * @type String
   */
  this.type = null;
  /**
   * 아이템 다중선택 여부.
   * readonly
   * @type String
   */
  this.multiple = null;
  /**
   * 선택된 옵션의 값.
   * @type String
   */
  this.value = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Nmuber
   */
  this.fontWeight = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 앞쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.frontItems = new eXria.data.ArrayMap();
  /**
   * 인스턴스로 부터 가져올 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.itemset = new eXria.data.ArrayMap();
  /**
   * 뒤쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.backItems = new eXria.data.ArrayMap();
  /**
   * 선택된 아이템의 리스트
   * @private
   */
  this.selectedItems = new eXria.data.ArrayMap();
  /**
   * ref의 값
   * @private
   */
  //this.refValue = null;
  /**
   * 가로 간격.
   * @type Number
   */
  this.horizontalGap = null;
  /**
   * 세로 간격.
   * @type Number
   */
  this.verticalGap = null;
  /**
   * 컨트롤내에서의 옵션의 left offset.
   * @type Number
   */
  this.offsetLeft = null;
  /**
   * 컨트롤내에서의 옵션의 top offset.
   * @type Number
   */
  this.offsetTop = null;
  /**
   * Data 연동 시의 Instance의 label Tag 명.
   * @type String
   */
  this.labelTagName = null;
  /**
   * Data 연동 시의 Instance의 value Tag 명.
   * @type String
   */
  this.valueTagName = null;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 아이템의 공통 속성 (아이템 생성 시 기본 값 적용).
   * @type Object
   */
  this.itemgroup = new eXria.controls.xhtml.Select_itemgroup();
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Select);
//////////////////////////////////////////////////////////////////
// 메소드
/*eXria.controls.xhtml.Select.prototype.createCtrl = function(poDocument){
  voCtrl.setAttribute("id", this.id);
  voCtrl.style.overflow = "hidden"; // 컨트롤 영역을 벗어난 하위 요소를 안보이게 처리
  return voCtrl;
};*/
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.createCtrl = function(poDocument){
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.setTemplate = function(poCtrl, poDocument){
  this.template = [];
  var vaTemplate = this.template;
  vaTemplate.push("@innStrBuf");
};
/**
 * RidioButton 컨트롤의 개별 초기값 설정.
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voItemgroupDf = this.itemgroup;
  this.setStyleCurrentBorderValue(this);

  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  // CSS가 적용되지 않는 속성에 대한 초기값 설정(main 컨트롤)
  this.value = this.getAttrValue("value", this.value);
  this.offsetLeft = this.getAttrValue("offsetLeft", this.offsetLeft);
  this.offsetTop = this.getAttrValue("offsetTop", this.offsetTop);
  this.displayNum = this.getAttrValue("displayNum", this.displayNum);
  this.displayMode = this.getAttrValue("displayMode", this.displayMode);
  this.horizontalGap = this.getAttrValue("horizontalGap", this.horizontalGap);
  this.verticalGap = this.getAttrValue("verticalGap", this.verticalGap);
  if(this.offsetLeft == null) this.offsetLeft = 0;
  if(this.offsetTop == null) this.offsetTop = 0;

  voItemgroupDf.labelPos = this.getAttrValue("itemgroup.labelPos", this.itemgroup.labelPos);
};
///*eXria.controls.xhtml.Select.prototype.setSpecificAttrs = function(poCtrl, poDocument){
//  var voDf = this.df;
//  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
//  if(this.innerWidth < 0) this.innerWidth = 0;
//  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
//  if(this.innerHeight < 0) this.innerHeight = 0;
//
//  this.setAttrCtrl("borderColor", this.borderColor, poCtrl);
//  this.setAttrCtrl("borderStyle", this.borderStyle, poCtrl);
//  this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", poCtrl);
//  this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", poCtrl);
//  this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", poCtrl);
//  this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", poCtrl);
//  this.setAttrCtrl("name", this.name, poCtrl);
//  this.setAttrCtrl("value", this.value, poCtrl);
//  this.setAttrCtrl("fontFamily", this.fontFamily, poCtrl);
//  this.setAttrCtrl("fontSize", this.fontSize, poCtrl);
//  this.setAttrCtrl("fontStyle", this.fontStyle, poCtrl);
//  this.setAttrCtrl("fontWeight", this.fontWeight, poCtrl);
//  this.setAttrCtrl("color", this.color, poCtrl);
//  this.setAttrCtrl("backgroundColor", this.backgroundColor, poCtrl);
//  this.setAttrCtrl("width", this.innerWidth, poCtrl);
//  this.setAttrCtrl("height", this.innerHeight, poCtrl);
//};*/
/**
 * RidioButton 컨트롤의 개별 Attrs 적용.
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.setSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;

  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  poCtrl["name"] = this.name;
  poCtrl["value"] = this.value;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);

  vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  poCtrl.style.cssText = vaCssStrBuf.join("");
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.dochange = function(e) {
  var voDf = this.df;
//this.atchange(e);
  if(this.onchange) {
    try {
      this.onchange(e);
    } catch(err) {
      if(this.debug){
        alert("onchange_" + e.object.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(this.changeEventCallback) this.changeEventCallback(e);
  this.finalchange(e);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.finalchange = function(e) {
  this.changed = false;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.atclick = function(e) {
  //if(e.target.tagName.toUpperCase() == "INPUT") {
  if(this.eventObject != null) {
    e.objectType = this.eventObjectType;
    e.object = this.eventObject;
    this.clearSelected();
    this.checkSelected();
    this.value = this.getValue();
    this.value = this.getValue();
    if(this.data.instanceId && this.data.instancePath) {
      this.data.setData(this.value);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.finalclick = function(e) {
  if(this.canvas) {
    var voCanvas = this.canvas;
    if(!this.isRClick(e)) voCanvas.hideContextMenu();
  }
  if(this.changed) {
    this.dochange(e);
  }
  this.eventObjectType = null;
  this.eventObject = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.removeSpecificDefaults = function(e) {
  this.template = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  this.setSpecificDefaults(poCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  this.setSpecificAttrs(poCtrl); // Select 컨트롤의 개별 속성들을 설정한다.
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.reloadData = function(poCtrl, poDocument){
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  this.itemset.clear();
  //this.clearCtrlNode(poCtrl);
  for (var i = 0; i < poCtrl.childNodes.length;) {
    poCtrl.removeChild(poCtrl.childNodes[0]);
  }
  this.loadData(poDocument);
};
/**
 * 속성에 대한 하위 전파를 처리합니다.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Select.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl){
  switch (psAttrName) {
    case "disabled":
      for (var i = 0; i < poCtrl.childNodes.length; i++) {
        poCtrl.childNodes[i].disabled = psAttrValue;

        var voNode = poCtrl.childNodes[i];
        do {
          if(voNode.childNodes[0] == null)
            break;
          voNode = voNode.childNodes[0];
        } while(voNode != null)
        if(voNode.parentNode.parentNode) {  // table
          voNode = voNode.parentNode.parentNode;
          for (var j = 0; j < voNode.childNodes.length; j++)            // table의 td 2개
            voNode.childNodes[j].childNodes[0].disabled = psAttrValue;  // td의 input또는 span
        }
        /*for (var j = 0; j < poCtrl.childNodes[i].childNodes.length; j++) {
          poCtrl.childNodes[i].childNodes[j].disabled = psAttrValue;
        }*/
      }
      break;
    case "color":
      for (var i = 0; i < poCtrl.childNodes.length; i++) {
        poCtrl.childNodes[i].style.color = psAttrValue;
        var voNode = poCtrl.childNodes[i];
        do {
          if(voNode.childNodes[0] == null)
            break;
          voNode = voNode.childNodes[0];
        } while(voNode != null)
        if(voNode.parentNode.parentNode) {  // table
          voNode = voNode.parentNode.parentNode;
          for (var j = 0; j < voNode.childNodes.length; j++)              // table의 td 2개
            voNode.childNodes[j].childNodes[0].style.color = psAttrValue; // td의 input또는 span
        }
        /*for (var j = 0; j < poCtrl.childNodes[i].childNodes.length; j++) {
          poCtrl.childNodes[i].childNodes[j].style.color = psAttrValue;
        }*/
      }
      break;
    default:
      //      poCtrl.childNodes[i].setAttribute(psAttrName, psAttrValue);
      break;
  }
};
/**
 * refresh가 필요한 경우
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Select.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument){
  var voCtrl = this.getCtrl(poDocument);

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
//    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setDisable(voCtrl, psAttrValue);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * id와 위치를 재설정합니다.
 * @param {eXria.controls.xhtml.Item} poItemControl
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @private
 */
eXria.controls.xhtml.Select.prototype.setIdPos = function(poItemControl, pnIndex) {
  var voDf = this.df;
  var vnLeft = null;
  var vnTop = null;
  var vnWidth = poItemControl.width;
  var vnHeight = poItemControl.height
  var vnOffsetLeft = this.offsetLeft;
  var vnOffsetTop = this.offsetTop;
  var vnItemNum = pnIndex;
  var vsItemId = this.id + "_item" + vnItemNum;
  var vnBorderHWidth = poItemControl.borderLeftWidth + poItemControl.borderRightWidth;
  var vnBorderVWidth = poItemControl.borderTopWidth + poItemControl.borderBottomWidth;
  var vnDisplayNum = this.displayNum;
  var vsDisplayMode = this.displayMode;
  var vnHorizontalGap = this.horizontalGap;
  var vnVerticalGap = this.verticalGap;
  var vnQuotient = parseInt(vnItemNum / vnDisplayNum); // 몫
  var vnRemainder = vnItemNum % vnDisplayNum; // 나머지

//    this.offsetLeft = Math.abs(parseInt((this.width - ((vnDisplayNum * this.getAttrValue("itemgroup.width", this.itemgroup.width)) + ((vnDisplayNum-1) * vnHorizontalGap) + (vnDisplayNum * this.itemgroup.borderWidth)))/2));

  // 옵션의 좌표 계산
  if (vsDisplayMode == "horizontal") { // 수평모드
    vnLeft = vnOffsetLeft + (vnRemainder * vnWidth) + (vnRemainder * vnHorizontalGap);
    if(vnBorderHWidth) vnLeft = vnLeft + (vnRemainder * vnBorderHWidth);
    vnTop = vnOffsetTop + (vnQuotient * vnHeight) + (vnQuotient * vnVerticalGap);
    if(vnBorderVWidth) vnTop = vnTop + (vnQuotient * vnBorderVWidth);
  } else if (vsDisplayMode == "vertical") { // 수직모드
    vnLeft = (vnQuotient * vnWidth) + (vnQuotient * vnVerticalGap);
    vnTop = (vnRemainder * vnHeight) + (vnRemainder * vnHorizontalGap);
  }
  poItemControl.id = vsItemId;
  poItemControl.left = vnLeft;
  poItemControl.top = vnTop;
};
/**
 * frontItems혹은 backItems에 아이템을 추가 시킵니다.
 * @param {String} psType 아이템 타입
 * @param {String} psLabelText 아이템 라벨 텍스트
 * @param {String} psValue 컨트롤 disabled설정
 * @param {Number} pnIndex 전체 리스트에서의 인덱스(인덱스를 지정하지 않은 경우  아이템을 아이템 리스트의 맨 후미에 저장)
 * @param {HTMLDiv} poCtrl 실체화 컨트롤(생략가능)
 * @return 새롭게 생성된 eXria.controls.xhtml.Item 객체
 * @type eXria.controls.xhtml.Item
 */
eXria.controls.xhtml.Select.prototype.addItem = function(psType, psLabelText, psValue, pnIndex, poCtrl) {
  if(psValue == null || psValue === undefined) new Error("vlaue is Empty");
  if (poCtrl == null) poCtrl = this.ctrl;
  var voItemControl = null;
  var vsItemId = this.id + "_item";

  voItemControl = new eXria.controls.xhtml.Item(vsItemId, this, psLabelText, psValue, 0, 0, 0, 0);

  var voItemGroup = this.itemgroup;

  // 아이템의 공통 속성 설정
  voItemControl.height = this.getAttrValue("itemgroup.height", voItemGroup.height);
  voItemControl.width = this.getAttrValue("itemgroup.width", voItemGroup.width);
  voItemControl.labelPos = voItemGroup.labelPos;
  voItemControl.backgroundColor = voItemGroup.backgroundColor;
  voItemControl.borderWidth = voItemGroup.borderWidth;
  voItemControl.borderStyle = voItemGroup.borderStyle;
  voItemControl.borderColor = voItemGroup.borderColor;
  voItemControl.textAlign = voItemGroup.textAlign;
  voItemControl.verticalAlign = voItemGroup.verticalAlign;
  voItemControl.disabled = voItemGroup.disabled;
  // 공통 속성의 하위 전달
  //if(this.disabled) voItemControl.disabled = true;
  voItemControl.color = this.color;

  // 아이템 타입  속성의 하위 전달 (라디오/체크박스)
  voItemControl.type = this.type;

  var voItems = null;
  if(psType == "front") voItems = this.frontItems;
  else if(psType == "itemset") voItems = this.itemset;
  else if(psType == "back") voItems = this.backItems;
  else new Error("아이템이 추가되는 타입 front/itemset/Back을 지정하지 않았습니다.");

  if(pnIndex == null) {  // 인덱스를 지정하지 않은 경우  아이템을 아이템 리스트의 맨 후미에 저장
    voItems.put(voItems.size(), voItemControl);
  } else {               // 인덱스를 지정한 경우 아이템 리스트의 지정된 인덱스에 아이템을 저장
    var voNewItems = new eXria.data.ArrayMap();
    var vnIndex = 0;
    var voValue = null;
    var voIterator = voItems.getValueCollection().iterator();
    while(voIterator.hasNext()) {
      if(vnIndex == pnIndex) voNewItems.put(vnIndex++, voItemControl);
      voValue = voIterator.next();
      voNewItems.put(vnIndex, voValue);
      vnIndex++;
    }
    if(psType == "front") {
      this.frontItems.clear();
      this.frontItems = voNewItems;
    } else if(psType == "itemset") {
      this.itemset.clear();
      this.itemset = voNewItems;
    } else if(psType == "back") {
      this.backItems.clear();
      this.backItems = voNewItems;
    }
  }
  return voItemControl;
};
/**
 * frontItems에 아이템을 추가하 시킵니다.
 * @param {String} psLabelText 아이템 라벨 텍스트
 * @param {String} psValue 컨트롤 disabled설정
 * @param {Number} pnIndex 전체 리스트에서의 인덱스(인덱스를 지정하지 않은 경우  아이템을 아이템 리스트의 맨 후미에 저장)
 * @param {HTMLDiv} poCtrl 실체화 컨트롤(생략가능)
 * @return 새롭게 생성된 eXria.controls.xhtml.Item 객체
 * @type eXria.controls.xhtml.Item
 */
eXria.controls.xhtml.Select.prototype.addItemFront = function(psLabelText, psValue, pnIndex, poCtrl) {
  return this.addItem("front", psLabelText, psValue, pnIndex, poCtrl);
};
/**
 * itemset에 아이템을 추가 시킵니다.
 * @param {String} psLabelText 아이템 라벨 텍스트
 * @param {String} psValue 컨트롤 disabled설정
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 새롭게 생성된 eXria.controls.xhtml.Item 객체
 * @type eXria.controls.xhtml.Item
 * @private
 */
eXria.controls.xhtml.Select.prototype.addToItemset = function(psLabelText, psValue, poCtrl, poDocument){
   return this.addItem("itemset", psLabelText, psValue, null, poCtrl, poDocument);
};
/**
 * backItems에 아이템을 추가 시킵니다.
 * @param {String} psLabelText 아이템 라벨 텍스트
 * @param {String} psValue 컨트롤 disabled설정
 * @param {Number} pnIndex 전체 리스트에서의 인덱스(인덱스를 지정하지 않은 경우  아이템을 아이템 리스트의 맨 후미에 저장)
 * @param {HTMLDiv} poCtrl 실체화 컨트롤(생략가능)
 * @return 새롭게 생성된 eXria.controls.xhtml.Item 객체
 * @type eXria.controls.xhtml.Item
 */
eXria.controls.xhtml.Select.prototype.addItemBack = function(psLabelText, psValue, pnIndex, poCtrl) {
  return this.addItem("back", psLabelText, psValue, pnIndex, poCtrl);
};
/**
 * 아이템을 제거 시킵니다.
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.removeItem = function(psName, poDocument) {
//  this.frontItems.remove(psName);
//  this.itemset.remove(psName);
//  this.backItems.remove(psName);
  var voFrontItems = this.frontItems;
  var voItemset = this.itemset;
  var voBackItems = this.backItems;
  var vnIndex = this.getIndex(psName);
  if(vnIndex < voFrontItems.size()) {
    voFrontItems.remove(vnIndex);
  } else if(vnIndex < voFrontItems.size() + voItemset.size()) {
    voItemset.remove(vnIndex - voFrontItems.size());
  } else {
    voBackItems.remove(vnIndex - voFrontItems.size() - voItemset.size())
  }
  this.selectedItems.remove(vnIndex);
  var voCtrl = this.getCtrl(poDocument);
  this.refreshList(voCtrl, poDocument);
};
/**
 * 모든 리스트의 아이템을 제거 시킵니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.Select.prototype.removeAll = function(poDocument) {
  this.frontItems.clear();
  this.itemset.clear();
  this.backItems.clear();
  this.selectedItems.clear();
  this.refresh(poDocument);
};
/**
 * itemSet에 속한 모든 item의 disable 속성 지정후 refresh 처리
 * @param {String} pbDisable disable 속성
 */
eXria.controls.xhtml.Select.prototype.setDisableAllItems = function(pbDisable) {
  if(typeof pbDisable !== "boolean"){
    var voErrMsg = {};
    voErrMsg.name = "setDisableAllItems"
    voErrMsg.message = "pbDisable 가 boolean 타입이 아닙니다."
    throw voErrMsg;
  }

  this.disabled = pbDisable;
  this.itemgroup.disabled = pbDisable;

  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voItem.disabled = pbDisable;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voItem.disabled = pbDisable;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voItem.disabled = pbDisable;
  }

  this.refresh();
}
/**
 * 지정된 라벨과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스를 반환합니다.
 * @param {String} psName 아이템 라벨 명
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.Select.prototype.getIndex = function(psName) {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var vsValue = null;
  var i = -1;
  while(voIterator.hasNext()) {
    i++;
    vsValue = voIterator.next();
    if(vsValue.text == psName) {
      return i;
    }
  }
  voIterator = this.itemset.getKeyCollection().iterator();
  while(voIterator.hasNext()) {
    i++;
    vsValue = voIterator.next();
    if(vsValue.text == psName) {
      return i;
    }
  }
  voIterator = this.backItems.getKeyCollection().iterator();
  while(voIterator.hasNext()) {
    i++;
    vsValue = voIterator.next();
    if(vsValue.text == psName) {
      return i;
    }
  }
  return -1;
};
/**
 * 지정된 아이템의 값과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스를 반환합니다.
 * @param {String} psValue 아이템 값
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.Select.prototype.getIndexByVal = function(psValue) {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  var i = 0;
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.visible == false) continue;
    if(voItem.value == psValue) return i;
    i++;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.visible == false) continue;
    if(voItem.value == psValue) return i;
    i++;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.visible == false) continue;
    if(voItem.value == psValue) return i;
    i++;
  }
  return -1;
};
/**
 * 선택된 아이템 value를 반환합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 선택된 아이템 value
 * @type String|Array(String)
 */
eXria.controls.xhtml.Select.prototype.getValue = function(poDocument) {
  var vaRet = [];
  var voCtrl = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voCtrl = voItem.getItemCtrl(poDocument);
    if (voCtrl.checked) {
      if(this.multiple == false) return voItem.getValue();
      vaRet.push(voItem.getValue());
    }
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voCtrl = voItem.getItemCtrl(poDocument);
    if (voCtrl.checked) {
      if(this.multiple == false) return voItem.getValue();
      vaRet.push(voItem.getValue());
    }
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voCtrl = voItem.getItemCtrl(poDocument);
     if (voCtrl.checked) {
      if(this.multiple == false) return voItem.getValue();
      vaRet.push(voItem.getValue());
    }
  }

  if(vaRet.length == 0) {
    return null;
  } else {
    return vaRet;
  }
};
/**
 * 지정된 인덱스에 해당하는 아이템 value를 반환합니다.
 * @param {Number} pnIndex 인덱스 번호
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 지정된 인덱스에 해당하는 아이템 value
 * @type String
 */
eXria.controls.xhtml.Select.prototype.getItemValue = function(pnIndex, poDocument){
  var voCtrl = null;
  var voItems = null;
  if(pnIndex < this.frontItems.size()) voItems = this.frontItems;
  else if(pnIndex < this.frontItems.size() + this.itemset.size()) {
    voItems = this.itemset;
    pnIndex -= this.frontItems.size();
  } else {
    voItems = this.backItems;
    pnIndex -= this.frontItems.size() + this.itemset.size();
  }
  var voIterator =voItems.getValueCollection().iterator();
  var voItem = voIterator.collection[pnIndex];
  if(voItem != null) {
    return voItem.getValue();
  }
  return null;
};
/**
 * 지정된 라벨명에 해당하는 아이템을 반환합니다.
 * @param {String} psName 아이템 라벨 값
 * @return 인덱스로 지정된 eXria.controls.xhtml.Item 객체
 * @type eXria.controls.xhtml.Item
 */
eXria.controls.xhtml.Select.prototype.getItemByName = function(psName) {
  var voItems = null;
  var voItem = null;
  var voRet = null;
  var vbBreak = false;
  var vaItems = [this.frontItems, this.itemset, this.backItems];
  for(var i = 0; i < vaItems.length; i++) {
    voItems = vaItems[i];
    for(var j = 0; j < voItems.size(); j++) {
      voItem = voItems.get(j);
      if(voItem.text == psName) {
        voRet = voItem;
        vbBreak = true;
        break;
      }
    }
    if(vbBreak) break;
  }

  return voRet;
};
/**
 * 지정된 값을 포함한 아이템을 반환합니다.
 * @param {String} psValue 검색할 값
 * @return 지정된 값을 포함한 아이템
 * @type eXria.controls.xhtml.Item
 */
eXria.controls.xhtml.Select.prototype.getItemByVal = function(psValue) {
  var voItem = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.getValue() == psValue) return voItem;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.getValue() == psValue) return voItem;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.getValue() == psValue) return voItem;
  }
  return null;
};
/**
 * 지정된 값을 갖는 아이템을 선택합니다.
 * @param {Array(String)} paValue 컨트롤 disabled설정
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.Select.prototype.setValue = function(paValue, poDocument) {
  this.clearChecked();

  var voCtrl = null;
  var vsValue = null;
  var vbBreak = false;
  var vaValue = [];
  if(typeof paValue == "string") vaValue.push(paValue);
  else if(paValue != null && paValue.push) vaValue = paValue;
  for(var i = 0; i < vaValue.length; i++) {
    vsValue = vaValue[i];
    vbBreak = false;
    var voIterator = this.frontItems.getValueCollection().iterator();
    var voItem = null;
    while (voIterator.hasNext()) {
      voItem = voIterator.next();
      voCtrl = voItem.getItemCtrl(poDocument);
      voItem.selected = false;
      if (voItem.getValue() == vsValue) {
        voCtrl.checked = true;
        voItem.selected = true;
        vbBreak = true;
        break;
      }
    }
    if(vbBreak) continue;
    voIterator = this.itemset.getValueCollection().iterator();
    while (voIterator.hasNext()) {
      voItem = voIterator.next();
      voCtrl = voItem.getItemCtrl(poDocument);
      voItem.selected = false;
      if (voItem.getValue() == vsValue) {
        voCtrl.checked = true;
        voItem.selected = true;
        vbBreak = true;
        break;
      }
    }
    if(vbBreak) continue;
    voIterator = this.backItems.getValueCollection().iterator();
    while (voIterator.hasNext()) {
      voItem = voIterator.next();
      voCtrl = voItem.getItemCtrl(poDocument);
      voItem.selected = false;
      if (voItem.getValue() == vsValue) {
        voCtrl.checked = true;
        voItem.selected = true;
        vbBreak = true;
        break;
      }
    }
  }
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined) {
    var vsOldValue = this.onchangeInitValue;
    if(vsOldValue instanceof Array) vsOldValue = vsOldValue.join();
    if(vsOldValue != vaValue.join()) vbChanged = true;
  }
  this.onchangeInitValue = vaValue;
  this.value = vaValue;
  if(!!this.data.instanceId && !!this.data.instancePath) {
    if(vbChanged) this.data.setData(this.value);
  }
};
/**
 * 모든 아이템의 selected속성을 초기화 시킵니다.
 */
eXria.controls.xhtml.Select.prototype.clearSelected = function() {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    voItem.selected = false;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    voItem.selected = false;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    voItem.selected = false;
  }
};
/**
 * 모든 아이템의 체크버튼을 초기화 시킵니다.
 */
eXria.controls.xhtml.Select.prototype.clearChecked = function() {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  var voCtrl = null;
  var voDocument = this.document;

  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.visible == false) continue;
    voCtrl = voItem.getItemCtrl(voDocument);
    voCtrl.checked = false;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.visible == false) continue;
    voCtrl = voItem.getItemCtrl(voDocument);
    voCtrl.checked = false;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voItem = voIterator.next();
    if(voItem.visible == false) continue;
    voCtrl = voItem.getItemCtrl(voDocument);
    voCtrl.checked = false;
  }
};
/**
 * 아이템의 선택 버튼을 체크하여 아이템의 selected 속성 값을 갱신합니다.
 */
eXria.controls.xhtml.Select.prototype.checkSelected = function() {
  var voCtrl = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voCtrl = voItem.getItemCtrl();
    if (voCtrl.checked == true) voItem.selected = true;
    else voItem.selected = false;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voCtrl = voItem.getItemCtrl();
    if (voCtrl.checked == true) voItem.selected = true;
    else voItem.selected = false;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    voCtrl = voItem.getItemCtrl();
    if (voCtrl.checked == true) voItem.selected = true;
    else voItem.selected = false;
  }
};
/**
 * 아이템 위치를 새로고침 합니다.
 * @param {String} psPosition 라벨의 상대 위치(left/right/top/bottom)
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.Select.prototype.setLabelPos = function(psPosition, poDocument) {
  this.itemgroup.labelPos = psPosition;
  this.refresh(poDocument);
};
/**
 * 각 속성에 따른 디폴트 값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.Select.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  var vaAttrName = psAttrName.split(".");
  var vsType = this.toString();
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default[vsType][psAttrName];
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default[vsType][vaAttrName[0]][vaAttrName[1]];
  }
  if(vsDefaultValue === undefined) { return null;}
  return vsDefaultValue;
};
/**
 * loadData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Select.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
  }
  if(poDocument == null) poDocument = document;
  var voCtrl = this.getCtrl(poDocument);

  this.loadNodesetData(poDocument, voCtrl);
  this.loadRefData();
  this.loadDataDisplay(poDocument, voCtrl);
};
/**
 * loadNodesetData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Select.prototype.loadNodesetData = function(poDocument, poCtrl) {
  if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    this.loadNodesetDataFromPluginInstance(poDocument, poCtrl);
    return;
  }

  var voCollectionNode = null;
  if(this.data.nodesetInstanceId && this.data.nodesetInstancePath) voCollectionNode = this.data.getNodesetData2();
  var vsLabelTagName = this.getAttrValue("labelTagName", this.labelTagName);
  var vsVauleTagName = this.getAttrValue("valueTagName", this.valueTagName);

  if(voCollectionNode && vsLabelTagName && vsVauleTagName) {
    var vnLoop = voCollectionNode.getLength();
    var voMapNode = null;
    for (var i = 0; i < vnLoop; i++) {
      voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
      var vsLabel = voMapNode.get(vsLabelTagName);
      var vsValue = voMapNode.get(vsVauleTagName);
      if(vsLabel != null && vsValue != null) var voItem = this.addToItemset(vsLabel, vsValue, poCtrl, poDocument);
    }
  }
};
/**
 * loadNodesetDataFromPluginInstance
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Select.prototype.loadNodesetDataFromPluginInstance = function(poDocument, poCtrl) {
  var voCollectionNode = null;
  if(this.data.nodesetInstanceId && this.data.nodesetInstancePath) voCollectionNode = this.data.getNodesetStr();
  if(voCollectionNode) voCollectionNode = eval(voCollectionNode);
  var vsLabelTagName = this.getAttrValue("labelTagName", this.labelTagName);
  var vsVauleTagName = this.getAttrValue("valueTagName", this.valueTagName);

  if(voCollectionNode && vsLabelTagName && vsVauleTagName) {
    var vnLoop = voCollectionNode.length;
    var voMapNode = null;
    for (var i = 0; i < vnLoop; i++) {
      voMapNode = voCollectionNode[i];
      var vsLabel = voMapNode[vsLabelTagName];
      var vsValue = voMapNode[vsVauleTagName];
      if(vsLabel != null && vsValue != null) var voItem = this.addToItemset(vsLabel, vsValue, poCtrl, poDocument);
    }
  }
};
/**
 * loadRefData
 * @private
 */
eXria.controls.xhtml.Select.prototype.loadRefData = function() {
  this.selectedItems.clear();
  var vsRefValue = null;
  var vaValue = [];
  if(this.data.instanceId && this.data.instancePath) vsRefValue = this.data.getData();
  if(vsRefValue != null) {
    if(vsRefValue instanceof Array) vaValue = vsRefValue;
    else if(vsRefValue != null) vaValue.push(vsRefValue);
    //this.refValue = vaValue;
    this.value = vaValue;
  } else {
    //this.refValue = null;
    this.value = null;
  }
  if(this.value) this.clearSelected();
};

//eXria.controls.xhtml.Select.prototype.loadDataDisplay = function(poDocument, poCtrl) {
//  var vnIndex = 0;
//  var vnSelectedIndex = 0;
//  var voIterator = this.frontItems.getKeyCollection().iterator();
//  var voItem = null;
//  var vsKey = null;
//  while (voIterator.hasNext()) {
//    vsKey = voIterator.next();
//    voItem = this.frontItems.get(vsKey);
//
//   if(voItem.visible == false) continue;
//    if(this.refValue) {
//      for(var i = 0; i < this.refValue.length; i++) {
//        if(this.refValue[i] == voItem.value) {
//          voItem.selected = true;
//          this.selectedItems.put(vnSelectedIndex, voItem);
//          vnSelectedIndex = vnSelectedIndex + 1;
//          break;
//        }
//      }
//    }
//    this.setIdPos(voItem, vnIndex);
//    var voDivCtrl = voItem.createCtrl(poDocument);
//    voItem.setSpecificDefaults(voDivCtrl, poDocument);
//    voItem.setSpecificAttrs(voDivCtrl, poDocument);
//    poCtrl.appendChild(voDivCtrl);
//    vnIndex++;
//  }
//
//  voIterator = this.itemset.getKeyCollection().iterator();
//  while (voIterator.hasNext()) {
//    vsKey = voIterator.next();
//    voItem = this.itemset.get(vsKey);
//    if(voItem.visible == false) continue;
//
//    if(this.refValue) {
//      for(var i = 0; i < this.refValue.length; i++) {
//        if(this.refValue[j] == voItem.value) {
//          voItem.selected = true;
//          this.selectedItems.put(vnSelectedIndex, voItem);
//          vnSelectedIndex = vnSelectedIndex + 1;
//          break;
//        }
//      }
//    }
//
//    this.setIdPos(voItem, vnIndex);
//    var voDivCtrl = voItem.createCtrl(poDocument);
//    voItem.setSpecificDefaults(voDivCtrl, poDocument);
//    voItem.setSpecificAttrs(voDivCtrl, poDocument);
//    poCtrl.appendChild(voDivCtrl);
//    vnIndex++;
//  }
//
//  voIterator = this.backItems.getKeyCollection().iterator();
//  while (voIterator.hasNext()) {
//    vsKey = voIterator.next();
//    voItem = this.backItems.get(vsKey);
//    if(voItem.visible == false) continue;
//
//    if(this.refValue) {
//      for(var i = 0; i < this.refValue.length; i++) {
//        if(this.refValue[j] == voItem.value) {
//          voItem.selected = true;
//          this.selectedItems.put(vnSelectedIndex, voItem);
//          vnSelectedIndex = vnSelectedIndex + 1;
//          break;
//        }
//      }
//    }
//
//    this.setIdPos(voItem, vnIndex);
//    voDivCtrl = voItem.createCtrl(poDocument);
//    voItem.setSpecificDefaults(voDivCtrl, poDocument);
//    voItem.setSpecificAttrs(voDivCtrl, poDocument);
//    poCtrl.appendChild(voDivCtrl);
//    vnIndex++;
//  }
//
//  if(this.refValue) {
//    this.setValue(this.refValue, poDocument);
//  }
//};
/**
 * loadDataDisplay
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Select.prototype.loadDataDisplay = function(poDocument, poCtrl) {
  var vaInnStrBuf = [];
  var vnIndex = 0;
  var voIterator = this.frontItems.getKeyCollection().iterator();
  var voItem = null;
  var vsKey = null;
  var voValue = this.value;
  var voSelectedItems = this.selectedItems;
  while (voIterator.hasNext()) {
    vsKey = voIterator.next();
    voItem = this.frontItems.get(vsKey);
    voItem.window = this.window;
    voItem.document = this.document;

   if(voItem.visible == false) continue;
    //if(this.refValue) {
   if(voValue) {
      for(var i = 0; i < voValue.length; i++) {
        if(voValue[i] == voItem.value) {
          if(voSelectedItems.size() > 0 && this.type == "radio") {
            this.clearSelected();
            this.selectedItems.clear();
          }
          voItem.selected = true;
          voSelectedItems.put(vnIndex, voItem);
          break;
        }
      }
    }
    this.setIdPos(voItem, vnIndex);
    vaInnStrBuf.push(voItem.getInnerHTML());
    vnIndex++;
  }

  voIterator = this.itemset.getKeyCollection().iterator();
  while (voIterator.hasNext()) {
    vsKey = voIterator.next();
    voItem = this.itemset.get(vsKey);
    if(voItem.visible == false) continue;

    //if(this.refValue) {
    if(voValue) {
      for(var i = 0; i < voValue.length; i++) {
        if(voValue[i] == voItem.value) {
          if(voSelectedItems.size() > 0 && this.type == "radio") {
            this.clearSelected();
            this.selectedItems.clear();
          }
          voItem.selected = true;
          voSelectedItems.put(vnIndex, voItem);
          break;
        }
      }
    }

    this.setIdPos(voItem, vnIndex);
    vaInnStrBuf.push(voItem.getInnerHTML());
    vnIndex++;
  }

  voIterator = this.backItems.getKeyCollection().iterator();
  while (voIterator.hasNext()) {
    vsKey = voIterator.next();
    voItem = this.backItems.get(vsKey);
    if(voItem.visible == false) continue;

    //if(this.refValue) {
    if(voValue) {
      for(var i = 0; i < voValue.length; i++) {
        if(voValue[i] == voItem.value) {
          if(voSelectedItems.size() > 0 && this.type == "radio") {
            this.clearSelected();
            this.selectedItems.clear();
          }
          voItem.selected = true;
          voSelectedItems.put(vnIndex, voItem);
          break;
        }
      }
    }

    this.setIdPos(voItem, vnIndex);
    vaInnStrBuf.push(voItem.getInnerHTML());
    vnIndex++;
  }

  var vaTemplate = this.template;
  vaTemplate[0] = vaInnStrBuf.join("");
  poCtrl.innerHTML = vaTemplate.join("");

  vaInnStrBuf = null;
  //vaTemplate = null;
  //this.template = null;

  if(voValue) {
    this.setValue(voValue, poDocument);
  }
};
/**
 * 로딩된 아이템을 새로고침 합니다.(아이템들을 리로딩 하지 않는다는 점에서 refresh메소드와 구별됨)
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Select.prototype.repaint = function(poDocument) {
  if(poDocument == null) poDocument = document;
  var voCtrl = this.getCtrl(poDocument);
//  for (var i = 0; i < voCtrl.childNodes.length;) {
//    voCtrl.removeChild(voCtrl.childNodes[i]);
//  }
  this.removeUIGeneralDefaults(voCtrl, poDocument);
  this.removeSpecificDefaults(voCtrl, poDocument);
  this.refreshTemplate(voCtrl, poDocument);
  this.refreshUIGeneralDefaults(voCtrl, poDocument);
  this.refreshSpecificDefaults(voCtrl, poDocument);
  this.refreshSpecificAttrs(voCtrl, poDocument);
  this.loadDataDisplay(poDocument, voCtrl);
};
