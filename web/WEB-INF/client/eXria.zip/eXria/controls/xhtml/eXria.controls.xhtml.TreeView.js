/**
 * @fileoverview
 * Concreate xhtml TreeView(XHTML TreeView 컨트롤)
 * @author 조영진
 */

/**
 * Concreate xhtml TreeNode
 * @author 조영진
 * @version 1.0
 * @param {String} psName
 * @constructor
 */
eXria.controls.xhtml.TreeNode = function(psName) {
  if(psName == null) psName = "";
  /**
   * 자신이 속한 트리뷰 컨트롤 참조 속성.
   * @type eXria.controls.xhtml.Tree
   */
  this.tree = null;
  /**
   * 트리노드 식별 index번호. <br>[readOnly]
   * @type Number
   */
  this.index = -1;
  /**
   * 트리노드 라벨 텍스트.
   * @type String
   */
  this.name = psName;
  /**
   * 현재 노드의 Depth.
   * @type Number
   * @private
   */
  this.depth = - 1;
  /**
   * leftside icons ( 0 : blank, 1: vertical line ).
   * @type Array(Number)
   * @private
   */
  this.leftside = new Array();
  /**
   * 펼쳐져있는지 여부.
   * @type Boolean
   */
  this.expand = false;
  /**
   * 자식 노드 허용 여부.
   * @type Number
   */
  this.isAllowsChildren = 0;
  /**
   * 아이콘 파일명.
   * @type String
   */
  this.icon = "";
  /**
   * 포커스 상태의 아이콘 파일명.
   * @type String
   */
  this.iconOpened = "";
  /**
   * 부모노드. [readOnly]
   * @type eXria.controls.xhtml.TreeNode
   */
  this.parent = null;
  /**
   * childCollection
   * @type eXria.data.ArrayCollection
   * @private
   */
  this.childCollection = new eXria.data.ArrayCollection();
  /**
   * 자식 노드를 저장하는 배열.
   * @type Array
   */
  this.children = new Array();
  /**
   * 실제 자식 노드의 유무에 상관없이 true값을 가지면 자식 노드를 가지는 것으로 하기위한 속성.
   * @type Boolean
   */
  this.hasChild = null;
  /**
   * name이외의 속성을 저장하기 위한 Object. value속성도 이곳에 저장됨.
   * @type eXria.data.ArrayMap
   */
  this.extData = new eXria.data.ArrayMap();
  /**
   * 노드가 포함된 노드셋을 참조하기 위한 속성.
   * @type eXria.controls.xhtml.TreeNodeset
   * @private
   */
  this.nodeset = null;
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   * @private
   */
  this.data = new eXria.controls.DataRefNode();
  /**
   * 줄바꿈을 기준으로 라벨 텍스트를 분리한 문자열 배열 객체
   * @type Array(String)
   */
  this.names = psName.split("\\n");
};
/**
 * 자식 노드를 가지고 있는지 여부.
 * @return 자식 노드를 가지고 있는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.TreeNode.prototype.isLeaf = function() {
  if(this.hasChild) return false;
  return this.children.length == 0 ? true : false;
};
/**
 * 지정된 노드의 부모노드 인지 여부 반환
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @return 대상 노드의 부모노드 인지 여부
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.isAncestor = function(poNode) {
  if(poNode == this.tree.root) return false;
  var parent = poNode.parent;
  var vbAncestor = false;
//  while(parent != this.tree.root) {
  while(parent != null) {
    if(parent == this) {
       vbAncestor = true;
       break;
    }
    parent = parent.parent;
    if(parent == null) break;
  }
  return vbAncestor;
};
/**
 * 노드 혹은 노드셋 추가 메소드
 * @param {eXria.controls.xhtml.TreeNode|eXria.controls.xhtml.TreeNodeset} poChild 추가할 노드 혹은 노드셋.
 * @example
 * var treeView = page.getControl("treeview");<br>
   var newNode = treeView.createTreeNode("nodeName");<br>
   var node = treeView.getNodeByVal("value");<br>
   node.addChild(newNode);<br>
 */
eXria.controls.xhtml.TreeNode.prototype.addChild = function(poChild) {
  this.childCollection.add(poChild);
};
/**
 * childCollection의 노드를 children 속성에 위치시키는 메소드
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.deployChildren = function() {
  this.removeAllChildren();
  var voIterator = this.childCollection.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild instanceof eXria.controls.xhtml.TreeNode) {
      voChild["parentValue"] = this.getValue();
      this.tree.addToItemValueMap(voChild);
      this.add(voChild);
    } else {
      this.addNodeset(voChild, this.tree.canvas);
    }
  }
};
/**
 * Removes newChild from its parent and makes it a child of this node by adding it to the end of this node's child array.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.add = function(poNode, pnIndex, pnSourceIndex) {
  if(pnIndex == null) {
    var voChild = null;
   poNode.index = this.tree.latestIdx++;
   this.tree.items.put(poNode.index, poNode);
   this.children[this.children.length] = poNode;
   poNode.tree = this.tree;
   var voData = poNode.data;
   voData.control = this.tree;
   if(voData.instanceId && voData.instancePath) {
     this.name = voData.getData();
   }
   if(poNode.selected) this.tree.selectedItems.put(poNode.index, poNode);
   poNode.parent = this;
   poNode.depth = this.depth + 1;
   for(var i = 0; i < poNode.children.length; i++) {
     voChild = poNode.children[i];
     voChild.depth++;
   }
   if(this.depth > 0) {
     poNode.leftside = new Array();
     for(var i = 0; i < this.leftside.length; i++) {
       poNode.leftside[poNode.leftside.length] = this.leftside[i];
     }
     poNode.leftside[poNode.leftside.length] = this.parent.getLastChild() == this ? 0 : 1;
   } else {
     poNode.leftside = new Array();
   }
   poNode.fixDecendantsInfo();
   if(this.getChildCount() > 1) this.children[this.children.length - 2].fixLeftsideOfChildren();
   if(this.tree != null) this.tree.addChangedNode(this);
  } else {
    poNode.index = this.tree.latestIdx++;
    this.tree.items.put(poNode.index, poNode);
    var voTarget = this.children[pnIndex - 1]
    for(var i = this.children.length - 1; i >= pnSourceIndex; i--) {
      this.children[i + 1] = this.children[i];
    }
    this.children[pnSourceIndex] = voTarget;
    this.children[pnIndex] = poNode;
    poNode.tree = this.tree;
    poNode.parent = this;
    poNode.depth = this.depth + 1;
    if(this.depth > 0) {
      poNode.leftside = new Array();
      for(var i = 0; i < this.leftside.length; i++) {
        poNode.leftside[poNode.leftside.length] = this.leftside[i];
      }
      poNode.leftside[poNode.leftside.length] = this.parent.getLastChild() == this ? 0 : 1;
    } else {
      poNode.leftside = new Array();
    }
    poNode.fixDecendantsInfo();
    if(this.tree != null) this.tree.addChangedNode(this);
  }
};
/**
 * addNodeset
 * @param {eXria.controls.xhtml.TreeNodeset} poNodeset
 * @param {eXria.form.xhtml.Canvas} poCanvas Canvas 객체
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.addNodeset = function(poNodeset, poCanvas) {
  //this.children[this.children.length] = poNodeset;
  poNodeset.tree = this.tree;
  if(this.tree != null) this.tree.addChangedNode(this);
  poNodeset.loadData(this, poCanvas);
};
/**
 * 자식 노드의 expand속성을 true로 갱신하는 메소드.<br>
 * 노드 새로고침 시 트리에 결과 반영.
 */
eXria.controls.xhtml.TreeNode.prototype.expandChildren = function() {
  this.expand = true;
  for(var i=0; i<this.children.length; i++){
    this.children[i].expand = true;
  }
};
/**
 * 자식 노드와 그 하위의 자식노드 모두의 expand속성을 true로 갱신하는 메소드.<br>
 * 노드 새로고침 시 트리에 결과 반영.
 */
eXria.controls.xhtml.TreeNode.prototype.expandDecendants = function() {
  this.expand = true;
  for(var i=0; i<this.children.length; i++){
    this.children[i].expand = true;
    this.children[i].expandDecendants();
  }
};
/**
 * Fix depth of decendants
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.fixDecendantsInfo = function() {
  for(var i = 0; i < this.children.length; i++) {
    this.children[i].tree = this.tree;
    this.children[i].depth = this.depth + 1;
    this.children[i].leftside = new Array();
    for(var j = 0; j < this.leftside.length; j++) {
      this.children[i].leftside[this.children[i].leftside.length] = this.leftside[j];
    }
    this.children[i].leftside[this.children[i].leftside.length] = this.parent.getLastChild() == this ? 0 : 1;
    this.children[i].fixDecendantsInfo();
  }
};
/**
 * Fix Leftside of Children
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.fixLeftsideOfChildren = function() {
  this.fixLeftsideOfDescendants(this.depth, this.parent.getLastChild() == this ? 0 : 1);
};
/**
 * fixLeftsideOfDescendants
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.fixLeftsideOfDescendants = function(pnDepth, pnValue) {
  for(var i = 0; i < this.children.length; i++) {
    this.children[i].leftside[pnDepth - 1] = pnValue;
    this.children[i].fixLeftsideOfDescendants(pnDepth, pnValue);
  }
};
/**
 * Removes aChild from this node's child array, giving it a null parent.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.remove = function(poNode) {
  for(var i = 0; i < this.children.length; i++) {
    if(this.children[i] == poNode) {
      poNode.parent = null;
      poNode.depth = - 1;
      poNode.tree = null;
      this.tree.remove(poNode);
      this.tree.removeFromChangedNode(poNode);
      this.tree.removeFromSelectedNode(poNode);
      if(this.tree.openedItem == poNode) {
        this.tree.openedItem = null;
      }
      this.children.splice(i, 1);
      break;
    }
  }
  if(this.getChildCount() > 0) this.children[this.children.length - 1].fixLeftsideOfChildren();
  if(this.tree != null) this.tree.addChangedNode(this);
};
/**
 * 하위노드(노드셋) 제거.
 * @param {eXria.controls.xhtml.TreeNode|eXria.controls.xhtml.TreeNodeset} poChild 하위노드(노드셋)
 */
eXria.controls.xhtml.TreeNode.prototype.removeChild = function(poChild) {
  var vnIndex = this.getChildCollectionIdx(poChild);
  if(vnIndex != -1) this.childCollection.remove(vnIndex);
};
/**
 * 하위노드(노드셋) 제거.
 * @param {eXria.controls.xhtml.TreeNode|eXria.controls.xhtml.TreeNodeset} poChild 하위노드(노드셋)
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeAll = function() {
  this.childCollection.clear();
};
/**
 * 하위노드(노드셋)의 인덱스 반환.
 * @param {eXria.controls.xhtml.TreeNode|eXria.controls.xhtml.TreeNodeset} poChild 하위노드(노드셋)
 * @return 하위노드(노드셋)의 인덱스
 * @type Number
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.getChildCollectionIdx = function(poChild) {
  var vnIndex = -1;
  var voIterator = this.childCollection.iterator();
  var voChild = null;
  var i = -1;
  while(voIterator.hasNext()) {
    i++;
    voChild = voIterator.next();
    if(voChild == poChild) {
      vnIndex = i;
      break;
    }
  }
  return vnIndex;
};

/**
 * Removes all of this node's children, setting their parents to null.
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeAllChildren = function() {
  var vnSize = this.children.length;
  for(var i = 0; i < vnSize; i++) {
    this.children[i].parent = null;
    this.children[i].depth = - 1;
    this.children[i].tree = null;
    if(this.tree && this.children[i].index) {
      this.tree.removeFromChangedNode(this.children[i]);
      this.removeFromTreeItems(this.children[i]);
    }
  }
  this.children = new Array();
  if(this.tree) this.tree.addChangedNode(this);
};
/**
 * Removes all of specified node's children include itself from tree items.
 * @param {eXria.controls.xhtml.TreeNode} poNode specified node
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeFromTreeItems = function(poNode) {
  this.tree.remove(poNode);
  var vnSize = poNode.children.length;
  for(var i = 0; i < vnSize; i++) {
    this.removeFromTreeItems(poNode.children[i]);
  }
};
/**
 * Removes the subtree rooted at this node from the tree, giving this node a null parent
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeFromParent = function() {
  this.parent.remove(this);
};
/**
 * 이 노드가 선택되었는지 여부 반환.
 * @Return 이 노드가 선택되었는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.TreeNode.prototype.isSelected = function() {
  var vbSelected = false;
  if(this.tree != null) {
    //for(var i = 0; i < this.tree.selectedItems.size(); i++) {
    //  if(this.tree.selectedItems.get(i) == this) vbSelected = true;
    //}
    if(this.tree.selectedItems.get(this.index)) vbSelected = true;
  }
  return vbSelected;
};
/**
 * 노드가 열려져 있는지 여부 반환.
 * 현재 선택되어진 상태라는 점에서 expanded와는 구별됨.
 * @return 노드가 열려져 있는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.TreeNode.prototype.isOpened = function() {
  var vbOpened = false;
  if(this.tree != null) {
    if(this.tree.openedItem.expand == true &&
        this.tree.openedItem.childCollection.length != 0) vbOpened = true;
  }
  return vbOpened;
};
/**
 * 자식 노드의 개수 반환.
 * @return 자식 노드의 개수
 * @type Number
 */
eXria.controls.xhtml.TreeNode.prototype.getChildCount = function() {
   return this.children.length;
};
/**
 * 지정된 노드의 다음 형제 노드 반환.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return 지정된 노드의 다음 형제 노드
 * @type eXria.controls.xhtml.TreeNode
 * @example
 * var treeView = page.getControl("treeview");<br>
   var node = treeView.getNodeByVal("value");<br>
   node.getChildAfter(node);<br>
 */
eXria.controls.xhtml.TreeNode.prototype.getChildAfter = function(poNode) {
  var voAfter = null;
  for(var i = 0; i < this.children.length - 1; i++) {
    if(this.children[i] == poNode) {
      for(var j = i + 1; j < this.children.length; j++) {
        voAfter = this.children[j];
        if(voAfter.visible != false) {
          return voAfter;
        }
      }
    }
  }
  return null;
};
/**
 * 지정된 노드의 이전 형제 노드 반환.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return 지정된 노드의 이전 형제 노드
 * @type eXria.controls.xhtml.TreeNode
 * @example
 * var treeView = page.getControl("treeview");<br>
   var node = treeView.getNodeByVal("value");<br>
   node.getChildBefore(node);<br>
 */
eXria.controls.xhtml.TreeNode.prototype.getChildBefore = function(poNode) {
   var voBefore = null;
   for(var i = 1; i < this.children.length; i++) {
      if(this.children[i] == poNode) voBefore = this.children[i - 1];
   }
   return voBefore;
};
/**
 * 첫 번째 자식 노드 반환.
 * @return 첫 번째 자식 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getFirstChild = function() {
   return this.children[0];
};
/**
 * 마지막 자식 노드 반환.
 * @return 마지막 자식 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getLastChild = function() {
  var voChild = null;
  for(var i = this.children.length - 1; i >= 0; i--) {
    voChild = this.children[i];
    if(voChild.visible != false) return voChild;
  }
  return null;
};
//this.getLastChild = function() {
//  return this.children[this.children.length - 1];
//};
/**
 * 지정된 인덱스에 해당하는 자식 노드를 반환.
 * @param pnIndex 자식의 인덱스
 * @return 지정된 인덱스에 해당하는 자식 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getChildAt = function(pnIndex) {
   return this.children[pnIndex];
};
/**
 * 지정된 자식노드의 인덱스 번호 반환. 자식노드가 없으면 -1 반환.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @return 지정된 자식노드의 인덱스 번호
 * @type Number
 * @example
   var treeView = page.getControl("treeview");<br>
   var node = treeView.getNodeByVal("value");<br>
   var lastNode = node.getLastChild();<br>
   node.getIndex(lastNode);<br>
 */
eXria.controls.xhtml.TreeNode.prototype.getIndex = function(poNode) {
   var index = - 1;
   for(var i = 0; i < this.children.length; i++) {
      if(this.children[i] == poNode) index = i;
   }
   return index;
};
/**
 * Returns the path from the root, to get to this node.
 * @return 루트노드로 부터의 path값
 * @type String
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.getPath = function() {
  var vsPath = "";
  vsPath = this.updatePath(this, vsPath);

  return vsPath;
};
/**
 * path 속성 값 갱신
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {String} psPath 갱신될 path 값
 * @return vsPath
 * @type String
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.updatePath = function(poNode, psPath) {
  var vsPath = psPath;
  var vsNodePath = "/tn[@name='" + poNode.name + "']";
  vsPath = vsNodePath + vsPath;
  if(poNode.parent != null) {
    vsPath = this.updatePath(poNode.parent, vsPath);
  } else {
    vsPath = "/root" + vsPath;
  }

  return vsPath;
};
/**
 * 현재 노드가 소속되어 있는 루트노드 반환.
 * @return 현재 노드가 소속되어 있는 루트노드
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.getRoot = function() {
   return this.tree.root;
};
/**
 * value key 이외의 값을 저장할 수 있는 Map에 put.
 * @param {String} psKey 데이타의 키 값
 * @param {String} poValue 데이타
 */
eXria.controls.xhtml.TreeNode.prototype.put = function(psKey, poValue) {
   this.extData.put(psKey, poValue);
};
/**
 * 해당 키 값에 대한 value 값을 얻음.
 * @param {String} poKey extData에서 추출할 데이타의 키 값
 * @return 해당 키 값에 대한 value 값
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.get = function(poKey) {
   var value = null;
   value = this.extData.get(poKey);
   return value;
};
/**
 * 트리노드에 할당된 값 반환.
 * @return 트리노드에 할당된 값
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.getValue = function() {
  var vsValue = null;
  vsValue = this.extData.get("value");
  return vsValue;
};
/**
 * 트리노드에 value값 할당.
 * @param {String} psValue 할당될 value값.
 */
eXria.controls.xhtml.TreeNode.prototype.setValue = function(psValue) {
  this.extData.put("value", psValue);
};
/**
 * Clone of this
 * @return Clone of this
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.clone = function() {
   var voNode = new TreeNode(this.name);
   voNode.icon = this.icon;
   voNode.isAllowChildren = this.isAllowChildren;
   voNode.extData = this.extData;
   for(var i = 0; i < this.getChildCount(); i++) {
      voNode.add(this.children[i].clone());
   }
   return voNode;
};
/**
 * 트리노드의 스타일 속성값을 일괄적으로 변경하기 위한 메소드.
 * @param {Object} poStyleObject 변경될 속성값을 담은 오브젝트
 * @example
 * var data = new eXria.data.Map();
   data.put("name","newName");

   var node = treeView.getNodeByVal("value");
   node.setNodeStyle(data.getEntries());
 */
eXria.controls.xhtml.TreeNode.prototype.setNodeStyle = function(poStyleObject) {
  var vsAttr = null;
  for(vsAttr in poStyleObject) {
    this[vsAttr] = poStyleObject[vsAttr];
  }
  this.tree.addChangedNode(this);
};
/**
 * 클래스 명을 반환.
 * @return "TreeNode"
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.toString = function() {
  return "TreeNode";
};

/**
 * @class Concreate xhtml TreeNodeset.<br>
 * TreeView 컨트롤을 구성하는 아이템의 속성정보를 담당하는 클래스.
 * 아이템의 실체화는 TreeView에서 담당.
 * @version 1.0
 * @return 새로운 eXria.controls.xhtml.TreeNodeset 객체
 * @type eXria.controls.xhtml.TreeNodeset
 * @constructor
 */
eXria.controls.xhtml.TreeNodeset = function() {
  /**
   * @private
   */
  //this.index = null;
  /**
   * 인스턴스 데이터로 부터 label 데이타를 가져오기 위한 element 태그명.
   * @type String
   */
  this.labelTagName = null;
  /**
   * 인스턴스 데이터로 부터 value 데이타를 가져오기 위한 element 태그명.
   * @type String
   */
  this.valueTagName = null;
  /**
   * 인스턴스 데이터로 부터 icon image path 데이타를 가져오기 위한 element 태그명.
   * @type String
   */
  this.iconTagName = null;
  /**
   * 인스턴스 데이터로 부터 iconOpened image path 데이타를 가져오기 위한 element 태그명.
   * @type String
   */
  this.iconOpenedTagName = null;
  /**
   * 부모 데이타 노드에서 라벨 데이타를 가져올 때 사용되는 DOM Element 명.
   * @type String
   */
  this.parentTagName = "parent";
  /**
   * tree 컨트롤 참조 변수. readOnly
   * @type eXria.controls.xhtml.TreeView
   */
  this.tree = null;
  /**
   * 데이타 연동 객체.
   * @type eXria.controls.DataRefNodeset()
   */
  this.data = new eXria.controls.DataRefNodeset();

};
/**
 * loadData
 * @param {eXria.controls.xhtml.TreeNode} poParentTreeNode
 * @param {eXria.form.xhtml.Canvas} poCanvas
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.loadData = function(poParentTreeNode, poCanvas) {
  var voTree = this.tree;
  if(voTree == null || (this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null)) return;
  if(voTree.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    this.loadDataFromPluginInstance(poParentTreeNode, poCanvas);
    return;
  }
  this.data.control = voTree;

  var vsRefValue = null;
  if(this.data.instanceId != null) vsRefValue = this.data.getData();
  var voCollectionNode = this.data.getNodesetData2();
  if(voCollectionNode == null) return;
  var vnLoop = voCollectionNode.getLength();
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vsSelectNode = null;
  var vsDisableNode = null;
  var vsWbsType = null;
  var vsParentNode = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  var vaNodes = [];
  var voTreeNode = null;
  var vsIcon = null;
  var vsIconOpened = null;
  this.parent = poParentTreeNode;
  var vsParentValue = poParentTreeNode.getValue();
  for(var i = 0; i < vnLoop; i++) {
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
    vsLabelNode = voMapNode.get(this.labelTagName);
    vsValueNode = voMapNode.get(this.valueTagName);
    vsParentNode = voMapNode.get(this.parentTagName);
    if(vsParentNode == null || vsParentNode == "") vsParentNode = vsParentValue;
    if(voTree.selectTagName) vsSelectNode = voMapNode.get(voTree.selectTagName);
    if(voTree.disableTagName) vsDisableNode = voMapNode.get(voTree.disableTagName);
    if(voTree.wbsTypeTagName) {
      vsWbsType = voMapNode.get(voTree.wbsTypeTagName);
    }
    vsIcon = voMapNode.get(this.iconTagName);
    vsIcon = eXria.controls.xhtml.Util.getImagePath(vsIcon, poCanvas.page.window);
    vsIconOpened = voMapNode.get(this.iconOpenedTagName);
    vsIconOpened = eXria.controls.xhtml.Util.getImagePath(vsIconOpened, poCanvas.page.window);
    voTreeNode = voTree.createTreeNode(vsLabelNode);
    voTreeNode.nodeset = this;
    voTreeNode.tree = this.tree;
    voTreeNode.put("value", vsValueNode);
    voTreeNode["parentValue"] = vsParentNode;
    if(vsSelectNode == "Y") voTreeNode.selected = true;
    if(vsDisableNode == "Y") voTreeNode.disabled = true;
    if(vsWbsType && voTree.wbsIconMap) {
      vsIcon = voTree.wbsIconMap[vsWbsType];
      vsIcon = eXria.controls.xhtml.Util.getImagePath(vsIcon, poCanvas.page.window);
      vsIconOpened = vsIcon;
    }
    voTreeNode.icon = vsIcon;
    voTreeNode.iconOpened = vsIconOpened;
    vaNodes.push(voTreeNode);
    this.tree.addToItemValueMap(voTreeNode, vsValueNode);
    //if(vsLabelNode == vsRefValue) {
    //  this.tree.selectedItems.add(voTreeNode);
    //}
    //this.checkParent(voTreeNode, vsParentNode);
  }
  var voMap = this.tree.itemValueMap;
  var voFunc = this.tree.mapBlockIdFunc;
  for(var i = 0; i < vaNodes.length; i++) {
    voTreeNode = vaNodes[i];
    vsParentNode = voTreeNode["parentValue"];
//    this.checkParent(voTreeNode, vsParentNode, vaNodes, i);
    this.checkParent(voTreeNode, vsParentNode, voMap, voFunc);
  }
};
/**
 * loadDataFromPluginInstance
 * @param {eXria.controls.xhtml.TreeNode} poParentTreeNode
 * @param {eXria.form.xhtml.Canvas} poCanvas
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.loadDataFromPluginInstance = function(poParentTreeNode, poCanvas) {
  var voTree = this.tree;
  if(voTree == null || (this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null)) return;
  this.data.control = voTree;

  var vsRefValue = null;
  if(this.data.instanceId != null) vsRefValue = this.data.getData();
  var voCollectionNode = this.data.getNodesetStr();
  if(voCollectionNode == null) return;
  voCollectionNode = eval(voCollectionNode);
  var vnLoop = voCollectionNode.length;
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vsParentNode = null;
  var vsSelectNode = null;
  var vsDisableNode = null;
  var vsWbsType = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  var vaNodes = [];
  var voTreeNode = null;
  var vsIcon = null;
  var vsIconOpened = null;
  this.parent = poParentTreeNode;
  var vsParentValue = poParentTreeNode.getValue();
  for(var i = 0; i < vnLoop; i++) {
    voMapNode = voCollectionNode[i];
    vsLabelNode = voMapNode[this.labelTagName];
    vsValueNode = voMapNode[this.valueTagName];
    vsParentNode = voMapNode[this.parentTagName];
    if(vsParentNode == null || vsParentNode == "") vsParentNode = vsParentValue;
    if(voTree.selectTagName) vsSelectNode = voMapNode[voTree.selectTagName];
    if(voTree.disableTagName) vsDisableNode = voMapNode[voTree.disableTagName];
    if(voTree.wbsTypeTagName) {
      vsWbsType = voMapNode[voTree.wbsTypeTagName];
    }
    vsIcon = voMapNode[this.iconTagName];
    vsIcon = eXria.controls.xhtml.Util.getImagePath(vsIcon, poCanvas.page.window);
    vsIconOpened = voMapNode[this.iconOpenedTagName];
    vsIconOpened = eXria.controls.xhtml.Util.getImagePath(vsIconOpened, poCanvas.page.window);
    voTreeNode = voTree.createTreeNode(vsLabelNode);
    voTreeNode.nodeset = this;
    voTreeNode.tree = this.tree;
    voTreeNode.put("value", vsValueNode);
    voTreeNode["parentValue"] = vsParentNode;
    if(vsSelectNode == "Y") voTreeNode.selected = true;
    if(vsDisableNode == "Y") voTreeNode.disabled = true;
    if(vsWbsType && voTree.wbsIconMap) {
      vsIcon = voTree.wbsIconMap[vsWbsType];
      vsIcon = eXria.controls.xhtml.Util.getImagePath(vsIcon, poCanvas.page.window);
      vsIconOpened = vsIcon;
    }
    voTreeNode.icon = vsIcon;
    voTreeNode.iconOpened = vsIconOpened;
    vaNodes.push(voTreeNode);
    this.tree.addToItemValueMap(voTreeNode, vsValueNode);
    //if(vsLabelNode == vsRefValue) {
    //  this.tree.selectedItems.add(voTreeNode);
    //}
    //this.checkParent(voTreeNode, vsParentNode);
  }
  var voMap = this.tree.itemValueMap;
  var voFunc = this.tree.mapBlockIdFunc;
  for(var i = 0; i < vaNodes.length; i++) {
    voTreeNode = vaNodes[i];
    vsParentNode = voTreeNode["parentValue"];
//    this.checkParent(voTreeNode, vsParentNode, vaNodes, i);
    this.checkParent(voTreeNode, vsParentNode, voMap, voFunc);
  }
};
/**
 * checkParent
 * @private
 */
//eXria.controls.xhtml.TreeNodeset.prototype.checkParent = function(poTreeNode, psParentNode, paNodes, pnBaseIdx) {
 eXria.controls.xhtml.TreeNodeset.prototype.checkParent = function(poTreeNode, psParentNode, poMap, poMapBlockIdFunc) {
    var voParentNode = null;
    if(psParentNode == null || psParentNode == "") {
      //if(this.tree) voParentNode = this.tree.root;
      voParentNode = this.parent;
      if(voParentNode) voParentNode.add(poTreeNode);
      return;
    }
//    var vsBlockId = "gen";
//    if(poMapBlockIdFunc) {
//      vsBlockId = poMapBlockIdFunc(psParentNode);
//    }
//    voParentNode = poMap[vsBlockId][psParentNode];
    voParentNode = poMap[psParentNode]
    if(!!voParentNode) voParentNode.add(poTreeNode);
};
/**
 * data 속성으로 부터 DOM 데이타를 얻어옴.
 * @return data 속성으로 부터 얻어온 DOM 데이타
 * @type XMLElement
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.getInstanceData =function() {
  var viInstance = this.data.getNodesetInstance();
  var voDataNode = null;
  if(viInstance) voDataNode = viInstance.selectSingleNode(this.data.nodesetInstancePath);
  return voDataNode;
};
/**
 * makeTreeByData
 * @param {eXria.controls.xhtml.TreeNode} poParentTreeNode
 * @param {XMLElement} poParentDataNode
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.makeTreeByData = function(poParentTreeNode, poParentDataNode) {
  var voTreeNode = null;
  var voChild = null;
  var vnNodeType = -1;
  for(var i = 0; i < poParentDataNode.childNodes.length; i++) {
    voChild = poParentDataNode.childNodes[i];
    vnNodeType = voChild.nodeType;
    if(vnNodeType == 1) {
      voTreeNode = this.makeTreeNodeByData(voChild);
      poParentTreeNode.add(voTreeNode);
      if(voChild.childNodes.length > 0) this.makeTreeByData(voTreeNode, voChild);
    }
  }
};
/**
 * makeTreeNodeByData
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return poNode에 의해 새롭게 생성된 트리노드
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.makeTreeNodeByData = function(poNode) {
  var vsName = poNode.getAttribute(this.labelTagName);
  var voTreeNode = this.tree.createTreeNode(vsName);
  var voAttr = null;
  var vnNodeType, vsAttrName, vsAttrValue;
  for(var i = 0; i < poNode.attributes.length; i++) {
    voAttr = poNode.attributes[i];
    vsAttrName = voAttr.nodeName;
    if(vsAttrName == this.labelTagName) continue;
    vsAttrValue = voAttr.nodeValue;
    voTreeNode.put(vsAttrName, vsAttrValue);
  }
  return voTreeNode;
};
/**
 * 클래스 명을 반환.
 * @return "TreeNodes"
 * @type String
 */
eXria.controls.xhtml.TreeNodeset.prototype.toString = function() {
  return "TreeNodeset";
};


/**
 * 트리뷰 아이템의 공통 속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.TreeView_itemgroup = function() {
  /**
   * 아이템 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 아이템 텍스트 색상.
   * @type String
   */
  this.color = null;
  /**
   * 선택된 아이템의 배경 색상.
   * @type String
   */
  this.selectedBackgroundColor = null;
  /**
   * 선택된 아이템의 텍스트 색상.
   * @type String
   */
  this.selectedColor = null;
  /**
   * 아이템에 마우스 위치 시 커서 유형.
   * @type String
   */
  this.cursor = null;
  /**
   * 아이템 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 아이템 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 아이템 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 아이템 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 아이템 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 아이템 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 아이템에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 아이템의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};


/**
 * @class Concreate xhtml TreeView.<br>
 * XHTML TreeView 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return eXria.controls.xhtml.TreeView 새로운 객체
 * @type eXria.controls.xhtml.TreeView
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.TreeView = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft =  pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth =  pnWidth == null ? 200 : pnWidth;
  pnHeight =  pnHeight == null ? 250 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  // 데이타연동관련
  /**
   * Data 연동 객체.
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * 인스턴스로 부터 라벨 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.labelTagName = "label";
  /**
   * 인스턴스로 부터 value 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.valueTagName = "value";
  // 데이타연동관련End
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 루트노드 전체 노드의 최상위 노드. 화면에 보여지지는 않음.
   * @private
   */
  this.root = null;
  /**
   * 전체 트리노드를 노드 index를 key로 해서 저장하는 eXria.data.ArrayMap 객체.
   * @type eXria.data.ArrayMap
   * @private
   */
  this.items = new eXria.data.ArrayMap();
  /**
   * 전체 트리노드를 노드 value를 key로 해서 저장 맵 객체.
   * @type Object
   * @private
   */
  this.itemValueMap = {};
  /**
   * 노드 생성 후 노드 간 관계 설정 시 순차적으로 증가하는 노드 인덱스(노드 ID 생성에 이용)의 최근값 저장.
   * @type Number
   * @private
   */
  this.latestIdx = 0;
  /**
   * 트리뷰에 사용될 아이콘 이미지 경로 속성들을 포함하는 오브젝트.<br>
   * blank : 여백을 표현하기 위해 사용되는 이미지.<br>
   * verticalLine : 노드 연결 선을 표현하는 이미지.<br>
   * closedLastnode : 트리의 가지끝에 위치하며 닫힌 하위 포함 노드를 표현하는 이미지.<br>
   * closedNode : 트리의 가지 중간에 위치하며 닫힌 하위 포함 노드를 표현하는 이미지.<br>
   * openedLastnode : 트리의 가지끝에 위치하며 펼쳐진 하위 포함 노드를 표현하는 이미지.<br>
   * openedNode : 트리의 가지 중간에 위치하며 펼쳐진 하위 포함 노드를 표현하는 이미지.<br>
   * lastnode : 트리의 가지끝에 위치하는 노드(하위 노드가 없음)를 표현하는 이미지.<br>
   * node : 트리의 가지 중간에 위치하는 노드를 표현하는 이미지.<br>
   * closedFolder : 닫힌 노드 옆에 위치하는 아이콘 이미지.<br>
   * openedFolder : 펼쳐진 노드 옆에 위치하는 아이콘 이미지<br>
   * leafItem : 노드(하위 노드가 없음) 옆에 위치하는 아이콘 이미지.<br>
   * selectedLeafItem : 선택된 노드(하위 노드가 없음) 옆에 위치하는 아이콘 이미지.<br>
   * @type Object
   */
  this.iconFiles = {
    blank : null, //0
    verticalLine : null, //1
    closedLastnode : null, //2
    closedNode : null, //3
    openedLastnode : null, //4
    openedNode : null, //5
    lastnode : null, //6
    node : null, //7
    closedFolder : null, //8
    openedFolder : null, //9
    leafItem : null, //10
    selectedLeafItem : null //11
  };
  /**
   * 아이콘 이미지 경로 상수에 해당하는 실체화 객체를 저장하는 Map.
   * @type eXria.data.ArrayMap
   */
  this.icons = new eXria.data.ArrayMap();
  /**
   * Selection Mode.<br>
   * 트리노드의 선택 유형[단일선택, 다중선택].
   * @type String
   * @ignore
   */
  this.selectionMode = null;//[single | multi]
  /**
   * Selected Node instance.<br>
   * 선택된 트리노드 리스트(펼쳐진 트리노드와는 구별됨. 텍스트가 선택된 트리노드).
   */
  this.selectedItems = new eXria.data.ArrayMap();
  /**
   * Opened Node.<br>
   * 열려진 트리노드(마지막으로 선택된 트리노드).
   * @type eXria.controls.xhtml.TreeNode
   * @private
   */
  this.openedItem = null;
  /**
   * 아이템 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 아이템 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 아이템 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 아이템 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 아이템 텍스트 컨텐츠 오버플로우 속성.
   * @type String
   */
  this.overflow = null;
  /**
   * 아이템 텍스트 컨텐츠 오버플로우X 속성.
   * @type String
   */
  this.overflowX = null;
  /**
   * 아이템 텍스트 컨텐츠 오버플로우Y 속성.
   * @type String
   */
  this.overflowY = null;
  /**
   * 이미지 파일이 위치한 디렉토리(절대경로).
   * @type String
   */
  this.iconDir = null;
  /**
   * 이미지 파일의 가로길이(사용되는 모든 이미지 파일에 사이즈는 동일해야함).
   * @type Number
   */
  this.iconWidth = null;
  /**
   * 이미지 파일의 세로길이.
   * @type Number
   */
  this.iconHeight = null;
  /**
   * Changed node list for repaint.<br>
   * redraw 해할야 트리노드 목록.
   * @type eXria.data.ArrayCollection
   * @private
   */
  this.changedNodes = new eXria.data.ArrayCollection();
  /**
   * Name of Root Node
   * @type String
   * @private
   */
  this.rootName = "ROOT";
  /**
   * 선택된 트리노드의 값.
   * @type String
   */
  this.value = null;
  /**
   * 드래그&드랍을 허용할 지 여부.
   * @type Boolean
   */
  this.dragDrop = false;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 아이템 공통 속성 저장 오브젝트.
   * @type Object
   * @private
   */
  this.itemgroup = new eXria.controls.xhtml.TreeView_itemgroup();
  /**
   * 마우스가 텍스트에 위치해 있을 때의 마우스 커서 타입.
   * @type String
   * @private
   */
  this.spanCursor = "pointer";
  /**
   * 이벤트 target이 컨트롤인지 아이템인지를 구분하기 위한 속성.
   * @type String
   * @private
   */
   this.eventObjectType = null;
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type Object
   * @private
   */
  this.document = null;
  /**
   * 새로고침시 이전 노드 펼침상태를 유지할지 여부.
   * @type Boolean
   */
  this.keepExpandedState = null;
  /**
   * 펼쳐진 노드의 루트 노드로부터의 상대 위치를 저장하는 배열 .
   * @type Array(String)
   * @private
   */
  this.expandedIndexes = [];
  /**
   * 체크박스를 보여줄지 여부.
   * @type Boolean
   */
  this.showCheckBox = null;
  /**
   * @return 클릭 타임.
   * @type Number
   * @private
   */
  this.clickTime = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트.
   * @type Object
   * @private
   */
  this.df = {};

  this.init();
  /**
   * 컨트롤의 하위 HTMLElement 요소들.
   * @private
   */
  this.subElement = {};
  /**
   * 최대 노드의 길이.
   * @private
   */
  this.maxLen = 0;
  /**
   * 노드를 펼쳐 보일것인가의 여부
   * @type Boolean
   */
  this.expandAll = null;
  /**
   * 트리 형태 지정 문자열
   * @type String
   */
  this.trvType = null;
  /**
   * 라벨 배경색 정보 저장 배열
   * @type Array(String)
   */
  this.lblColors = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.TreeView);
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.init = function() {
  this.root = this.createTreeNode(this.rootName);
  this.root.index = this.latestIdx++;
  this.root.setValue("");
  this.root.tree = this;
  this.root.depth = 0;
  this.root.expand = true;
  this.items.put(this.root.index, this.root);
};

eXria.controls.xhtml.TreeView.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  // ie브라우저일 경우 focus 시에 점선 테두리 안보이게 하기
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};

//eXria.controls.xhtml.TreeView.prototype.createSubCtrl = function(poCtrl, poDocument) {
//  var voTable = poDocument.createElement("div");
//  voTable.setAttribute("id", this.id + "_table");
//  var voStyle = voTable.style;
//  voStyle.position = "absolute" ;
//  voStyle.margin = "0px";
//  voStyle.padding = "0px"
//  voStyle.left = "0px";
//  voStyle.top = "0px";
//
//  voTable.ondragstart = function(e) { return false; };
//  voTable.onselectstart = function(e) { return false; };
//  voTable.oncontextmenu = function(e) { return false; };
//  poCtrl.appendChild(voTable);
//
//  this.loadIcons();
//};

eXria.controls.xhtml.TreeView.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);

  vaTemplate.push("<div id='");
  vaTemplate.push(this.id);
  // yhkim 2009.09.04
  //vaTemplate.push("_table' style='position:absolute;margin:0px;padding:0px;left:0px;top:0px;width:" + this.innerWidth + "px;height:" + this.innerHeight + "px;'");
  vaTemplate.push("_table' style='position:absolute;margin:0px;padding:0px;left:0px;top:0px;width:0px;height:0px;'>");
  //vaTemplate.push(" ongragstart=\"return false;\" onselectstart=\"return false;\" oncontextmenu=\"return false;\"");
  //vaTemplate.push(" class='" + vsClass + "'>");
  vaTemplate.push("</div>");

  // yhkim 2009.09.15 span에 적용해줘야 동적으로 setNodeCtrl에서 font-size에 맞게 결정된다
  var vsClass = this.getCSSClass(this, 1, "itemgroup");

  vaTemplate.push("<span class = '" + vsClass + "' style=\"");
  vaTemplate.push("@cssStrBuf"); //0
  vaTemplate.push("\"/>");

  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
//  poCtrl.innerHTML = vaTemplate.join("");
//  vaTemplate = null;
};

eXria.controls.xhtml.TreeView.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voIconFiles = this.iconFiles;
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup;
  voIconFiles.blank = this.getAttrValue("iconFiles.blank",voIconFiles.blank);
  voIconFiles.verticalLine = this.getAttrValue("iconFiles.verticalLine",voIconFiles.verticalLine);
  voIconFiles.closedLastnode = this.getAttrValue("iconFiles.closedLastnode",voIconFiles.closedLastnode);
  voIconFiles.closedNode = this.getAttrValue("iconFiles.closedNode",voIconFiles.closedNode);
  voIconFiles.openedLastnode = this.getAttrValue("iconFiles.openedLastnode",voIconFiles.openedLastnode);
  voIconFiles.openedNode = this.getAttrValue("iconFiles.openedNode",voIconFiles.openedNode);
  voIconFiles.lastnode = this.getAttrValue("iconFiles.lastnode",voIconFiles.lastnode);
  voIconFiles.node = this.getAttrValue("iconFiles.node",voIconFiles.node);
  voIconFiles.closedFolder = this.getAttrValue("iconFiles.closedFolder",voIconFiles.closedFolder);
  voIconFiles.openedFolder = this.getAttrValue("iconFiles.openedFolder",voIconFiles.openedFolder);
  voIconFiles.leafItem = this.getAttrValue("iconFiles.leafItem",voIconFiles.leafItem);
  voIconFiles.selectedLeafItem = this.getAttrValue("iconFiles.selectedLeafItem",voIconFiles.selectedLeafItem);

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.iconDir = this.getAttrValue("iconDir",this.iconDir);
  this.iconWidth = this.getAttrValue("iconWidth",this.iconWidth);
  this.iconHeight = this.getAttrValue("iconHeight",this.iconHeight);
  this.expandAll = this.getAttrValue("expandAll",this.expandAll);
  this.showCheckBox = this.getAttrValue("showCheckBox", this.showCheckBox);
  this.selectionMode = this.getAttrValue("selectionMode",this.selectionMode);
  if(this.showCheckBox == true) this.selectionMode = "multi";
  this.keepExpandedState = this.getAttrValue("keepExpandedState", this.keepExpandedState);

  voItemgroupDf.className = this.getAttrValue("itemgroup.className",this.itemgroup.className);
  voItemgroupDf.selectedBackgroundColor = this.getAttrValue("itemgroup.selectedBackgroundColor",this.itemgroup.selectedBackgroundColor);
  voItemgroupDf.selectedColor = this.getAttrValue("itemgroup.selectedColor",this.itemgroup.selectedColor);
  voItemgroupDf.cursor = this.getAttrValue("itemgroup.cursor", this.itemgroup.cursor);
  if(voItemgroupDf.cursor == null) voItemgroupDf.cursor = "pointer";
};

//eXria.controls.xhtml.TreeView.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
//  //var voRuler = this.lookup(this.id + "_ruler");
//  //var voStyle = voRuler.style;
//  //voStyle.fontFamily = this.fontFamily;
//  //voStyle.fontSize = this.fontSize + "pt";
//
//  this.setAttrCtrl("width", this.innerWidth, poCtrl);
//  this.setAttrCtrl("height", this.innerHeight, poCtrl);
//  this.setAttrCtrl("borderColor", voDf.borderColor, poCtrl);
//  this.setAttrCtrl("borderStyle", voDf.borderStyle, poCtrl);
//  this.setAttrCtrl("borderLeftWidth", voDf.borderLeftWidth + "px", poCtrl);
//  this.setAttrCtrl("borderRightWidth", voDf.borderRightWidth + "px", poCtrl);
//  this.setAttrCtrl("borderTopWidth", voDf.borderTopWidth + "px", poCtrl);
//  this.setAttrCtrl("borderBottomWidth", voDf.borderBottomWidth + "px", poCtrl);
//  this.setAttrCtrl("backgroundColor", voDf.backgroundColor, poCtrl);
//  this.setAttrCtrl("color", voDf.color, poCtrl);
//  this.setAttrCtrl("overflowX", voDf.overflowX, poCtrl);
//  this.setAttrCtrl("overflowY", voDf.overflowY, poCtrl);
//  this.setAttrCtrl("cursor", voDf.cursor, poCtrl);
//  this.setAttrCtrl("textAlign", voDf.textAlign, poCtrl);
//  this.setAttrCtrl("fontFamily", voDf.fontFamily, poCtrl);
//  this.setAttrCtrl("fontSize", voDf.fontSize, poCtrl);
//  this.setAttrCtrl("fontStyle", voDf.fontStyle, poCtrl);
//  this.setAttrCtrl("fontWeight", voDf.fontWeight, poCtrl);
//
//  this.loadIcons();
//
//  this.changedNodes.clear();
//  var voTable = poCtrl.childNodes[0];
//  try {
//    var size = voTable.childNodes.length;
//    for(var j = 0; j < size; j++) {
//      this.deleteTreeNode(0, poDocument);
//    }
//  } catch(err) {
//  }
//};

eXria.controls.xhtml.TreeView.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;

  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    this.trvType = voUserAttr.trvType;
    this.lblColors = voUserAttr.lblColors;
    if(this.lblColors == null) this.lblColors = [];
    this.lblClasses = voUserAttr.lblClasses;
    if(this.lblClasses == null) this.lblClasses = [];
    this.getNodeColor = voUserAttr.getNodeColor;
    this.selectTagName = voUserAttr.selectTagName;
    this.disableTagName = voUserAttr.disableTagName;
    if(this.trvType == "WBS") {
      this.wbsTypeTagName = voUserAttr.wbsTypeTagName;
      this.wbsIconMap = voUserAttr.wbsIconMap;
    }
    this.isOneLine = voUserAttr.isOneLine;
    if(this.isOneLine) this.expandAll = false;
    this.labelName = voUserAttr.labelName;
    this.allowExpand = voUserAttr.allowExpand;
    this.mapBlockIdFunc = voUserAttr.mapBlockIdFunc;
  }

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
//  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  // ie브라우저가 아닐 경우 focus 시에 점선 테두리 안보이게 하기
  if(this.canvas.page.metadata.browser.ie == 0) vfcSetCssStrBuf(vaCssStrBuf, "outline", "none");
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vaCssStrBuf.push("white-space:nowrap;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", voItemgroupDf.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", voItemgroupDf.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", voItemgroupDf.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", voItemgroupDf.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", voItemgroupDf.textDecoration);
  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");
  voIndexMap.clear();
  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  this.template = null;
  this.templateIndexMap = null;

  this.setSubElement(poDocument);

  this.loadIcons();
};
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;

  voSubElement.tableDiv = this.getSubCtrl("div", voCtrl, poDocument);
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};

eXria.controls.xhtml.TreeView.prototype.refreshTemplate = function(poCtrl, poDocument) {
  this.setTemplate(poCtrl, poDocument);
};

eXria.controls.xhtml.TreeView.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.refreshSpecificEvents = function(poCtrl) {
  this.setSpecificEvents(poCtrl);
};

eXria.controls.xhtml.TreeView.prototype.setSpecificEvents = function(poCtrl) {
};

eXria.controls.xhtml.TreeView.prototype.startDrag = function(e) {
  if(this.sourceItem == null) return;

  var voDocument = this.document;
//  var voParent = this.canvas;
  var vnLeft = 0;
  var vnTop = 0;
  var vnAbsLeft = 0;
  var vnAbsTop = 0;
  var voParent = this.parent;
  var voPage = this.canvas.page;
  while(voParent) {
    vnLeft += voParent.left;
    vnTop += voParent.top - voParent.ctrl.scrollTop;
    voParent = voParent.parent;
  }
  while(voPage) {
    var voFrameElement = voPage.window.frameElement;
    if(voFrameElement) {
      vnLeft += voFrameElement.offsetLeft;
      vnTop += voFrameElement.offsetTop;
      vnAbsLeft += voFrameElement.offsetLeft;
      vnAbsTop += voFrameElement.offsetTop;
    }
    if(voPage.window.parent.page && voPage != voPage.window.parent.page) voPage = voPage.window.parent.page;
    else break;
  }
  this.clientAbsLeft = vnAbsLeft;
  this.clientAbsTop = vnAbsTop;

  if(voPage == null) voParent = this.canvas;
  else voParent = voPage.canvas;
  voDocument = voPage.window.document;

  var voCtrl = this.ctrl;
  var voItem = this.sourceItem;

  var vnScrollTop = this.ctrl.scrollTop + this.canvas.ctrl.scrollTop;
  vnLeft += this.left + voItem.left;
//  vnTop += this.top + voItem.top;
  vnTop += this.top + parseInt(this.document.getElementById(this.id + "_node" + voItem.index).style.top) - vnScrollTop;

  this.dragDropHandler.srcObject = this.sourceItem;
  this.dragDropHandler.srcObjectType = "item";
  var voGlassPane = new eXria.controls.xhtml.GlassPane(voParent);
  voGlassPane.id = voParent.id + "_glassPane";
  this.glassPane = voGlassPane;
  voGlassPane.opacity = 50;
  voParent.ctrl.parentNode.appendChild(voGlassPane.create(voDocument));

  var voDragDropHandler = this.dragDropHandler;
  var voPaneCtrl = voDragDropHandler.createPane(vnLeft, vnTop, voItem.width, voItem.height, voDocument);
  var voPaneStyle = voPaneCtrl.style;

  var voEvent = e;
  var voTarget = voEvent.target;
  this.mode = voTarget.style.cursor;

  var vnMouseX = voEvent.e.clientX + this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY + this.clientAbsTop;

  var vnPaneLeft = parseInt(voPaneStyle.left);
  var vnPaneTop = parseInt(voPaneStyle.top);
  this.leftOffset = vnPaneLeft - vnMouseX;
  this.topOffset = vnPaneTop - vnMouseY;

  voPaneStyle.display = "block";
  voDocument.body.style.cursor = "move";
  this.ctrl.style.cursor = "move";

  voPaneCtrl.control = this;
  voPaneCtrl.onmousemove = function(e) {
    this.control.onDrag(e);
  };
  voPaneCtrl.onmouseup = function(e) {
    this.control.stopDrag(e);
  };
  voDocument.control = this;
  voDocument.onmousemove = function(e) {
    this.control.onDrag(e);
  };
  voDocument.onmouseup = function(e) {
    this.control.stopDrag(e);
  };
  if (typeof voPaneCtrl.onselectstart != "undefined") {
    voPaneCtrl.onselectstart = function(e) {
      return false;
    };
  } else {
    voPaneCtrl.onmousedown = function(e) {
      return false;
    };
  }
  var vnScrAreaLeft = vnAbsLeft + this.left;
  var vnScrAreaTop = vnAbsTop + this.top;
  var vnScrAreaWidth = this.width;
  var vnScrAreaHeight = this.height;
  if(voCtrl.scrollWidth > voCtrl.clientWidth) {
    var voScrollAreaLeft = voDragDropHandler.createScrollArea(vnScrAreaLeft, vnScrAreaTop, vnScrAreaWidth, vnScrAreaHeight, voItem.width, voItem.height, "left", voDocument);
    var voScrollAreaRight = voDragDropHandler.createScrollArea(vnScrAreaLeft, vnScrAreaTop, vnScrAreaWidth, vnScrAreaHeight, voItem.width, voItem.height, "right", voDocument);
    voScrollAreaLeft.control = this;
    voScrollAreaRight.control = this;
    voScrollAreaLeft.onmouseover = function(e) {
      this.control.onAutoScroll(e, this, "left");
    };
    voScrollAreaRight.onmouseover = function(e) {
      this.control.onAutoScroll(e, this, "right");
    };
  }
  if(voCtrl.scrollHeight > voCtrl.clientHeight) {
    var voScrollAreaTop = voDragDropHandler.createScrollArea(vnScrAreaLeft, vnScrAreaTop, vnScrAreaWidth, vnScrAreaHeight, voItem.width, voItem.height, "top", voDocument);
    var voScrollAreaBottom = voDragDropHandler.createScrollArea(vnScrAreaLeft, vnScrAreaTop, vnScrAreaWidth, vnScrAreaHeight, voItem.width, voItem.height, "bottom", voDocument);
    voScrollAreaTop.control = this;
    voScrollAreaBottom.control = this;
    voScrollAreaTop.onmouseover = function(e) {
      this.control.onAutoScroll(e, this, "top");
    };
    voScrollAreaBottom.onmouseover = function(e) {
      this.control.onAutoScroll(e, this, "bottom");
    };
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.atmousedown = function(e) {
  e.objectType = this.eventObjectType;
  e.object = this.eventObject;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.atmouseup = function(e) {
  e.objectType = this.eventObjectType;
  e.object = this.eventObject;
  if(this.isRClick(e)) {
    if(e.objectType == "item" && e.object) this.selectNode(e.object, e, this.document);
  }
};

eXria.controls.xhtml.TreeView.prototype.finalmouseup = function(e) {
  var voDocument = this.document;
  this.sourceItem = null;
  this.targetItem = null;

  var voCanvas = this.canvas;
  voCanvas.doCollapseForAllFrame();
  if (!this.isRClick(e)) {
    return;
  } else {
    var posx=0,posy=0;
    if(e.pageX || e.pageY) {
      posx=e.pageX; posy=e.pageY;
    } else if(e.clientX || e.clientY) {
      if(voDocument.documentElement.scrollTop) {
        posx=e.clientX + voDocument.documentElement.scrollLeft;
        posy=e.clientY + voDocument.documentElement.scrollTop;
      } else {
        posx=e.clientX + voDocument.body.scrollLeft;
        posy=e.clientY + voDocument.body.scrollTop;
      }
    }
    this.showContextMenu(posx,posy);
    if(this.contextMenuId) e.stopEvent();       // TODO : 향후 변경할것
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.atclick = function(poEvent) {
  poEvent.objectType = this.eventObjectType;
  poEvent.object = this.eventObject;
  //if(poEvent.object && poEvent.objectType == "item") {
    //this.openedItem = poEvent.object;
  //}
  var voBase = this;
  //this.temp = function() {
    if(poEvent.object) {
      voBase.selectNode(poEvent.object, poEvent, voBase.document);
      if(!poEvent.object.isLeaf()) {
        if(poEvent.object.expand == false) voBase.toggleNode(poEvent.object, voBase.document);
      }
    }
    //voBase.temp = null;
  //};

  //setTimeout(this.temp, 300);
};

eXria.controls.xhtml.TreeView.prototype.finalclick = function(poEvent) {
  if(this.canvas) {
    var voCanvas = this.canvas;
    if(!this.isRClick(poEvent)) voCanvas.hideContextMenu();
  }
  this.eventObjectType = null;
  this.eventObject = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.atdblclick = function(poEvent) {
  poEvent.objectType = this.eventObjectType;
  poEvent.object = this.eventObject;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.finaldblclick = function(poEvent) {
  this.eventObjectType = null;
  this.eventObject = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.dochange = function(poEvent, poControl) {
  if(poControl.atchange) { poControl.atchange(poEvent); }
  if(poControl.cochange) { poControl.cochange(poEvent); }
  if(poControl.onchange) { poControl.onchange(poEvent); }
  if(poControl.changeEventCallback) { poControl.changeEventCallback(poEvent); }
};
/**
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.onAutoScroll = function(e, poCtrl, psPos) {
  var voDragDropHandler = this.dragDropHandler;
  var voItemCtrl = voDragDropHandler.ctrl;
  var vnGap = 0;
  var vnOverLen = Math.ceil(poCtrl.offsetHeight / 2);
  var vnScrollLen = Math.ceil(this.height / 100);
  var vnMaxLen = poCtrl.offsetHeight;
  var vnScrollPos = this.ctrl.scrollTop;
  switch(psPos) {
  case "top" :
    vnGap = voItemCtrl.offsetTop - poCtrl.offsetTop;
    break;
  case "bottom" :
    vnGap = poCtrl.offsetTop - voItemCtrl.offsetTop;
    vnScrollLen *= -1;
    break;
  case "left" :
    vnGap = voItemCtrl.offsetLeft - poCtrl.offsetLeft;
    vnOverLen = Math.ceil(poCtrl.offsetWidth / 2);
    vnScrollLen = Math.ceil(this.width / 100);
    vnMaxLen = poCtrl.offsetWidth;
    vnScrollPos = this.ctrl.scrollLeft;
    break;
  case "right" :
    vnGap = poCtrl.offsetLeft + poCtrl.offsetWidth - (voItemCtrl.offsetLeft + voItemCtrl.offsetWidth);
    vnOverLen = Math.ceil(poCtrl.offsetWidth / 2);
    vnScrollLen = -Math.ceil(this.width / 100);
    vnMaxLen = poCtrl.offsetWidth;
    vnScrollPos = this.ctrl.scrollLeft;
    break;
  }
  if(vnScrollLen == 0) vnScrollLen = 1;

  if(Math.abs(vnGap) < vnMaxLen) {
    if(vnGap < 0 && Math.abs(vnGap) > vnOverLen) vnScrollLen = vnScrollLen * 5;
    else if(vnGap < 0) vnScrollLen = vnScrollLen * 3;
    else if(Math.abs(vnGap) < vnOverLen) vnScrollLen = vnScrollLen * 2;
  } else {
    return;
  }

  vnScrollPos -= vnScrollLen;
  var vbOver = false;
  switch(psPos) {
  case "top" :
    if(vnScrollPos < 0) {
      vnScrollPos = 0;
      vbOver = true;
    }
    this.ctrl.scrollTop = vnScrollPos;
    break;
  case "bottom" :
    if(vnScrollPos > this.ctrl.scrollHeight) {
      vnScrollPos = this.ctrl.scrollHeight;
      vbOver = true;
    }
    this.ctrl.scrollTop = vnScrollPos;
    break;
  case "left" :
    if(vnScrollPos < 0) {
      vnScrollPos = 0;
      vbOver = true;
    }
    this.ctrl.scrollLeft = vnScrollPos;
    break;
  case "right" :
    if(vnScrollPos > this.ctrl.scrollWidth) {
      vnScrollPos = this.ctrl.scrollWidth;
      vbOver = true;
    }
    this.ctrl.scrollLeft = vnScrollPos;
    break;
  }
  if(vbOver) return;

  var voBase = this;
  var voFunc = function() {
    voBase.onAutoScroll(e, poCtrl, psPos);
  };
  this.window.setTimeout(voFunc, 500);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
  this.itemgroup.df = {};
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
  case "height" :
    this.refresh(poDocument);
    break;
  case "borderColor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "borderStyle" :
  case "borderWidth" :
  case "borderLeftWidth" :
  case "borderRightWidth" :
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.refresh(poDocument);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * loadData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.loadData = function(poDocument) {
  if(poDocument == null) poDocument = this.document;
  this.deployTreeNode(this.root);
//  var voCtrl = this.getCtrl(poDocument);
//  this.setSpecificAttrs(voCtrl, poDocument)
//  this.repaintNode(this.root, 0, true, voCtrl, poDocument);
//  this.changedNodes.clear();
//  if(this.data.instanceId != null && this.data.instancePath != null) {
//    var vsRefValue = this.data.getData();
//    var voIterator = this.items.getValueCollection().iterator();
//    var voTreeNode = null;
//    while(voIterator.hasNext()) {
//      voTreeNode = voIterator.next();
//      if(voTreeNode.getValue() == vsRefValue) {
//        this.toggleNode(voTreeNode);
//        break;
//      }
//    }
//  }
};

eXria.controls.xhtml.TreeView.prototype.reloadData = function(poCtrl, poDocument) {
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  this.markNodeLabel(null, null, false);
  this.changedNodes.clear();
  var voTable = poCtrl.childNodes[0];
  try {
    var size = voTable.childNodes.length;
    for(var j = 0; j < size; j++) {
      this.deleteTreeNode(0, poDocument);
    }
  } catch(err) {
  }
  this.openedItem = null;
  if(this.keepExpandedState) {
    if(!this.skipRemark) this.remarkExpand(this.root, "");
  }
  this.clearItems();
  this.deployTreeNode(this.root);
  this.value = null;
  this.restoreExpand();
  this.loadComplete(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.loadComplete = function(poDocument) {

  this.clickTime = new Date().getTime();
  if(poDocument == null) poDocument = this.document;
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;
  if(this.expandAll) this.expandAllNode();
  this.repaintNode(this.root, 0, true, voCtrl, poDocument);
  this.changedNodes.clear();

  var voCover = this.lookup(this.id + "_cover", poDocument);
  if(voCover != null) {
    if(this.visible == false) {
      this.setAttrCtrl("display", "none", voCover);
    } else {
      this.setAttrCtrl("display", "", voCover);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.clearItems = function() {
  this.latestIdx = 0;
  var voCollection = this.items.getValueCollection();
  var vnSize = voCollection.size();
  var voItem = null;
  for(var i = 0; i < vnSize; i++) {
    voItem = voCollection.get(i);
    voItem.index = null;
  }
  this.items.clear();
  this.itemValueMap = {};
  this.selectedItems.clear();
  this.root.index = 0;
  this.items.put(this.root.index, this.root);
  this.latestIdx = this.root.index + 1;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.deployTreeNode = function(poTreeNode) {
  poTreeNode.deployChildren();
  var voIterator = poTreeNode.childCollection.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild instanceof eXria.controls.xhtml.TreeNode) {
      this.deployTreeNode(voChild);
    }
  };
};
/**
 * 선택된 노드에 값을 바인딩 된 data에 반영하는 메소드.
 */
eXria.controls.xhtml.TreeView.prototype.checkSelected = function() {
  var voDf = this.df;
  var vaRet = [];
  var voSelectedItems = this.selectedItems.getValueCollection();
  var voNode = null;
  for(var i = 0; i < voSelectedItems.size(); i++) {
    voNode = voSelectedItems.get(i);
    vaRet.push(voNode.get("value"));
  }
  if(vaRet.length == 0) vaRet = null;
  if(this.selectionMode == "single" && this.showCheckBox == false) {
    if(vaRet) vaRet = vaRet[0];
  }
  this.value = vaRet;
  this.value = vaRet;
  if(this.data.instanceId !=null && this.data.instancePath != null) this.data.setData(vaRet);
};
/**
 * 해당노드의 value를 컨트롤에 설정. toggleNode()함수와 동일한 기능.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @example
 * var tree = page.getControl("treeview");<br>
   var node = tree.getNodeByVal("value1");<br>
   tree.setValue(node);<br>
 */
eXria.controls.xhtml.TreeView.prototype.setValue = function(poNode) {
  //this.value = poNode.get("value");
  //if(this.data.instanceId) this.data.setData(this.value);
  this.toggleNode(poNode);
};
/**
 * 컨트롤의 할당된 값 반환.
 * @return 컨트롤 value 속성 값
 * @type String
 */
eXria.controls.xhtml.TreeView.prototype.getValue = function() {
  return this.value;
};
/**
 * 트리노드 생성.
 * @param {String} psName 트리노드에 표시될 라벨명
 * @return 새롭게 생성된 트리노드 객체
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.createTreeNode = function(psName) {
  var voNode = new eXria.controls.xhtml.TreeNode(psName);
  //voNode.index = this.latestIdx++;
  //this.items.put(voNode.index, voNode);
  return voNode;
};
/**
 * 트리노드셋 생성.
 * @return 새롭게 생성된 트리노드셋 객체
 * @type eXria.controls.xhtml.TreeNodeset
 */
eXria.controls.xhtml.TreeView.prototype.createTreeNodeset = function() {
  var voNodeset = new eXria.controls.xhtml.TreeNodeset();
  //voNode.index = this.latestIdx++;
  //this.items.put(voNode.index, voNode);

  return voNodeset;
};
/**
 * 트리노드 제거.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.remove = function(poNode) {
  this.items.remove(poNode.index);
};
/**
 * 아이콘 이미지 경로 상수에 행당하는 실체화 객체를 생성하여 this.icons에 저장하는 메소드.<br>
 * Preload icons
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.loadIcons = function() {
  var voWindow = this.canvas.page.window;
  var voIcon = null;
  var vsIconTag = null;
  var voIconFiles = this.iconFiles;
  var voDefaultsIconFiles = null;
  if(eXria.controls.xhtml.Default.TreeView.iconFiles) voDefaultsIconFiles = eXria.controls.xhtml.Default.TreeView.iconFiles;
  for(vsIconTag in voDefaultsIconFiles) {
    if(voIconFiles[vsIconTag]) continue;
    if(voDefaultsIconFiles[vsIconTag]) {
      voIconFiles[vsIconTag] = voDefaultsIconFiles[vsIconTag];
    }
  }
  for(vsIconTag in this.iconFiles) {
    //voIcon = new Image();
    voIcon = {};
    voIcon.src = eXria.controls.xhtml.Util.getImagePath(voIconFiles[vsIconTag], voWindow);
    this.icons.put(vsIconTag, voIcon);
  }
};
/**
 * paint tree
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.paint = function(poDocument) {
  this.paintNode(this.root, poDocument);
};
/**
 * paint node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.paintNode = function(poNode, poDocument) {
  var vsId = this.id;
  var voTable = this.lookup(this.id + "_table");
  var voDiv = poDocument.createElement("div");
  if(this.itemgroup.className) voDiv.setAttribute("class", this.itemgroup.className);
  var voStyle = voDiv.style;
  this.setAttrCtrl("backgroundColor", this.backgroundColor, voDiv);
  voDiv.setAttribute("id", vsId + "_node" + poNode.index);
  voStyle.position = "absolute";
  voStyle.left = "0px";
  voStyle.top = (voTable.childNodes.length * this.iconHeight) + "px";
  var vnLayer = poNode.names.length;
  voStyle.height = (this.iconHeight * vnLayer) + "px";
  this.setNodeCtrl(poNode, voDiv, poDocument);
  for(var i = 0; i < poNode.children.length && poNode.expand; i++) {
    this.paintNode(poNode.children[i], voDiv);
  }
};
/**
 * Get the index of row by specified row id.<br>
 * row id에 해당하는 row 인덱스 번호 반환
 * @param {String} psRowId row id
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return row 인덱스 번호
 * @type Number
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getRowIndexById = function(psRowId, poDocument) {
   var voTable = this.lookup(this.id + "_table", poDocument);
   var voRows = voTable.childNodes;
   for(var i = 0; i < voRows.length; i++) {
      if(voRows.item(i).id == psRowId)
      return i;
   }
   return - 1;
};
/**
 * 트리 새로 그리기.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 */
eXria.controls.xhtml.TreeView.prototype.repaint = function(poDocument) {
  this.markNodeLabel(null, null, false);
  var voCtrl = this.getCtrl(poDocument);
  this.repaintChanged(voCtrl, poDocument);

  this.changedNodes.clear();
};

//eXria.controls.xhtml.TreeView.prototype.resizeNodeDiv = function(){
//Node length setting
//  var voSubElement = this.subElement;
//
//  var vnLen = voSubElement.tableDiv.childNodes.length;
//
//  for(var i = 0 ; i<vnLen; i++){
//    //var voWidth = parseInt(voSubElement.tableDiv.childNodes[i].getElementsByTagName("table")[0].style.width);
//    var voWidth = this.innerWidth - (vnOffset * this.df.iconWidth)
//
//    voWidth += this.maxLen;
//    voSubElement.tableDiv.childNodes[i].getElementsByTagName("div")[0].style.width = voWidth+"px";
//    voSubElement.tableDiv.childNodes[i].getElementsByTagName("table")[0].style.width = voWidth+"px";
//  }
//
//  this.maxLen = 0;
//};

/**
 * Repaint nodes of which displays are changed.
 * @param {HTMLDiv} poCtrl 실체화 객체의 최외곽 DIV
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.repaintChanged = function(poCtrl, poDocument) {
  if(this.trvType == "MENU") {
    this.repaintChangedMenu(poCtrl, poDocument);
    return;
  }

  if(poDocument == null) poDocument = this.document;
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  var voTable = poCtrl.childNodes[0];
  var vsId = this.id;
  for(var i = 0; i < this.changedNodes.size(); i++) {
    var voNode = this.changedNodes.get(i);
    var vsRowId = vsId + "_node" + voNode.index;
    var nextRowId = - 1;
    var vnRowIndex1 = - 1;
    var vnRowIndex2 = - 1;
    if(voNode != this.root) {
      vnRowIndex1 = this.getRowIndexById(vsRowId, poDocument);
      if(vnRowIndex1 == -1) continue;
      try {
        if(voNode.parent.getChildAfter(voNode) == null) throw new Error(9999, "Null point exception!");
        nextRowId = vsId + "_node" + voNode.parent.getChildAfter(voNode).index;
        vnRowIndex2 = this.getRowIndexById(nextRowId, poDocument) - 1;
        if(vnRowIndex2 < 0) throw new Error(9999, "Index out of bound!");
      } catch(err) {
        try {
          if(this.getNextOpenedAncestor(voNode, poDocument) == null) throw new Error(9999, "Null point exception!");
          nextRowId = vsId + "_node" + this.getNextOpenedAncestor(voNode, poDocument).index;
          vnRowIndex2 = this.getRowIndexById(nextRowId, poDocument) - 1;
          if(vnRowIndex2 == -1) throw new Error(9999, "Index Out of bound!");
        } catch(err) {
          vnRowIndex2 = voTable.childNodes.length - 1;
        }
      }
    } else {
      vnRowIndex1 = 0;
      vnRowIndex2 = voTable.childNodes.length - 1;
    }
    var vbRepaintChildren = true;
    if(!voNode.expand) vbRepaintChildren = false;
    try {
      for(var j = 0; j <(vnRowIndex2 - vnRowIndex1); j++) {
        this.deleteTreeNode(vnRowIndex1 + 1, poDocument);
      }
    } catch(err) {
    }

    var vbRoot = false;
    if(voNode == this.root) vbRoot = true;
    this.repaintNode(voNode, vnRowIndex1, vbRoot, poCtrl, poDocument, vbRepaintChildren);
  }
};
/**
 * deleteTreeNode.
 * @param {Number} pnIndex 현재 보여지는 트리 리스트의 row 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.deleteTreeNode = function(pnIndex, poDocument) {
  if(this.trvType == "MENU") {
    this.deleteTreeNodeMenu(pnIndex, poDocument);
    return;
  }

  var voTable = this.lookup(this.id + "_table", poDocument);
  //this.clearCtrlNode(voTable.childNodes.item(pnIndex));
  var voNodeCtrl = voTable.childNodes.item(pnIndex);
  var vnHeight = parseInt(voNodeCtrl.style.height);
  voTable.removeChild(voNodeCtrl);
  var voDiv = null;
  var voStyle = null;
  for(var i = pnIndex; i < voTable.childNodes.length; i++) {
    voDiv = voTable.childNodes.item(i);
    voStyle = voDiv.style;
    voStyle.top = (parseInt(voStyle.top) - vnHeight) + "px";
  }
};
/**
 * repaint node.
 * @param {eXria.controls.xhtml.TreeNode} poNode 새로고침 대상 트리노드
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @param {Boolean} pbRoot 루트노드인지 여부
 * @param {HTMLDiv} 실체화 컨트롤 객체의 최외곽 div 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.repaintNode = function(poNode, pnIndex, pbRoot, poCtrl, poDocument, pbRepaintChildren) {
  if(this.trvType == "MENU") {
    this.repaintNodeMenu(poNode, pnIndex, pbRoot, poCtrl, poDocument, pbRepaintChildren);
    return;
  }

  if(poNode.visible == false || pnIndex < 0) return;
  if(poDocument == null) poDocument = this.document;
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  if(pbRepaintChildren == null) pbRepaintChildren = true;
  var voTable = poCtrl.childNodes[0];
  var vsId = this.id;
  var voDiv = poDocument.getElementById(vsId + "_node" + poNode.index);
  if(voDiv == null) {
    voDiv = poDocument.createElement("div");
    if(this.itemgroup.className) voDiv.setAttribute("class", this.itemgroup.className);
    var voStyle = voDiv.style;
    var voDf = this.df;
    var vaCssStrBuf = null;
    var vfcSetCssStrBuf = this.setCssStrBuf;

    voDiv["id"] = vsId + "_node" + poNode.index;

    vaCssStrBuf = [];
    vfcSetCssStrBuf(vaCssStrBuf, "padding", 0, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "margin", 0, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "position", "absolute");
    vfcSetCssStrBuf(vaCssStrBuf, "left", 0, "px");
    var vnTop = 0;
    if(pnIndex != 0) {
      var voPrevRow = voTable.childNodes.item(pnIndex - 1);
      vnTop += parseInt(voPrevRow.style.top);
      vnTop += parseInt(voPrevRow.style.height);
    }
//    vfcSetCssStrBuf(vaCssStrBuf, "top", (pnIndex * this.iconHeight), "px");
    vfcSetCssStrBuf(vaCssStrBuf, "top", vnTop, "px");
    var vnLayer = poNode.names.length;
    vfcSetCssStrBuf(vaCssStrBuf, "height", (this.iconHeight * vnLayer), "px");
    voStyle.cssText = vaCssStrBuf.join("");

    if(!pbRoot) {
      if(pnIndex == voTable.childNodes.length) voTable.appendChild(voDiv);
      else voTable.insertBefore(voDiv, voTable.childNodes.item(pnIndex));
      this.setNodeCtrl(poNode, voDiv, poDocument);

      for(var i = pnIndex + 1; i < voTable.childNodes.length; i++) {
        voDiv = voTable.childNodes.item(i);
        voStyle = voDiv.style;
        voStyle.top = (parseInt(voStyle.top) + (this.iconHeight * vnLayer)) + "px";
      }
    }
  } else {
    this.refreshNodeCtrl(poNode, voDiv, poDocument);
  }
  if(pbRepaintChildren == false) return;
  var voNextAncestor = null;
  var voPrevious = null;
  for(var i = 0; i < poNode.children.length && poNode.expand; i++) {
    // 하위노드(0) 추가 후 그 하위노드의 하위 노드들이 추가되었을 경우 하위노드(0)의 다음노드(1)은
    // 하위노드(0)의 NextOpenedAncestor에 위치하여야 한다.
    if(i == 0) {
       if(pbRoot) this.repaintNode(poNode.children[i], pnIndex, false, poCtrl, poDocument);
       else this.repaintNode(poNode.children[i], pnIndex + 1, false, poCtrl, poDocument);
    } else {
      var rowId = null;
      var rowIndex = null;
       try {
          voNextAncestor = this.getNextOpenedAncestor(voPrevious, poDocument);
          if(voNextAncestor == null) throw new Error(9999, "It has no next opened ancestor!");
          rowId = vsId + "_node" + voNextAncestor.index;
          rowIndex = this.getRowIndexById(rowId, poDocument);
          if(rowIndex == -1) throw new Error(9999, "Index out of bound!");
          this.repaintNode(poNode.children[i], rowIndex, false, poCtrl, poDocument);

       } catch(err) {
          rowIndex = voTable.childNodes.length;
          this.repaintNode(poNode.children[i], rowIndex, false, poCtrl, poDocument);
       }
    }
    if(poNode.children[i].visible != false) voPrevious = poNode.children[i];
  }
};
/**
 * generate leftside.<br>
 * 지정된 트리노드 렌더링.
 * @param {eXria.controls.xhtml.TreeNode} poNode 렌더링할 트리노드
 * @param {HTMLDiv} poDiv 트리노드가 렌더링될 div객체
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.setNodeCtrl = function(poNode, poDiv, poDocument){
  if(this.trvType == "MENU") {
    this.setNodeCtrlMenu(poNode, poDiv, poDocument);
    return;
  }

  var vaTemplate = [];
  var voIcon = null;
  var vaTagStrBuf = null;
  var vaAttStrBuf = null;
  var vaCssStrBuf = null;
  var vaStrBuf = null;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup;
  var vnLayer = poNode.names.length;
  var vnLeftGap = poNode.leftside.length;
  var vbNBlank = true;
  for(var i = 0; i < vnLeftGap; i++) {
    voIcon = this.icons.get("blank");
    if(poNode.leftside[i] == 1) {
      voIcon = this.icons.get("verticalLine");
      vbNBlank = true;
    }
    vaTagStrBuf = [];
    if(vbNBlank && voIcon.src != "none") {
      for(var j = 0; j < vnLayer; j++) {
        vaTagStrBuf.push("<img border=0 src='");
        vaTagStrBuf.push(voIcon.src);
        vaTagStrBuf.push("' style='position:absolute;");
        vaCssStrBuf = [];
        vfcSetCssStrBuf(vaCssStrBuf, "top", (j * this.iconHeight), "px");
        vfcSetCssStrBuf(vaCssStrBuf, "left", (i * this.iconWidth), "px");
        vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
        vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
        vaTagStrBuf.push(vaCssStrBuf.join(""));
        vaTagStrBuf.push("'>");
      }
    }
    vaTemplate.push(vaTagStrBuf.join(""));
  }
  if(poNode != this.root) {
    if(poNode.isLeaf()) {
      vbNBlank = false;
      voIcon = this.icons.get("lastnode");
      if(poNode.parent.getLastChild() != poNode) {
         voIcon = this.icons.get("node");
         vbNBlank = true;
      }
      if(voIcon.src != "none") {
        vaTagStrBuf = [];
        vaTagStrBuf.push("<img name='node' border=0 src='");
        vaTagStrBuf.push(voIcon.src);
        vaTagStrBuf.push("' style='position:absolute;top:0px;");
        vaCssStrBuf = [];
        vfcSetCssStrBuf(vaCssStrBuf, "left", (vnLeftGap * this.iconWidth), "px");
        vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
        vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
        vaTagStrBuf.push(vaCssStrBuf.join(""));
        vaTagStrBuf.push("'>");
      }
      if(vbNBlank) voIcon = this.icons.get("verticalLine");
      else voIcon = this.icons.get("blank");
      if(vbNBlank && voIcon.src != "none") {
        for(var j = 1; j < vnLayer; j++) {
          vaTagStrBuf.push("<img border=0 src='");
          vaTagStrBuf.push(voIcon.src);
          vaTagStrBuf.push("' style='position:absolute;");
          vaCssStrBuf = [];
          vfcSetCssStrBuf(vaCssStrBuf, "top", (j * this.iconHeight), "px");
          vfcSetCssStrBuf(vaCssStrBuf, "left", (vnLeftGap * this.iconWidth), "px");
          vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
          vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
          vaTagStrBuf.push(vaCssStrBuf.join(""));
          vaTagStrBuf.push("'>");
        }
      }
      vaTemplate.push(vaTagStrBuf.join(""));
    } else {
      vbNBlank = false;
      if(poNode.expand) {
        voIcon = this.icons.get("openedLastnode");
        if(poNode.parent.getLastChild() != poNode) {
          voIcon = this.icons.get("openedNode");
          vbNBlank = true
        }
      } else {
        voIcon = this.icons.get("closedLastnode");
        if(poNode.parent.getLastChild() != poNode) {
          voIcon = this.icons.get("closedNode");
          vbNBlank = true;
        }
      }
      vaTagStrBuf = [];
      vaTagStrBuf.push("<img name='node' border=0 src='");
      vaTagStrBuf.push(voIcon.src);
      vaTagStrBuf.push("' style='");
      vaCssStrBuf = [];
      vfcSetCssStrBuf(vaCssStrBuf, "position", "absolute");
      vfcSetCssStrBuf(vaCssStrBuf, "left", (poNode.leftside.length * this.iconWidth), "px");
      vfcSetCssStrBuf(vaCssStrBuf, "top", 0, "px");
      vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
      vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
      vaTagStrBuf.push(vaCssStrBuf.join(""));
      vaTagStrBuf.push("' ");
      if(poNode.disabled != true || this.allowExpand) {
        vaTagStrBuf.push("onclick=\"");
        vaTagStrBuf.push(this.getEHandler(poNode.index, "nodeClick"));
        vaTagStrBuf.push("\"")
      };
      vaTagStrBuf.push(">");
      if(vbNBlank) voIcon = this.icons.get("verticalLine");
      else voIcon = this.icons.get("blank");
      if(vbNBlank && voIcon.src != "none") {
        for(var j = 1; j < vnLayer; j++) {
          vaTagStrBuf.push("<img border=0 src='");
          vaTagStrBuf.push(voIcon.src);
          vaTagStrBuf.push("' style='position:absolute;");
          vaCssStrBuf = [];
          vfcSetCssStrBuf(vaCssStrBuf, "top", (j * this.iconHeight), "px");
          vfcSetCssStrBuf(vaCssStrBuf, "left", (vnLeftGap * this.iconWidth), "px");
          vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
          vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
          vaTagStrBuf.push(vaCssStrBuf.join(""));
          vaTagStrBuf.push("'>");
        }
      }
      vaTemplate.push(vaTagStrBuf.join(""));
    }
  }
  var vbSelectedNode = false;
  if(this.selectedItems.get(poNode.index)) {
    vbSelectedNode = true;
  }
  if(this.openedItem == poNode) {
    if(poNode.isLeaf()) voIcon = this.icons.get("selectedLeafItem");
    else voIcon = this.icons.get("openedFolder_" + poNode.depth);
    if(voIcon == null) {
      if(poNode.expand) {
        voIcon = this.icons.get("openedFolder");
      } else {
        voIcon = this.icons.get("closedFolder_" + poNode.depth);
        if(voIcon == null) voIcon = this.icons.get("closedFolder");
      }
    }
    if(poNode.iconOpened && poNode.iconOpened != "") {
      voIcon = {};
      voIcon.src = poNode.iconOpened;
    }

  } else {
    if(poNode.isLeaf()) {
      voIcon = this.icons.get("leafItem_" + poNode.depth);
      if(voIcon == null) voIcon = this.icons.get("leafItem");
    } else{
      voIcon = this.icons.get("closedFolder_" + poNode.depth);
    }
    if(voIcon == null) {
      if(poNode.expand) {
        voIcon = this.icons.get("openedFolder_" + poNode.depth);
        if(voIcon == null) voIcon = this.icons.get("openedFolder");
      } else {
        voIcon = this.icons.get("closedFolder");
      }
    }
    if(poNode.icon && poNode.icon != "") {
      voIcon = {};
      voIcon.src = poNode.icon;
    }
  }
  var vnOffset = 0;

  vnOffset = vnLeftGap + 1;
  if(poNode == this.root) vnOffset = 0;
  if(voIcon.src != "none") {
    vaTagStrBuf = [];
    vaTagStrBuf.push("<img name='folder' border=0 src='");
    vaTagStrBuf.push(voIcon.src);
    vaTagStrBuf.push("' style='position:absolute;top:0px;");
    vaCssStrBuf = [];
    vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
    if(poNode.disabled != true) vfcSetCssStrBuf(vaCssStrBuf, "cursor", voItemgroupDf.cursor);
    vaTagStrBuf.push(vaCssStrBuf.join(""));
    vaTagStrBuf.push("'");
    if(poNode.disabled != true) {
      vaTagStrBuf.push(" onmousedown=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMousedown"));
      vaTagStrBuf.push("return false;\" onmouseup=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMouseup"));
      vaTagStrBuf.push("\" onclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelClick"));
      vaTagStrBuf.push("\" ondblclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelDblClick"));
      vaTagStrBuf.push("\" ");
    }
    vaTagStrBuf.push(">");
    voIcon = this.icons.get("verticalLine");
    if(poNode.expand == false || poNode.isLeaf()) {
      voIcon = this.icons.get("blank");
    }
    for(var j = 1; j < vnLayer; j++) {
      vaTagStrBuf.push("<img name='blank' border=0 src='");
      vaTagStrBuf.push(voIcon.src);
      vaTagStrBuf.push("' style='position:absolute;");
      vaCssStrBuf = [];
      vfcSetCssStrBuf(vaCssStrBuf, "top", (j * this.iconHeight), "px");
      vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
      vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
      vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
      vaTagStrBuf.push(vaCssStrBuf.join(""));
      vaTagStrBuf.push("'>");
    }
    vaTemplate.push(vaTagStrBuf.join(""));
  } else {
    vnOffset--;
  }
  var vsFontColor = poNode.color;
  if(vsFontColor == null && this.getNodeColor) vsFontColor = this.getNodeColor(poNode);
  if(vsFontColor == null && voItemgroupDf.className) vsFontColor = this.getStyleCurrentValue(voItemgroupDf, "color", "color");
  if(vsFontColor == null) vsFontColor = voItemgroupDf.color;
  if(vsFontColor == null) vsFontColor = this.color;
  var vsBackgroundColor = poNode.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = voItemgroupDf.backgroundColor;
  if(vsBackgroundColor == null && voItemgroupDf.className) vsBackgroundColor = this.getStyleCurrentValue(voItemgroupDf, "background-color", "backgroundColor");
  if(vsBackgroundColor == null) vsBackgroundColor = this.backgroundColor;
  if(vbSelectedNode)
  {
    vsFontColor = voItemgroupDf.selectedColor;
    vsBackgroundColor = voItemgroupDf.selectedBackgroundColor;
  }

  if(this.showCheckBox) {
    vnOffset++;
    if(poNode == this.root) vnOffset = 0;
    vaTagStrBuf = [];
    vaTagStrBuf.push("<input type=checkbox hideFocus='true' ");
    if(this.selectedItems.get(poNode.index)) {
      vaTagStrBuf.push("checked ");
    }
    //vaTagStrBuf.push("style='position:absolute;top:0px;");
    // todo: yhkim 체크 깨지는 문제 아래처럼(IE8에서는 깨진다)
    vaTagStrBuf.push("style='position:absolute;top:0px;margin-top:0px;margin-left:0px;padding-bottom: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px;");
    vaCssStrBuf = [];
    vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
//    vfcSetCssStrBuf(vaCssStrBuf, "background-color", vsBackgroundColor);
    vaTagStrBuf.push(vaCssStrBuf.join(""));
    vaTagStrBuf.push("' ");
    if(poNode.disabled != true) {
      vaTagStrBuf.push("onclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "cbClick"));
      vaTagStrBuf.push("\">");
    } else {
      vaTagStrBuf.push("disabled >");
    }
    if(voIcon.src == "none") {
      voIcon = this.icons.get("verticalLine");
      if(poNode.parent.getLastChild() == poNode && poNode.expand == false) {
        voIcon = this.icons.get("blank");
      }
      for(var j = 1; j < vnLayer; j++) {
        vaTagStrBuf.push("<img name='blank' border=0 src='");
        vaTagStrBuf.push(voIcon.src);
        vaTagStrBuf.push("' style='position:absolute;");
        vaCssStrBuf = [];
        vfcSetCssStrBuf(vaCssStrBuf, "top", (j * this.iconHeight), "px");
        vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
        vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
        vfcSetCssStrBuf(vaCssStrBuf, "height", this.iconHeight, "px");
        vaTagStrBuf.push(vaCssStrBuf.join(""));
        vaTagStrBuf.push("'>");
      }
    }
    vaTemplate.push(vaTagStrBuf.join(""));
  }

  var voSpan = this.subElement.span;
  voSpan.innerHTML = poNode.name;
  var vnLen = voSpan.offsetWidth;

  vnOffset++;
  vaTagStrBuf = [];
  vaTagStrBuf.push("<div onselectstart=\"return false;\" ");
  if(poNode.disabled) {
//    vaTagStrBuf.push("disabled ");
  } else if(this.trvType != "WBS") {
    vaTagStrBuf.push("onmousedown=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMousedown"));
    vaTagStrBuf.push("return false;\" onmouseup=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMouseup"));
    vaTagStrBuf.push("\" onclick=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelClick"));
    vaTagStrBuf.push("\" ondblclick=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelDblClick"));
    vaTagStrBuf.push("\" ");
  }

  vaTagStrBuf.push("style='position:absolute;margin:0px;padding:0px;top:0px;");
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnLen, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", (this.iconHeight * vnLayer), "px");
  if(this.trvType != "WBS") {
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", vsBackgroundColor);
    if(poNode.disabled != true) vfcSetCssStrBuf(vaCssStrBuf, "cursor", voItemgroupDf.cursor);
  }
  vaTagStrBuf.push(vaCssStrBuf.join(""));
  vaTagStrBuf.push("'>");

  vaTemplate.push(vaTagStrBuf.join(""));

  poNode.left = vnOffset * this.iconWidth;
//  poNode.top = parseInt(poDiv.style.top);
  poNode.width = vnLen;
  poNode.height = this.iconHeight * vnLayer;

  // yhkim 2009.09.04
  var vsClass = this.getCSSClass(this, 1, "itemgroup");
  vaTagStrBuf = [];
  vaTagStrBuf.push("<table class='" + vsClass + "' cellSpacing=0 cellPadding=0 style='position:absolute;left:0px;top:0px;");
  vaCssStrBuf = [];
  if(this.trvType != "WBS") {
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", vsBackgroundColor);
    vfcSetCssStrBuf(vaCssStrBuf, "color", vsFontColor);
    if(poNode.disabled) vfcSetCssStrBuf(vaCssStrBuf, "color", this.disabledColor);//박상찬 수정(disabled color)
  }

  vfcSetCssStrBuf(vaCssStrBuf, "width", vnLen, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", (this.iconHeight * vnLayer), "px");
  var vuAttr = poNode.fontFamily;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontFamily;
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", vuAttr);
  vuAttr = poNode.fontSize;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontSize;
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vuAttr, "pt");
  vuAttr = poNode.fontStyle;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontStyle;
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", vuAttr);
  vuAttr = poNode.fontWeight;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontWeight;
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", vuAttr);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", voItemgroupDf.cursor);
  vaTagStrBuf.push(vaCssStrBuf.join(""));
  vaTagStrBuf.push("'>");

  vaTemplate.push(vaTagStrBuf.join(""));

  vaTagStrBuf = [];
  vaTagStrBuf.push("<tbody><tr><td style='white-space:nowrap;");
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voItemgroupDf.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", voItemgroupDf.verticalAlign);
  vaTagStrBuf.push(vaCssStrBuf.join(""));

  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
  }

  if(!!voUserAttr && !!voUserAttr.nodeTitle){
    vaTagStrBuf.push("' title='"+poNode.names.join('')+"'>");
  }else{
    vaTagStrBuf.push("'>");
  }

  if(this.trvType == "WBS") {
    vaCssStrBuf = [];
    vaTagStrBuf.push("<table border='0' cellSpacing=0 cellPadding=0 ");
    if(!poNode.disabled){
      vaTagStrBuf.push("onmousedown=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMousedown"));
      vaTagStrBuf.push("return false;\" onmouseup=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMouseup"));
      vaTagStrBuf.push("\" onclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelClick"));
      vaTagStrBuf.push("\" ondblclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelDblClick"));
      vaTagStrBuf.push("\" ");
    }
    vaTagStrBuf.push("style='");
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", vsBackgroundColor);
    vfcSetCssStrBuf(vaCssStrBuf, "color", vsFontColor);
    if(poNode.disabled) vfcSetCssStrBuf(vaCssStrBuf, "color", this.disabledColor);//박상찬 수정(disabled color)
    vfcSetCssStrBuf(vaCssStrBuf, "cursor", voItemgroupDf.cursor);
    vfcSetCssStrBuf(vaCssStrBuf, "border-collapse", "collapse");
    vaTagStrBuf.push(vaCssStrBuf.join(""));
    vaTagStrBuf.push("'><tbody>");
    for(var j = 0; j < vnLayer; j++) {
      vaTagStrBuf.push("<tr><td ");
      if(this.lblClasses[j]) vaTagStrBuf.push("class=\"" + this.lblClasses[j] + "\" ");
      vaTagStrBuf.push("style='white-space:nowrap;");
      vaCssStrBuf = [];
      if(this.lblColors[j]) vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.lblColors[j]);
      if(vbSelectedNode) {
        vfcSetCssStrBuf(vaCssStrBuf, "color", voItemgroupDf.selectedColor);
      }
      vaTagStrBuf.push(vaCssStrBuf.join(""));
      vaTagStrBuf.push("'>" + poNode.names[j]);
      vaTagStrBuf.push("</td></tr>");
    }
    vaTagStrBuf.push("</tbody></table>");
  } else {
    vaTagStrBuf.push(poNode.names.join("<br>"));
  }
  vaTagStrBuf.push("</td></tr></tbody>");

  vaTemplate.push(vaTagStrBuf.join(""));
  poDiv.innerHTML = vaTemplate.join("");
  vaTemplate = null;
};
/**
 * refreshNodeCtrl
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.refreshNodeCtrl = function(poNode, poDiv, poDocument){
  if(this.trvType == "MENU") {
    this.refreshNodeCtrlMenu(poNode, poDiv, poDocument);
    return;
  }

  var voIcon = null;
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup;
  var voBase = this;

  var voImgCtrl = null;
  var vaCtrl = null;
  if(poNode == this.root) return;
  if(poNode.isLeaf()) {
    voIcon = this.icons.get("lastnode");
    if(poNode.parent.getLastChild() != poNode) {
       voIcon = this.icons.get("node");
    }
  } else {
    if(poNode.expand) {
      voIcon = this.icons.get("openedLastnode");
      if(poNode.parent.getLastChild() != poNode) {
        voIcon = this.icons.get("openedNode");
      }
    } else {
      voIcon = this.icons.get("closedLastnode");
      if(poNode.parent.getLastChild() != poNode) {
        voIcon = this.icons.get("closedNode");
      }
    }
  }
  vaCtrl = poDiv.getElementsByTagName("img");
//    voImgCtrl = vaCtrl[vaCtrl.length - 2];
  voImgCtrl = this.getElementsByAttr(vaCtrl, "name", "node")[0];
  voImgCtrl.src = voIcon.src;
  if(poNode.disabled != true || this.allowExpand) {
    voImgCtrl.onclick = function(e) {
      e = e ? e : voBase.window.event;
      voBase.nodeClick(e, poNode.index);
    };
  } else {
    voImgCtrl.onclick = null;
  }

  var vbSelectedNode = false;
  if(this.selectedItems.get(poNode.index)) {
    vbSelectedNode = true;
  }
  if(this.openedItem == poNode) {
    if(poNode.isLeaf()) voIcon = this.icons.get("selectedLeafItem");
    else voIcon = this.icons.get("openedFolder_" + poNode.depth);
    if(voIcon == null) {
      if(poNode.expand) {
        voIcon = this.icons.get("openedFolder");
      } else {
        voIcon = this.icons.get("closedFolder_" + poNode.depth);
        if(voIcon == null) voIcon = this.icons.get("closedFolder");
      }
    }
    if(poNode.iconOpened && poNode.iconOpened != "") {
      voIcon = {};
      voIcon.src = poNode.iconOpened;
    }

  } else {
    if(poNode.isLeaf()) {
      voIcon = this.icons.get("leafItem_" + poNode.depth);
      if(voIcon == null) voIcon = this.icons.get("leafItem");
    } else{
      voIcon = this.icons.get("closedFolder_" + poNode.depth);
    }
    if(voIcon == null) {
      if(poNode.expand) {
        voIcon = this.icons.get("openedFolder_" + poNode.depth);
        if(voIcon == null) voIcon = this.icons.get("openedFolder");
      } else {
        voIcon = this.icons.get("closedFolder");
      }
    }
    if(poNode.icon && poNode.icon != "") {
      voIcon = {};
      voIcon.src = poNode.icon;
    }
  }

//  voImgCtrl = vaCtrl[vaCtrl.length - 1];
  if(voIcon.src != "none") {
    voImgCtrl = this.getElementsByAttr(vaCtrl, "name", "folder")[0];
    voImgCtrl.style.cursor = voItemgroupDf.cursor;
    voImgCtrl.src = voIcon.src;
    if(poNode.disabled != true) {
      voImgCtrl.onmousedown = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMousedown(e, poNode.index);
      };
      voImgCtrl.onmouseup = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMouseup(e, poNode.index);
      };
      voImgCtrl.onclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelClick(e, poNode.index);
      };
      voImgCtrl.ondblclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelDblClick(e, poNode.index);
      };
    } else {
      voImgCtrl.onmousedown = null;
      voImgCtrl.onmouseup = null;
      voImgCtrl.onclick = null;
      voImgCtrl.ondblclick = null;
    }
  }

  voIcon = this.icons.get("verticalLine");
  if(poNode.expand == false || poNode.isLeaf()) voIcon = this.icons.get("blank");
  var vaImgCtrl = this.getElementsByAttr(vaCtrl, "name", "blank");
  var vnSize = vaImgCtrl.length
  for(var i = 0; i < vnSize; i++) {
    vaImgCtrl[i].src = voIcon.src;
  }

  var vsFontColor = poNode.color;
  if(vsFontColor == null && voItemgroupDf.className) vsFontColor = this.getStyleCurrentValue(voItemgroupDf, "color", "color");
  if(vsFontColor == null) vsFontColor = voItemgroupDf.color;
  if(vsFontColor == null) vsFontColor = this.color;
  var vsBackgroundColor = poNode.backgroundColor;
  if(vsBackgroundColor == null && voItemgroupDf.className) vsBackgroundColor = this.getStyleCurrentValue(voItemgroupDf, "background-color", "backgroundColor");
  if(vsBackgroundColor == null) vsBackgroundColor = voItemgroupDf.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = this.backgroundColor;
  if(vbSelectedNode)
  {
    vsFontColor = voItemgroupDf.selectedColor;
    vsBackgroundColor = voItemgroupDf.selectedBackgroundColor;
  }
  if(vsFontColor == null) vsFontColor = "";
  if(vsBackgroundColor == null) vsBackgroundColor = "";

  if(this.showCheckBox) {
    var voChkCtrl = this.getSubCtrl("input", poDiv, poDocument);
    if(this.selectedItems.get(poNode.index)) voChkCtrl.checked = true;
    else voChkCtrl.checked = false;
//    this.setAttrCtrl("backgroundColor", vsBackgroundColor, voChkCtrl);
    if(poNode.disabled != true) {
      voChkCtrl.onclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.cbClick(e, poNode.index);
      };
      //voChkCtrl.setAttribute("disabled", false); false에 false를 설정하면 한 번은 true가 되어버리는 문제가 있음.
      voChkCtrl.disabled = false;
    } else {
      voChkCtrl.onclick = null;
      voChkCtrl.disabled = true;
    }
  }

  var voDivCtrl = this.getSubCtrl("div", poDiv, poDocument);
  var voTableCtrl =  this.getSubCtrl("table", voDivCtrl, poDocument);
  poNode.names = poNode.name.split("\\n");
  if(this.trvType != "WBS") {
    this.setAttrCtrl("backgroundColor", vsBackgroundColor, voDivCtrl);
    if(poNode.disabled) {
      voDivCtrl.onmousedown = null;
      voDivCtrl.onmouseup = null;
      voDivCtrl.onclick = null;
      voDivCtrl.ondblclick = null;
      if(poNode.disabled) this.setAttrCtrl("color", this.disabledColor, voTableCtrl); //박상찬 수정
      this.setAttrCtrl("cursor", "default", voDivCtrl);
    } else {
      voDivCtrl.onmousedown = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMousedown(e, poNode.index);
      };
      voDivCtrl.onmouseup = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMouseup(e, poNode.index);
      };
      voDivCtrl.onclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelClick(e, poNode.index);
      };
      voDivCtrl.ondblclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelDblClick(e, poNode.index);
      };
      this.setAttrCtrl("cursor", voItemgroupDf.cursor, voDivCtrl);
    }
    this.setAttrCtrl("backgroundColor", vsBackgroundColor, voTableCtrl);
    this.setAttrCtrl("color", vsFontColor, voTableCtrl);
//    voTableCtrl.rows[0].cells[0].innerHTML = poNode.name;
    voTableCtrl.rows[0].cells[0].innerHTML = poNode.names.join("<br>");
  } else {
    var voInnTblCtrl = voTableCtrl.rows[0].cells[0].childNodes[0];
    this.setAttrCtrl("backgroundColor", vsBackgroundColor, voInnTblCtrl);
    this.setAttrCtrl("color", vsFontColor, voInnTblCtrl);
    if(poNode.disabled) this.setAttrCtrl("color", this.disabledColor, voInnTblCtrl);
    var vnSize = voInnTblCtrl.rows.length;
    for(var i = 0; i < vnSize; i++) {
      voInnTblCtrl.deleteRow(0);
    }
//    poNode.names = poNode.name.split("\\n");
    var vnLayer = poNode.names.length;
    var voRow = null;
    var voCell = null;
    var vsCss = "white-space:nowrap;";
    vfcSetCssStrBuf = this.setCssStrBuf;
    vaCssStrBuf = null;
    for(var j = vnLayer - 1; j >= 0; j--) {
      voRow = voInnTblCtrl.insertRow(0);
      voCell = voRow.insertCell(0);
      if(this.lblClasses[j]) voCell.className = this.lblClasses[j];
      vaCssStrBuf = [];
      if(this.lblColors[j]) vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.lblColors[j]);
      if(vbSelectedNode) {
        vfcSetCssStrBuf(vaCssStrBuf, "color", voItemgroupDf.selectedColor);
      }
      voCell.style.cssText = vsCss + vaCssStrBuf.join("");
      voCell.innerHTML = poNode.names[j];
    }
    if(poNode.disabled) {
      voInnTblCtrl.onmousedown = null;
      voInnTblCtrl.onmouseup = null;
      voInnTblCtrl.onclick = null;
      voInnTblCtrl.ondblclick = null;
      this.setAttrCtrl("cursor", "default", voDivCtrl);
    } else {
      voInnTblCtrl.onmousedown = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMousedown(e, poNode.index);
      };
      voInnTblCtrl.onmouseup = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMouseup(e, poNode.index);
      };
      voInnTblCtrl.onclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelClick(e, poNode.index);
      };
      voInnTblCtrl.ondblclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelDblClick(e, poNode.index);
      };
      this.setAttrCtrl("cursor", voItemgroupDf.cursor, voInnTblCtrl);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.getEHandler = function(pnIndex, psFuncName) {
  var vaStrBuf = [];
  vaStrBuf.push("var voControl=page.getControl('");
  vaStrBuf.push(this.id);
  vaStrBuf.push("');");
  vaStrBuf.push("voControl.")
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("(event, ");
  vaStrBuf.push(pnIndex);
  vaStrBuf.push(", this);");
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.cbClick = function(e, pnIndex, poCtrl) {
  /*
  var voItem = this.items.get(pnIndex);
  //this.treeSelectionListener(e, voItem, document);
  this.eventObjectType = "item";
  this.eventObject = voItem;
  */

  var voBase = this;
  var vsId = voBase.id;
  var voNode = voBase.items.get(pnIndex);
  var voNodeCtrl = voBase.lookup(vsId + "_node" + voNode.index);
  var voCb = voBase.getSubCtrl("input", voNodeCtrl);

  voBase.eventObjectType = "item";
  voBase.eventObject = voNode;
  e.objectType = voBase.eventObjectType;
  e.object = voBase.eventObject;

  ///// 2010.12.06 yjcho edit start
  //2010.05.03
  //selectNode 메소드 내부에서 voCb.checked 를 체크 하는 로직이
  //존재하기에 voCb.checked를 뒤바꿔서 처리 하는 로직 추가
//  if(voCb.checked)
//    voCb.checked = false;
//  else
//    voCb.checked = true;
//  voBase.selectNode(voNode, e, voBase.document);
  ///// 2010.12.06 yjcho edit end
  //e.stopPropagation();
  /*
  var voItem = this.items.get(pnIndex);
  if(poCtrl.checked) this.selectedItems.put(voItem.index, voItem);
  else this.selectedItems.remove(voItem.index);


  //2010.03.24 노드클릭과 동일한 기능을 하게 수정
  var voEvent = new eXria.event.Event(e, this.window);
  this.dochange(voEvent, this);
  this.addChangedNode(voItem);
  this.repaint(this.document);
  this.checkSelected();
  */

};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.labelMousedown = function(e, pnIndex) {
  var voItem = this.items.get(pnIndex);
  this.sourceItem = voItem;
  this.eventObjectType = "item";
  this.eventObject = voItem;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.labelMouseup = function(e, pnIndex) {
  var voItem = this.items.get(pnIndex);
  this.targetItem = voItem;
  this.eventObjectType = "item";
  this.eventObject = voItem;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.labelClick = function(e, pnIndex) {
  var voItem = this.items.get(pnIndex);
  //this.treeSelectionListener(e, voItem, document);
  this.eventObjectType = "item";
  this.eventObject = voItem;
  ///// 2010.12.06 yjcho edit start
  if(this.showCheckBox) {
    var voDocument = this.document;
    voDiv = voDocument.getElementById(this.id + "_node" + pnIndex);
    var voChkCtrl = this.getSubCtrl("input", voDiv, voDocument);
    if(voChkCtrl.checked) voChkCtrl.checked = false;
    else voChkCtrl.checked = true;
  }
  ///// 2010.12.06 yjcho edit end
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.nodeClick = function(e, pnIndex) {
  var vnClickTime = new Date().getTime();
  var voControl = this;
  var voItem = this.items.get(pnIndex);
  //this.treeSelectionListener(e, voItem, document);
  this.eventObjectType = "item";
  this.eventObject = voItem;
  this.toggleNode(voItem);
  var voEvent = new eXria.event.Event(e, this.window);
  if(this.onexpand && voItem.expand) {
    voEvent.objectType = "item";
    voEvent.object = voItem;
    this.onexpand(voEvent);
  }
  voEvent.stopEvent();
  this.eventObjectType = null;
  this.eventObject = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.dodblclick = function(e, pnIndex) {
  this.labelDblClick(e, pnIndex);
  if(this.ondblclick) {
    try {
      this.ondblclick(e);
    } catch(err) {
      if(this.debug){
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }

}
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.labelDblClick = function(e, pnIndex) {
  var voItem = this.items.get(pnIndex);
  this.eventObjectType = "item";
  this.eventObject = voItem;
};
/**
 * 현재 랜더링된 트리노드 리스트에서 지정된 트리노드의 다음번 상위노드를 찾는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 기준 트리노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @Returns next opened ancestor
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getNextOpenedAncestor = function(poNode, poDocument) {
  var vsId = this.id;
  var voTable = this.lookup(vsId + "_table", poDocument);
  var vnRowIndex = this.getRowIndexById(vsId + "_node" + poNode.index, poDocument);
  var voNextNode = null;
  var voTempNode = null;
  var vsRowId = null;
  var vnPrefixLen = (vsId + "_node").length;
  for(var i = vnRowIndex + 1; i < voTable.childNodes.length; i++)
  {
    vsRowId = voTable.childNodes.item(i).id;
    voTempNode = this.items.get(vsRowId.substring(vnPrefixLen));
    if(voTempNode.parent == null) continue;
    if(!poNode.isAncestor(voTempNode) && !voTempNode.isAncestor(poNode))
    {
      voNextNode = voTempNode;
      break;
    }
  }
  return voNextNode;
};
/**
 * Returns the number of rows that are currently being displayed
 * @Return the number of rows that are currently being displayed.
 * @type Number
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getRowCount = function() {
  var voTable = this.lookup(this.id + "_table");
  return voTable.childNodes.length;
};
/**
 * Returns the path to the first selected node
 * @Return the path to the first selected node.
 * @type String
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getSelectionPath = function() {
};
/**
 * Move node
 * @param {eXria.controls.xhtml.TreeNode} poSource 트리노드가 원래 위치한 상위 노드
 * @param {eXria.controls.xhtml.TreeNode} poTarget 옮겨진 트리노드를 포함할 상위 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.moveNode = function(poSource, poTarget) {
  poSource.parent.remove(poSource);
  poTarget.add(poSource);
};
/**
 * Copy node
 * @param {eXria.controls.xhtml.TreeNode} poSource 복제될 노드
 * @param {eXria.controls.xhtml.TreeNode} poTarget 복제될 노드를 포함할 상위 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.copyNode = function(poSource, poTarget) {
  var voNode = poSource.clone();
  poTarget.add(voNode);
};
/**
 * Returns true if the node at the specified display row is collapsed.
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @return true if the node at the specified display row is collapsed.
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isCollapsed = function(pnIndex) {
  var vsId = this.id;
  var voTable = this.lookup(vsId + "_table");
  var vsRowId = voTable.rows[pnIndex].id;
  var vnPrefixLen = (vsId + "_node").length;
  vsRowId = vsRowId.substring(vnPrefixLen);

  return this.items.get(parseInt(vsRowId)).expand ? false : true;
};
/**
 * Returns true if the node at the specified display row is currently expanded.
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @return true if the node at the specified display row is currently expanded.
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isExpanded = function(pnIndex) {
  var vsId = this.id;
  var voTable = this.lookup(vsId + "_table");
  var vsRowId = voTable.rows[pnIndex].id;
  var vnPrefixLen = (vsId + "_node").length;
  vsRowId = vsRowId.substring(vnPrefixLen);

  return this.items.get(parseInt(vsRowId)).expand ? true : false;
};
/**
 * Returns true if the node at the specified display row is currently selected.
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @return true if the node at the specified display row is currently selected.
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isSelected = function(pnIndex) {
  var vsId = this.id;
  var voTable = this.lookup(vsId + "_table");
  var vsRowId = voTable.rows[pnIndex].id;
  var vnPrefixLen = (vsId + "_node").length;
  vsRowId = vsRowId.substring(vnPrefixLen);

  return this.items.get(parseInt(vsRowId)).isSelected() ? false : false;
};
/**
 * Ensures that the node in the specified row is expanded and viewable.
 * @param {Number} pnIndex
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.expandRow = function(pnIndex) {
};
/**
 * Ensures that the node identified by the specified path is expanded and viewable.
 * @param {String} psPath
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.expandPath = function(psPath) {
};
/**
 * 모든 노드를 펼침.
 */
eXria.controls.xhtml.TreeView.prototype.expandAllNode = function() {
  this.root.expandDecendants();
};
/**
 * Returns true if the node identified by row is selected.
 * @param {Number} pnIndex
 * @return this.selectedItems
 * @type Boolean
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.isRowSelected = function(pnIndex) {
  var vsId = this.id;
  var voTable = this.lookup(vsId + "_table");
  var vsRowId = voTable.rows[pnIndex].id;
  var vnPrefixLen = (vsId + "_node").length;
  vsRowId = vsRowId.substring(vnPrefixLen);

  //return this.selectedItems.get(0) == this.items.get(parseInt(vsId)) ? true : false;
  return this.selectedItems.get(vsRowId) ? true : false;
};
/**
 * Removes the row at the index row from the current selection.
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.removeSelectionRow = function() {
};
/**
 * 현재 보여지는 트리 상에서 지정된 row를 선택하는 메소드.
 * @param {Number} pnIndex 현재 보여지는 트리 상에서 지정된 row 인덱스 번호
 */
eXria.controls.xhtml.TreeView.prototype.setSelectionRow = function(pnIndex) {
  var vsId = this.id;
  var voTable = this.lookup(vsId + "_table");
  var vsRowId = voTable.rows[pnIndex].id;
  var vnPrefixLen = (vsId + "_node").length;
  vsRowId = vsRowId.substring(vnPrefixLen);

  this.selectNode(this.items.get(parseInt(vsRowId)));
};
/**
 * 지정된 트리노드 선택 해제.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 트리노드
 * @example
 * var tree = page.getControl("treeview");<br>
   var node = tree.getNodeByVal("value1");<br>
   tree.unselectNode(node);<br>
 */
eXria.controls.xhtml.TreeView.prototype.unselectNode = function(poNode) {
  //for(var i = 0; i < this.selectedItems.size(); i++) {
  //  if(this.selectedItems.get(i) == poNode) {
  //    this.selectedItems.remove(i);
  //    this.addChangedNode(poNode);
  //    return;
  //  }
  //}
  this.selectedItems.remove(poNode.index);
  this.addChangedNode(poNode);
  this.openedItem = null;
  return;
};
/**
 * Selects the specified node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @param {eXria.event.Event} poEvent 이벤트 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.TreeView.prototype.selectNode = function(poNode, poEvent, poDocument) {
  if(poEvent == null) {
    poEvent = {};
    poEvent.object = poNode;
    poEvent.objectType = "item";
  }
  if(this.showCheckBox) {
    this.selectNodeCb(poNode, poEvent, poDocument);
  } else {
    this.selectNodeNoCb(poNode, poEvent, poDocument);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.selectNodeNoCb = function(poNode, poEvent, poDocument) {
  var vnTop = this.ctrl.scrollTop;
  if(this.selectionMode == "single") {
    var voSelectedItems = this.selectedItems.getValueCollection();
    if(voSelectedItems.get(0) != null) {
       this.addChangedNode(voSelectedItems.get(0));
    }
    //this.selectedItems.set(0, poNode);
    this.selectedItems.clear();
    this.selectedItems.put(poNode.index, poNode)
    if(this.openedItem != poNode) {
      this.dochange(poEvent, this);
    }
    this.openedItem = poNode;
  } else {
    var vbCtrl = false;
    if(poEvent) vbCtrl = poEvent.ctrlKey;
    if(vbCtrl) {
      if(poNode.isSelected()) {
         this.unselectNode(poNode);
      } else {
        //this.selectedItems.add(poNode);
        this.selectedItems.put(poNode.index, poNode);
        this.openedItem = poNode;
      }
    } else {
      var voSelectedItems = this.selectedItems.getValueCollection();
      for(var i = 0; i < voSelectedItems.size(); i++) {
         this.addChangedNode(voSelectedItems.get(i));
      }
//      if(this.openedItem != null) this.addChangedNode(this.openedItem);
      this.selectedItems.clear()
      //this.selectedItems.set(0, poNode);
      this.selectedItems.put(poNode.index, poNode);
      if(this.openedItem != poNode) {
        this.dochange(poEvent, this);
      }
      this.openedItem = poNode;
    }
  }
  this.addChangedNode(poNode);
  this.repaint(poDocument);
  //this.setValue(poNode);
  this.checkSelected();
  this.ctrl.scrollTop = vnTop;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.selectNodeCb = function(poNode, poEvent, poDocument) {
  var vnTop = this.ctrl.scrollTop;
  var vsId = this.id;
  var voNodeCtrl = this.lookup(vsId + "_node" + poNode.index);
  var voCb = this.getSubCtrl("input", voNodeCtrl);
  ///// 2010.12.06 yjcho edit start
//  if(voCb.checked) {
//    this.selectedItems.remove(poNode.index);
//    voCb.checked = false;
//  } else {
//    this.selectedItems.put(poNode.index, poNode);
//    voCb.checked = true;
//  }
  if(voCb.checked) {
    this.selectedItems.put(poNode.index, poNode);
  } else {
    this.selectedItems.remove(poNode.index);
  }
  ///// 2010.12.06 yjcho edit end
  if(this.openedItem) this.addChangedNode(this.openedItem);
//  if(this.openedItem != poNode) {
    this.dochange(poEvent, this);
//  }
  this.openedItem = poNode;

  this.addChangedNode(poNode);
  this.repaint(poDocument);
  this.checkSelected();
  this.ctrl.scrollTop = vnTop;
};
/**
 * remove node from selected node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.removeFromSelectedNode = function(poNode) {
  //for(var i = 0; i < this.selectedItems.size(); i++) {
  //  if(poNode == this.selectedItems.get(i)) {
  //    this.selectedItems.remove(i)
  //    return;
  //  }
  //}
  this.selectedItems.remove(poNode.index);
};
/**
 * 지정된 트리노드를 선택하는 메소드.(노드를 펼치는 것과는 다름).
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 */
eXria.controls.xhtml.TreeView.prototype.openNode = function(poNode) {
  if(this.openedItem != null) this.addChangedNode(this.openedItem);
  this.openedItem = poNode;
  this.selectedItems.put(poNode.index, poNode)
  this.addChangedNode(poNode);
};
/**
 * 노드 선택.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @example
   var tree = page.getControl("treeview");<br>
   var node = tree.getNodeByVal("value1");<br>
   tree.toggleNode(node);<br>
 */
eXria.controls.xhtml.TreeView.prototype.toggleNode = function(poNode, poDocument) {
  var vbExpand = poNode.expand ? false : true;
  poNode.expand = vbExpand;
  ///// 2010.12.06 yjcho edit start
//  if(vbExpand == false) {
//    //var setSelected = false;
//    var voSelectedItems = this.selectedItems.getValueCollection();
//    //for(var i = 0; i < this.selectedItems.size(); i++) {
//    //  if(poNode.isAncestor(this.selectedItems.get(i))) {
//    //    this.unselectNode(this.selectedItems.get(i));
//    //    setSelected = true;
//    //    i--;
//    //  }
//    //}
//    //if(setSelected) this.selectedItems.add(poNode);
//    for(var i = 0; i < voSelectedItems.size(); i++) {
//      if(poNode.isAncestor(voSelectedItems.get(i))) {
//        this.unselectNode(voSelectedItems.get(i));
//      }
//    }
//    if(this.openedItem != null && poNode.isAncestor(this.openedItem)) this.openNode(poNode);
//  }
  ///// 2010.12.06 yjcho edit end
  if(this.isOneLine && vbExpand) {
    if(this.prevExpandNode == null) this.prevExpandNode = this.root;
    if(!this.prevExpandNode.isAncestor(poNode) && !poNode.isAncestor(this.prevExpandNode)) {
      var voParent = this.prevExpandNode.parent;
      var voCollapseNode = this.prevExpandNode;
      while(!voParent.isAncestor(poNode)) {
        voCollapseNode = voParent;
        voParent = voParent.parent;
      }
      voCollapseNode.expand = false;
      this.addChangedNode(voCollapseNode);
    }
    this.prevExpandNode = poNode;
  }
  this.addChangedNode(poNode);
//  var voNodeCtrl = this.document.getElementById(this.id + "_node" + poNode.index);
//  var vnClientHeight01 = voNodeCtrl.clientHeight;
  this.repaint(poDocument);
//  voNodeCtrl = this.document.getElementById(this.id + "_node" + poNode.index);
//  var vnScrollHeight02 = voNodeCtrl.scrollHeight;
//  var vnScrollTop = vnScrollHeight02 - vnClientHeight01;
//  if(vnScrollTop > 0) this.ctrl.scrollTop = vnScrollTop;
};
/**
 * add node to changed node.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.addChangedNode = function(poNode) {
//  if(!this.hasChangedAncestor(poNode)) this.changedNodes.add(poNode);
  this.changedNodes.add(poNode);
};
/**
 * remove node from changed node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.removeFromChangedNode = function(poNode) {
  for(var i = 0; i < this.changedNodes.size(); i++) {
    if(poNode == this.changedNodes.get(i)) {
      this.changedNodes.remove(i);
      return;
    }
  }
};
/**
 * Returns true if node has changed ancestor
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return 변경 사항이 존재하는 부모 트리노드
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.hasChangedAncestor = function(poNode) {
  var voParent = poNode;
  if(voParent == null) return true;
  var vbHasChangedAncestor = false;
  while(voParent != this.root) {
    if(voParent.parent == null) return true;
    voParent = voParent.parent;
    if(this.isChangedNode(voParent)) {
      vbHasChangedAncestor = true;
      break;
    }
  }
  return vbHasChangedAncestor;
};
/**
 * Returns true is node is changed
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return vbChanged
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isChangedNode = function(poNode) {
  var vbChanged = false;
  for(var i = 0; i < this.changedNodes.size(); i++) {
    if(this.changedNodes.get(i) == poNode) vbChanged = true;
  }
  return vbChanged;
};

//treeSelectionListener
//@param {HTMLEvent} e 윈도우이벤트
//@param {eXria.controls.xhtml.TreeNode} poNode 대상노드
//@param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
//@private

//eXria.controls.xhtml.TreeView.prototype.treeSelectionListener = function(e, poNode, poDocument) {
//  var voEvent = new eXria.event.Event(e);
//  this.selectNode(poNode, voEvent, poDocument);
//  voEvent.stopEvent();
//};
/**
 * refresh시 해당 노드의 이전의 펼쳐진 상태로 복원하기 위해
 * 해당 노드와 그 하위 노드의 펼쳐진 상태를 인덱스를 통해 기록하는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 펼쳐진 상태를 체크할 노드
 * @param {String} psIndexes 노드의 위치를 root로 부터의 상대적 인덱스 형태로 표현한 값
 * root 노드는 "", this.root.children[0].childrent[0]은 "0,0" 인 형태
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.remarkExpand =  function(poNode, psIndexes) {
  var voChild = null;
  var vsIndexes = null;
  if(psIndexes != "") psIndexes += ","
  for(var i = 0; i < poNode.children.length; i++) {
    voChild = poNode.children[i];
    vsIndexes = psIndexes + i;
    if(voChild.expand) {
      this.expandedIndexes.push(vsIndexes);
      this.remarkExpand(voChild, vsIndexes);
    }
  }
};
/**
 * root로 부터의 상대적 위치 값을 통해 노드를 검색하는 메소드.
 * @param {String} psIndexes 노드의 위치를 root로 부터의 상대적 인덱스 형태로 표현한 값
 * @return 검색된 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.getNodeFromRoot = function(psIndexes) {
  var vaIndex = psIndexes.split(",");
  var vnIndex = null;
  var voNode = this.root;
  for(var i = 0; i < vaIndex.length; i++) {
    vnIndex = parseInt(vaIndex[i]);
    voNode = voNode.children[vnIndex];
    if(voNode == null) return null;
  }
  return voNode;
};
/**
 * 트리의 펼쳐진 상태를 refresh 이전의 펼쳐진 상태로 복원시켜 주기위한 메소드.
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.restoreExpand = function() {
  if(this.expandedIndexes == null) {
    this.expandedIndexes = [];
    return;
  }
  var voNode =  null;
  var vsIndexes = null;
  for(var i = 0 ; i < this.expandedIndexes.length; i++) {
    vsIndexes = this.expandedIndexes[i];
    voNode = this.getNodeFromRoot(vsIndexes);
    if(voNode) {
      voNode.expand = true;
    }
  }
  this.expandedIndexes = [];
};
/**
 * 해당 노드에 매핑된 인스턴스 element의 인덱스(그 상위 노드를 기준)를 반환하는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @return 해당 노드에 매핑된 인스턴스 element의 인덱스
 * @type Number
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getInstanceIndex = function(poNode) {
  if(poNode.nodeset) {
   var voCollectionNode = poNode.nodeset.data.getNodesetData2();
   var vnSize = voCollectionNode.getLength();
   var voMapNode = null;
   var vsLabelNode = poNode.nodeset.labelTagName;
   var vsValueNode = poNode.nodeset.valueTagName;
   var vsLabel = null;
    var vsValue = null;
   for(var i = 0; i < vnSize; i++) {
     voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
     vsLabel = voMapNode.get(vsLabelNode);
     vsValue = voMapNode.get(vsValueNode);
     if(poNode.name == vsLabel && poNode.getValue() == vsValue) {
      return i;
     }
   }
  }
  return -1;
};
/**
 * 노드를 위, 아래로 이동시켜주는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 이동시킬 노드
 * @param {Boolean} pbUp 위로 이동시킬지 여부
 * @example
 * var tree = page.getControl("treeview");<br>
   var node = tree.getNodeByVal("value1");<br>
   tree.upDownNode(node, true);<br>
 */
eXria.controls.xhtml.TreeView.prototype.upDownNode = function(poNode, pbUp) {
  var vnSourceIndex = poNode.parent.getIndex(poNode);
  var voTargetNode = null;
  if(pbUp) {
    if(vnSourceIndex == 0) return;
    voTargetNode = poNode.parent.children[vnSourceIndex - 1];
  } else {
    voTargetNode = poNode.parent.children[vnSourceIndex + 1];
  }
  if(voTargetNode == null) return;
  this.switchNode(poNode, voTargetNode);
};
/**
 * 두 노드의 위치를 상호 교환시켜주는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poSourceNode 이동시킬 노드
 * @param {eXria.controls.xhtml.TreeNode} poTargetNode 이동시킬 위치의 기존 노드
 * @example
 * var tree = page.getControl("treeview");<br>
   var node1 = tree.getNodeByVal("value1");<br>
   var node2 = tree.getNodeByVal("value2");<br>
   tree.switchNode(node1, node2);<br>
 */
eXria.controls.xhtml.TreeView.prototype.switchNode = function(poSourceNode, poTargetNode) {
  if(poSourceNode == poTargetNode) return;
  if(poSourceNode.parent != poTargetNode.parent) return;
  var vnSourceIndex = poSourceNode.parent.getIndex(poSourceNode);
  var vnTargetIndex = poTargetNode.parent.getIndex(poTargetNode);
  var vnAdjust = 1;
//  if(vnTargetIndex < vnSourceIndex) vnAdjust = 0;

  vnSourceIndex = poTargetNode.parent.getIndex(poSourceNode);
  vnTargetIndex = poTargetNode.parent.getIndex(poTargetNode);

  if(vnSourceIndex > vnTargetIndex){
    var vnTemp = vnSourceIndex;
    vnSourceIndex = vnTargetIndex;
    vnTargetIndex = vnTemp;
    poSourceNode.parent.remove(poTargetNode);
    poSourceNode.parent.add(poTargetNode, vnTargetIndex, vnSourceIndex);
  }else{
    poSourceNode.parent.remove(poSourceNode);
    poTargetNode.parent.add(poSourceNode, vnTargetIndex, vnSourceIndex);
  }
//  poTargetNode.parent.add(poSourceNode, vnTargetIndex, vnSourceIndex);
  this.repaintChanged();
  this.switchInstanceNode(poSourceNode, poTargetNode);
};
//eXria.controls.xhtml.TreeView.prototype.switchNode = function(poSourceNode, poTargetNode) {
//  if(poSourceNode == poTargetNode) return;
//  if(poSourceNode.parent != poTargetNode.parent) return;
//  var vnSourceIndex = poSourceNode.parent.getIndex(poSourceNode);
//  var vnTargetIndex = poTargetNode.parent.getIndex(poTargetNode);
//  var vnAdjust = 1;
//  if(vnTargetIndex < vnSourceIndex) vnAdjust = 0;
//
//  poSourceNode.parent.remove(poSourceNode);
//  vnTargetIndex = poTargetNode.parent.getIndex(poTargetNode);
//  poTargetNode.parent.add(poSourceNode, vnTargetIndex + vnAdjust);
//  this.repaintChanged();
//  this.switchInstanceNode(poSourceNode, poTargetNode);
//};
/**
 * 두 노드의 인스턴스 위치를 상호 교환시켜주는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poSourceNode 이동시킬 노드
 * @param {eXria.controls.xhtml.TreeNode} poTargetNode 이동시킬 위치의 기존 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.switchInstanceNode = function(poSourceNode, poTargetNode) {
  if(poSourceNode == poTargetNode) return;
  if(poSourceNode.nodeset != poTargetNode.nodeset) return;
  var vnSourceIndex = this.getInstanceIndex(poSourceNode);
  var vnTargetIndex = this.getInstanceIndex(poTargetNode);
  if(vnSourceIndex == -1 || vnTargetIndex == -1) return;
  var voCollectionNode = poSourceNode.nodeset.data.getNodesetData2();
  var voSourceMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(vnSourceIndex));
  var voTargetMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(vnTargetIndex));
  var vsLabelTag = poTargetNode.nodeset.labelTagName;
  var vsValueTag = poTargetNode.nodeset.valueTagName;
  var vsParentTag = poTargetNode.nodeset.parentTagName;
  var vsTargetLabel = voTargetMapNode.get(vsLabelTag);
  var vsTargetValue = voTargetMapNode.get(vsValueTag);
  var vsTargetParent = voTargetMapNode.get(vsParentTag);
  voTargetMapNode.put(vsLabelTag, voSourceMapNode.get(vsLabelTag));
  voTargetMapNode.put(vsValueTag, voSourceMapNode.get(vsValueTag));
  voTargetMapNode.put(vsParentTag, voSourceMapNode.get(vsParentTag));
  voSourceMapNode.put(vsLabelTag, vsTargetLabel);
  voSourceMapNode.put(vsValueTag, vsTargetValue);
  voSourceMapNode.put(vsParentTag, vsTargetParent);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type String|Number|Object
 */
eXria.controls.xhtml.TreeView.prototype.getSpecificDefaultValue = function(psAttrName){
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.TreeView[psAttrName];
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.TreeView[vaAttrName[0]][vaAttrName[1]];
  }
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
//  if(psAttrName == "iconDir") {
//    vsDefaultValue = (this.canvas.page.metadata.resourceBaseUrl + vsDefaultValue;
//  }
  return vsDefaultValue;
};
/**
 * 지정된 값을 포함한 트리노드를 얻어오기 위한 메소드.
 * @param {String} psValue 검색할 값
 * @return 지정된 값을 포함한 트리노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.getNodeByVal = function(psValue) {
  var voIterator = this.items.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voNode = voIterator.next();
    if(voNode.getValue() == psValue) {
      return voNode;
    }
  }
  return null;
};
/**
 * 지정된 값을 포함한 트리노드를 얻어오기 위한 메소드.
 * @param {String} psValue 검색할 값
 * @return 지정된 값을 포함한 트리노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.openNodeByVal = function(psValue) {
  var voIterator = this.items.getValueCollection().iterator();
  var voNode = null;
  var voRet = null;
  while(voIterator.hasNext()) {
    voNode = voIterator.next();
    if(voNode.getValue() == psValue) {
      voRet = voNode;
      break;
    }
  }
  if(voRet == null) return;
  voRet.expand = true;
  var voParent = null;
  var voChangedRoot = null;
  if(voRet.parent) voParent = voRet.parent;
  while(voParent) {
    //if(voParent.expand) break;
    voParent.expand = true;
    //voChangedRoot = voParent;
    voParent = voParent.parent;
  }
  this.addChangedNode(this.root);
  this.repaint();

  //2010.12.15 추가
  var voDiv = null;
  var voDocument = this.document;
  voDiv = voDocument.getElementById(this.id + "_node" + voRet.index);
  if(this.showCheckBox) {
    var voChkCtrl = this.getSubCtrl("input", voDiv, voDocument);
    if(voChkCtrl.checked) voChkCtrl.checked = false;
    else voChkCtrl.checked = true;
  }
  this.selectNode(voRet);
  this.ctrl.scrollTop = parseInt(voDiv.style.top);
  return voRet;
};
/**
 * 지정된 위치(document.body를 기준)의 item을 반환하는 메소드
 * @param {Number} pnIndex 현재 보여지는 트리 리스트의 row 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getItemByPos = function(pnX, pnY, pbChkParent) {
  var voDocument = this.document;
  var voCtrl = this.ctrl;
  var voTable = this.lookup(this.id + "_table", this.document);
  var vnSize = voTable.childNodes.length;
  var voDiv = null;
  var voStyle = null;
  var vsIdx = null;
  var voItems = this.items;
  var voItem = null;

  if(pbChkParent) {
    var voParent = this.parent;
    while(voParent) {
      pnX -= voParent.left;
      pnY -= voParent.top;
      voParent = voParent.parent;
    }
  }
  pnX -= this.left;
  pnY -= this.top;

  var vnTop = null;
  for(var i = 0; i < vnSize; i++) {
    voDiv = voTable.childNodes.item(i);
    vsIdx = voDiv.id;
    vsIdx = vsIdx.replace(this.id + "_node", "");
    voItem = voItems.get(vsIdx);
    vnTop = parseInt(voDocument.getElementById(this.id + "_node" + voItem.index).style.top) - voCtrl.scrollTop;
    if((pnX >= voItem.left && pnX <= voItem.left + voItem.width) &&
        (pnY >= vnTop && pnY <= vnTop + voItem.height)) {
      break;
    }
    voItem = null;
  }
  return voItem;
};







eXria.controls.xhtml.TreeView.prototype.repaintChangedMenu = function(poCtrl, poDocument) {
  if(poDocument == null) poDocument = this.document;
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  var voTable = poCtrl.childNodes[0];
  var vsId = this.id;
  for(var i = 0; i < this.changedNodes.size(); i++) {
    var voNode = this.changedNodes.get(i);
    var vsRowId = vsId + "_node" + voNode.index;
    var nextRowId = - 1;
    var vnRowIndex1 = - 1;
    var vnRowIndex2 = - 1;
    if(voNode != this.root) {
      vnRowIndex1 = this.getRowIndexById(vsRowId, poDocument);
      try {
        if(voNode.parent.getChildAfter(voNode) == null) throw new Error(9999, "Null point exception!");
        nextRowId = vsId + "_node" + voNode.parent.getChildAfter(voNode).index;
        vnRowIndex2 = this.getRowIndexById(nextRowId, poDocument) - 1;
        if(vnRowIndex2 < 0) throw new Error(9999, "Index out of bound!");
      } catch(err) {
        try {
          if(this.getNextOpenedAncestor(voNode, poDocument) == null) throw new Error(9999, "Null point exception!");
          nextRowId = vsId + "_node" + this.getNextOpenedAncestor(voNode, poDocument).index;
          vnRowIndex2 = this.getRowIndexById(nextRowId, poDocument) - 1;
          if(vnRowIndex2 == -1) throw new Error(9999, "Index Out of bound!");
        } catch(err) {
          vnRowIndex2 = voTable.childNodes.length - 1;
        }
      }
    } else {
      vnRowIndex1 = 0;
      vnRowIndex2 = voTable.childNodes.length - 1;
    }
    var vbRepaintChildren = true;
    if(!voNode.expand) vbRepaintChildren = false;
    try {
      for(var j = 0; j <(vnRowIndex2 - vnRowIndex1); j++) {
         this.deleteTreeNode(vnRowIndex1 + 1, poDocument);
      }
    } catch(err) {
    }

    var vbRoot = false;
    if(voNode == this.root) vbRoot = true;
    this.repaintNode(voNode, vnRowIndex1, vbRoot, poCtrl, poDocument, vbRepaintChildren);
  }

  var voCtrl = this.ctrl;
  var vnSize = voTable.childNodes.length;
  var voNodeCtrl = null;
  var vnHeight = 0;
  for(var i = 0; i < vnSize; i++) {
    voNodeCtrl = voTable.childNodes.item(i);
    vnHeight += parseInt(voNodeCtrl.style.height);
  }
  if(vnHeight > this.innerHeight && this.scrolled != true) {
    var vnSize = voTable.childNodes.length;
    var voNodeCtrl = null;
    var voSubCtrl = null;
    for(var i = 0; i < vnSize; i++) {
      var vnSpanWidth = this.innerWidth - this.window.scrollBarWidth;
      voNodeCtrl = voTable.childNodes.item(i);
      voNodeCtrl.style.width = vnSpanWidth + "px";
      voSubCtrl = voNodeCtrl.getElementsByTagName("div");
      if(voSubCtrl.length == 1) voSubCtrl = voSubCtrl[0];
      else voSubCtrl = voSubCtrl[1];
      if(voNodeCtrl.firstChild != voSubCtrl) {
        vnSpanWidth -= this.iconWidth;
      }
      voSubCtrl.style.width = vnSpanWidth + "px";
      voSubCtrl = voSubCtrl.childNodes.item(0);
      voSubCtrl.style.width = vnSpanWidth + "px";
    }
    this.scrolled = true;
  } else if(vnHeight <= this.innerHeight && this.scrolled) {
    var vnSize = voTable.childNodes.length;
    var voNodeCtrl = null;
    var voSubCtrl = null;
    for(var i = 0; i < vnSize; i++) {
      var vnSpanWidth = this.innerWidth;
      voNodeCtrl = voTable.childNodes.item(i);
      voNodeCtrl.style.width = vnSpanWidth + "px";
      voSubCtrl = voNodeCtrl.getElementsByTagName("div");
      if(voSubCtrl.length == 1) voSubCtrl = voSubCtrl[0];
      else voSubCtrl = voSubCtrl[1];
      if(voNodeCtrl.firstChild != voSubCtrl) {
        vnSpanWidth -= this.iconWidth;
      }
      voSubCtrl.style.width = vnSpanWidth + "px";
      voSubCtrl = voSubCtrl.childNodes.item(0);
      voSubCtrl.style.width = vnSpanWidth + "px";
    }
    this.scrolled = false;
  }
};

eXria.controls.xhtml.TreeView.prototype.deleteTreeNodeMenu = function(pnIndex, poDocument) {
  var voTable = this.lookup(this.id + "_table", poDocument);
  //this.clearCtrlNode(voTable.childNodes.item(pnIndex));
  var voNodeCtrl = voTable.childNodes.item(pnIndex);
  var vnHeight = parseInt(voNodeCtrl.style.height);
  voTable.removeChild(voNodeCtrl);

  var voDiv = null;
  var voStyle = null;
  for(var i = pnIndex; i < voTable.childNodes.length; i++) {
    voDiv = voTable.childNodes.item(i);
    voStyle = voDiv.style;
    voStyle.top = (parseInt(voStyle.top) - vnHeight) + "px";
  }
};

eXria.controls.xhtml.TreeView.prototype.repaintNodeMenu = function(poNode, pnIndex, pbRoot, poCtrl, poDocument, pbRepaintChildren) {
  if(poNode.visible == false || pnIndex < 0) return;
  if(poDocument == null) poDocument = this.document;
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  if(pbRepaintChildren == null) pbRepaintChildren = true;
  var vaMenuAttr = window.maMenuAttr;
  var voMenuAttr = null;
  if(poNode.depth == 1) voMenuAttr = vaMenuAttr[0];
  else if(poNode.isLeaf()) voMenuAttr = vaMenuAttr[2];
  else voMenuAttr = vaMenuAttr[1];
  var vnNodeHeight = voMenuAttr.height;
  var voTable = poCtrl.childNodes[0];
  var voPreviousNodeCtrl = null;
  if(pnIndex - 1 >= 0) voPreviousNodeCtrl = voTable.childNodes[pnIndex - 1];
  var vnTop = 0;
  if(voPreviousNodeCtrl) {
    vnTop = parseInt(voPreviousNodeCtrl.style.top);
    vnTop += parseInt(voPreviousNodeCtrl.style.height);
  }

  var vsId = this.id;
  var voDiv = poDocument.getElementById(vsId + "_node" + poNode.index);
  if(voDiv == null) {
    voDiv = poDocument.createElement("div");
    if(this.itemgroup.className) voDiv.setAttribute("class", this.itemgroup.className);
    var voStyle = voDiv.style;
    var voDf = this.df;
    var vaCssStrBuf = null;
    var vfcSetCssStrBuf = this.setCssStrBuf;

    voDiv["id"] = vsId + "_node" + poNode.index;

    vaCssStrBuf = [];
    vfcSetCssStrBuf(vaCssStrBuf, "padding", 0, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "margin", 0, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "position", "absolute");
    vfcSetCssStrBuf(vaCssStrBuf, "left", 0, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "top", vnTop, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", vnNodeHeight, "px");
    voStyle.cssText = vaCssStrBuf.join("");

    if(!pbRoot) {
      if(pnIndex == voTable.childNodes.length) voTable.appendChild(voDiv);
      else voTable.insertBefore(voDiv, voTable.childNodes.item(pnIndex));
      this.setNodeCtrl(poNode, voDiv, poDocument);

      for(var i = pnIndex + 1; i < voTable.childNodes.length; i++) {
        voDiv = voTable.childNodes.item(i);
        voStyle = voDiv.style;
        voStyle.top = (parseInt(voStyle.top) + vnNodeHeight) + "px";
      }
    }
  } else {
    this.refreshNodeCtrl(poNode, voDiv, poDocument);
  }
  if(pbRepaintChildren == false) return;
  var voNextAncestor = null;
  var voPrevious = null;
  for(var i = 0; i < poNode.children.length && poNode.expand; i++) {
    // 하위노드(0) 추가 후 그 하위노드의 하위 노드들이 추가되었을 경우 하위노드(0)의 다음노드(1)은
    // 하위노드(0)의 NextOpenedAncestor에 위치하여야 한다.
    if(i == 0) {
       if(pbRoot) this.repaintNode(poNode.children[i], pnIndex, false, poCtrl, poDocument);
       else this.repaintNode(poNode.children[i], pnIndex + 1, false, poCtrl, poDocument);
    } else {
      var rowId = null;
      var rowIndex = null;
       try {
          voNextAncestor = this.getNextOpenedAncestor(voPrevious, poDocument);
          if(voNextAncestor == null) throw new Error(9999, "It has no next opened ancestor!");
          rowId = vsId + "_node" + voNextAncestor.index;
          rowIndex = this.getRowIndexById(rowId, poDocument);
          if(rowIndex == -1) throw new Error(9999, "Index out of bound!");
          this.repaintNode(poNode.children[i], rowIndex, false, poCtrl, poDocument);

       } catch(err) {
          rowIndex = voTable.childNodes.length;
          this.repaintNode(poNode.children[i], rowIndex, false, poCtrl, poDocument);
       }
    }
    if(poNode.children[i].visible != false) voPrevious = poNode.children[i];
  }
};

eXria.controls.xhtml.TreeView.prototype.setNodeCtrlMenu = function(poNode, poDiv, poDocument){
  var vaTemplate = [];
  var voIcon = null;
  var vaTagStrBuf = null;
  var vaAttStrBuf = null;
  var vaCssStrBuf = null;
  var vaStrBuf = null;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup;
  var vnNodeHeight = parseInt(poDiv.style.height);
  var vaMenuAttr = window.maMenuAttr;
  var voMenuAttr = null;
  if(poNode.depth == 1) voMenuAttr = vaMenuAttr[0];
  else if(poNode.isLeaf()) voMenuAttr = vaMenuAttr[2];
  else voMenuAttr = vaMenuAttr[1];
  var vsMenuBg = eXria.controls.xhtml.Util.getBackgroundImagePath(voMenuAttr.backgroundImage, this.window);
  var vsClassName = voMenuAttr.className;

  var vbSelectedNode = false;
  if(this.selectedItems.get(poNode.index)) {
  //if(this.openedItem == poNode) {
    vbSelectedNode = true;
  }
  if(this.openedItem == poNode) {
    if(poNode.isLeaf()) voIcon = this.icons.get("selectedLeafItem");
    else voIcon = this.icons.get("openedFolder_" + poNode.depth);
    if(voIcon == null) {
//      if(poNode.isLeaf()) {
//        voIcon = this.icons.get("selectedLeafItem");
//      } else{
        if(poNode.expand) {
          voIcon = this.icons.get("openedFolder");
        } else {
          voIcon = this.icons.get("closedFolder_" + poNode.depth);
          if(voIcon == null) voIcon = this.icons.get("closedFolder");
        }
//      }
    }
    if(poNode.iconOpened && poNode.iconOpened != "") {
      voIcon = {};
      voIcon.src = poNode.iconOpened;
    }

  } else {
    if(poNode.isLeaf()) {
      voIcon = this.icons.get("leafItem_" + poNode.depth);
      if(voIcon == null) voIcon = this.icons.get("leafItem");
    } else{
      voIcon = this.icons.get("closedFolder_" + poNode.depth);
    }
    if(voIcon == null) {
//      if(poNode.isLeaf()) {
//        voIcon = this.icons.get("leafItem_" + poNode.depth);
//        if(voIcon == null) voIcon = this.icons.get("leafItem");
//      } else{
        if(poNode.expand) {
          voIcon = this.icons.get("openedFolder_" + poNode.depth);
          if(voIcon == null) voIcon = this.icons.get("openedFolder");
        } else {
          voIcon = this.icons.get("closedFolder");
        }
//      }
    }
    if(poNode.icon && poNode.icon != "") {
      voIcon = {};
      voIcon.src = poNode.icon;
    }
  }
  var vnOffset = 0;

  if(poNode == this.root) vnOffset = 0;
  if(poNode.depth > 1 && voIcon.src != "none") {
    vaTagStrBuf = [];
    vaTagStrBuf.push("<div ");
    vaTagStrBuf.push("' style='position:absolute;top:0px;background-repeat:no-repeat;background-position:center center;");
    vaCssStrBuf = [];
    vfcSetCssStrBuf(vaCssStrBuf, "background-image", eXria.controls.xhtml.Util.getBackgroundImagePath(voIcon.src, this.window));
    vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", vnNodeHeight, "px");
    if(poNode.disabled != true) vfcSetCssStrBuf(vaCssStrBuf, "cursor", "pointer");
    vaTagStrBuf.push(vaCssStrBuf.join(""));
    vaTagStrBuf.push("'");
    if(poNode.disabled != true) {
      vaTagStrBuf.push(" onmousedown=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMousedown"));
      vaTagStrBuf.push("return false;\" onmouseup=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMouseup"));
      if(poNode.isLeaf()) {
        vaTagStrBuf.push("\" onclick=\"");
        vaTagStrBuf.push(this.getEHandler(poNode.index, "labelClick"));
      } else {
        vaTagStrBuf.push("\" onclick=\"");
        vaTagStrBuf.push(this.getEHandler(poNode.index, "nodeClick"));
      }
      vaTagStrBuf.push("\" ondblclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelDblClick"));
      vaTagStrBuf.push("\" ");
    }
    vaTagStrBuf.push(">");

    vaTemplate.push(vaTagStrBuf.join(""));
  } else {
    vnOffset--;
  }
  var vsFontColor = voMenuAttr.fontColor;
  if(vsFontColor == null) vsFontColor = voItemgroupDf.color;
  if(vsFontColor == null) vsFontColor = this.color;
  var vsBackgroundColor = voMenuAttr.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = voItemgroupDf.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = this.backgroundColor;
  if(vbSelectedNode)
  {
    vsFontColor = voItemgroupDf.selectedColor;
    vsClassName = voMenuAttr.focusClassName;
//    vsBackgroundColor = voItemgroupDf.selectedBackgroundColor;
  } else if(poNode.expand) {
    if(voMenuAttr.focusClassName) vsClassName = voMenuAttr.focusClassName;
  }
//  if(poNode.depth == 1) vsBackgroundColor = "transparent";

  var vnLen = this.ctrl.clientWidth;
  if(poNode.depth > 1 && voIcon.src != "none") {
//    var voSpan = this.subElement.span;
//    voSpan.innerHTML = poNode.name;
//    vnLen = voSpan.offsetWidth;
      vnLen -= this.iconWidth;
  }

  vnOffset++;
  vaTagStrBuf = [];
  vaTagStrBuf.push("<div onselectstart=\"return false;\" ");
  if(poNode.disabled) {
    vaTagStrBuf.push("disabled ");
  } else {
    vaTagStrBuf.push("onmousedown=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMousedown"));
    vaTagStrBuf.push("return false;\" onmouseup=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelMouseup"));
    if(poNode.isLeaf()) {
      vaTagStrBuf.push("\" onclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "labelClick"));
    } else {
      vaTagStrBuf.push("\" onclick=\"");
      vaTagStrBuf.push(this.getEHandler(poNode.index, "nodeClick"));
    }
    vaTagStrBuf.push("\" ondblclick=\"");
    vaTagStrBuf.push(this.getEHandler(poNode.index, "labelDblClick"));
    vaTagStrBuf.push("\" ");
    if(vsClassName) {
      vaTagStrBuf.push(" class=\"");
      vaTagStrBuf.push(vsClassName);
      vaTagStrBuf.push("\" ");
    }
  }

  vaTagStrBuf.push("style='position:absolute;overflow:hidden;margin:0px;padding:0px;top:0px;");
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "left", (vnOffset * this.iconWidth), "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "width", (this.innerWidth - (vnOffset * voDf.iconWidth)), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnLen, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnNodeHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", vsBackgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", vsMenuBg);
  if(poNode.disabled != true) vfcSetCssStrBuf(vaCssStrBuf, "cursor", "pointer");
  vaTagStrBuf.push(vaCssStrBuf.join(""));
  vaTagStrBuf.push("'>");

  vaTemplate.push(vaTagStrBuf.join(""));

  // yhkim 2009.09.04
  var vsClass = this.getCSSClass(this, 1, "itemgroup");
  vaTagStrBuf = [];
  vaTagStrBuf.push("<table class='" + vsClass + "' cellSpacing=0 cellPadding=0 style='position:absolute;left:0px;top:0px;");
  vaCssStrBuf = [];
  //vfcSetCssStrBuf(vaCssStrBuf, "width", (this.innerWidth - (vnOffset * voDf.iconWidth)), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", vsBackgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnLen, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnNodeHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", vsFontColor);
  var vuAttr = poNode.fontFamily;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontFamily;
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", vuAttr);
  vuAttr = voMenuAttr.fontSize;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontSize;
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vuAttr, "pt");
  vuAttr = poNode.fontStyle;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontStyle;
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", vuAttr);
  vuAttr = poNode.fontWeight;
  if(vuAttr == null) vuAttr = voItemgroupDf.fontWeight;
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", vuAttr);
  vaTagStrBuf.push(vaCssStrBuf.join(""));
  vaTagStrBuf.push("'>");

  vaTemplate.push(vaTagStrBuf.join(""));

  vaTagStrBuf = [];
  vaTagStrBuf.push("<tbody><tr><td style='");
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voItemgroupDf.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", voItemgroupDf.verticalAlign);
  vaTagStrBuf.push(vaCssStrBuf.join(""));
  vaTagStrBuf.push("'>");
  vaTagStrBuf.push(eXria.controls.xhtml.Util.parseLang(poNode.name));
  vaTagStrBuf.push("</td></tr></tbody>");

  vaTemplate.push(vaTagStrBuf.join(""));
  poDiv.innerHTML = vaTemplate.join("");
  vaTemplate = null;
};

eXria.controls.xhtml.TreeView.prototype.refreshNodeCtrlMenu = function(poNode, poDiv, poDocument){
  var voIcon = null;
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup;
  var voBase = this;
  var vaMenuAttr = window.maMenuAttr;
  var voMenuAttr = null;
  if(poNode.depth == 1) voMenuAttr = vaMenuAttr[0];
  else if(poNode.isLeaf()) voMenuAttr = vaMenuAttr[2];
  else voMenuAttr = vaMenuAttr[1];
  var vsMenuBg = eXria.controls.xhtml.Util.getBackgroundImagePath(voMenuAttr.backgroundImage, this.window);
  var vsClassName = voMenuAttr.className
  var voImgCtrl = null;
  var vaCtrl = null;

  var vbSelectedNode = false;
  if(this.selectedItems.get(poNode.index)) {
    vbSelectedNode = true;
  }
  if(this.openedItem == poNode) {
    if(poNode.isLeaf()) voIcon = this.icons.get("selectedLeafItem");
    else voIcon = this.icons.get("openedFolder_" + poNode.depth);
    if(voIcon == null) {
      if(poNode.expand) {
        voIcon = this.icons.get("openedFolder");
      } else {
        voIcon = this.icons.get("closedFolder_" + poNode.depth);
        if(voIcon == null) voIcon = this.icons.get("closedFolder");
      }
    }
    if(poNode.iconOpened && poNode.iconOpened != "") {
      voIcon = {};
      voIcon.src = poNode.iconOpened;
    }

  } else {
    if(poNode.isLeaf()) {
      voIcon = this.icons.get("leafItem_" + poNode.depth);
      if(voIcon == null) voIcon = this.icons.get("leafItem");
    } else{
      voIcon = this.icons.get("closedFolder_" + poNode.depth);
    }
    if(voIcon == null) {
      if(poNode.expand) {
        voIcon = this.icons.get("openedFolder_" + poNode.depth);
        if(voIcon == null) voIcon = this.icons.get("openedFolder");
      } else {
        voIcon = this.icons.get("closedFolder");
      }
    }
    if(poNode.icon && poNode.icon != "") {
      voIcon = {};
      voIcon.src = poNode.icon;
    }
  }

  var vnIdx = 0;
  if(poNode.depth > 1 && voIcon.src != "none") {
    vnIdx = 1;
    var vaCtrl = poDiv.getElementsByTagName("div");
    voImgCtrl = vaCtrl[0];
    voImgCtrl.style.backgroundImage = eXria.controls.xhtml.Util.getBackgroundImagePath(voIcon.src, this.window);
    if(poNode.disabled != true) {
      voImgCtrl.onmousedown = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMousedown(e, poNode.index);
      };
      voImgCtrl.onmouseup = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelMouseup(e, poNode.index);
      };
      if(poNode.isLeaf()) {
        voImgCtrl.onclick = function(e) {
          e = e ? e : voBase.window.event;
          voBase.labelClick(e, poNode.index);
        };
      } else {
        voImgCtrl.onclick = function(e) {
          e = e ? e : voBase.window.event;
          voBase.nodeClick(e, poNode.index);
        };
      }
      voImgCtrl.ondblclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelDblClick(e, poNode.index);
      };
    } else {
      voImgCtrl.onmousedown = null;
      voImgCtrl.onmouseup = null;
      voImgCtrl.onclick = null;
      voImgCtrl.ondblclick = null;
    }
  }

  var vsFontColor = voMenuAttr.fontColor;
  if(vsFontColor == null) vsFontColor = voItemgroupDf.color;
  if(vsFontColor == null) vsFontColor = this.color;
  var vsBackgroundColor = voMenuAttr.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = voItemgroupDf.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = this.backgroundColor;
  if(vbSelectedNode)
  {
    vsFontColor = voItemgroupDf.selectedColor;
    vsClassName = voMenuAttr.focusClassName;
//    vsBackgroundColor = voItemgroupDf.selectedBackgroundColor;
  } else if(poNode.expand) {
    if(voMenuAttr.focusClassName) vsClassName = voMenuAttr.focusClassName;
  }
  if(vsFontColor == null) vsFontColor = "";
  if(vsBackgroundColor == null) vsBackgroundColor = "";
//  if(poNode.depth == 1) vsBackgroundColor = "transparent";

  var voDivCtrl = this.getSubCtrl("div", poDiv, poDocument, vnIdx);
  this.setAttrCtrl("className", vsClassName, voDivCtrl)
  this.setAttrCtrl("backgroundColor", vsBackgroundColor, voDivCtrl);
  this.setAttrCtrl("backgroundImage", vsMenuBg, voDivCtrl);
  if(poNode.disabled) {
    voDivCtrl.onmousedown = null;
    voDivCtrl.onmouseup = null;
    voDivCtrl.onclick = null;
    voDivCtrl.ondblclick = null;
    this.setAttrCtrl("cursor", "pointer", voDivCtrl);
  } else {
    voDivCtrl.onmousedown = function(e) {
      e = e ? e : voBase.window.event;
      voBase.labelMousedown(e, poNode.index);
    };
    voDivCtrl.onmouseup = function(e) {
      e = e ? e : voBase.window.event;
      voBase.labelMouseup(e, poNode.index);
    };
    if(poNode.isLeaf()) {
      voDivCtrl.onclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.labelClick(e, poNode.index);
      };
    } else {
      voDivCtrl.onclick = function(e) {
        e = e ? e : voBase.window.event;
        voBase.nodeClick(e, poNode.index);
      };
    }
    voDivCtrl.ondblclick = function(e) {
      e = e ? e : voBase.window.event;
      voBase.labelDblClick(e, poNode.index);
    };
    this.setAttrCtrl("cursor", "default", voDivCtrl);
  }

  var voTableCtrl =  this.getSubCtrl("table", voDivCtrl, poDocument);
  this.setAttrCtrl("backgroundColor", vsBackgroundColor, voTableCtrl);
  this.setAttrCtrl("color", vsFontColor, voTableCtrl);
};
/**
 * 해당 item 위치로 스크롤 이동.
 * @param {String|eXria.controls.xhtml.TreeNode} psValue 스크롤 타겟 노드 혹은 노드 값
 */
eXria.controls.xhtml.TreeView.prototype.scrollToItem = function(psValue) {
  var voItem = null;
  if(typeof(psValue) == "string") voItem = this.getNodeByVal(psValue);
  else voItem = psValue;
  if(voItem == null) return;
  var voCtrl = this.document.getElementById(this.id + "_node" + voItem.index);
  if(voCtrl == null) {
    voItem.expand = true;
    var voParent = voItem.parent;
    while(voParent) {
      voParent.expand = true;
      voParent = voParent.parent;
    }
    this.addChangedNode(this.root);
    this.repaint();
    voCtrl = this.document.getElementById(this.id + "_node" + voItem.index);
  }
  this.ctrl.scrollTop = parseInt(voCtrl.style.top);
};
/**
 * 주어진 depth 이전의 모든 노드를 펼쳐주는 메소드
 * @param {Number} pnDepth 노드 depth
 * @param {Boolean} pbCollapseChild 주어진 Depth 이하의 노드를 닫을 지 여부.
 * 값 미지정 혹은 false일 경우 주어진 Depth 이하의 노드들의 펼침 상태가 그대로 유지됨.
 */
eXria.controls.xhtml.TreeView.prototype.expandToDepth = function(pnDepth, pbCollapseChild) {
  if(pbCollapseChild == null) pbCollapseChild = false;
  var vnDepth = pnDepth + 1;
  var voMap = this.items;
  var voCollection = voMap.getValueCollection();
  var vnSize = voCollection.size();
  var voItem = null;
  for(var i = 0; i < vnSize; i++) {
    voItem = voCollection.get(i);
    if(voItem.depth < vnDepth) voItem.expand = true;
    else if(pbCollapseChild) voItem.expand = false;
  }
  this.addChangedNode(this.root);
  this.repaint();
};
/**
 * 특정 노드의 label 색상을 주어진 색상으로 변경하여 해당 노드에 강조효과를 주기위한 메소드.
 * 하나의 이미 그려진 노드만을 강조할 수 있음.
 * @param {eXria.controls.xhtml.TreeNode|String} poNode 대상 노드 혹은 노드 인덱스
 * @param {String} psColor 강조 색상
 */
eXria.controls.xhtml.TreeView.prototype.markNodeLabel = function(poNode, psColor, pbMark) {
  if(pbMark == null) pbMark = true;
  if(pbMark == false) {
    if(this.markedNode) {
      poNode = this.markedNode;
      psColor = this.markedPrevColor;
    } else {
      return;
    }
  }
  var voItem = null;
  if(typeof(poNode) == "string") voItem = this.getNodeByVal(poNode);
  else voItem = poNode;
  if(pbMark && voItem == this.markedNode) return;
  else if(pbMark && this.markedNode) this.markNodeLabel(null, null, false);
  this.markedNode = voItem;

  var vsId = voItem.index;
  vsId = this.id + "_node" + vsId;
  var voDocument = this.document;
  var voNodeCtrl = this.document.getElementById(vsId);
  var voDivCtrl = this.getSubCtrl("div", voNodeCtrl, voDocument);
  var voTableCtrl =  this.getSubCtrl("table", voDivCtrl, voDocument);
  if(this.trvType != "WBS") {
    this.markedPrevColor = voTableCtrl.style.color;
    this.setAttrCtrl("color", psColor, voTableCtrl);
  } else {
    var voInnTblCtrl = voTableCtrl.rows[0].cells[0].childNodes[0];
    this.markedPrevColor = voInnTblCtrl.style.color;
    this.setAttrCtrl("color", psColor, voInnTblCtrl);
    var vnSize = voInnTblCtrl.rows.length;
    for(var i = 0; i < vnSize; i++) {
      voInnTblCtrl.rows[i].cells[0].style.color = psColor;
    }
  }
  if(pbMark == false) {
   this.markedNode = null;
   this.markedColor = null;
  }
};
/**
 * 주어진 노드를 itemValueMap에 등록하는 메소드.
 * 반드시 해당 노드의 parentValue이 지정된 상태에서 호출되야됨.
 * @param {eXria.controls.xhtml.TreeNode} poNode 트리노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.addToItemValueMap = function(poNode, psValue) {
  var voMap = this.itemValueMap;
//  if(vsParentValue == null || vsParentValue == "") vsParentValue = "root";
  if(psValue == null) psValue = poNode.getValue();
//  var vsBlockId = "gen";
//  if(this.mapBlockIdFunc) {
//    vsBlockId = this.mapBlockIdFunc(vsValue);
//  }
//  if(voMap[vsBlockId] == null) voMap[vsBlockId] = {};
//  voMap[vsBlockId][vsValue] = poNode;
  voMap[psValue] = poNode;
};
/**
 * 클래스 명을 반환.
 * @return "TreeView"
 * @type String
 */
eXria.controls.xhtml.TreeView.prototype.toString = function() {
  return "TreeView";
};

