/**
 * @fileoverview
 * Concreate xhtml TableLayout(XHTML TableLayout 컨트롤)
 * @author ???
 */

/**
 * @class Concreate xhtml TableLayout.<br>
 * XHTML TableLayout 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.TableLayout 객체
 * @type eXria.controls.xhtml.TableLayout
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 * @base eXria.controls.TableLayout
 */
eXria.controls.xhtml.TableLayout = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight =  pnHeight == null ? 300 : pnHeight;

  eXria.controls.TableLayout.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  eXria.controls.xhtml.FreeForm.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight, true); // UIControl을 상속받는다.
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 테이블의 열 갯수
   * @type Number
   * @private
   */
  this.colCnt = null;

  this.rowsInfo = {};

  /**
   * 테이블 선 속성
   * @type String
   * @private
   */
  this.isCellBorder = null;

  this.borderCollapse = null;
  /**
   * 테이블 cellSpacing
   * @type String
   * @private
   */
  this.cellSpacing = null;

  this.cursor = null;
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
  
  this.ctrlPositionMap = {};
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.TableLayout, eXria.controls.xhtml.TableLayout);
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.FreeForm, eXria.controls.xhtml.TableLayout);
//////////////////////////////////////////////////////////////////
// 메소드

/**
 * @ignore
 */
eXria.controls.xhtml.TableLayout.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;

  vaTemplate.push("<table id='" + this.id + "_tableLayout' cellspacing='");
  vaTemplate.push("@innStrBuf");
  vaTemplate.push("' width='100%' height='100%' style='table-layout:fixed;position:absolute;z-index:-1;'>");
  vaTemplate.push("@innStrBuf");
  vaTemplate.push("</table>");

  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};

eXria.controls.xhtml.TableLayout.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
//  this.minWidth = this.getAttrValue("minWidth", this.minWidth);
//  this.minHeight = this.getAttrValue("minHeight", this.minHeight);
//  this.maxWidth = this.getAttrValue("maxWidth", this.maxWidth);
//  this.maxHeight = this.getAttrValue("maxHeight", this.maxHeight);
  if(this.minWidth == null) this.minWidth = this.width;
  if(this.minHeight == null) this.minHeight = this.height;
  if(this.maxWidth == null) this.maxWidth = page.canvas.width - this.left;
  if(this.maxHeight == null) this.maxHeight = page.canvas.height - this.top;
  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    if(voUserAttr.layoutInfo != null){
      voLayoutInfo = eval(voUserAttr.layoutInfo);
      var voRowInfo = null;
      var voCellInfo = null;
      var voRowObj = null;
      var voCellObj = null;
      for(var vsAttr in voLayoutInfo) {
        if(isNaN(vsAttr)) {
          this[vsAttr] = voLayoutInfo[vsAttr];
        } else {
          voRowInfo = this.getRowInfo(eval(vsAttr));
          voRowObj = voLayoutInfo[vsAttr];
          for(var vsAttrRow in voRowObj) {
            if(isNaN(vsAttrRow)) {
              voRowInfo[vsAttrRow] = voRowObj[vsAttrRow];
            } else {
              voCellInfo = voRowInfo.getCellInfo(eval(vsAttrRow));
              voCellObj = voRowObj[vsAttrRow];
              for(var vsAttrCell in voCellObj) {
                voCellInfo[vsAttrCell] = voCellObj[vsAttrCell];
              }
            }
          }
        }
      }
    }
  }
};

eXria.controls.xhtml.TableLayout.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var vsClass = this.getCSSClass(this, 1);
  poCtrl.className = poCtrl.className + " " + vsClass;

  var vaCssStrBuf = null;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vaTemplate = this.template;
  var voIndexMap = this.templateIndexMap;


  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.10.12 동적인 코드에서는 disabled를 제어하지 않으며 FF에서는 없는 속성이다
  //if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "tooltip", this.tooltip);
  vfcSetCssStrBuf(vaCssStrBuf, "disabled", this.disabled);
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  if(this.cellSpacing == null) this.cellSpacing = 0;
  vaTemplate[voIndexMap.get(0)] = this.cellSpacing;
  vaCssStrBuf = null;

  if(page.tableLayoutMap && page.tableLayoutMap[this.id] != null) this.setPositions();
  
  var vaInnStrBuf = [];
  var vnCntI = this.rowCnt;
  var vnCntJ = this.colCnt;
  var vnTrRowSpan = null;
  var vnRowSpan = null;
  var vnColSpan = null;
  var vbCellRowSpan = null;
  var voRowInfo = null;
  var voCellInfo = null;
  var vnStep = null;
  var vnTdWidth = null;
  var vnTdHeight = null;
  
  var voBase = this;
  var voFuncSetEmptyRowSpan = function(poRowInfo, pnCol, pnColSpan) {
    var voTCellInfo = null;
    var vnCntIi = pnCol + pnColSpan;
    for(var ii = pnCol; ii < vnCntIi; ii++) {
      voTCellInfo = poRowInfo.getCellInfo(ii);
      voTCellInfo.rowSpan = 0;
    }
  };
  this.maRowHeight = [];
  this.maColWidth = [];
  var vaRowHeight = this.maRowHeight;
  var vaColWidth = this.maColWidth;
  for(var i = 0; i < vnCntI; i++) {
    vaInnStrBuf.push("<tr");
    voRowInfo = this.getRowInfo(i);
    if(voRowInfo.height != null) {
      vaInnStrBuf.push(" style=\"height:" + voRowInfo.height + "px;\"");
      vaRowHeight[i] = voRowInfo.height;
    }
    vnTrRowSpan = voRowInfo.rowSpan;
    if(vnTrRowSpan != null && vnTrRowSpan > 1) {
      vbCellRowSpan = false;
    } else {
      vbCellRowSpan = true;
    }
    vaInnStrBuf.push(">");
    for(var j = 0; j < vnCntJ; j++) {
      voCellInfo = voRowInfo.getCellInfo(j);
      if(voCellInfo.padding == null) voCellInfo.padding = 0;
      if(voCellInfo.paddingLeft == null) voCellInfo.paddingLeft = voCellInfo.padding;
      if(voCellInfo.paddingRight == null) voCellInfo.paddingRight = voCellInfo.padding;
      if(voCellInfo.paddingTop == null) voCellInfo.paddingTop = voCellInfo.padding;
      if(voCellInfo.paddingBottom == null) voCellInfo.paddingBottom = voCellInfo.padding;
      
      if(vbCellRowSpan == false) {
        voCellInfo.rowSpan = vnTrRowSpan;
      }
      vnRowSpan = voCellInfo.rowSpan;
      vnColSpan = voCellInfo.colSpan;
      
      if(vnRowSpan == null) vnRowSpan = 1;
      if(vnColSpan == null) vnColSpan = 1;
      vaInnStrBuf.push("<td");
      var vsStyle = "padding:0px;";
      if(voCellInfo.width != null) {
        vsStyle += "width:" + voCellInfo.width + "px;";
        vaColWidth[i] = voCellInfo.width;
      }
      if(voCellInfo.height != null) {
        vsStyle += "height:" + voCellInfo.height + "px;";
        vaRowHeight[i] = voCellInfo.height;
      }
      if(vsStyle != "") vaInnStrBuf.push(" style=\"" + vsStyle + "\"");
      vnStep = 1;
      if(vnRowSpan > 1) {
        var voNextRowInfo = null;
        while(vnStep < vnRowSpan) {
          voNextRowInfo = this.getRowInfo(i + vnStep);
          voFuncSetEmptyRowSpan(voNextRowInfo, j, vnColSpan);
          vnStep++;
        }
      }
      vnStep = 1;
      if(vnColSpan > 1) {
        while(vnStep < vnColSpan) {
          voCellInfo = voRowInfo.getCellInfo(j + vnStep);
          voCellInfo.colSpan = 0;
          vnStep++;
        }
//        j += vnColSpan - 1;
      }
      vaInnStrBuf.push("></td>");
    }
    vaInnStrBuf.push("</tr>");
  }
  vaTemplate[voIndexMap.get(1)] = vaInnStrBuf.join("");
  this.ctrl.innerHTML = vaTemplate.join("");
  this.setSubElement(this.document);
  vaTemplate = null;
  voIndexMap.clear();
  this.template = null;
  this.templateIndexMap = null;
  
  var vnFixedRowHeight = 0;
  var vnFixedColWidth = 0;
  var vnFixedRowCnt = 0;
  var vnFixedColCnt = 0;
  for(var i = 0; i < vnCntI; i++) {
    if(vaRowHeight[i] != null) {
      vnFixedRowHeight += vaRowHeight[i];
      vnFixedRowCnt++;
    }
  }
  for(var j = 0; j < vnCntJ; j++) {
    if(vaColWidth[j] != null) {
      vnFixedColWidth += vaColWidth[j];
      vnFixedColCnt++;
    }
  }
  var vnRelRowHeight = (this.innerHeight - (vnCntI + 1) * this.cellSpacing - vnFixedRowHeight) / (vnCntI - vnFixedRowCnt);
  var vnRelColWidth = (this.innerWidth - (vnCntJ + 1) * this.cellSpacing - vnFixedColWidth) / (vnCntJ - vnFixedColCnt);
  for(var i = 0; i < vnCntI; i++) {
    if(vaRowHeight[i] == null) vaRowHeight[i] = vnRelRowHeight;
  }
  for(var j = 0; j < vnCntJ; j++) {
    if(vaColWidth[j] == null) vaColWidth[j] = vnRelColWidth;
  }
};

/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.TableLayout.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.table = this.getSubCtrl("table", voCtrl, poDocument);
};

eXria.controls.xhtml.TableLayout.prototype.refreshComplete = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshComplete(voChild.ctrl, voChild.document);
  }
  this.resizeChildren(this.controls, poDocument);
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  this.setDisable(poCtrl, this.disabled);
  this.hideFocusLine(poCtrl, true);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TableLayout.prototype.resize = function() {
  if(this.isResize === false) {
    this.refreshPos();
    return;
  }
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

	this.ctrl.style["left"] = this.left + "px";
  this.ctrl.style["top"] = this.top + "px";
  this.ctrl.style["width"] = this.innerWidth + "px";
  this.ctrl.style["height"] = this.innerHeight + "px";

  this.resizeChildren(this.controls);
};
/**
 * resizeTable 이벤트 발생시 TableLayout 크기가 변함에 따라 안에 있는 컨트롤 크기를 변화시킨후 refresh해줌.
 * @param {HTMLElement} poCtrls 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.TableLayout.prototype.resizeChildren = function(poCtrls, poDocument) {
  var voChild = null;
  var voIterator = poCtrls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    this.resizeChild(voChild);
    voChild.resize();
  }
};

/**
 * @ignore
 */
eXria.controls.xhtml.TableLayout.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;

  var voTableLayout = poCtrl.childNodes[0];

  switch(psAttrName) {
    case "disabled" :
      poCtrl.disabled = psAttrValue;
      this.applyAttrToChildren("disabled", psAttrValue);
      break;
    //case "borderWidth" :
    //  this.innerWidth = this.width - 2 * this.borderWidth;
    //  this.innerHeight = this.height - 2 * this.borderWidth;
    //  poCtrl.style.width = this.innerWidth + "px";
    //  poCtrl.style.height = this.innerHeight + "px";
    //  break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TableLayout.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "className" :
  case "outerClassName" :
  case "overflow" :
    this.refresh(poDocument);
    break;
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue)
    this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
    var voChild = null;
    var voIterator = this.controls.iterator();
    while(voIterator.hasNext()) {
      voChild = voIterator.next();
      if(voChild.refreshVerticalAlign) {
        voChild.refreshVerticalAlign();
      }
    }
    break;
  case "readOnly" :
    this.setReadOnly(psAttrValue);
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  }
};

eXria.controls.xhtml.TableLayout.prototype.clear = function() {
  this.removeChildren();
  this.clearCtrl();
  this.clearControl();
};
/**
 * @ignore
 */
eXria.controls.xhtml.TableLayout.prototype.loadComplete = function() {
  this.resizeTable();
  this.createChildren();
  if(this.readOnly != null) this.setReadOnly(this.readOnly);
};
/**
 * 하위 컨트롤 resize, repositioning
 * @param voControl
 * @private
 */
eXria.controls.xhtml.TableLayout.prototype.resizeChild = function(poControl) {
  var voTable = this.subElement.table;
  var voRowInfo = this.getRowInfo(poControl.rowNum);
  var voCellInfo = voRowInfo.getCellInfo(poControl.colNum);
  var position = voTable.rows[voCellInfo.rowNum].cells[voCellInfo.colNum];
  var vnCellSpacing = this.cellSpacing;
  var vnRowSpan = voCellInfo.rowSpan;
  var vnColSpan = voCellInfo.colSpan;
  if(vnRowSpan == null) vnRowSpan = 1;
  if(vnColSpan == null) vnColSpan = 1;
  var positionEd = voTable.rows[voCellInfo.rowNum + vnRowSpan - 1].cells[voCellInfo.colNum + vnColSpan - 1];;
  var voPositionMap = this.getLeftTop(poControl);
  var vbFill = voCellInfo.fill;
  vbFill == undefined ? vbFill = true : vbFill = false;
  
  if(vbFill){
    poControl.left = position.offsetLeft + voCellInfo.paddingLeft;
    poControl.top = position.offsetTop + voCellInfo.paddingTop;
    poControl.isResize = false;
  }else{
    poControl.left = voPositionMap.left + position.offsetLeft + voCellInfo.paddingLeft;
    poControl.top = voPositionMap.top + position.offsetTop + voCellInfo.paddingTop;
  }
  var vnWidth = (positionEd.offsetLeft - position.offsetLeft) + positionEd.offsetWidth - voCellInfo.paddingLeft - voCellInfo.paddingRight;;
  var vnHeight = (positionEd.offsetTop - position.offsetTop) + positionEd.offsetHeight - voCellInfo.paddingTop - voCellInfo.paddingBottom;;
  if(vbFill) {
    poControl.width = vnWidth;
    poControl.isResize = true;
  }
  if(vbFill) {
    poControl.height = vnHeight;
    poControl.isResize = true;
  }
};

/**
 * 포함된 하위 컨트롤의 실체화 객체를 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {String} psIdSuffix 실체화된 컨트롤 id에 따라붙을 문자열
 * @private
 */
eXria.controls.xhtml.TableLayout.prototype.createChildren = function(poDocument, psIdSuffix) {
  if(poDocument == null) poDocument = this.document;
  if(psIdSuffix == null && this.idSuffix) psIdSuffix = this.idSuffix;
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vsId = null;
  var voTable = this.subElement.table;
  var voCell = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    this.setLeftTop(voControl);
//    this.setIndex(voControl);
    vsId = voControl.id;
    if(psIdSuffix != null) voControl.id += psIdSuffix;
    if(voControl.canvas == null) {
      voControl.canvas = this.canvas;
      voControl.window = this.window;
      voControl.document = this.document;

      this.resizeChild(voControl);
      this.canvas.registerControl(voControl);
    }
    if(voControl.toString() != "Timer") {
      this.appendChild(voControl.create(poDocument), poDocument);
      voControl.load(this.document);
    }
    voControl.id = vsId;
  }
};
/**
 * 윈도우에 리사이즈 이벤트 발생시 TableLayout 컨트롤의 사이즈를 자동조정
 * @param {HTMLElement} poCtrl 넓이와 높이 사이즈가 변경될 TableLayout 컨트롤의 배열
 */
eXria.controls.xhtml.TableLayout.prototype.resizeTable = function(pnWidth, pnHeight, poCtl) {
  page.mnWidth = page.window.document.documentElement.clientWidth;
  page.mnHeight = page.window.document.documentElement.clientHeight;
  var vsResizeEventCnt = "resizeEventCnt_" + page.id;

  if(poCtl == null) poCtl = this.ctrl.control;

  if(pnWidth != null) poCtl.applyAttr("width", pnWidth);
  if(pnHeight != null) poCtl.applyAttr("height", pnHeight);
  if(pnWidth != null || pnHeight != null) poCtl.resizeChildren(poCtl.controls);

  var voFunc = function() {
    page [vsResizeEventCnt] = 0;
    var vnHGap = page.window.document.documentElement.clientWidth - page.mnWidth;
    var vnVGap = page.window.document.documentElement.clientHeight - page.mnHeight;
    page.mnWidth = page.window.document.documentElement.clientWidth;
    page.mnHeight = page.window.document.documentElement.clientHeight;

    var vbResizeChildren = false;
    if((poCtl.width > poCtl.minWidth || vnHGap > 0) && (poCtl.width < poCtl.maxWidth || vnHGap < 0)) {
      vbResizeChildren = true;
      poCtl.applyAttr("width", poCtl.width + vnHGap);
    }
    if((poCtl.height > poCtl.minHeight || vnVGap > 0) && (poCtl.height < poCtl.maxHeight || vnVGap < 0)) {
      vbResizeChildren = true;
      poCtl.applyAttr("height", poCtl.height + vnVGap);
    }
    if(vbResizeChildren) poCtl.resizeChildren(poCtl.controls);
  };

  if (page [vsResizeEventCnt] == null) page [vsResizeEventCnt] = 0;
  if (page.window.onresize == null) {
    page.window.onresize = function(poEvent) {
      page [vsResizeEventCnt]++;

      var voCaller = arguments.caller;
      if (!!voCaller) return false;

      if (page [vsResizeEventCnt] == 1) {
        setTimeout(voFunc, 100);
      }
    };

  }
};

eXria.controls.xhtml.TableLayout.prototype.setLeftTop = function(poControl) {
  this.ctrlPositionMap[poControl.id + "_left"] = poControl.left;
  this.ctrlPositionMap[poControl.id + "_top"] = poControl.top;
};

eXria.controls.xhtml.TableLayout.prototype.getLeftTop = function(poControl) {
  var voPositionMap = {};
  voPositionMap["left"] = this.ctrlPositionMap[poControl.id + "_left"];
  voPositionMap["top"] = this.ctrlPositionMap[poControl.id + "_top"];
  return voPositionMap;
};

eXria.controls.xhtml.TableLayout.prototype.setIndex = function(poControl) {
  var vnCellSpacing = this.cellSpacing;
  var vnRowCnt = this.rowCnt;
  var vnColCnt = this.colCnt;
  if(this.maIdx == null) this.maIdx = [];
  var vaIdx = this.maIdx;
  var voDistMap = {};
  var vfDist = null;
  var vaColWidth = this.maColWidth;
  var vaRowHeight = this.maRowHeight;
  var voRowInfo = null;
  var voCellInfo = null;
  var vnTop = 0;
  var vnLeft;
  for(var i = 0; i < vnRowCnt; i++) {
    if(vaIdx[i] == null) vaIdx[i] = [];
    vnTop += vnCellSpacing + (i > 0 ? vaRowHeight[i - 1] : 0);
    vnLeft = 0;
    voRowInfo = this.getRowInfo(i);
    for(var j = 0; j < vnColCnt; j++) {
      voCellInfo = voRowInfo.getCellInfo(j);
      if(voCellInfo.rowSpan == 0 || voCellInfo.colSpan == 0) continue;
      vnLeft += vnCellSpacing + ( j > 0 ? vaColWidth[j - 1] : 0);
      if(vaIdx[i][j] != null) continue;
      vfDist = Math.sqrt(Math.pow(poControl.left - vnLeft, 2) + Math.pow(poControl.top - vnTop, 2));
      if(vaIdx[i][j] == null && voDistMap[vfDist + ""] == null) voDistMap[vfDist + ""] = i + "," + j;
    }
  }
  var vaDist = [];
  for(var vsDist in voDistMap) {
    vaDist.push(eval(vsDist));
  }
  vaDist.sort(function(a,b){return a-b});
  var vsIdx = voDistMap[vaDist[0] + ""];
  vsIdx = vsIdx.split(",");
  vnRowNum = eval(vsIdx[0]);
  vnColNum = eval(vsIdx[1]);
  vaIdx[vnRowNum][vnColNum] = poControl;
  poControl.rowNum = eval(vnRowNum);
  poControl.colNum = eval(vnColNum);
};

eXria.controls.xhtml.TableLayout.prototype.setPositions = function() {
  var voColPosMap = {};
  var voRowPosMap = {};
  var voCollection = this.controls;
  var vnCnt = voCollection.size();
  var voCtl = null;  
  for(var i = 0; i < vnCnt; i++) {
    voCtl = voCollection.get(i);
    voColPosMap[voCtl.colNum + ""] = "";
    voRowPosMap[voCtl.rowNum + ""] = "";
  }
  
  var vaRowPos = [];
  var vaColPos = [];
  for(var vsCol in voColPosMap) {
    vaColPos.push(eval(vsCol));
  }
  for(var vsRow in voRowPosMap) {
    vaRowPos.push(eval(vsRow));
  }
  
  var voSortFunc = function(a,b){return a-b};
  vaColPos.sort(voSortFunc);
  vaRowPos.sort(voSortFunc);
  
  vnCnt = voCollection.size();
  var vnCntJ = vaColPos.length;
  var vnCntK = vaRowPos.length;
  this.colCnt = vnCntJ;
  this.rowCnt = vnCntK;
  var vnColSpan, vnRowSpan;
  var voRowInfo = null;
  var voCellInfo = null;

  for(var i = 0; i < vnCnt; i++) {
    voCtl = voCollection.get(i);
    voRowInfo = this.getRowInfo(voCtl.rowNum);
    voCellInfo = voRowInfo.getCellInfo(voCtl.colNum);
    vnColSpan = 1;
    for(var j = voCtl.colNum + 1; j < vnCntJ; j++) {
      if(voCtl.left + voCtl.width > vaColPos[j]) vnColSpan++;
      else break;
    }
    if(vnColSpan > 1) voCellInfo.colSpan = vnColSpan;
    vnRowSpan = 1;
    for(var k = voCtl.rowNum + 1; k < vnCntK; k++) {
      if(voCtl.top + voCtl.height > vaRowPos[k]) vnRowSpan++;
      else break;
    }
    if(vnRowSpan > 1) voCellInfo.rowSpan = vnRowSpan;
  }
  for(var i = vnCnt - 1; i >= 0; i--) {
    voCtl = voCollection.get(i);
    if(voCtl.value == "@") voCollection.remove(i);
  }
};

eXria.controls.xhtml.TableLayout.prototype.getRowInfo = function(pnRow) {
  var vsId = "" + pnRow;
  var voRowInfo = this.rowsInfo[vsId];
  if(voRowInfo == null) {
    voRowInfo = new eXria.controls.xhtml.TableLayout_rowInfo(pnRow);
    this.rowsInfo[vsId] = voRowInfo;
  }
  return voRowInfo;
};
/**
 * 클래스 명을 반환합니다.
 * @return "TableLayout"
 * @type String
 */
eXria.controls.xhtml.TableLayout.prototype.toString = function() {
  return "TableLayout";
};

eXria.controls.xhtml.TableLayout_rowInfo = function(pnRow) {
  this.rowNum = pnRow;
};

eXria.controls.xhtml.TableLayout_rowInfo.prototype.setCellInfo = function(pnCol, poControl) {
  var vsId = "" + pnCol;
  var voCellInfo = this[vsId];
  if(voCellInfo == null) {
    voCellInfo = {};
    voCellInfo.ctrlLeft = poControl.left;
    voCellInfo.ctrlTop = poControl.top;
    voCellInfo.ctrlHeight = poControl.height;
    voCellInfo.ctrlWidth = poControl.width;
    this[vsId] = voCellInfo;
  }
};

eXria.controls.xhtml.TableLayout_rowInfo.prototype.getCellInfo = function(pnCol) {
  var vsId = "" + pnCol;
  var voCellInfo = this[vsId];
  if(voCellInfo == null) {
    voCellInfo = {};
    voCellInfo.rowNum = this.rowNum;
    voCellInfo.colNum = pnCol;
    voCellInfo.rowIdx = this.rowNum;
    voCellInfo.colIdx = pnCol;
//    voCellInfo.ctrlLeft = pnCol;
//    voCellInfo.ctrlTop = pnCol;
//    voCellInfo.ctrlHeight = pnCol;
//    voCellInfo.ctrlWidth = pnCol;
    this[vsId] = voCellInfo;
  }
  return voCellInfo;
};