/**
 * @fileoverview
 * canvas를 통해 컨트롤을 생성 시 사용되는 컨트롤 타입 값을 정의한 오브젝트
 * @author 조동일
 * @version 2.0
 */

/**
 * eXria.controls.xhtml.ControlTypeProvider Object
 */
eXria.controls.xhtml.ControlTypeProvider = {
  /**
   * 컨트롤 타입 별 컨트롤 full class name 반환
   * @param {String} psType 컨트롤 타입<br>
   * slidetab : 슬라이드탭 컨트롤<br>
   * button : 버튼 컨트롤<br>
   * combo : 콤보박스 컨트롤<br>
   * listbox : 리스트박스 컨트롤<br>
   * label : 레이블 컨트롤<br>
   * calendar : 달력 컨트롤<br>
   * input : 입력 컨트롤<br>
   * object : 플래시 등 ActiveX 로딩용 오브젝트 컨트롤<br>
   * output : 결과출력용 ouput 컨트롤<br>
   * secret : 비밀번호 등 암호입력 컨트롤<br>
   * progress : 진행바 표시 컨트롤<br>
   * textarea : 줄바꿈이 가능한 입력 컨트롤<br>
   * dateinput : 날짜입력 컨트롤<br>
   * treeview : 트리뷰 컨트롤<br>
   * image : 이미지 컨트롤<br>
   * tab : 탭 컨트롤<br>
   * editmask : 입력마스크 컨트롤<br>
   * group : 여러 컨트롤을 하위관계로 포함시키는 그룹 컨트롤<br>
   * mdigroup : 여러 창으로 작업할 수 있는 컨트롤<br>
   * time : 시간 컨트롤<br>
   * check : 체크박스 컨트롤<br>
   * radio : 라디오 버튼 컨트롤<br>
   * freeform : 프리폼(그룹 컨트롤에 데이타 연동기능 제공) 컨트롤<br>
   * line : 선 도형 컨트롤<br>
   * rectangle : 사각형 도형 컨트롤<br>
   * roundrect : 둥근모서리 사각형 도형 컨트롤<br>
   * ellipse : 타원 도형 컨트롤<br>
   * import : 다른 페이지 화면을 현재 화면에 하나에 윈도우로 결합하여 보여주기 위한 컨트롤<br>
   * subpage : 다른 페이지 화면을 현재 화면에 결합하여(두개의 윈도우로 존재) 보여주기 위한 컨트롤<br>
   * htmlsnippet : 매쉬업 컨텐츠를 로딩하기 위한 컨트롤<br>
   * gridex : 그리드 컨트롤<br>
   * contextmenu : 우측 팝업 메뉴 컨트롤<br>
   * fileselector : 파일 선택 컨트롤<br>
   * htmleditor : html 편집기 컨트롤<br>
   * @return 컨트롤 생성 시 이용될 컨트롤의 full class name
   * @type Class
   */
  get : function(psType) {
    switch(psType) {
      case "slidetab" :
      return eXria.controls.xhtml.SlideTab;
      case "button" :
      return eXria.controls.xhtml.Button;
      case "combo" :
      return eXria.controls.xhtml.ComboBox;
      case "listbox" :
      return eXria.controls.xhtml.ListBox;
      case "label" :
      return eXria.controls.xhtml.Label;
      case "calendar" :
      return eXria.controls.xhtml.Calendar;
      case "input" :
      return eXria.controls.xhtml.InputBox;
      case "object" :
      return eXria.controls.xhtml.Object;
      case "output" :
      return eXria.controls.xhtml.Output;
      case "secret" :
      return eXria.controls.xhtml.SecretBox;
      case "progress":
      return eXria.controls.xhtml.Progress;
      case "textarea":
      return eXria.controls.xhtml.TextArea;
      case "dateinput" :
      return eXria.controls.xhtml.DateInput;
      case "treeview" :
      return eXria.controls.xhtml.TreeView;
      case "image" :
      return eXria.controls.xhtml.Image;
      case "tab" :
      return eXria.controls.xhtml.Tab;
      case "editmask" :
      return eXria.controls.xhtml.EditMask;
      case "group" :
      return eXria.controls.xhtml.Group;
      case "mdigroup" :
      return eXria.controls.xhtml.MDIGroup;
      case "tablelayout" :
      return eXria.controls.xhtml.TableLayout;
      case "time" :
      return eXria.controls.xhtml.Timer;
      case "check" :
      return eXria.controls.xhtml.CheckBox;
      case "radio" :
      return eXria.controls.xhtml.RadioButton;
      case "freeform" :
      return eXria.controls.xhtml.FreeForm;
      case "line" :
      return eXria.controls.xhtml.Line;
      case "rectangle" :
      return eXria.controls.xhtml.Rectangle;
      case "roundrect" :
      return eXria.controls.xhtml.Roundrect;
      case "ellipse" :
      return eXria.controls.xhtml.Ellipse;
      case "import" :
      return eXria.controls.xhtml.Import;
      case "subpage" :
      return eXria.controls.xhtml.SubPage;
      case "htmlsnippet" :
      return eXria.controls.xhtml.HtmlSnippet;
//      case "grid" :
//      return eXria.controls.xhtml.Grid;
      case "gridex" :
      return eXria.controls.xhtml.GridEx;
      case "contextmenu" :
      return eXria.controls.xhtml.ContextMenu;
      case "fileselector" :
      return eXria.controls.xhtml.FileSelector;
      case "htmleditor" :
      return eXria.controls.xhtml.HtmlEditor;
    }
  }
};



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of import Const6.js
var BOpera9 = navigator.appName.search("Opera")>=0;
var BOpera8 = BOpera9 ? 0 : navigator.userAgent.search("Opera")>=0;
var BOperaVer = parseFloat(navigator.appVersion);
var BSafariMac = navigator.userAgent.search("Safari")>=0;
var BSafariWin = BSafariMac && navigator.userAgent.search("Windows")>=0;
var BSafari = navigator.userAgent.search("KHTML")>=0;
var BSafariVer = BSafari?parseFloat(navigator.userAgent.match(/(?:KHTML\D*|VERSION\D*)(\d[\d\.]+)/i)[1]):0;
var BKonqueror = BSafari && !BSafariMac && !BSafariWin;
var BChrome = BSafari && navigator.userAgent.search("Chrome")>=0;
var BMozilla = navigator.appName.search("Netscape")>=0 && !BOpera8 && !BSafari;
var BStrict = document.compatMode=="CSS1Compat";
var BIEA = navigator.appName.search("Microsoft")>=0 && !BOpera8;

var BIE = BIEA && !BStrict;
var BIEStrict = BIEA && !BIE;

var BIE5 = BIE && navigator.appVersion.search("MSIE 5")>=0;
var BIEA6 = BIEA && navigator.appVersion.search("MSIE 6")>=0 || BIE5;

var BIEA8 = BIEA && document.documentMode==8;
var BIE8Strict = BIEA8 && BIEStrict;
if(BIEA6) try { document.execCommand("BackgroundImageCache", false, true); } catch(e) { }

var BNN = navigator.userAgent.search("Netscape")>=0;
var BFF1 = BMozilla && navigator.userAgent.search("Firefox/1.")>=0;
var BFF15 = BMozilla && navigator.userAgent.search("Firefox/1.5")>=0;
var BFF3 = BMozilla && navigator.userAgent.search("Firefox/3.")>=0;
var BFF35 = BMozilla && navigator.userAgent.search("Firefox/3.5")>=0;

if(BIE5) undefined=null;
//-----------------------------------------------------------------------------------------------------------
var CScrollWidth = 0, CScrollHeight = 0;
var CCursorPointer = BIE5 ? "cursor:hand;" : "cursor:pointer;";
//-----------------------------------------------------------------------------------------------------------
try { if(BIEA6) document.execCommand("BackgroundImageCache", false, true); } catch(e) {}
//////////////////////////////////////////////////////////////////////////////////////////
//end of import Const6.js


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of import Format6.js
var PFormat = {

EmptyNumber : null,
EmptyDate : "",

ValueSeparator : ";",
RangeSeparator : "~",
ValueSeparatorHtml : " <b style='color:red;'>;</b> ",
RangeSeparatorHtml : " <b style='color:red;'>~</b> ",

LongDayNames : "Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday".split(","),
ShortDayNames : "Sun,Mon,Tue,Wed,Thu,Fri,Sat".split(","),
Day2CharNames : "Su,Mo,Tu,We,Th,Fr,Sa".split(","),
Day1CharNames : "S,M,T,W,T,F,S".split(","),
LongMonthNames : "January,February,March,April,May,June,July,August,September,October,November,December".split(","),
LongMonthNames2 : "January,February,March,April,May,June,July,August,September,October,November,December".split(","),
ShortMonthNames : "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec".split(","),
DayNumbers : "1st,2nd,3rd,4th,5th,6th,7th,8th,9th,10th,11th,12th,13th,14th,15th,16th,17th,18th,19th,20th,21st,22nd,23rd,24th,25th,26th,27th,28th,29th,30th,31st".split(","),
Quarters : "I,II,III,IV".split(","),
Halves : "I,II".split(","),
DateSeparator : "/",
InputDateSeparators : "/.-",
TimeSeparator : ":",
InputTimeSeparators : ":",
AMDesignator : "AM",
PMDesignator : "PM",
FirstWeekDay : 0,
NaD : "NaN",
GMT : 0,
Hirji : 0,

DecimalSeparator : ".",
InputDecimalSeparators : ".,",
GroupSeparator : ",",
InputGroupSeparators : ",",
Percent : "%",
NaN : "NaN",

d : "M/d/yyyy",
D : "d. MMMM yyyy",
t : "H:mm",
T : "H:mm:ss",
f : "d. MMMM yyyy H:mm",
F : "d. MMMM yyyy H:mm:ss",
g : "M/d/yyyy H:mm",
G : "M/d/yyyy H:mm:ss",
m : "d. MMMM",
M : "d. MMMM",
s : "yyyy-MM-ddTHH:mm:ss",
u : "yyyy-MM-dd HH:mm:ssZ",

U : "d. MMMM yyyy HH:mm:ss",
r : "ddd MMM d HH:mm:ss UTCzzzzz yyyy",
R : "ddd MMM d HH:mm:ss UTCzzzzz yyyy",
y : "MMMMMMM yyyy",
Y : "MMMMMMM yyyy",

ng : "0.######",
nf : "0.00",
nc : "$###########0.00",
np : "0.00%",
nr : "0.0000",
ne : "0.000000 E+000"
}

PFormat.CNumberMinMax = ["",/\D*0$/,/\D*0{1,2}$/,/\D*0{1,3}$/,/\D*0{1,4}$/,/\D*0{1,5}$/,/\D*0{1,6}$/,/\D*0{1,7}$/,/\D*0{1,8}$/,/\D*0{1,9}$/,/\D*0{1,10}$/,/\D*0{1,11}$/,/\D*0{1,12}$/,/\D*0{1,13}$/,/\D*0{1,14}$/,/\D*0{1,15}$/,/\D*0{1,16}$/,/\D*0{1,17}$/,/\D*0{1,18}$/,/\D*0{1,19}$/,/\D*0{1,20}$/];
PFormat.CEmptyString = ["","0","00","000","0000","00000","000000","0000000","00000000","000000000","0000000000","00000000000"];
PFormat.CNumberSep = ["",/.{1,1}$/,/.{2,2}$/,/.{3,3}$/,/.{4,4}$/,/.{5,5}$/,/.{6,6}$/,/.{7,7}$/,/.{8,8}$/,/.{9,9}$/,/.{10,10}$/,/.{11,11}$/,/.{12,12}$/,/.{13,13}$/,/.{14,14}$/,/.{15,15}$/,/.{16,16}$/,/.{17,17}$/,/.{18,18}$/,/.{19,19}$/,/.{20,20}$/];

PFormat.CDateFormatEng = /\D*(\d{1,4})?\s*([\-\/\.])?\s*(\d{1,2})?\s*([\-\/\.])?\s*(\d{1,4})?[^\d\:\.]*(\d{1,2})?\s*[\:\.]?\s*(\d{1,2})?\s*[\:\.]?\s*(\d{1,2})?\s*([apAP]\.?[Mm]?\.?)?\D*/;
PFormat.CActualYear = (new Date()).getUTCFullYear();
PFormat.CActualMonth = (new Date()).getUTCMonth();
PFormat.CActualDay = (new Date()).getUTCDate();

PFormat.CDateFormat = /\W*(\d{1,4})?([a-zA-Z]+)?\s*([\-\/\.\,])?\s*(\d{1,4})?([a-zA-Z]+)?\s*([\-\/\.\,])?\s*(\d{1,4})?([a-zA-Z]+)?[^\d\:\.aApP]*(\d{1,2})?\s*([\:\.])?\s*(\d{1,2})?\s*([\:\.])?\s*(\d{1,2})?\s*([apAP]\.?[Mm]?\.?)?\W*/;

PFormat.CSearchEscape1 = /[\&\<]/;
PFormat.CSearchEscape2 = /[\&\<\n]/;
PFormat.CSearchEscape3 = /[\&\<\"\']/;
PFormat.CReplaceWhite = new RegExp(BIE5?"^ | $|  ":"^ | $| (?= )","g");
PFormat.CReplaceCR = /\n/g;
PFormat.CReplaceAmp = /\&/g;
PFormat.CReplaceLt = /\</g;
PFormat.CReplaceApos = /\'/g;
PFormat.CReplaceQuot = /\"/g;

PFormat.Parsed = {};

var TFormat = function(){ };
TFormat.prototype = PFormat;
Formats = new TFormat();

//---------------------------------------------------------------------------------------------------------------------------
PFormat.NumberToString = function(num,ff,range){

if(!ff) {
if(num-0 || num===0) return num+"";
return isFinite(num) ? "" : this.NaN;
}
var f = this.Parsed[ff];
if(!f){ f = this.ParseNumberFormat(ff); if(!f) return "Bad format"; }
if(!(num-0)) {
if(num=="0") return f.Zero;
return isFinite(num) ? f.Empty : f.NaN;
}
var neg = 0, exp="";
if(num<0){
num = -num;
neg = 1;
}
if(f.Exp){
var e = f.Exp;
if(num<=e.Min || num>=e.Max){
   exp = Math.floor(Math.log(num)*Math.LOG10E);
   if(e.Sub) exp-=e.Sub;
   num /= Math.pow(10,exp);
   var eneg = 0;
   if(exp<0){ eneg = 1; exp = -exp; }
   exp+="";
   if(e.Dig){
      var len = e.Dig-exp.length;
      if(len==1) exp = "0"+exp;
      else if(len==2) exp = "00"+exp;
      }
   if(eneg) exp = e.NegPrefix+exp+e.NegPostfix;
   else exp = e.Prefix+exp+e.Postfix;
   }
}
num = Math.round(num*f.Div);
if(num<1e21) num+="";
else {
var s = "";
while(num>=1e21){ s+="000"; num/=1000; }
num += s;
}
if(f.Dig){
var len = f.Max+f.Dig-num.length;
if(len>0) num = (len==1 ? "0" : this.CEmptyString[len]) + num;
}
if(f.Group){
var len = num.length - f.Max;
if(len>3){
   if(len<7) num = num.slice(0,len-3) + f.Group + num.slice(len-3);
   else if(len<10) num = num.slice(0,len-6) + f.Group + num.slice(len-6,len-3) + f.Group + num.slice(len-3);
   else {
      var s = num.slice(len-3,len+f.Max); len-=3;
      while(len>3){ s = num.slice(len-3,len) + f.Group + s; len -= 3; }
      num = (len ? num.slice(0,len)+f.Group : "")+s;
      }
   }
}
if(f.Max){
if(BIE5){
   var cnt = num.length-f.Max, d = num.slice(cnt);
   if(f.Max!=f.Min) d = d.replace(this.CNumberMinMax[f.Max-f.Min],"");
   if(d) num = num.slice(0,cnt) + f.Sep + d;
   else num = num.slice(0,cnt);
   }
else {
   num = num.replace(this.CNumberSep[f.Max],f.Sep+"$&");
   if(f.Max!=f.Min) num = num.replace(this.CNumberMinMax[f.Max-f.Min],"");
   }
}
if(neg) return f.NegPrefix + num + exp + f.NegPostfix;
return f.Prefix + num + exp + f.Postfix;
}
//---------------------------------------------------------------------------------------------------------------------------
PFormat.ParseNumberFormat = function(f,neg){
if(!f) return null;
if(f.length==1){
switch(f){
   case 'g' : f = this.ng; break;
   case 'f' : f = this.nf; break;
   case 'c' : f = this.nc; break;
   case 'p' : f = this.np; break;
   case 'r' : f = this.nr; break;
   case 'e' : f = this.ne; break;
   }
}

var F = {Dig:0,Min:0,Max:0,Div:1,Sep:"",Group:"",Prefix:"",Postfix:""};

var g = 0, pp = "", t = 0;
for(var i=0;i<f.length;i++){
var c = f.charAt(i);
if(c=='0' || c=='#'){
   if(g){ F.Group = this.GroupSeparator; g = 0; }
   if(t==0){ t=1; F.Prefix = pp; pp = ""; }
   if(t==2){ t=3; F.Sep = pp; pp = ""; }
   }
if(c=='"' || c=="'"){
   for(i++;i<f.length && f.charAt(i)!=c;i++) pp += f.charAt(i);
   }
else if(c=='\\'){
   i++;
   pp += f.charAt(i);
   }
else if(c=='0'){
   if(t==1) F.Dig++;
   if(t==3){ F.Min++;F.Max++; }
   if(t==5) F.Exp.Dig++;
   }
else if(c=='#'){
   if(t==3){ F.Max++; }
   if(t==5) F.Exp.Dig++;
   }
else if(c=='.'){
   if(t==0){ t=1; F.Prefix = pp; pp = ""; }
   if(t<2) t = 2;
   pp += this.DecimalSeparator;
   if(g) { F.Div/=Math.pow(1000,g); g = 0; }
   }
else if(c==','){
   if(t<2) g++;
   }
else if(c=='%'){
   pp += this.Percent;
   F.Div*=100;
   }
else if(c==';'){
   var ff = f.slice(i+1);
   if(!ff) F.Zero = "";
   else {
      var N = this.ParseNumberFormat(ff,1);
      if(N){
         if(neg){
            F.Zero = N.Prefix + this.CEmptyString[N.Dig] + N.Sep + this.CEmptyString[N.Min] + N.Postfix;
            }
         else {
            F.NegPrefix = N.Prefix; F.NegPostfix = N.Postfix; F.Zero = N.Zero;
            }
         }
      }
   break;
   }
else if((c=='e' || c=='E') && pp==0){
   var e = new Object();
   F.Exp = e;
   e.Dig = 0;
   e.Min = 1; e.Max = 1;
   e.Sub = F.Dig-1; if(e.Sub<0) e.Sub = 0;
   c = pp + c; pp = "";
   e.Prefix = c; e.NegPrefix = c+"-";
   e.Postfix = ""; e.NegPostfix = "";
   var sig = f.charAt(i+1);
   if(sig=='-') i++;
   else if(sig=='+'){ e.Prefix+='+'; i++; }
   t = 5;
   }
else pp += c;
}
F.Postfix = pp;
F.Div *= Math.pow(10,F.Max);
if(F.NegPrefix==null) F.NegPrefix = F.Prefix+"-";
if(F.NegPostfix==null) F.NegPostfix = F.Postfix;
if(F.Zero==null){
if(F.Exp) F.Zero = F.Prefix + this.CEmptyString[F.Dig] + (F.Dig||F.Min?F.Sep:"0") + this.CEmptyString[F.Min] + F.Exp.Prefix + this.CEmptyString[F.Exp.Dig] + F.Exp.Postfix + F.Postfix;
else F.Zero = F.Prefix + this.CEmptyString[F.Dig] + (F.Dig||F.Min?F.Sep:"0") + this.CEmptyString[F.Min] + F.Postfix;
}
F.NaN = this.NaN;
this.Parsed[f] = F;
F.Empty = this.EmptyNumber==null?this.NumberToString(0,f):this.EmptyNumber;
return F;
}
//-----------------------------------------------------------------------------------------------------------
//Converts number to string, ignores format. Its possible to read hexadecimal numbers with 'x' preffix.
PFormat.StringToNumber = function(str,f,range){
if(!str) return this.EmptyNumber!=null ? "" : 0;
if(str==this.EmptyNumber) return "";
if(str-0+""==str) return str-0;

if(!str.replace) return parseFloat(str);
var gs = this.InputGroupSeparators; if(gs) gs = "\\"+gs.split('').join('\\');
str = str.replace(new RegExp("[\\s"+gs+"]","g"),"").replace(new RegExp("[\\"+this.InputDecimalSeparators.split('').join('\\')+"]","g"),".");
if(str.search(/[xe]/i)>=0){
if(str.charAt(0).toLowerCase()=="x") str="0"+str;
try { return eval(str); }
catch(e){ return 0; }
}
return parseFloat(str);
}
PFormat.DateToStringEng = function(num,pnGmt){
if(num==null||num==="") return "";
if(typeof(num)!="object") num = new Date(num-0+""==num?num-0:num);
if(!isFinite(num)) return this.NaD;
var vnGmt = this.GMT;
if(pnGmt != null) vnGmt = pnGmt;
if(vnGmt-0) {
var d = num.getUTCDate(), M = num.getUTCMonth()+1, y = num.getUTCFullYear();
var h = num.getUTCHours(), m = num.getUTCMinutes(), s = num.getUTCSeconds();
}
else {
var d = num.getDate(), M = num.getMonth()+1, y = num.getFullYear();
var h = num.getHours(), m = num.getMinutes(), s = num.getSeconds();
}
var S = "";
if(d!=1 || M!=1 || y!=1970) S = (M<10?"0":"")+M+"/"+(d<10?"0":"")+d+"/"+y;
if(h||m||s) S += (S?" ":"")+(h<10?"0":"")+h+":"+(m<10?"0":"")+m+(s?":"+(s<10?"0":"")+s:"");
return S;
}
//---------------------------------------------------------------------------------------------------------------------------
PFormat.DateToString = function(num,ff,range,pnGmt){

if(!ff) return this.DateToStringEng(num,pnGmt);
var f = this.Parsed[ff];
if(!f){
f = this.ParseDateFormat(ff,pnGmt);
if(!f) return "Bad format";
this.Parsed[ff] = f;
}
if(num==null || num==="") return f[3];
if(typeof(num)!="object") num = new Date(num-0+""==num?num-0:num);
if(!isFinite(num)) return f[4];
var len = f.length, s = f[10], n;

if(f[2]=="0") for(var i=11;i<len;i+=2){
switch(f[i]){
   case 1: s += num.getUTCDate(); break;
   case 2: n = num.getUTCDate(); s += n<10?"0"+n:n; break;
   case 3: s += f[6][num.getUTCDay()]; break;
   case 6: s += f[7][num.getUTCDate()-1]; break;
   case 7:
      var ddd = new Date(num.getUTCFullYear(),0,1);
      s += Math.ceil((((num - ddd) / 86400000) + ddd.getUTCDay())/7);
      break;
   case 11: s += num.getUTCMonth()+1; break;
   case 12: n = num.getUTCMonth()+1; s += n<10?"0"+n:n; break;
   case 13: s += f[5][num.getUTCMonth()]; break;
   case 15: s += f[5][Math.floor(num.getUTCMonth()/3)]; break;
   case 16: s += f[5][Math.floor(num.getUTCMonth()/6)]; break;
   case 21: s += num.getUTCFullYear()%100; break;
   case 22: n = num.getUTCFullYear()%100; s += n<10?"0"+n:n; break;
   case 24: s += num.getUTCFullYear(); break;
   case 41 : s += num.getUTCHours()%12; break;
   case 42 : n = num.getUTCHours()%12; s += n<10?"0"+n:n; break;
   case 51 : s += num.getUTCHours(); break;
   case 52 : n = num.getUTCHours(); s += n<10?"0"+n:n; break;
   case 61 : s += num.getUTCMinutes(); break;
   case 62 : n = num.getUTCMinutes(); s += n<10?"0"+n:n; break;
   case 71 : s += num.getUTCSeconds(); break;
   case 72 : n = num.getUTCSeconds(); s += n<10?"0"+n:n; break;
   case 81 : s += num.getUTCHours()<12?f[8]:f[9]; break;
   default:
      n = -num.getTimezoneOffset();
       if(n<0){ s+="-"; n=-n; } else s+="+";
       s += (n<600&&f[i]==92||f[i]==94||f[i]==95 ? "0":"") + Math.round(n/60);
       if(f[i]>=93){ n = n%60; s += (f[i]==95?"":":") + (n<10?"0":"") + n; }
      break;
   }
s+=f[i+1];
}

else if(!f[2]) for(var i=11;i<len;i+=2){
switch(f[i]){
   case 1: s += num.getDate(); break;
   case 2: n = num.getDate(); s += n<10?"0"+n:n; break;
   case 3: s += f[6][num.getDay()]; break;
   case 6: s += f[7][num.getDate()-1]; break;
   case 7:
      var ddd = new Date(num.getFullYear(),0,1);
      s += Math.ceil((((num - ddd) / 86400000) + ddd.getDay())/7);
      break;
   case 11: s += num.getMonth()+1; break;
   case 12: n = num.getMonth()+1; s += n<10?"0"+n:n; break;
   case 13: s += f[5][num.getMonth()]; break;
   case 15: s += f[5][Math.floor(num.getMonth()/3)]; break;
   case 16: s += f[5][Math.floor(num.getMonth()/6)]; break;
   case 21: s += num.getFullYear()%100; break;
   case 22: n = num.getFullYear()%100; s += n<10?"0"+n:n; break;
   case 24: s += num.getFullYear(); break;
   case 41 : s += num.getHours()%12; break;
   case 42 : n = num.getHours()%12; s += n<10?"0"+n:n; break;
   case 51 : s += num.getHours(); break;
   case 52 : n = num.getHours(); s += n<10?"0"+n:n; break;
   case 61 : s += num.getMinutes(); break;
   case 62 : n = num.getMinutes(); s += n<10?"0"+n:n; break;
   case 71 : s += num.getSeconds(); break;
   case 72 : n = num.getSeconds(); s += n<10?"0"+n:n; break;
   case 81 : s += num.getHours()<12?f[8]:f[9]; break;
   default:
      n = -num.getTimezoneOffset();
       if(n<0){ s+="-"; n=-n; } else s+="+";
       s += (n<600&&f[i]==92||f[i]==94||f[i]==95 ? "0":"") + Math.round(n/60);
       if(f[i]>=93){ n = n%60; s += (f[i]==95?"":":") + (n<10?"0":"") + n; }
      break;
   }
s+=f[i+1];
}
return s;
}

PFormat.ParseDateFormat = function(f,pnGmt){
if(!f) return null;
var vnGmt = this.GMT;
if(pnGmt != null) vnGmt = pnGmt;
var F = [null,null,vnGmt-0?0:null,this.EmptyDate?this.EmptyDate:"",this.NaD];
if(f.length==1){
if(f=='U') F[2] = 0;
if(f=='R' || f=='r') F[2] = null;
if(this[f]) f = this[f];
}

var p = 10, out = "";
for(var i=0;i<f.length;i++){
switch(f.charAt(i)){
   case '%' : break;
   case '/' : out+=this.DateSeparator; break;
   case ':' : out+=this.TimeSeparator; break;
   case 'd' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='d'){ F[p++]=1; break; }
      i++; if(f.charAt(i+1)!='d'){ F[p++]=2; break; }
      i++; if(f.charAt(i+1)!='d'){ F[p++]=3; F[6] = this.ShortDayNames; break; }
      i++; if(f.charAt(i+1)!='d'){ F[p++]=3; F[6] = this.LongDayNames;  break; }
      i++; if(f.charAt(i+1)!='d'){ F[p++]=3; F[6] = this.Day1CharNames;  break; }
      i++; if(f.charAt(i+1)!='d'){ F[p++]=6; F[7] = this.DayNumbers; break; }
      i++; if(f.charAt(i+1)!='d'){ F[p++]=7; break; }
      F[p++] = ""; break;
   case 'M' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='M'){ F[p++] = 11; break; }
      i++; if(f.charAt(i+1)!='M'){ F[p++] = 12; break; }
      i++; if(f.charAt(i+1)!='M'){ F[p++] = 13; F[5] = this.ShortMonthNames; break; }
      i++; if(f.charAt(i+1)!='M'){ F[p++] = 13; F[5] = this.LongMonthNames; break; }
      i++; if(f.charAt(i+1)!='M'){ F[p++] = 15; F[5] = this.Quarters; break; }
      i++; if(f.charAt(i+1)!='M'){ F[p++] = 16; F[5] = this.Halves; break; }
      i++; if(f.charAt(i+1)!='M'){ F[p++] = 13; F[5] = this.LongMonthNames2; break; }
      F[p++] = ""; break;
   case 'y' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='y'){ F[p++] = 21; break; }
      i++; if(f.charAt(i+1)!='y'){ F[p++] = 22; break; }
      i++; if(f.charAt(i+1)!='y'){ F[p++] = "";  break; }
      i++; if(f.charAt(i+1)!='y'){ F[p++] = 24; break; }
      F[p++] = ""; break;
   case 'h' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='h'){ F[p++] = 41; break; }
      i++; if(f.charAt(i+1)!='h'){ F[p++] = 42; break; }
      F[p++] = ""; break;
   case 'H' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='H'){ F[p++] = 51; break; }
      i++; if(f.charAt(i+1)!='H'){ F[p++] = 52; break; }
      F[p++] = ""; break;
   case 'm' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='m'){ F[p++] = 61; break; }
      i++; if(f.charAt(i+1)!='m'){ F[p++] = 62; break; }
      F[p++] = ""; break;
   case 's' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='s'){ F[p++] = 71; break; }
      i++; if(f.charAt(i+1)!='s'){ F[p++] = 72; break; }
      F[p++] = ""; break;

   case 't' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='t'){ F[p++] = 81; F[8] = this.AMDesignator.charAt(0); F[9] = this.PMDesignator.charAt(0); break; }
      i++; if(f.charAt(i+1)!='t'){ F[p++] = 81; F[8] = this.AMDesignator; F[9] = this.PMDesignator; break; }
      F[p++] = ""; break;
   case 'z' :
      F[p++] = out; out="";
      if(f.charAt(i+1)!='z'){ F[p++]=91; break; }
      i++; if(f.charAt(i+1)!='z'){ F[p++]=92; break; }
      i++; if(f.charAt(i+1)!='z'){ F[p++]=93; break; }
      i++; if(f.charAt(i+1)!='z'){ F[p++]=94; break; }
      i++; if(f.charAt(i+1)!='z'){ F[p++]=95; break; }
      break;
   case '\\' : i++; out+=f.charAt(i); break;
   case '"' :
   case "'" :
      var pos = f.indexOf(f.charAt(i),i+1);
      if(pos==-1) break;
      out+=f.substring(i+1,pos); i=pos;
      break;
   default : out+=f.charAt(i);
   }
}
F[p] = out;
return F;
}
//---------------------------------------------------------------------------------------------------------------------------
//Converts string to date (number of milliseconds), possible formats: yyyy-mm-dd, mm-dd, mm/dd/yyyy, mm/dd, dd.mm.yyyy, dd.mm nebo hh:mm, hh:mm:ss

PFormat.StringToDateEng = function(str,pnGmt){
if(!str) return this.EmptyDate!=null ? "" : 0;
if(str==this.EmptyDate) return "";
var M = (str+"").match(this.CDateFormatEng);
if(!M) return 0;
var c = M[2], d, h = M[6], m = M[7], s = M[8];
if(!h) h = 0; if(!m) m = 0; if(!s) s = 0;

if(M[9]){
var a = M[9].charAt(0);
if(!c) h = M[1];
if(h<12) { if(a=='p' || a=='P') h = h-0+12; }
else if(h==12) { if(a=='a' || a=='A') h = 0; }
if(!c) M[1] = h;
}
var vnGmt = this.GMT;
if(pnGmt != null) vnGmt = pnGmt;
if(vnGmt-0) {

if(!c) {
   if(M[7]) return Date.UTC(1970,0,1,M[1],m,s);
   if(!M[1]&&M[0]-0+""!=M[0]) return NaN;
   return Date.UTC(this.CActualYear,this.CActualMonth,M[1]?M[1]:this.CActualDay);
   }

if(M[4]){
   if(c=='/') return Date.UTC(M[5]<70?M[5]-0+2000:M[5],M[1]-1,M[3],h,m,s);
   if(c=='-') return Date.UTC(M[1]<70?M[5]-0+2000:M[1],M[3]-1,M[5],h,m,s);
   if(c=='.') return Date.UTC(M[5]<70?M[5]-0+2000:M[5],M[3]-1,M[1],h,m,s);
   return 0;
   }

if(c=='/') return Date.UTC(this.CActualYear,M[1]-1,M[3]?M[3]:1,h,m,s);
if(c=='-') return Date.UTC(this.CActualYear,M[1]-1,M[3]?M[3]:1,h,m,s);
if(c=='.') return Date.UTC(this.CActualYear,M[3]?M[3]-1:CActualMonth,M[1],h,m,s);
return 0;
}

if(!c){
if(M[7]) return (new Date(1970,0,1,M[1],m,s)).getTime();
if(!M[1]&&M[0]-0+""!=M[0]) return NaN;
return (new Date(this.CActualYear,this.CActualMonth,M[1]?M[1]:this.CActualDay)).getTime();
}

if(M[4]){
if(c=='/') return (new Date(M[5]<70?M[5]-0+2000:M[5],M[1]-1,M[3],h,m,s)).getTime();
if(c=='-') return (new Date(M[1]<70?M[5]-0+2000:M[1],M[3]-1,M[5],h,m,s)).getTime();
if(c=='.') return (new Date(M[5]<70?M[5]-0+2000:M[5],M[3]-1,M[1],h,m,s)).getTime();
return 0;
}

if(c=='/') return (new Date(this.CActualYear,M[1]-1,M[3]?M[3]:1,h,m,s)).getTime();
if(c=='-') return (new Date(this.CActualYear,M[1]-1,M[3]?M[3]:1,h,m,s)).getTime();
if(c=='.') return (new Date(this.CActualYear,M[3]?M[3]-1:CActualMonth,M[1],h,m,s)).getTime();
return 0;
}
//---------------------------------------------------------------------------------------------------------------------------
PFormat.StringToDate = function(str,f,range,pnGmt){
if(!str) return this.EmptyDate!=null ? "" : 0;
if(str==this.EmptyDate) return "";

if(!f) return this.StringToDateEng(str,pnGmt);

var gmt = this.GMT-0;
if(pnGmt != null) gmt = pnGmt;

function GetIndex(str,A){
if(!A) return null;
str = str.toLowerCase();
for(var i=0;i<A.length;i++) if(A[i].toLowerCase()==str) return i+1;
return null;
}

function GetMonthIndex(str){
var m = GetIndex(str,this.LongMonthNames); if(m) return m;
m = GetIndex(str,this.LongMonthNames2); if(m) return m;
m = GetIndex(str,this.ShortMonthNames); if(m) return m;
return null;
}

if(f.length==1){
f = this[f];
if(!f) this.DateToStringEng(str,pnGmt);
}
f = f.replace(/\'[^\']*\'|\"[^\"]*\"|\\\S/g,"");

if(str-0 && str.length>=3){
var ok = 0, len = str.length;
var h=0,n=0,s=0;
//if(f.indexOf('M')<0){
if(/(h{1,2}|m{1,2}|s{1,2})/.test(f)){
   if(len==6){ h = str.slice(0,2)-0; n = str.slice(2,4)-0; s = str.slice(4,6)-0; ok = 1; }
   else if(len==5){ h = str.slice(0,1)-0; n = str.slice(1,3)-0; s = str.slice(3,5)-0; ok = 1; }
   else if(len==4){
      if(f.search(/h/i)>=0){ h = str.slice(0,2)-0; n = str.slice(2,4)-0; ok = 1; }
      else { n = str.slice(0,2)-0; s = str.slice(2,4)-0; ok = 1; }
      }
   else if(len==3){
      if(f.search(/h/i)>=0){ h = str.slice(0,1)-0; n = str.slice(1,3)-0; ok = 1; }
      else { n = str.slice(0,1)-0; s = str.slice(1,3)-0; ok = 1; }
      }
   if(ok) return gmt ? Date.UTC(1970,0,1,h,n,s) : (new Date(1970,0,1,h,n,s)).getTime();
   }
else {
   var date = new Date();
   if(gmt) { var d = date.getUTCDate(), m = date.getUTCMonth(), y = date.getUTCFullYear(); }
   else { var d = date.getDate(), m = date.getMonth()+1, y = date.getFullYear(); }
   if(len==3){
      if(f.search(/M.*d/)>=0){ m = str.slice(0,1)-0; d = str.slice(1,3)-0; ok = 1; }
      else if(f.search(/d.*M/)>=0){ d = str.slice(0,1)-0; m = str.slice(1,3)-0; ok = 1; }
      }
   else if(len==4){
      if(f.search(/M.*d/)>=0){ m = str.slice(0,2)-0; d = str.slice(2,4)-0; ok = 1; }
      else if(f.search(/d.*M/)>=0){ d = str.slice(0,2)-0; m = str.slice(2,4)-0; ok = 1; }
      else if(f.search(/y.*M/)>=0){ y = str.slice(0,2)-0; m = str.slice(2,4)-0; y+=y<70?2000:1900; ok = 1; }
      else if(f.search(/M.*y/)>=0){ m = str.slice(0,2)-0; y = str.slice(2,4)-0; y+=y<70?2000:1900; ok = 1; }
      }
   else if(len==6){
      if(f.search(/M.*d.*y/)>=0){ m = str.slice(0,2)-0; d = str.slice(2,4)-0; y = str.slice(4,6)-0; y+=y<70?2000:1900; ok = 1; }
      else if(f.search(/d.*M.*y/)>=0){ d = str.slice(0,2)-0; m = str.slice(2,4)-0; y = str.slice(4,6)-0; y+=y<70?2000:1900; ok = 1; }
      else if(f.search(/y.*M.*d/)>=0){ y = str.slice(0,2)-0; m = str.slice(2,4)-0; d = str.slice(4,6)-0; y+=y<70?2000:1900; ok = 1; }
      else if(f.search(/y.*d.*M/)>=0){ y = str.slice(0,2)-0; d = str.slice(2,4)-0; m = str.slice(4,6)-0; y+=y<70?2000:1900; ok = 1; }
      else if(f.search(/yyyy.*M/)>=0){ y = str.slice(0,4)-0; m = str.slice(4,6)-0; ok = 1; }
      else if(f.search(/M.*yyyy/)>=0){ m = str.slice(0,2)-0; y = str.slice(2,6)-0; ok = 1; }
      }
   else if(len==8){
      if(f.search(/M.*d.*y/)>=0){ m = str.slice(0,2)-0; d = str.slice(2,4)-0; y = str.slice(4,8)-0; ok = 1; }
      else if(f.search(/d.*M.*y/)>=0){ d = str.slice(0,2)-0; m = str.slice(2,4)-0; y = str.slice(4,8)-0; ok = 1; }
      else if(f.search(/y.*M.*d/)>=0){ y = str.slice(0,4)-0; m = str.slice(4,6)-0; d = str.slice(6,8)-0; ok = 1; }
      else if(f.search(/y.*d.*M/)>=0){ y = str.slice(0,4)-0; d = str.slice(4,6)-0; m = str.slice(6,8)-0; ok = 1; }
      }
   if(ok) return gmt ? Date.UTC(y,m-1,d) : (new Date(y,m-1,d)).getTime();
   }
}

var M = str.match(this.CDateFormat);

if(!M) return 0;
var d,m,y,h = M[9], n = M[11], s = M[13], t = 0;
if(!M[3]&&!M[4]&&!M[5] && M[10]) t = f.search(/[dMy]/)<0 ? 1 : 2;
else if(M[3]=='.' && !h && !n){
if(f.search(/[dMy]/)<0) t = 1;
else if(this.TimeSeparator=='.') t = 2;
if(t){ n = M[4]; s = M[7]; }
}
else if(M[1] && !M[2] && !h && f.search(/[dMy]/)<0) t = 1;

if(t) h = M[1];
else if(!h && M[10]){
if(M[7]){ h = M[7]; M[7] = null; }
}
if(!h) h = 0; if(!n) n = 0; if(!s) s = 0;

if(M[14] || !M[3]&&M[2]&&M[2].search(/^[ap]m?$/i)==0){
var a = (M[14]?M[14]:M[2]).charAt(0);
if(!M[14]) { t = 1; h = M[1]-0; }
if(h<12) { if(a=='p' || a=='P') h = h-0+12; }
else if(h==12) { if(a=='a' || a=='A') h = 0; }
}

if(t==2) {
var date = new Date();
if(gmt) date.setUTCHours(h,n,s,0);
else date.setHours(h,n,s,0);
return date.getTime();
}
else if(t==1) return gmt ? Date.UTC(1970,0,1,h,n,s) : (new Date(1970,0,1,h,n,s)).getTime();

if(!M[1] && M[2]){
m = GetMonthIndex(M[2]); if(!m) return 0
d = M[4];
y = M[7];
}
else if(!M[4] && M[5]){
m = GetMonthIndex(M[5]); if(!m) return 0
d = M[1];
y = M[7];
}
else if(!M[7] && M[8]){
m = GetMonthIndex(M[8]); if(!m) return 0
d = M[4];
y = M[1];
}
else if(M[1]>31){
d = M[7]; m = M[4];
if(f.search(/y{1,4}\W*d{1,2}/)>=0){ d = M[4]; m = M[7]; }
if(!d) d = 1;
if(!m) m = 1;
y = M[1];
}
else if(M[4]>31){
d = M[7]; if(!d) d = 1;
m = M[1];
if(f.search(/d{1,2}\W*y{1,4}/)>=0){ m = d; d = M[1]; }
y = M[4];
}
else if(!M[1]){
d = this.CActualDay;
}
else {

if(f.search(/d{1,2}\W*M{1,5}/)>=0){
   if(f.search(/y{1,4}\W*d{1,2}/)>=0){
      d = M[4]; if(!d) d = 1;
      m = M[7]; if(!m) m = 1;
      y = M[1];
      if(m>12 && y<=31) { d = M[1]; m = M[4]; y = M[7]; }
      }
   else {
      d = M[1]; m = M[4]; y = M[7];
      }
   }
else if(f.search(/y{1,4}\W*M{1,5}/)>=0){
   if(f.search(/d{1,2}\W*y{1,4}/)>=0){
      d = M[1];
      m = M[7];
      y = M[4];
      }
   else {
      d = M[7]; if(!d) d = 1;
      m = M[4]; if(!m) m = 1;
      y = M[1];
      if(d>31 && y<=31) { d = M[1]; m = M[4]; y = M[7]; }
      }
   }
else if(f.search(/M{1,5}\W*y{1,4}/)>=0){
   d = M[7]; if(!d) d = 1;
   m = M[1];
   y = M[4];
   }
else {
   d = M[4]; if(!d) d = 1;
   m = M[1];
   y = M[7];
   }
}
if(!y){ y = m||d ? this.CActualYear : 1970; }
else if(y<100){ if(y<70) y=y-0+2000; else y=y-0+1900; }
if(!m) m = d ? this.CActualMonth+1 : 1;
m--;
if(!d) d = 1;
return gmt ? Date.UTC(y,m,d,h,n,s) : (new Date(y,m,d,h,n,s)).getTime();

}

//-----------------------------------------------------------------------------------------------------------
//Converts value to show it in HTML
PFormat.Escape = function(val){
if(val==null) return "";
if(typeof(val)!="string") return val+"";
if(val.search(this.CSearchEscape3)<0) return val;
if(val.indexOf("&")>=0) val = val.replace(PFormat.CReplaceAmp,"&amp;");
if(val.indexOf("<")>=0) val = val.replace(PFormat.CReplaceLt,"&lt;");
if(val.indexOf('"')>=0) val = val.replace(PFormat.CReplaceQuot,"&quot;");
if(val.indexOf("'")>=0) val = val.replace(PFormat.CReplaceApos,"&#x27;");
return val;
}
//-----------------------------------------------------------------------------------------------------------
//Formats HTML string of types "Text" and "Lines"
PFormat.FormatString = function(Value,format, esc){
if(Value==null) Value="";
else Value+="";
if(!format){
if(!esc) return Value;
if(Value.search(this.CSearchEscape2)>=0) {
   if(Value.indexOf("&")>=0) Value = Value.replace(this.CReplaceAmp,"&amp;");
   if(Value.indexOf("<")>=0) Value = Value.replace(this.CReplaceLt,"&lt;");
   if(Value.indexOf("\n")>=0) Value = Value.replace(this.CReplaceCR,"<br>");
   }
if(Value.indexOf(" ")>=0) Value = Value.replace(this.CReplaceWhite,CNBSP);
return Value;
}
format+="";
var f = format.split(format.charAt(0));
if(f[4]){
try { Value = Value.replace(new RegExp(f[4],f[5]),f[6]); }
catch(e){ alert ((e.message?e.message:e)+"\n\nin value: "+Value+"\nwith format: "+format+"\nregex: /"+f[4]+"/"+f[5]+" => "+f[6]); }
}
switch(f[1]-0){
case 1 : Value = Value.toLowerCase(); break;
case 2 : Value = Value.toUpperCase(); break;
case 3 : Value = Value.toLocaleLowerCase(); break;
case 4 : Value = Value.toLocaleUpperCase(); break;
}
return (f[2] ? (esc>1 ? this.Escape(f[2]) : f[2]) : "") + (esc ? this.Escape(Value).replace(this.CReplaceWhite,CNBSP).replace(this.CReplaceCR,"<br/>") : Value) + (f[3] ? (esc>1 ? this.Escape(f[3]) : f[3]) : "");
}
//-----------------------------------------------------------------------------------------------------------
//Converts value to show it in HTML

//-----------------------------------------------------------------------------------------------------------
PFormat.StringToValue = function(val,type,format,range){
if(type=="Int" || type=="Float") val = this.StringToNumber(val,format,range);
else if(type=="Date") val = this.StringToDate(val,format,range);
return val;
}
//-----------------------------------------------------------------------------------------------------------
PFormat.ValueToString = function(val,type,format,range){
if(type=="Int" || type=="Float") {
if(val==="" && this.EmptyNumber) return "";
val = this.NumberToString(val,format,range);
}
else if(type=="Date") {
if(val==="" && this.EmptyDate) return "";
val = this.DateToString(val,format,range);
}
else if(val==null) val = "";
else val+="";
return val;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end of import Format6.js

var TGP = {};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of import Value6.js
TGP.GetString = function(psValue, psType, psFormat, pnGmt){
var type = psType, Value = psValue;
switch(type){
case "string" :
  return PFormat.FormatString(Value, psFormat);
case "number":
  return PFormat.NumberToString(Value, psFormat);
case "date":
  return  PFormat.DateToString(Value, psFormat, null, pnGmt);
default:
  return Value;
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end of import Value6.js

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of import Grid/Edit6.js
TGP.GetValueInput = function(Value, psType, psFormat, pnGmt){
var format = psFormat, type = psType;
switch(type){
case "number":
   if(Value==="" && PFormat.EmptyNumber!=null) return "";
   Value = PFormat.StringToNumber(Value,format);
   return Value;
case "date":
   if(Value==="" && PFormat.EmptyDate!=null) return "";
   if(Value==PFormat.NaN) return '/';
   return PFormat.StringToDate(Value,format,null,pnGmt);
   return '/';
case "string":
   if(!format) return Value;
   var f = format.split(format.charAt(0));
   if(f[2]!="" && Value.slice(0,f[2].length)==f[2]) Value = Value.slice(f[2].length);
   if(f[3]!="" && Value.slice(Value.length-f[3].length,Value.length)==f[3]) Value = Value.slice(0,Value.length-f[3].length);
   return Value;
default:
   return Value;
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end of import Grid/Edit6.js

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of import Lib/Edit6.js
function TestKey(ev,tag,func,data){
var okey = ev.keyCode; if(!okey || BMozilla) okey = ev.charCode; if(!okey) return;
var nkey = func(okey,tag.value,data), dom2 = !!ev.preventDefault;
if(typeof(nkey)=="string") nkey = nkey.charCodeAt(0);
if(nkey && nkey!=okey){
  if(!dom2) ev.keyCode = nkey;
  else {
     try {
        var s = tag.selectionStart, e = tag.selectionEnd; if(e==null) e = s;
        tag.value = tag.value.slice(0,s)+String.fromCharCode(nkey)+tag.value.slice(e);
        tag.selectionStart = s+1; tag.selectionEnd = s+1;
        }
     catch(e) { }
     nkey = 0;
     }
  }
if(!nkey){
  if(dom2) ev.preventDefault();
  else ev.returnValue = false;
  }
if(tag.control.onkeypress)  {
  tag.control.onkeypress(new eXria.event.Event(ev, tag.control.window));
}
return nkey;
}
// -----------------------------------------------------------------------------------------------------------
// Tests pressed key if can be added into integer number, include hexadecimal numbers
function TestKeyInt(key,val,add){
if(key>=97 && key<=122) key-=32;
if(add) for(var i=0;i<add.length;i++) if(key==add.charCodeAt(i)) return key;

if(key==88) return 120;

if(key==45) return  key;
if(key>=65 && key<=70) return val.indexOf('x')>=0 ? key : 0;
if(key>=48 && key<=57 || key==8 || BSafari&&(key==37 || key==39)) return key;
return 0;
}

// -----------------------------------------------------------------------------------------------------------
// Tests pressed key if can be added into floating point number
function TestKeyFloat(key,val,add){
if(key>=97 && key<=122) key-=32;
if(add) for(var i=0;i<add.length;i++) if(key==add.charCodeAt(i)) return key;
if(key==45) return key;
for(var i=0;i<Formats.InputDecimalSeparators.length;i++) if(key==Formats.InputDecimalSeparators.charCodeAt(i)){

  return Formats.DecimalSeparator.charCodeAt(0);
  }
for(var i=0;i<Formats.InputGroupSeparators.length;i++) if(key==Formats.InputGroupSeparators.charCodeAt(i)) {

  return Formats.GroupSeparator.charCodeAt(0);
  }
if(key==69) return val.indexOf('e')>=0 ? 0 : 101;
if(key>=48 && key<=57 || key==8 || key==37 || key==39) return key;
return 0;
}
// -----------------------------------------------------------------------------------------------------------
// Tests pressed key if can be added into date/time value
function TestKeyDate(key,val,add){
if(key>=97 && key<=122) key-=32;
if(add) for(var i=0;i<add.length;i++) if(key==add.charCodeAt(i)) return key;
for(var i=0;i<Formats.InputDateSeparators.length;i++) if(key==Formats.InputDateSeparators.charCodeAt(i)) return Formats.DateSeparator.charCodeAt(0);
for(var i=0;i<Formats.InputTimeSeparators.length;i++) if(key==Formats.InputTimeSeparators.charCodeAt(i)) return Formats.TimeSeparator.charCodeAt(0);
if(key==32 || key==44) return 32;
if(key>=48 && key<=57 || key==8 || key==37 || key==39) return key;
return 0;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end of import Lib/Edit6.js


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of eXria.controls.xhtml.DateInput.js override
eXria.controls.xhtml.DateInput.prototype.getDate = eXria.controls.xhtml.EditMask.prototype.getDate;
eXria.controls.xhtml.DateInput.prototype.getDateString = eXria.controls.xhtml.EditMask.prototype.getDateString;
eXria.controls.xhtml.Output.prototype.getDate = eXria.controls.xhtml.DateInput.prototype.getDate;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end of eXria.controls.xhtml.DateInput.js override

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start of eXria.controls.xhtml.Output.js override

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end of eXria.controls.xhtml.Output.js override
