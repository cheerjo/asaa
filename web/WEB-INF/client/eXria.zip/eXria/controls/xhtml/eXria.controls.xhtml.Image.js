﻿/**
 * @fileoverview
 * Concreate xhtml Image(XHTML Image 컨트롤)
 * @author 조영진
 */

/**
 * @class 이미지파일을 보다 간편하게 화면에 링크할 수 있는 컨트롤을 생성합니다.<br />
 * XHTML Image Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Image 객체
 * @type eXria.controls.xhtml.Image
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Image = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 100 : pnHeight;

  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);

  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 이미지 경로.
   * @type String
   */
  this.src = null;
  /**
   * 로딩 실패 이미지 경로.
   * @type String
   */
  this.altSrc = null;
  /**
   * 이미지 불투명도.
   * @type Number
   */
  this.imageOpacity = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   */
  this.innerHeight = this.height;
  /**
   * (임시) 백그라운드 이미지
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};

  this.cursor = null;

};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Image);
//////////////////////////////////////////////////////////////////
// 메소드

//this.click  = function() {
/**
 * 이미지에 클릭 이벤트 발생 메소드.
 */
eXria.controls.xhtml.Image.prototype.click  = function() {
  this.ctrl.click();
};

eXria.controls.xhtml.Image.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};

eXria.controls.xhtml.Image.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<img class='" + vsClass + "' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_img' ");
  vaTemplate.push("@attStrBuf"); //index:3
  vaTemplate.push("style=\"");
  vaTemplate.push("@cssStrBuf"); //index:5
  vaTemplate.push("\"/>");
};

eXria.controls.xhtml.Image.prototype.refreshTemplate = null;

eXria.controls.xhtml.Image.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  //this.src = this.getAttrValue("src",this.src);
  if(this.data.instanceId == null || this.data.isRelativeRef())
  this.src = this.getAttrValue("src",this.src);
  else{
  this.src = this.data.getData();
  }

  this.imageOpacity = this.getAttrValue("imageOpacity", this.imageOpacity);
};

eXria.controls.xhtml.Image.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  //var vsContextPath = eXria.controls.xhtml.Util.getImagePath(this.getAttrValue("src",this.src), this.window);
  var vsContextPath = this.getAttrValue("src",this.src);
  vfcSetAttStrBuf(vaAttStrBuf, "src", vsContextPath);
//  IE 6.0이하 투명 PNG처리 용 (MS AlphaImageLoader로 대체되는 방식이라 Size/opacity 처리 안됨)
//  var vsImageType = this.src.substring(this.src.lastIndexOf(".") + 1, this.src.length);
//  if(vsImageType == "png") vfcSetAttStrBuf(vaAttStrBuf, "class", "png24");
  vaAttStrBuf.push(" onerror=\"");
  vaAttStrBuf.push(this.getEHandler(this.id, "aterror"));
  vaAttStrBuf.push("\"");
  vaTemplate[3] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;border-style:none;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  var pnOpacity = 100;
  if(isFinite(this.imageOpacity)) pnOpacity = this.imageOpacity;
  var vsFilter = "alpha(opacity=" + pnOpacity + ")";
  var vsOpacity = "" + pnOpacity/100;
  this.setOpacityToCssStrBuf(vaCssStrBuf, vsFilter, vsOpacity);

  vaTemplate[5] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");

  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;

  this.setSubElement(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Image.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.img = this.getSubCtrl("img", voCtrl, poDocument);
};

eXria.controls.xhtml.Image.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};

eXria.controls.xhtml.Image.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voImgCtrl = this.subElement.img;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  //voImgCtrl["src"] = this.src+"?status="+Math.round(Math.random()* (new Date().getTime()));
  voImgCtrl["src"] = this.src;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;border-style:none;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  var pnOpacity = 100;
  if(isFinite(this.imageOpacity)) pnOpacity = this.imageOpacity;
  var vsFilter = "alpha(opacity=" + pnOpacity + ")";
  var vsOpacity = "" + pnOpacity/100;
  this.setOpacityToCssStrBuf(vaCssStrBuf, vsFilter, vsOpacity);

  voImgCtrl.style.cssText = vaCssStrBuf.join("");
};
/**
 * @ignore
 */
eXria.controls.xhtml.Image.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voImg = poCtrl.childNodes[0];
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(psAttrValue);
    break;
  case "width" :
    this.setAttrCtrl("width", this.innerWidth, voImg);
    break;
  case "height" :
    this.setAttrCtrl("height", this.innerHeight, voImg);
    break;
  //case "borderWidth" :
  //  this.setAttrCtrl("width", this.innerWidth, voImg);
  //  this.setAttrCtrl("height", this.innerHeight, voImg);
  //  break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Image.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voImg = voCtrl.childNodes[0];
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
//    if(this.borderLeftWidth == null) this.borderLeftWidth = this.borderWidth;
//    if(this.borderRightWidth == null) this.borderRightWidth = this.borderWidth;
//    if(this.borderTopWidth == null) this.borderTopWidth = this.borderWidth;
//    if(this.borderBottomWidth == null) this.borderBottomWidth = this.borderWidth;
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;

    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderTopHeight" :
    this.innerHeight = this.width - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
    break;
  case "imageOpacity" :
    var vsFilter = "alpha(opacity=" + this.imageOpacity + ")";
    var vsOpacity = "" + this.imageOpacity/100;
  this.setOpacity(voCtrl, vsFilter, vsOpacity);
  break;
  case "src" :
  var vsContextPath = eXria.controls.xhtml.Util.getImagePath(psAttrValue, this.window);
    this.setAttrCtrl(psAttrName, vsContextPath, voImg);
    break;
  case "cursor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setAttrCtrl(psAttrName, psAttrValue, voImg);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Image.prototype.aterror = function(e) {
  var voImgCtrl = this.subElement.img;
  if(this.altSrc != null && this.tempSrc != this.altSrc) {
    this.tempSrc = this.altSrc;
    voImgCtrl.src = this.altSrc;
  }
};
/**
 * 불러오는 이미지에 대한 URL 및 파일 경로 설정합니다.
 * @param {String} psSrc URL 및 파일 경로
 * @param {Boolean} pbChgUrlPattern 브라우저에서의 Image 캐싱 방지를 위해 URL 패턴을 변경할 지 여부
 */
eXria.controls.xhtml.Image.prototype.setSrc = function(psSrc, pbChgUrlPattern) {
  this.src = psSrc;
  if(!!this.data)
  this.data.setData(psSrc);

  this.tempSrc = null;
  var voImgCtrl = this.subElement.img;
  var vsParam = "";
  if(pbChgUrlPattern) {
    if(/\?/.test(psSrc)) vsParam = "&";
    else vsParam = "?"
    vsParam += "ct=" + new Date().toTimeString();
  }
  voImgCtrl.src = psSrc + vsParam;
};

eXria.controls.xhtml.Image.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Image[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * Image의 Div에 포커스를 사용
 * @private
 */
eXria.controls.xhtml.Image.prototype.dofocus = function() {
  this.ctrl.focus();
};
/**
 * 클래스 명을 반환합니다.
 * @return "Image"
 * @type String
 */
eXria.controls.xhtml.Image.prototype.toString = function() {
  return "Image";
};
