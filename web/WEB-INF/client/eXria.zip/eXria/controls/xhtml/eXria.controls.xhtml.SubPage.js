/**
 * @fileoverview
 * Concreate xhtml Image(XHTML SubPage 컨트롤)
 * @author 조동일, 김경태
 */

/**
 * @class page 내부에 외부 page를 포함시키는 기능을 수행<br>
 * IFRAME으로 표현
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.SubPage 객체
 * @type eXria.controls.xhtml.SubPage
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
// 요구사항 :<br>
// 1. outter page와 inner page간의 data 연동 기능(function 제공) -> canvas 또는 page를 통해 연동 -> 협의 필요<br>
// 2. inner page에서의 outter page와 독립적인 data 구조 사용(data의 독립성 확보)<br>
// 3. 보여지는 size 및 좌표를 가짐<br>
// 4. import 되는 소스의 수정이 가능<br>
// 5. visible 여부의 관리 가능<br>
// 6. 활성화 여부의 관리 가능<br>
// View : <br>
eXria.controls.xhtml.SubPage = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight = pnHeight == null ? 300 : pnHeight;
  /**
   * Inheritance Call
   */
  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);   // UIControl을 상속받는다.
  /*
   * Class Field List
   */
  /**
   * Import에 속한 컨트롤들의 표시 여부.<br>
   * true | false
   * @type Boolean
   */
  this.visible = null;
  /**
   * SubPage에 속한 컨트롤들의 활성화 여부.<br>
   * true | false
   * @type Boolean
   */
  this.enable = null;
  /**
   * 불러오는 화면에 대한 URL 및 파일 경로.
   * @type String
   */
  this.src = null;
  /**
   * 컨트롤이 디스플레이 되는 document
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * SubPage 영역의 Scrolling 속성
   * @type String
   * @private
   */
  this.scrolling = "auto";
  /**
   * SubPage에 로딩된 xrf의 page 객체
   * @type eXria.form.Page
   * @private
   */
  this.page = null;

  this.df = {};
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.SubPage);

//  Lifecycle Function List
//
//  Canvas에 의해 호출된다.
//  객체가 생성되고, 좌표가 설정된 후에 Canvas에 append 시점에 호출된다.
//  HTML Control 생성후 리턴
//
//  HTML Control 생성

eXria.controls.xhtml.SubPage.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("iframe");
  voCtrl["id"] = this.id;
  voCtrl["frameBorder"] = "no";
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
//  if(this.src) {
//    voCtrl["src"] = this.getAbsolutePath(this.src);
//  }
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.SubPage.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  switch(psAttrName) {
    case "disabled" :
      //this.setEnable(!psAttrValue, poCtrl);
      break;
    case "visible" :
      //this.setVisible(psAttrValue, poCtrl);
      break;
    default :
      break;
  }
};

eXria.controls.xhtml.SubPage.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.scrolling = this.getAttrValue("scrolling", this.scrolling);
};

eXria.controls.xhtml.SubPage.prototype.setSpecificAttrs = function(poCtrl, poDocument, pbChildRefresh) {
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  if(pbChildRefresh != false && this.src) {
    poCtrl["src"] = this.getAbsolutePath(this.src);
  }

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  poCtrl["scrolling"] = this.scrolling;
  if(this.backgroundColor !== null && this.backgroundColor.toUpperCase() == "TRANSPARENT") poCtrl["allowTransparency"] = true;
  else  poCtrl["allowTransparency"] = false;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
//  vfcSetCssStrBuf(vaCssStrBuf, "overflow", voDf.overflow);
//  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", voDf.overflowX);
//  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", voDf.overflowY);
  poCtrl.style.cssText = vaCssStrBuf.join("");
};

eXria.controls.xhtml.SubPage.prototype.setSpecificEvents = null;

eXria.controls.xhtml.SubPage.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};

eXria.controls.xhtml.SubPage.prototype.refreshSpecificAttrs = function(poCtrl, poDocument, pbChildRefresh) {
  this.setSpecificAttrs(poCtrl, poDocument, pbChildRefresh);
};
/**
 * @ignore
 */
eXria.controls.xhtml.SubPage.prototype.refreshVerticalAlign = function() {
  var voPage = this.getPage();
  if(voPage == null) return;
  var voControls = voPage.canvas.controls.entries;
  var voControl = null;
  for(var member in voControls) {
    voControl = voControls[member];
    if(voControl.refreshVerticalAlign) {
      voControl.refreshVerticalAlign();
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.SubPage.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderTopHeight" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "className" :
  case "outerClassName" :
    this.refresh(poDocument);
    break;
  case "src" :
    this.setSrc(psAttrValue);
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  }
};
/**
 * 불러오는 화면에 대한 URL 및 파일 경로 설정합니다.
 * @param {String} psSrc URL 및 파일 경로
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.SubPage.prototype.setSrc = function(psSrc, poDocument) {
  if(psSrc === 'javascript:false'){
    psSrc = 'about:blank';
  }else{
    psSrc = this.getAbsolutePath(psSrc);
  }
  this.src = psSrc;
  var voCtrl = this.getCtrl(poDocument);
  var vsCssText = voCtrl.style.cssText;
  if(voCtrl) {
    if(this.canvas.page.metadata.browser.ie > 0) {
//      var voParent = voCtrl.parentNode;
//      if(voCtrl.contentWindow.page) {
//        voCtrl.contentWindow.page.isUnload = true;
//      }
//      voParent.removeChild(voCtrl);
//      voCtrl = this.document.createElement("iframe");
//      voCtrl["id"] = this.id;
//      voCtrl["frameBorder"] = "no";
//      voCtrl["hideFocus"] = true;
//      voCtrl.style.cssText = vsCssText;
//      voParent.appendChild(voCtrl);
//      this.ctrl = voCtrl;

      var voWindow = this.window;
      var voEvent = voWindow.event;
      if(voEvent && voEvent.type == "keydown" && voEvent.keyCode == 13) {
        voEvent.cancelBubble = true;
        voEvent.returnValue = false;
      }

    }
    voCtrl.src = this.src;
      //voCtrl.contentWindow.document.location.href = this.src;
//    voCtrl.offsetHeight;
  }
};
/**
 * 받은 경로를 절대경로로 변환하여 반환합니다.
 * @param {String} psSrc URL 및 파일 경로
 * @return 절대경로로 변환된값
 * @type String
 */
eXria.controls.xhtml.SubPage.prototype.getAbsolutePath = function(psSrc){
  var getSubSrc = function(psSrc){
    if(psSrc.indexOf("../") == 0) {
      if(vsBaseUrl != (this.document.location.protocol + "//" + this.document.location.host)) vsBaseUrl = vsBaseUrl.substring(0, vsBaseUrl.lastIndexOf("/"));
      psSrc = psSrc.substring((psSrc.indexOf("/") + 1), psSrc.length);
    } else if(psSrc.indexOf("./") == 0 || psSrc.indexOf("/") == 0){
      psSrc = psSrc.substring((psSrc.indexOf("/") + 1), psSrc.length);
    } else if(psSrc.indexOf("/") != -1){
      var vsTemp = psSrc.substring(0, psSrc.indexOf("/"));
      psSrc = psSrc.substring((psSrc.indexOf("/") + 1), psSrc.length);
      vsBaseUrl = vsBaseUrl + "/" + vsTemp;
    }
    if(psSrc.indexOf("/") != -1) psSrc = getSubSrc(psSrc);
    return psSrc;
  }
  if(psSrc == "#") return psSrc;
  if(psSrc.indexOf("http://") == -1 && psSrc.indexOf("about:") == -1 && psSrc.indexOf("/") != 0){ // 절대경로가 아닐 경우
    var vsBaseUrl = this.document.location.href;
    vsBaseUrl = vsBaseUrl.substring(0, vsBaseUrl.lastIndexOf("/"));

    psSrc = getSubSrc(psSrc);
    psSrc = vsBaseUrl + "/" + psSrc;
  }

  return psSrc;
};
/**
 * SubPage에 로딩된 xrf의 page 객체를 반환하는 메소드
 * @return SubPage에 로딩된 xrf의 page 객체
 * @type eXria.form.Page
 */
eXria.controls.xhtml.SubPage.prototype.getPage = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  if(voCtrl == null) {
    this.page = null;
  }else if(voCtrl.contentWindow && voCtrl.contentWindow.page) {
    this.page = voCtrl.contentWindow.page;
  }
  return this.page;
};
/**
 * 컨트롤 화면 디스플레이 여부를 설정합니다.
 * @param {String} psVisible 화면 디스플레이 여부
 * @param {HTMLIframe} poCtrl 실체화 컨트롤
 * @deprecated
 */
eXria.controls.xhtml.SubPage.prototype.setVisible = function(psVisible, poCtrl) {
  var voDf = this.df;
  this.visible = psVisible;
//  voDf.visible = psVisible;
//
//  debugger;
//  this.ctrl;

  if(!poCtrl)
    poCtrl = this.getCtrl(this.document);

  poCtrl.style.display = psVisible;
};
/**
 * 컨트롤의 화면 디스플레이 상태 값을 반환합니다.
 * @return 컨트롤의 visible 속성값
 * @type String
 */
eXria.controls.xhtml.SubPage.prototype.getVisible = function() {
  return this.visible;
};
/**
 * 불러오는 화면에 대한 URL 및 파일 경로를 반환합니다.
 * @return 컨트롤의 src 속성 값
 * @type String
 */
eXria.controls.xhtml.SubPage.prototype.getSrc = function() {
  return this.src;
};
/**
 * 내부페이지의 활성화 여부를 설정합니다.
 * @param {Boolean} pbEnable 활성화 설정
 * @param {HTMLIframe} poCtrl 실체화 컨트롤
 */
eXria.controls.xhtml.SubPage.prototype.setEnable = function(pbEnable, poCtrl) {
  if(this.enable != pbEnable) {
    //iframe inner control들을 disable 시킨다.
    this.enable = pbEnable;
    var voSubPageWindow = poCtrl.contentWindow;

    var voControls = voSubPageWindow.page.canvas.controls.getValueCollection();
    var voControlIterator = voControls.iterator();
    var voControl;
    while(voControlIterator.hasNext()) {
      voControl = voControlIterator.next();
      voControl.applyAttr("disabled", !this.enable);
    }
  }
};

eXria.controls.xhtml.SubPage.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  if(eXria.controls.xhtml.Default.SubPage) vsDefaultValue = eXria.controls.xhtml.Default.SubPage[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "SubPage"
 * @type String
 */
eXria.controls.xhtml.SubPage.prototype.toString = function() {
  return "SubPage";
};
