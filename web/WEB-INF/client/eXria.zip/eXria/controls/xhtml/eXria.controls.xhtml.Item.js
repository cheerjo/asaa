/**
 * @fileoverview
 * Concreate xhtml Item(XHTML Item 컨트롤)
 * @author 김경태
 */

/**
 * @class CheckBox와 RadioButton의 체크아이템을 실체화시키는 class입니다.<br />
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.Item 객체
 * @type eXria.controls.Item
 * @constructor
 * @base eXria.controls.Item
 * @private
 */

eXria.controls.xhtml.Item = function(psId, poParent, psLabelText, psValue, pnLeft, pnTop, pnWidth, pnHeight){

  vnLeft = pnLeft == null ? 0 : pnLeft;
  vnTop = pnTop == null ? 0 : pnTop;
  vnWidth = pnWidth == null ? 200 : pnWidth;
  vnHeight = pnHeight == null ? 20 : pnHeight;

  eXria.controls.Item.call(this, psId, poParent, psLabelText, psValue, vnLeft, vnTop, vnWidth, vnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * Radio, Checkbox Button 클래스의 라벨 속성 저장 오브젝트.
   * @type Object
   */
  this.label = new eXria.controls.xhtml.Select_label();
  /**
   * Radio, Checkbox Button 클래스의 선택버튼 속성 저장 오브젝트.
   * @type Object
   */
  this.selector = new eXria.controls.xhtml.Select_selector();
  /**
   * 아이템의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   * @private
   */
  this.data = new eXria.controls.DataRefNode(this.parent);
};
//eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Item);
eXria.controls.xhtml.Util.createInheritance(eXria.controls.Item, eXria.controls.xhtml.Item);
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.Item.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  var voStyle = voCtrl.style;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  voCtrl.setAttribute("id", this.id);
  voStyle.position = "absolute";
  voStyle.overflow = "hidden";       // 컨트롤 영역을 벗어난 하위 요소를 안보이게 처리
  voStyle.left = this.left + "px";
  voStyle.top = this.top + "px";
  voStyle.color = this.color;
  voStyle.backgroundColor = this.backgroundColor;
  if(this.borderWidth) voStyle.borderWidth = this.borderWidth + "px";
  if(this.borderStyle) voStyle.borderStyle = this.borderStyle;
  if(this.borderColor) voStyle.borderColor = this.borderColor;
  voCtrl.disabled = this.disabled;

  if(this.verticalAlign == null) this.verticalAlign = this.getSpecificDefaultValue("verticalAlign");

  this.createSubCtrl(voCtrl, poDocument);
  //this.setMainCtrlStyles(voCtrl, poDocument);
  return voCtrl;
};
/**
 * item을 구성하기 위한 HTML 문자열을 얻어오는 메소드.
 * @return item을 구성하기 위한 HTML 문자열 값.
 * @type String
 * @private
 */
eXria.controls.xhtml.Item.prototype.getInnerHTML = function() {
  this.setSpecificDefaults();

  var voDf = this.df;
  this.template = [];
  var vaTemplate = this.template;
  vaTemplate.push("<div id='");
  vaTemplate.push(this.id);
  vaTemplate.push("' ");
  vaTemplate.push("@attStrBuf");
  vaTemplate.push(" style='position:absolute;overflow:hidden;");
  vaTemplate.push("@cssStrBuf");  // 5
  vaTemplate.push("'>");
  var vsClass = this.parent.getCSSClass(this.parent, 1, "itemgroup");
  vaTemplate.push("<table cellSpacing=0 cellPadding=0 style='");
  vaTemplate.push("@cssStrBuf"); // 8
  vaTemplate.push("'><tbody><tr><td ");
  vaTemplate.push("@attStrBuf"); //10
  vaTemplate.push(" style='");
  vaTemplate.push("@cssStrBuf"); // 12

  var vsLabelCtrl = this.label.getInnerHTML(this);
  var vsSelectorCtrl = this.selector.getInnerHTML(this);
   switch(this.labelPos) {
    case "left" :
        // yhkim 기존코드
//      vaTemplate.push("'><div style='border-style:none;border-width:0px;overflow:hidden;"); // 위에꺼
//      vaTemplate.push("@cssStrBuf");  // 14                                                 // 위에꺼
//      vaTemplate.push("'>");                                                                // 위에꺼
//      vaTemplate.push(vsLabelCtrl);
//      vaTemplate.push(vsSelectorCtrl);
//      vaTemplate.push("</div>");                                                            // 아래꺼

    // yhkim 2009.07.23 라이오 체크 vertival문제
    vaTemplate.push("'><table cellspacing='0' cellpadding='0' ");
    vaTemplate.push("@attStrBuf");
    //vaTemplate.push("><tbody><tr><td>")
    // yhkim2009.09.21 table td내에 span이 브라어저 내에서 위치가 바뀌는 현상
    if(this.parent.canvas.page.metadata.browser.ie > 0 && this.parent.canvas.page.metadata.browser.ie < 8)
      vaTemplate.push("><tbody><tr><td style=\"padding-top:3px;\">")
    else if(this.parent.canvas.page.metadata.browser.ie > 7 || this.parent.canvas.page.metadata.browser.gecko > 0)
      vaTemplate.push("><tbody><tr><td style=\"padding-bottom:3px;\">")
    vaTemplate.push(vsLabelCtrl);
    vaTemplate.push("</td><td style='vertical-align:top;'>");
    vaTemplate.push(vsSelectorCtrl);
    vaTemplate.push("</td></tr></tbody></table>");

      //분기문에서 vaTemplate의 인덱스를 맞춰주기 위해 빈 문자열을 배열에 추가하는 것도 고려
      break;
    case "right":
        // yhkim 기존코드
//      vaTemplate.push("'><div style='border-style:none;border-width:0px;overflow:hidden;");
//      vaTemplate.push("@cssStrBuf");  // 14
//      vaTemplate.push("'>");
//      vaTemplate.push(vsSelectorCtrl);
//      vaTemplate.push(vsLabelCtrl);
//      vaTemplate.push("</div>");
        // yhkim 2009.07.23 라이오 체크 vertival문제
    vaTemplate.push("'><table cellspacing='0' cellpadding='0' ");
    vaTemplate.push("@attStrBuf");
    vaTemplate.push("><tbody><tr><td style='vertical-align:top;'>")
    vaTemplate.push(vsSelectorCtrl);
    //vaTemplate.push("</td><td >");
    // yhkim2009.09.21 table td내에 span이 브라어저 내에서 위치가 바뀌는 현상
    if(this.parent.canvas.page.metadata.browser.ie > 0 && this.parent.canvas.page.metadata.browser.ie < 8)
      vaTemplate.push("</td><td style=\"padding-top:3px;\">")
    else if(this.parent.canvas.page.metadata.browser.ie > 7 || this.parent.canvas.page.metadata.browser.gecko > 0)
      vaTemplate.push("</td><td style=\"padding-bottom:3px;\">")
    vaTemplate.push(vsLabelCtrl);
    vaTemplate.push("</td></tr></tbody></table>");
      break;

    case "top" :
      vaTemplate.push("'><div style='border-style:none;border-width:0px;overflow:hidden;");
      vaTemplate.push("@cssStrBuf");  // 14
      vaTemplate.push("'>");
      vaTemplate.push(vsLabelCtrl);
      vaTemplate.push("</div>");
      vaTemplate.push("<div style='border-style:none;border-width:0px;overflow:hidden;");
      vaTemplate.push("@cssStrBuf"); //19
      vaTemplate.push("'>");
      vaTemplate.push(vsSelectorCtrl);
      vaTemplate.push("</div>");
      break;

    case "bottom" :
      vaTemplate.push("'><div style='border-style:none;border-width:0px;overflow:hidden;");
      vaTemplate.push("@cssStrBuf");  // 14
      vaTemplate.push("'>");
      vaTemplate.push(vsSelectorCtrl);
      vaTemplate.push("</div>");
      vaTemplate.push("<div style='border-style:none;border-width:0px;overflow:hidden;");
      vaTemplate.push("@cssStrBuf"); //19
      vaTemplate.push("'>");
      vaTemplate.push(vsLabelCtrl);
      vaTemplate.push("</div>");
      break;
    default :
      throw new Error("labelPos 속성 값에 오류가 있습니다.");
      break;
  }
  //yhkim 기존코드
  //vaTemplate.push("</div>");
  vaTemplate.push("</td>");
  vaTemplate.push("</tr>");
  vaTemplate.push("</tbody>");
  vaTemplate.push("</table>");
  vaTemplate.push("</div>");

  this.setSpecificAttrs();

  var vsRet = vaTemplate.join("");
  vaTemplate = null;
  this.template = null;
  return vsRet;
};
/**
 * Main Style 적용
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Item.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
  //var voTable = poCtrl.childNodes[0];
  //this.parent.setAttrCtrl("className", this.parent.className, voTable);
};

///*
//eXria.controls.xhtml.Item.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
//  var vsTextAlign = null;
//  var vsVerticalAlign = null;
//  var voStyle = poCtrl.style;
//
//  // CSS가 적용되지 않는 속성에 대한 초기값 설정(main 컨트롤)
//  var vsLabelPos = this.getAttrValue("labelPos", this.labelPos);
//  var vnWidth = this.getAttrValue("width", this.width);
//  var vnHeight = this.getAttrValue("height", this.height);
//  voStyle.height = vnHeight + "px";
//  voStyle.width = vnWidth + "px";
//
//  // 고정값 설정
//  voStyle.position = "absolute";
//  voStyle.overflow = "hidden";      // 컨트롤 영역을 벗어난 하위 요소를 안보이게 처리
//  voStyle.left = this.left + "px";
//  voStyle.top = this.top + "px";
//  poCtrl.disabled = this.disabled;
//
//  var voTable = poCtrl.childNodes[0];
//  voTable.cellPadding = "0";             // IE 와 Firefox의 동작방식이 틀려서 0으로 고정
//  voTable.cellSpacing = "0";
//  var voTBody = voTable.childNodes[0];
//  var voTr1 = null;
//  var voTd1 = null;
//  var voItemDiv1 = null;
//  var voItemDiv2 = null;
//
//  switch(vsLabelPos) {
//    case "left" :
//      voTr1 = voTBody.childNodes[0];
//      voTd1 = voTr1.childNodes[0];
//
//      voTr1.style.width = vnWidth + "px";
//      voStyle = voTd1.style;
//      voStyle.backgroundColor = this.backgroundColor;
//      voStyle.height = vnHeight + "px";
//
//      voItemDiv1 = voTd1.childNodes[0];
//      voStyle = voItemDiv1.style;
//      voStyle.overflow = "hidden";
//      voStyle.width = vnWidth + "px";
//      voItemDiv1.textAlign = vsTextAlign;
//      break;
//    case "right" :
//      voTr1 = voTBody.childNodes[0];
//      voTd1 = voTr1.childNodes[0];
//
//      voStyle = voTd1.style;
//      voStyle.width = vnWidth + "px";
//      voStyle.backgroundColor = this.backgroundColor;
//      voStyle.height = vnHeight + "px";
//
//      if(vsVerticalAlign == "middle") {
//        voStyle.verticalAlign = "middle";
//      } else if(vsVerticalAlign == "top") {
//        voStyle.verticalAlign = "top";
//      } else if(vsVerticalAlign == "bottom") {
//        voTd1.vAlign="bottom";
//        voStyle.height = vnHeight + "px";
//        voTable.height = vnHeight + "px";
//      }
//
//      voItemDiv1 = voTd1.childNodes[0];
//      voStyle = voItemDiv1.style;
//      voStyle.overflow = "hidden";
//      voStyle.width = vnWidth + "px";
//      voItemDiv1.textAlign = vsTextAlign;
//      break;
//    case "top" :
//      voTr1 = voTBody.childNodes[0];
//      voTd1 = voTr1.childNodes[0];
//
//      voStyle = voTd1.style;
//      voStyle.backgroundColor = this.backgroundColor;
//      voStyle.height = vnHeight + "px";
//
//      if(vsVerticalAlign == "middle") {
//        voStyle.verticalAlign = "middle";
//      } else if(vsVerticalAlign == "top") {
//        voStyle.verticalAlign = "top";
//      } else if(vsVerticalAlign == "bottom") {
//        voTd1.vAlign="bottom";
//        voTr1.style.height = vnHeight + "px";
//        voTable.height = vnHeight + "px";
//      }
//
//      voItemDiv1 = voTd1.childNodes[0];
//      voStyle = voItemDiv1.style;
//      voStyle.overflow = "hidden";
//      voStyle.width = vnWidth + "px";
//      voItemDiv1.textAlign = vsTextAlign;
//
//      voItemDiv2 = voTd1.childNodes[1];
//      voStyle = voItemDiv2.style;
//      voStyle.overflow = "hidden";
//      voStyle.width = vnWidth + "px";
//      voItemDiv2.textAlign = vsTextAlign;
//      break;
//    case "bottom" :
//      voTr1 = voTBody.childNodes[0];
//      voTd1 = voTr1.childNodes[0];
//
//      voStyle = voTd1.style;
//      voStyle.backgroundColor = this.backgroundColor;
//      voStyle.height = vnHeight + "px";
//
//      if(vsVerticalAlign == "middle") {
//        voStyle.verticalAlign = "middle";
//      } else if(vsVerticalAlign == "top") {
//        voStyle.verticalAlign = "top";
//      } else if(vsVerticalAlign == "bottom") {
//        voTd1.vAlign="bottom";
//        voTr1.style.height = vnHeight + "px";
//        voTable.height = vnHeight + "px";
//      }
//      voItemDiv1 = voTd1.childNodes[0];
//      voStyle = voItemDiv1.style;
//      voStyle.overflow = "hidden";
//      voStyle.width = vnWidth + "px";
//      voItemDiv1.textAlign = vsTextAlign; //"center";
//
//      voItemDiv2 = voTd1.childNodes[1];
//      voStyle = voItemDiv2.style;
//      voStyle.overflow = "hidden";
//      voStyle.width = vnWidth + "px";
//      voItemDiv2.textAlign = vsTextAlign; //"center";
//      break;
//    default :
//      throw new Error("labelPos 속성 값에 오류가 있습니다.");
//      break;
//  }
//  return poCtrl;
//};
//*/
/**
 * 개별 초기값 설정
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return poCtrl
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.Item.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;
  this["color"] = this.getAttrValue("color", this.color);
  this["backgroundColor"] = this.getAttrValue("backgroundColor", this.backgroundColor);
  this["borderColor"] = this.getAttrValue("borderColor", this.borderColor);
  this["borderStyle"] = this.getAttrValue("borderStyle", this.borderStyle);
  this["borderLeftWidth"] = this.getAttrValue("borderLeftWidth", this.borderLeftWidth);
  this["borderRightWidth"] = this.getAttrValue("borderRightWidth", this.borderRightWidth);
  this["borderTopWidth"] = this.getAttrValue("borderTopWidth", this.borderTopWidth);
  this["borderBottomWidth"] = this.getAttrValue("borderBottomWidth", this.borderBottomWidth);
  this["fontFamily"] = this.getAttrValue("fontFamily", this.fontFamily);
  this["fontSize"] = this.getAttrValue("fontSize", this.fontSize);
  this["fontStyle"] = this.getAttrValue("fontStyle", this.fontStyle);
  this["fontWeight"] = this.getAttrValue("fontWeight", this.fontWeight);
  this["labelPos"] = this.getAttrValue("labelPos", this.labelPos);
  this["verticalAlign"] = this.getAttrValue("verticalAlign", this.verticalAlign);
  this["textAlign"] = this.getAttrValue("textAlign", this.textAlign);
  //TODO
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  var voData = this.data;
  if(voData.instanceId && voData.instancePath) {
    this.text = voData.getData();
  }
};
///*
//eXria.controls.xhtml.Item.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
//  var voTable = poCtrl.childNodes[0];
//  var voTd = voTable.rows[0].cells[0];
//  var voDiv = voTd.childNodes[0];
//  var voParentItemgroupDf = this.parent.itemgroup.df;
//
//  poCtrl.setAttribute("id", this.id);
//  this.parent.setAttrCtrl("borderColor", voParentItemgroupDf.borderColor, poCtrl);
//  this.parent.setAttrCtrl("borderStyle", voParentItemgroupDf.borderStyle, poCtrl);
//  this.parent.setAttrCtrl("borderLeftWidth", voParentItemgroupDf.borderLeftWidth, poCtrl);
//  this.parent.setAttrCtrl("borderRightWidth", voParentItemgroupDf.borderRightWidth, poCtrl);
//  this.parent.setAttrCtrl("borderTopWidth", voParentItemgroupDf.borderTopWidth, poCtrl);
//  this.parent.setAttrCtrl("borderBottomWidth", voParentItemgroupDf.borderBottomWidth, poCtrl);
//  this.parent.setAttrCtrl("color", voParentItemgroupDf.color, poCtrl);
//  this.parent.setAttrCtrl("backgroundColor", voParentItemgroupDf.backgroundColor, poCtrl);
//  this.parent.setAttrCtrl("fontFamily", voParentItemgroupDf.fontFamily, poCtrl);
//  this.parent.setAttrCtrl("fontSize", voParentItemgroupDf.fontSize, poCtrl);
//  this.parent.setAttrCtrl("fontStyle", voParentItemgroupDf.fontStyle, poCtrl);
//  this.parent.setAttrCtrl("fontWeight", voParentItemgroupDf.fontWeight, poCtrl);
//
//  this.parent.setAttrCtrl("textAlign", voParentItemgroupDf.textAlign, voDiv);
//  this.parent.setAttrCtrl("verticalAlign", voParentItemgroupDf.verticalAlign, voTd);
//};
//*/
/**
 * 개별 Attrs 적용
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Item.prototype.setSpecificAttrs = function() {
  var voParent = this.parent;
  var voDf = this.df;
  var vaTemplate = this.template;
  var vaAttStrBuf = null;
  var vaCssStrBuf = null;
  var vfcSetAttStrBuf = voParent.setAttStrBuf;
  var vfcSetCssStrBuf = voParent.setCssStrBuf;

  vaAttStrBuf = [];
  if(this.disabled) vaAttStrBuf.push("disabled");
  vaTemplate[3] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.width, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.height, "px");
  if(this.disabled) vfcSetCssStrBuf(vaCssStrBuf, "color", voParent.disabledColor);
  else vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vaTemplate[5] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  // yhkim2009.09.31 table은기본적으로  위아래 2px씩 가진다.
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight-2, "px");
  vaTemplate[8] = vaCssStrBuf.join(""); //table

  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "valign", this.verticalAlign);
  //vfcSetCssStrBuf(vaCssStrBuf, "align", this.textAlign);
  //yhkim 2009.07.23 라이오 체크 vertival문제
  vfcSetAttStrBuf(vaAttStrBuf, "align", this.textAlign);
  vaTemplate[10] = vaAttStrBuf.join(""); //td

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  // yhkim2009.09.31 table의 하위 table 은 위아래 합이4px 가진다.
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight-4, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  if(this.textAlign == "left" || this.textAlign == null) vfcSetCssStrBuf(vaCssStrBuf, "padding-left", "2px");
  if(this.textAlign == "right") vfcSetCssStrBuf(vaCssStrBuf, "padding-right", "2px");
//  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.verticalAlign);
  vaTemplate[12] = vaCssStrBuf.join(""); //td

  vaCssStrBuf = [];
  switch(this.labelPos) {
  case "left" :
  case "right" :
//    vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
//    vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
//    vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
    //vaTemplate[14] = vaCssStrBuf.join(""); //div1
    // yhkim 2009.07.23 라이오 체크 vertival문제
    vaTemplate[14] = vaTemplate[10];
    break;
  case "top" :
  case "bottom" :
//    vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.width, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
//    vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
    vaTemplate[19] = vaCssStrBuf.join(""); //div1
    break;
  }

  vaCssStrBuf = null;
};
/**
 * 아이템 새로고침
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Item.prototype.refresh = function(poDocument) {
  //this.createCtrl();
};
/**
 * 아이템의 실체화 객체를 반환합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document(생략가능)
 * @return 아이템 실체화 객체
 * @type HTMLInput(radio|checkbox)
 * @private
 */
eXria.controls.xhtml.Item.prototype.getItemCtrl = function(poDocument) {
  var voParent = this.parent;
  if(poDocument == null) poDocument = voParent.document;
  var voCtrl = poDocument.getElementById(this.id);
  var voTable = voCtrl.childNodes[0];
  var vaDiv = voTable.rows[0].cells[0].childNodes;
  var voDiv = null;
  var voSubCtrl = null;
  for(var i = 0; i < vaDiv.length; i++) {
    //voSubCtrl = vaDiv[i].childNodes[0];
    //if(voSubCtrl.nodeType == 1) {
    //  break;
    //}
    voDiv = vaDiv[i];
    voSubCtrl = voDiv.getElementsByTagName("input")[0];
    if(voSubCtrl) {
      break;
    }
  }

  return voSubCtrl;
};
/**
 * 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 디폴트 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.Item.prototype.getAttrValue = function(psAttrName, psAttrValue) {
  if (psAttrValue != null) return psAttrValue;
  else return this.getSpecificDefaultValue(psAttrName);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.Item.prototype.getSpecificDefaultValue = function(psAttrName) {
  var voDf = null;
  switch(psAttrName) {
  case "fontFamily" :
  case "fontStyle" :
  case "color" :
  case "fontSize" :
  case "fontWeight" :
    voDf = this.parent;
    break;
  default :
    voDf = this.parent.itemgroup;
  }
  var vsDefaultValue = voDf[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;
};
/**
 * 아이템의 스타일 속성값을 일괄적으로 변경합니다.
 * @param {Object} poStyleObject 변경될 속성값을 담은 오브젝트
 * @private
 */
eXria.controls.xhtml.Item.prototype.setItemStyle = function(poStyleObject) {
  var vsAttr = null;
  for(vsAttr in poStyleObject) {
    this[vsAttr] = poStyleObject[vsAttr];
  }
};
/**
 * 아이템의 innerHTML 요소에 이벤트 핸들러를 추가합니다.
 * @param {String} psFuncName 실질적으로 이벤트를 처리할 클래스 내부 메소드명
 * @private
 */
eXria.controls.xhtml.Item.prototype.getEHandler = function(psFuncName) {
  var voParent = this.parent;
  var vsParentId = voParent.id
  var vaStrBuf = [];
  vaStrBuf.push("var e=null;")
  vaStrBuf.push("if(arguments[0]) e=arguments[0];");
  vaStrBuf.push("page.getControl('");
  vaStrBuf.push(vsParentId);
  vaStrBuf.push("').getItemByVal(&quot;");
  vaStrBuf.push(this.value.replace(/"/g, "\\&quot;"));
  vaStrBuf.push("&quot;).");
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("(e);");

  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * 라벨 클릭시에 이벤트를 처리합니다.
 * @param {WindowEvent} e 윈도우 이벤트
 * @private
 */
eXria.controls.xhtml.Item.prototype.clickLabel = function(e) {
  var voParent = this.parent;
  if(this.disabled) {
    voParent.eventObjectType = null;
    voParent.eventObject = null;
    return;
  }
  voParent.eventObjectType = "item";
  voParent.eventObject = this;

  voSelectorCtrl = this.getItemCtrl();
  //voSelectorCtrl.click();
  if(voParent == "RadioButton") {
    voSelectorCtrl.checked = true;
    if(this.selected != true) voParent.changed = true;
  } else {
    if(voSelectorCtrl.checked) voSelectorCtrl.checked = false;
    else voSelectorCtrl.checked = true;
    voParent.changed = true;
  }
};
/**
 * selector onchange시에 이벤트를 처리합니다.
 * @param {WindowEvent} e 윈도우 이벤트
 * @private
 */
eXria.controls.xhtml.Item.prototype.checkSelector = function(e) {
  var voParent = this.parent;
  voParent.eventObjectType = "item";
  voParent.eventObject = this;
  if(voParent == "RadioButton") {
    if(this.selected != true) voParent.changed = true;
  } else {
    voParent.changed = true;
  }
};
/**
 * selector의 onmouseover시에 이벤트를 처리합니다.
 * @param {WindowEvent} e 윈도우 이벤트
 * @private
 */
eXria.controls.xhtml.Item.prototype.changeCursor = function(e) {
  var voParent = this.parent;
  var voEvent = new eXria.event.Event(e, voParent.window);
  var voTarget = voEvent.target;
  if(voTarget) {
    if(voParent.itemgroup.cursor)
      voTarget.style.cursor = voParent.itemgroup.cursor;
  }
};
/**
 * selector의 onmouseout시에 이벤트를 처리합니다.
 * @param {WindowEvent} e 윈도우 이벤트
 * @private
 */
eXria.controls.xhtml.Item.prototype.restoreCursor = function(e) {
  var voParent = this.parent;
  var voEvent = new eXria.event.Event(e, voParent.window);
  var voTarget = voEvent.target;
  if(voTarget) {
    if(voParent.cursor)
      voTarget.style.cursor = voParent.cursor;
  }
};
/**
 * Radio, Checkbox Button 클래스의 라벨 속성 저장 오브젝트입니다.
 * @type Object
 * @constructor
 * @private
 */
eXria.controls.xhtml.Select_label = function(){
  /**
   * 아이템 라벨의 넓이
   * @type number
   */
  this.width = null;

  /**
   * 아이템 라벨의 높이
   * @type number
   */
  this.height = null;

  /**
   * 아이템 라벨의 배경색
   * @type String
   */
  this.backgroundColor = null;

  /**
   * 아이템 라벨의 폰트 크기
   * @type number
   */
  this.fontSize = null;

  /**
   * 아이템 라벨에 설정 값
   * @type String
   */
  this.value = null;
};
/**
 * ignore
 */
eXria.controls.xhtml.Select_label.prototype.create = function(poParent, poCtrl, pnLeft, pnTop, poDocument) {
  var voDocument = this.document;
  var voSubCtrl = voDocument.createElement("span");
  var voSubTextCtrl = poDocument.createTextNode(eXria.controls.xhtml.Util.parseLang(poParent.text));
  voSubCtrl.appendChild(voSubTextCtrl);
  return voSubCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select_label.prototype.getInnerHTML = function(poParent) {
  var vsClass = "";
  if(poParent.parent) {
    vsClass = poParent.parent.getCSSClass(poParent.parent, 1, "itemgroup");
  var vsUserClass = poParent.parent.getCSSClass(poParent.parent, 1);
  if(vsUserClass) vsClass = vsClass + " " + vsUserClass;
  }

  var vsStyle = "";
  if(poParent.color) vsStyle = vsStyle + "color:" + poParent.color + ";";
  if(poParent.fontStyle) vsStyle = vsStyle + "font-style:" + poParent.fontStyle + ";";
  if(poParent.fontSize) vsStyle = vsStyle + "font-size:" + poParent.fontSize + "pt;";
  if(poParent.fontFamily) vsStyle = vsStyle + "font-family:" + poParent.fontFamily + ";";
  if(poParent.fontWeight) vsStyle = vsStyle + "font-weight:" + poParent.fontWeight + ";";

  var vaLabelStrBuf = [];
  vaLabelStrBuf.push("<span class='" + vsClass + "' style= \"" + vsStyle + "padding-left:3px;padding-right:3px;\" onclick=\"");
  vaLabelStrBuf.push(poParent.getEHandler("clickLabel"));
  vaLabelStrBuf.push("\"");
  vaLabelStrBuf.push(" onmouseover=\"")
  vaLabelStrBuf.push(poParent.getEHandler("changeCursor"));
  vaLabelStrBuf.push("\"");
  vaLabelStrBuf.push(" onmouseout=\"")
  vaLabelStrBuf.push(poParent.getEHandler("restoreCursor"));
  vaLabelStrBuf.push("\"/>");
  vaLabelStrBuf.push(eXria.controls.xhtml.Util.parseLang(poParent.text));
  vaLabelStrBuf.push("</span>");

  var vsRet = vaLabelStrBuf.join("");
  vaLabelStrBuf = null;
  return vsRet;
};
/**
 * Radio, Checkbox Button 클래스의 선택버튼 속성 저장 오브젝트입니다.
 * @type Object
 * @constructor
 * @private
 */
eXria.controls.xhtml.Select_selector = function(){
  /**
   * 아이템 선택버튼의 넓이
   * @type number
   */
  this.width = null;

  /**
   * 아이템 선택버튼의 높이
   * @type number
   */
  this.height = null;

  /**
   * 아이템 선택버튼의 배경색
   * @type String
   */
  this.backgroundColor = null;

  /**
   * 아이템 선택버튼의 폰트색상
   * @type String
   */
  this.color = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Select_selector.prototype.create = function(poParent, poCtrl, pnLeft, pnTop, poDocument) {
  var voSubCtrl = null;
  if(poParent.type == "none" || poParent.type == null) {
    return null;
  } else {
    if(poParent.parent) {
      vsClass = poParent.parent.getCSSClass(poParent.parent, 1, "itemgroup");
      var vsUserClass = poParent.parent.getCSSClass(poParent.parent, 1);
      if(vsUserClass) vsClass = vsClass + " " + vsUserClass;
    }

    if(poParent.type == "radio") {
      try {   // TODO : ie 브라우저 여부를 체크하는 구문으로 수정할 것
        voSubCtrl = poDocument.createElement("<input class='" + vsClass + "' type='radio' name='radio_item_" + poParent.parent.id + "'>");
      } catch(e) {
        voSubCtrl = poDocument.createElement("input");
        voSubCtrl.setAttribute("name", "radio_item_" + poParent.parent.id);
        voSubCtrl.setAttribute("type", "radio");
      }
      poParent.parent.setAttrCtrl("disabled", poParent.disabled, voSubCtrl);
    }
    else if(poParent.type == "checkbox") {
      try {   // TODO : ie 브라우저 여부를 체크하는 구문으로 수정할 것
        voSubCtrl = poDocument.createElement("<input class='" + vsClass + "' type='checkbox' name='checkbox_item_" + poParent.parent.id + "'>");
      } catch(e) {
        voSubCtrl = poDocument.createElement("input");
        voSubCtrl.setAttribute("name", "checkbox_item_" + poParent.parent.id);
        voSubCtrl.setAttribute("type", "checkbox");
      }
      poParent.parent.setAttrCtrl("disabled", poParent.disabled, voSubCtrl);
    }
    return voSubCtrl;
  }
};
/**
 * 선택자의 HTML 문자열 반환합니다.
 * @return 선택자의 HTML 문자열
 * @type String
 * @private
 */
eXria.controls.xhtml.Select_selector.prototype.getInnerHTML = function(poParent) {
  var vaSelectorStrBuf = [];

  if(poParent.type == "none" || poParent.type == null) {
    return "";
  } else {
    if(poParent.parent) {
      vsClass = poParent.parent.getCSSClass(poParent.parent, 1, "itemgroup");
      var vsUserClass = poParent.parent.getCSSClass(poParent.parent, 1);
      if(vsUserClass) vsClass = vsClass + " " + vsUserClass;
    }

    vaSelectorStrBuf.push("<input class='" + vsClass + "' type='");
    if(poParent.type == "radio") {
      vaSelectorStrBuf.push("radio");
      vaSelectorStrBuf.push("' name='radio_item_");
    }
    else if(poParent.type == "checkbox") {
      vaSelectorStrBuf.push("checkbox");
      vaSelectorStrBuf.push("' name='checkbox_item_");
    }

    vaSelectorStrBuf.push(poParent.parent.id);
    vaSelectorStrBuf.push("'");
    if(poParent.disabled) {
      vaSelectorStrBuf.push(" disabled=true");
    }
    if(poParent.selected) {
      vaSelectorStrBuf.push(" checked=true");
    }

  vaSelectorStrBuf.push(" hideFocus=true");

    vaSelectorStrBuf.push(" onclick=\"")
    vaSelectorStrBuf.push(poParent.getEHandler("checkSelector"));
    vaSelectorStrBuf.push("\"");
    vaSelectorStrBuf.push(" onmouseover=\"")
    vaSelectorStrBuf.push(poParent.getEHandler("changeCursor"));
    vaSelectorStrBuf.push("\"");
    vaSelectorStrBuf.push(" onmouseout=\"")
    vaSelectorStrBuf.push(poParent.getEHandler("restoreCursor"));
    vaSelectorStrBuf.push("\"/>");

    var vsRet = vaSelectorStrBuf.join("");
    vaSelectorStrBuf = null;
    return vsRet;
  }
};

