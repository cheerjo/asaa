/**
 * @fileoverview
 * Concreate xhtml Label(XHTML Label 컨트롤)
 * @author 조영진, 박찬수
 */

/**
 * @class 텍스트필드를 화면상에 보여주는 컨트롤을 생성하는 class입니다. <br />
 * InputBox등과는 다르게 직접적인 데이터의 에디팅이 불가능합니다.<br />
 * XHTML Label Contorl.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Label 객체
 * @type eXria.controls.xhtml.Label
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */

eXria.controls.xhtml.Label = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 텍스트에 줄을 넣을때.
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 컨트롤에 설정된 값.
   * @type String
   */
  this.value  = null;
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflow = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflowX = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflowY = null;
  /**
   * 자동줄바꿈 여부.
   * @type Boolean
   */
  this.wordWrap = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @ignore
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @ignore
   */
  this.innerHeight = this.height;
  /**
   * 컨트롤의 텍스트 패딩
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤의 상단 패딩
   * @type Number
   * @private
   */
  this.paddingTop = null;
  /**
   * 컨트롤의 우측 패딩
   * @type Number
   * @private
   */
  this.paddingRight = null;
  /**
   * 컨트롤의 하단 패딩
   * @type Number
   * @private
   */
  this.paddingBottom = null;
  /**
   * 컨트롤의 좌측 패딩
   * @type Number
   * @private
   */
  this.paddingLeft = null;
  /**
   * 컨트롤이 디스플레이 되는 document객체 지정
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  /**
   * 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;

  /**
  * @private
  */
  this.divOffsetHeight = null;
  /**
  * @private
  */
  this.subElement = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Label);
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  voCtrl["accesskey"] = this.accessKey;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;

  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<div class=\"" + vsClass + "\" style=\"");
  vaTemplate.push("@cssStrBuf"); //0
  vaTemplate.push("\">&nbsp;</div>");
  vaTemplate.push("<span style=\"");
  vaTemplate.push("@cssStrBuf"); //1
  vaTemplate.push("\"/>")

  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.refreshTemplate = null;
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    this.innerHTML = voUserAttr.innerHTML;
    if(voUserAttr.useHtmlTag != null &&  voUserAttr.useHtmlTag === true){
      this.value = "";
      this.innerHTML = this.data.getData();
    }
    this.funcNec = voUserAttr.funcNec;
    this.labelName = voUserAttr.labelName;
    this.type = voUserAttr.type;
  }
  if(this.type == "SPLITTER") {
    if(this.height > this.width) this.type = "HSPLITTER";
    else this.type = "VSPLITTER";
    this.ltCtls = voUserAttr.ltCtls ? voUserAttr.ltCtls : [];
    this.rbCtls = voUserAttr.rbCtls ? voUserAttr.rbCtls : [];
  }
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.verticalAlign = this.getAttrValue("verticalAlign", this.verticalAlign);
  this.value = this.getAttrValue("value", this.value);
  this.imagePushed = this.getAttrValue("imagePushed", this.imagePushed);
  this.imageFocused = this.getAttrValue("imageFocused", this.imageFocused);
  this.imageMouseover = this.getAttrValue("imageMouseover", this.imageMouseover);
  this.wordWrap = this.getAttrValue("wordWrap", this.wordWrap);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  // 반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  // 단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;outline-style:none;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
//  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");

  //외각DIV
  //2010.06.03
  //내부DIV 영역에 스크롤이 생성되는 경우를 막기 위해
  //visible 과 hidden 이 아닌경우에는 auto가 되게 수정
  if(!!this.overflow && !!(this.overflow === "scroll" || this.overflow === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "auto");
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);

  if(!!this.overflowX && !!(this.overflowX === "scroll" || this.overflowX === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", auto);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);

  if(!!this.overflowY && !!(this.overflowY === "scroll" || this.overflowY === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);


  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);

  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;position:absolute;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else{
    vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
    //2010.06.01
    //영문자 개행 관련 word-wrap 추가
    vfcSetCssStrBuf(vaCssStrBuf, "word-wrap","break-word");
  }

  //2010.06.03
  //내부 div 스크롤 관련 버그 수정
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(1)] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");

  voIndexMap.clear();
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
  this.templateIndexMap = null;

  this.setSubElement(poDocument);
};
/**
 * @ignroe
 */
eXria.controls.xhtml.Label.prototype.setSpecificEvents = function(poCtrl) {
  if(this.type != "HSPLITTER" && this.type != "VSPLITTER") return;
  this.movable = true;
  this.onMove = function(e) {
    var voCtrl = this.getCtrl();
    var voParentNode = voCtrl.parentNode;
    var voPaneCtrl = this.paneHandler.getCtrl();
    if(voCtrl == null || voPaneCtrl == null) {
        return;
    }

    var voStyle = voPaneCtrl.style;

    var voEvent = new eXria.event.Event(e, this.window);
    var voTarget = voEvent.target;
    if(voTarget == voPaneCtrl || voTarget == voPaneCtrl.parentNode) {
    } else {
      return;
    }
    var vnMouseX = voEvent.e.clientX; // - this.clientAbsLeft;
    var vnMouseY = voEvent.e.clientY; // - this.clientAbsTop;

    var vnNewLeft = vnMouseX + this.leftOffset;
    var vnNewTop = vnMouseY + this.topOffset;

    if(voParentNode.style.left == null || voParentNode.style.left == "") voParentNode.style.left = 0;
    if(voParentNode.style.top == null || voParentNode.style.top == "") voParentNode.style.top = 0;
    if(this.type == "HSPLITTER") voStyle.left = vnNewLeft + "px";
    else voStyle.top = vnNewTop + "px";
  };

  this.stopMove = function(e) {
    if (this.disabled == true) { return; }

    var voDocument = this.document;
    var voCtrl = this.getCtrl();
    var voPane = this.paneHandler.getCtrl();
    var voPaneStyle = voPane.style;

    var voParent = this.parent;
    if(voParent == null) voParent = this.canvas;
    var vnOldPos = null;
    if(this.type == "HSPLITTER") {
      vnOldPos = this.left;
      this.left = parseInt(voPaneStyle.left);
      if(this.left < 0) this.left = 0;
      else if(this.left + this.width > voParent.width) this.left = voParent.width - this.width;
      this.resizeHorz(this.left - vnOldPos);
    } else {
      vnOldPos = this.top;
      this.top = parseInt(voPaneStyle.top);
      if(this.top < 0) this.top = 0;
      else if(this.top + this.height > voParent.height) this.top = voParent.height - this.height;
      this.resizeVert(this.top - vnOldPos);
    }
    this.refresh();
    this.paneHandler.removePane();
    this.glassPane.removeCtrl();
    // Check
    voDocument.body.style.cursor = 'auto';
    voCtrl.style.cursor = this.backupCtrlCsr;

    voPane.onmousemove = null;
    voPane.onmouseup = null;
    voDocument.onmousemove = null;
    voDocument.onmouseup = null;
    if (typeof voPane.onselectstart != "undefined") {
      voPane.onselectstart = null;
    } else {
      voPane.onmousedown = null;
    }

    this.mode = null;
    this.leftOffset = -1;
    this.topOffset = -1;
    this.rightOffset = -1;
    this.bottomOffset = -1;
  };
};
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Label.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.div = this.getSubCtrl("div", voCtrl, poDocument);
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voDivCtrl = this.subElement.div;
  var voSpanCtrl = this.subElement.span;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;

  if(this.className) voDivCtrl.className = this.getCSSClass(this, 1);

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");

  //외각DIV
  //2010.06.03
  //내부DIV 영역에 스크롤이 생성되는 경우를 막기 위해
  //visible 과 hidden 이 아닌경우에는 auto가 되게 수정
  if(!!this.overflow && !!(this.overflow === "scroll" || this.overflow === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "auto");
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);

  if(!!this.overflowX && !!(this.overflowX === "scroll" || this.overflowX === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", auto);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);

  if(!!this.overflowY && !!(this.overflowY === "scroll" || this.overflowY === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);

  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;position:absolute;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else{
    vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
    //2010.06.01
    //영문자 개행 관련 word-wrap 추가
    vfcSetCssStrBuf(vaCssStrBuf, "word-wrap","break-word");
  }

  //2010.06.03
  //내부 div 스크롤 관련 버그 수정
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  voDivCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  voSpanCtrl.style.cssText = vaCssStrBuf.join("");
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voDf = this.df;
  var voDiv = this.subElement.div;
  var voSpan = this.subElement.span;

  switch(psAttrName) {
  case "width" :
    var vnWidth = this.innerWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    if(vnWidth < 0) vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voDiv);
    //var vsLabel = this.getWordWrapped(this.value, voSpan);
    var vsLabel = this.value;
    this.setText(voDiv, vsLabel);
    this.setVerticalAlign(voDiv, poCtrl, this.verticalAlign);
    break;
  case "height" :
    this.setVerticalAlign(voDiv, poCtrl, this.verticalAlign);
    break;
  }
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Label.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voDiv = this.subElement.div;
  var voSpan = this.subElement.span;
  var vaAttrName = psAttrName.split(".");
  var voDf = this.df;
  this.setAttr(psAttrName, psAttrValue);
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    voCtrl.style[psAttrName] = psAttrValue + "px";
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "padding" :
    this.paddingTop = this.padding;
    this.paddingRight = this.padding;
    this.paddingBottom = this.padding;
    this.paddingLeft = this.padding;
    this.setAttrCtrl("paddingTop", this.paddingTop + "px", voDiv);
    this.setAttrCtrl("paddingRight", this.paddingRight + "px", voDiv);
    this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voDiv);
    this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voDiv);
    var vnWidth = this.innerWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    this.setAttrCtrl("Width", vnWidth, voDiv);
    this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
    break;
  case "paddingTop" :
  case "paddingBottom" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voDiv);
    this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
    break;
  case "paddingLeft" :
  case "paddingRight" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voDiv);
    var vnWidth = this.innerWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    this.setAttrCtrl("Width", vnWidth, voDiv);
    break;
  break;
  case "value" :
    this.setValue(psAttrValue);
    break;
  case "outerClassName" :
  case "className" :
    this.refresh(poDocument);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * 데이타 로딩완료 후에 처리작업을 수행합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Label.prototype.loadComplete = function(poDocument) {
  if(this.value == null) this.value = "";
  if(this.value == "" && this.innerHTML) {
    this.subElement.div.innerHTML = this.innerHTML;
    this.setVerticalAlign(this.subElement.div, this.ctrl, this.verticalAlign);
  } else {
    this.setValue(this.value);
  }
};
/**
 * loadData.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Label.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;

  if(!!this.innerHTML) this.value = "";
  else this.value = this.data.getData();

//  this.value = this.data.getData();
//  this.df.value = this.value;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
  this.loadComplete(poDocument);
};
/**
 * 컨트롤에 값을 설정합니다.
 * @param {String} psLabel 컨트롤에 설정할 라벨 값
 */
eXria.controls.xhtml.Label.prototype.setValue = function(psLabel) {
  var voCtrl = this.ctrl;
  var voDiv = this.subElement.div;
  var voSpan = this.subElement.span;
  var voDf = this.df;
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psLabel) {
    vbChanged = true;
  }
  this.onchangeInitValue = psLabel;
  this.value = psLabel;
//  this.df.value = psLabel;
  if(vbChanged) this.data.setData(this.value);

  //var vsLabel = this.getWordWrapped(psLabel, voSpan);
  var vsLabel = "" + psLabel;
  if(this.funcNec) {
    this.funcNec(this, voDiv, vsLabel);
  } else {
    this.setText(voDiv, vsLabel);
  }
  this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
  var vnWidth = voCtrl.offsetWidth - this.borderLeftWidth - this.borderRightWidth;;
  var vnPaddingLeft = parseInt(this.getStyleCurrentValue(voDiv, "padding-left", "paddingLeft"), 10);
  var vnPaddingRight = parseInt(this.getStyleCurrentValue(voDiv, "padding-right", "paddingRight"), 10);
  if(vnPaddingLeft > 0 || vnPaddingRight > 0) {
  if(vnWidth > 0)
      this.setAttrCtrl("width", vnWidth - (vnPaddingRight+vnPaddingLeft), this.subElement.div);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.getWordWrapped = function(psLabel, poSpan) {
  var voDf = this.df;
  psLabel = eXria.controls.xhtml.Util.parseLang(psLabel);
  var vsLabel = "";
  if(psLabel != null) {
    if(this.wordWrap == false) {
      //var vnStrLen = Math.round(vsLabel.length * this.fontSize / 0.75); //pt -> px : pt / 0.75
      //voSpan.innerHTML = psLabel;
      //this.setAttrCtrl("width", voSpan.offsetWidth, voDiv);
      vsLabel = psLabel;
    } else {
      var voIdxCollection = new eXria.data.ArrayCollection();
      var vnSt = 0;
      for(var i = 1; i < psLabel.length; i++) {
        poSpan.innerHTML = psLabel.substring(vnSt, i);
        var vnWidth = this.innerWidth;
        if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
        if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
        if(poSpan.offsetWidth > vnWidth) {
          vnSt = i - 1;
          voIdxCollection.add(vnSt);
        } else if(psLabel.substring(vnSt, i).indexOf("\n") != -1) {
          vnSt = i - 1;
          psLabel = psLabel.substring(0, vnSt) + psLabel.substring(vnSt + 1);
          voIdxCollection.add(vnSt)
          i--;
        }
      }
      var voIterator = voIdxCollection.iterator();
      vnSt = 0;
      var vnIdx = 0;
      while(voIterator.hasNext()) {
        vnIdx = voIterator.next();
        vsLabel += psLabel.substring(vnSt, vnIdx) + "\n";
        vnSt = vnIdx;
      }
      vsLabel += psLabel.substring(vnSt);
    }
  }
  return vsLabel;
};
/**
 * 컨트롤에 할당된 값을 반환합니다.
 * @return 컨트롤에 할당된 값
 * @type String
 */
eXria.controls.xhtml.Label.prototype.getValue = function() {
  return this.value;
};
/**
 * 컨트롤 텍스트 수직정렬을 새로고침 합니다.
 */
eXria.controls.xhtml.Label.prototype.refreshVerticalAlign = function() {
  var voCtrl = this.ctrl;
  if(voCtrl == null) return;
  var voDf = this.df;
  var voDiv = this.subElement.div;
  this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.Label.prototype.getSpecificDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.Label[psAttrName];
  if(vsDefaultValue === undefined) {
    return null;
  }
  if((psAttrName == "backgroundImage")
  && vsDefaultValue != null) {
    if(vsDefaultValue.indexOf("http://") != -1) {
      vsDefaultValue = "url(" + this.canvas.page.metadata.resourceBaseUrl + vsDefaultValue + ")";
    } else {
      vsDefaultValue = "url(" + vsDefaultValue + ")";
    }
  }
  return vsDefaultValue;
};
/** Label 컨트롤의 Vertical Align을 설정한다
 * @private
 */
// IE6의 예외 처리문제로 추가 되었으며 UIControl에서 if..else문대신 재정의 형태로 함
eXria.controls.xhtml.Label.prototype.setVerticalAlign = function(poCtrl, poParent, psVAlign) {
  if(poCtrl.offsetHeight !== 0)
    this.divOffsetHeight = poCtrl.offsetHeight;

  if(!this.divOffsetHeight)
  this.divOffsetHeight = 0;

  var vnHeight = this.divOffsetHeight;

  if(this.canvas.page.metadata.browser.ie == 6) {
    var voFont = this.getStyleCurrentValue(poCtrl, "font-size", "fontSize");
    vnHeight = parseInt(voFont);
    vnHeight = vnHeight * 1.333;
    // IE6에서  특정 높이보다 작아지면 높이를 제대로 못가져오는 문제로 font-size로 설정하게 했으나
    // 멀티라인처럼 높이가 커진경우에는 원래 경우대로 하게끔 한다.
    if(this.divOffsetHeight > vnHeight) vnHeight = this.divOffsetHeight;
  }
  if(psVAlign == null) psVAlign = "middle";
  var vnParentHeight = poParent.style.height;
  if(vnParentHeight == "") vnParentHeight = "0";
  vnParentHeight = parseInt(vnParentHeight);
  var vnPadding = vnParentHeight - vnHeight;

  //2010.06.01
  //아래 로직이 있으면 스크롤이 중첩되서 생성되고
  //VerticalAlign 이 middle로 강제로 고정되는 경우가발생 그래서 주석 처리
  //if(vnPadding < 0) vnPadding = 0;

  switch(psVAlign) {
  case "top" :
    poCtrl.style.top = "0px";
    poCtrl.style.bottom = "";
    break;
  case "bottom" :
    poCtrl.style.top = ""; //(vnParentHeight - vnPadding)
    poCtrl.style.bottom = "0px";
    break;
  case "middle" :
    var vnPadding = vnPadding / 2;

    //2010.06.01
    //아래 로직이 있으면 스크롤이 중첩되서 생성되고
    //VerticalAlign 이 middle로 강제로 고정되는 경우가발생 그래서 주석 처리
    //if(vnParentHeight < vnHeight) vnPadding = 0;

    poCtrl.style.top = vnPadding + "px";
    poCtrl.style.bottom = "";
    break;
  }
};
/**
 * Label의 div에 포커스를 사용
 * @private
 */
eXria.controls.xhtml.Label.prototype.dofocus = function() {
  this.ctrl.focus();
};
/**
 * 좌우 splitter에 의한 관련 컨트롤들의 위치를 재설정 해주는 메소드
 * @param {Number} pnOffset splitter의 위치 이동 편차
 */
eXria.controls.xhtml.Label.prototype.resizeHorz = function(pnOffset) {
  if(pnOffset == 0) return;
  var voPage = this.canvas.page;
  var vaLeftCtls = this.ltCtls;
  var vaRightCtls = this.rbCtls;
  var vnSize = 0;
  var vcCtl = null;
  var vnWidth = null;
  vnSize = vaLeftCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaLeftCtls[i]);
    if(vcCtl.rWidth === undefined) vcCtl.rWidth = vcCtl.width;
    vnWidth = vcCtl.rWidth + pnOffset;
    vcCtl.rWidth = vnWidth;
    if(vnWidth < 0) vnWidth = 0;
    vcCtl.applyAttr("width", vnWidth);
  }
  vnSize = vaRightCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaRightCtls[i]);
    vcCtl.left = vcCtl.left + pnOffset;
    if(vcCtl.rWidth === undefined) vcCtl.rWidth = vcCtl.width;
    vnWidth = vcCtl.rWidth - pnOffset;
    vcCtl.rWidth = vnWidth;
    if(vnWidth < 0) vnWidth = 0;
    vcCtl.width = vnWidth;
    vcCtl.refresh(null, null, true);
  }
};
/**
 * 상하 splitter에 의한 관련 컨트롤들의 위치를 재설정 해주는 메소드
 * @param {Number} pnOffset splitter의 위치 이동 편차
 */
eXria.controls.xhtml.Label.prototype.resizeVert = function(pnOffset) {
  if(pnOffset == 0) return;
  var voPage = this.canvas.page;
  var vaUpperCtls = this.ltCtls;
  var vaLowerCtls = this.rbCtls;
  var vnSize = 0;
  var vcCtl = null;
  vnSize = vaUpperCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaUpperCtls[i]);
    vcCtl.applyAttr("height", vcCtl.height + pnOffset);
  }
  vnSize = vaLowerCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaLowerCtls[i]);
    vcCtl.top = vcCtl.top + pnOffset;
    vcCtl.height = vcCtl.height - pnOffset;
    vcCtl.refresh(null, null, true);
  }
};
/**
 * @
 */
eXria.controls.xhtml.Label.prototype.atdblclick = function(poEvent) {
  if(this.type != "HSPLITTER" && this.type != "VSPLITTER") return;
  if(this.type == "HSPLITTER") {
    if(this.left != 0) {
      this.orgLeft = this.left;
      this.left = 0;
      this.refresh();
      this.resizeHorz(-this.orgLeft);
    } else {
      this.left = this.orgLeft;
      this.refresh();
      this.resizeHorz(this.left);
    }
  } else {
    if(this.top != 0) {
      this.orgTop = this.top;
      this.top = 0;
      this.refresh();
      this.resizeVert(-this.orgTop);
    } else {
      this.top = this.orgTop;
      this.refresh();
      this.resizeVert(this.top);
    }
  }
};
/**
 * 클래스 명을 반환합니다.
 * @return "Label"
 * @type String
 */
eXria.controls.xhtml.Label.prototype.toString = function() {
  return "Label";
};
