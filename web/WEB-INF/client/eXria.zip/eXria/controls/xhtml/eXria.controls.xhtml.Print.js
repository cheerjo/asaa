/**
 * @fileoverview
 * Concreate xhtml Print(XHTML 컨트롤의 프린트 담당 클래스)
 * @author 조영진
 */

/**
 * @class Concreate xhtml Print.<br>
 * XHTML 컨트롤의 프린트 담당 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.UIControl} poControl 프린트 대상 컨트롤 객체
 * @return 새로운 eXria.controls.xhtml.Print 객체
 * @type eXria.controls.xhtml.Print
 * @constructor
 * @private
 */
eXria.controls.xhtml.Print = function(poControl) {
  /**
   * 프린트 시 적용될 css파일명.
   * @type String
   */
  this.css = null;
  /**
   * 반복되는 프린트 출력 요소간의 상하 여백.
   * @type Number
   */
  this.formSpacing = null;
  /**
   * 출력용지와 출력물간의 상단 여백.
   * @type Number
   */
  this.marginTop = null;
  /**
   * 출력용지와 출력물간의 우측 여백.
   * @type Number
   */
  this.marginRight = null;
  /**
   * 출력용지와 출력물간의 하단 여백.
   * @type Number
   */
  this.marginBottom = null;
  /**
   * 출력용지와 출력물간의 좌측 여백.
   * @type Number
   */
  this.marginLeft = null;
  /**
   * 프린트 대상 컨트롤 객체.
   * @private
   */
  this.control = poControl;
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 용지의 가로길이(A4, 72dpi기준).
   * @type Number
   * @private
   */
  this.pageWidth = Math.floor(210 * 72 / 25.4);
  /**
   * 용지의 세로길이(A4, 72dpi기준).
   * @type Number
   * @private
   */
  this.pageHeight = Math.floor(297 * 72 / 25.4);
  /**
   * 리포트 헤더.<br>
   * 전체 출력물에서의 겉 페이지 내용을 담당하는 오브젝트.
   * @type eXria.controls.xhtml.HeaderFooter
   */
  this.reportHeader = null;
  /**
   * 리포트 footer.<br>
   * 전체 출력물에서의 마무리 페이지 내용을 담당하는 오브젝트.
   * @type eXria.controls.xhtml.HeaderFooter
   */
  this.reportFooter = null;
  /**
   * 페이지 헤더.<br>
   * 출력물의 각 페이지에서 머리말 부분 담당하는 오브젝트.
   * @type eXria.controls.xhtml.HeaderFooter
   */
  this.pageHeader = null;
  /**
   * 페이지 footer.<br>
   * 출력물의 각 페이지에서 꼬리말 부분 담당하는 오브젝트.
   * @type eXria.controls.xhtml.HeaderFooter
   */
  this.pageFooter = null;
  /**
   * Data 연동 객체(노드 셋 연동).
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(poControl);
};
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * 프린트 오브젝트 생성.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.Print.prototype.create = function(poDocument) {
  this.document = poDocument;

  this.setDefault(poDocument);
  this.setAttr(poDocument);

  this.document = poDocument;
};
/**
 * 디폴트 속성 설정
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Print.prototype.setDefault = function(poDocument) {
  //xhtml.UIControls의 this.setUIGeneralDefault에 border설정부분이 있어 초기화 필요
  this.df = {};
  var voDf = this.df;
  voDf.css = this.getAttrValue("css", this.css);
  voDf.marginLeft = this.getAttrValue("marginLeft", this.marginLeft);
  voDf.marginTop = this.getAttrValue("marginTop", this.marginTop);
  voDf.marginRight = this.getAttrValue("marginRight", this.marginRight);
  voDf.marginBottom = this.getAttrValue("marginBottom", this.marginBottom);
  voDf.formSpacing = this.getAttrValue("formSpacing", this.formSpacing);

};
/**
 * 속성 설정
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Print.prototype.setAttr = function(poDocument) {

};
/**
 * 디폴트 속성값을 구함.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 디폴트 속성값
 * @type String|Number
 * @private
 */
eXria.controls.xhtml.Print.prototype.getAttrValue = function(psAttrName, psAttrValue) {
  if(psAttrValue != null) {
    return psAttrValue;
  } else {
    var vsAttrValue = this.getSpecificDefaultValue(psAttrName);
    return vsAttrValue;
  }
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 */
eXria.controls.xhtml.Print.prototype.getSpecificDefaultValue = function(psAttr) {
  var vsDefaultValue = eXria.controls.xhtml.Default.Print[psAttrName];
  if(vsDefaultValue === undefined) {
    return null;
  }
  return vsDefaultValue;
};
/**
 * 반복 요소를 프린트 창에 디스플레이하는 메소드.<br>
 * this.control의 printForm 메소드에 의해 호출됨
 * @private
 */
eXria.controls.xhtml.Print.prototype.repeatForm = function() {
  if(this.control.getCtrl(this.document)) return;

  var voDf = this.df;
  var voControl = this.control;
  var vnLoop = 0;
  var vsDataSetId = voControl.datasetId;
  if(vsDataSetId) {
    var voDataSet = voControl.canvas.page.model.getDataSet(vsDataSetId);
    if(voDataSet == null) return;
    vnLoop = voDataSet.getRowCnt();
  } else {
    var voCollectionNode = this.data.getNodesetData2();
    if(voCollectionNode == null) return;
    vnLoop = voCollectionNode.getLength();
  }
  var vsId = voControl.id;
  var vnTop = voControl.top;
  var vnLeft = voControl.left;
  var vsPosition = voControl.position;

  var vnContentWidth = this.pageWidth - voDf.marginLeft - voDf.marginRight;
  var vnContentHeight = this.pageHeight - voDf.marginTop - voDf.marginBottom;
  if(this.pageHeader) {
    vnContentHeight -= this.pageHeader.df.height + voDf.formSpacing;
  }
  if(this.pageFooter) {
    vnContentHeight -= this.pageFooter.df.height + voDf.formSpacing;
  }

  voControl.left = this.marginLeft;
  voControl.position = "relative";

  var voCtrl = null;
  var vnHeight = 0;
  var vbNewPage = true;
  var pnPageNum = 1;
  var voDiv = null;
  var vnTmpTop = null;

  for(var i = 0; i < vnLoop; i++) {
    if(vbNewPage) {
      voDiv = this.document.createElement("div");
    var voStyle = voDiv.style;
      voStyle.position = "relative";
      voStyle.margin = "0px";
      voStyle.padding = "0px";
      voStyle.borderWidth = "0px";
      voStyle.width = this.pageWidth + "px";
      voStyle.height = this.pageHeight + "px";
      voStyle.overflow = "hidden"; // 중요설정 사항. 누락 시 IE이외 브라우저에서 pageBreak가 제대로 동작 안함.
      voStyle.pageBreakAfter = "always";
      this.document.body.appendChild(voDiv);
      vnHeight = 0;
      vnTmpTop = this.marginTop;
    }

    if(vbNewPage && this.pageHeader) {
      if(this.pageHeader.data) {
        if(this.pageHeader.nodesetInstancePath) {
          var voMapNode = this.pageHeader.data.getNodesetData2(i);
          this.pageHeader.setData(voMapNode.get("value"));
        } else {
          var psValue = this.pageHeader.data.getData();
          this.pageHeader.setData(psValue);
        }
      }
      this.pageHeader.pageNum = pnPageNum;
      voDiv.appendChild(this.pageHeader.create(this.document));
      vnTmpTop += this.formSpacing;
    }
    voControl.id = vsId + "_" + i;
    voControl.top = vnTmpTop;
//    var voCtrl = voControl.create(this.document);
//    voDiv.appendChild(voCtrl);
    var vsIdSuffix = "_" + i;
//    if(voControl.createChildren) {
//      voControl.createChildren(this.document, vsIdSuffix);
//      this.setChildrenData(i, vsIdSuffix, this.document);
//    } else {
//      this.setData(i, this.document);
//    }
    if(voControl.createChildren) {
      voControl.idSuffix = vsIdSuffix;
    }
    voControl.rowIndex = i + 1;
    voCtrl = voControl.create(this.document);
    voDiv.appendChild(voCtrl);
    vnTmpTop += voDf.formSpacing;
    vnHeight += voControl.height + voDf.formSpacing;
    if(vnContentHeight - vnHeight < voControl.height + voDf.formSpacing) {
      if(this.pageFooter) {
        vnTmpTop += vnContentHeight - vnHeight;
        this.pageFooter.df.top = vnTmpTop;
        this.pageFooter.pageNum = pnPageNum++;
        voCtrl = this.pageFooter.create(this.document);
        voDiv.appendChild(voCtrl);
      }
      vbNewPage = true;
    } else {
      vbNewPage = false;
    }

  }
  voControl.top = vnTop;
  voControl.left = vnLeft;
  voControl.id = vsId;
  voControl.position = vsPosition;

  if(!vbNewPage && this.pageFooter) {
    vnTmpTop += vnContentHeight - vnHeight;
    alert(vnContentHeight);
    this.pageFooter.top = vnTmpTop;
    voCtrl = this.pageFooter.create(this.document);
    voDiv.appendChild(voCtrl);
  }

};
/**
 * 인스턴스와 연결된 하위 컨트롤의 value설정.
 * @param {Number} pnIndex 데이타의 Row 인덱스
 * @param {String} psIdSuffix 실체화 객체에 아이디 뒤에 추가될 문자열(unique 아이디 부여를 위해)
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Print.prototype.setChildrenData = function(pnIndex, psIdSuffix, poDocument) {
  var voChild = null;
  var voIterator = this.control.controls.iterator();
  var vsPath = null;
  var vsParentPath = this.data.nodesetInstancePath + "[" + (pnIndex + 1) + "]";
  var vsId = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.data != null && voChild.data.instanceId != null) {
      vsId = voChild.id;
      vsPath = voChild.data.instancePath;
      vsPath = vsPath.split("/");
      vsPath = vsPath[vsPath.length - 1];
      voChild.id += psIdSuffix;
      voChild.data.setRef(this.data.nodesetInstanceId, vsPath, vsParentPath);
      voChild.load(this.document);
      voChild.id = vsId;
    }
  }
};
/**
 * Row 인덱스에 해당하는 값을 컨트롤에 설정.
 * @param {Number} pnIndex 데이타의 Row 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.Print.prototype.setData = function(pnIndex, poDocument) {
  var vsParentPath = this.data.nodesetInstancePath + "[" + (pnIndex + 1) + "]";
  var vsPath = this.control.data.instancePath;
  vsPath = vsPath.split("/");
  vsPath = vsPath[vsPath.length - 1];
  this.control.data.setRef(this.data.nodesetInstanceId, vsPath, vsParentPath);
  this.control.load(this.document);
};
/**
 * 클래스 명을 반환.
 * @return "Print"
 * @type String
 */
eXria.controls.xhtml.Print.prototype.toString = function() {
  return "Print";
};



/**
 * Concreate xhtml HeaderFooter
 * @author 조영진
 * @version 1.0
 * @param {eXria.controls.xhtml.Print} poPrint 상위 프린트 객체
 * @constructor
 * @private
 */
eXria.controls.xhtml.HeaderFooter = function(poPrint) {
  /**
   * 상위 프린트 객체.
   * @type eXria.controls.xhtml.Print
   */
  this.printObject = poPrint;
  /**
   * 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 보더 스타일.
   * @type String
   */
  this.borderStyle = null;

  /**
   * 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 배경 이미지.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * left 좌표.
   * @type Number
   * @private
   */
  this.left = null;
  /**
   * top 좌표.
   * @type Number
   * @private
   */
  this.top = null;
  /**
   * 영역의 가로 길이.
   * @type Number
   */
  this.width = null;
  /**
   * 영역의 세로 길이.
   * @type Number
   */
  this.height = null;
  /**
   * 보더를 제외한 영역의 가로길이.
   * @Number
   * @private
   */
  this.innerWidth = null;
  /**
   * 보더를 제외한 영역의 세로길이.
   * @Number
   * @private
   */
  this.innerHeight = null;
  /**
   * 페이지 번호.
   * readOnly
   * @type Number
   * @private
   */
  this.pageNum = null;
  /**
   * id.
   * @type String
   * @private
   */
  this.id = null;
  /**
   * 아이디의 포함될 prefix 문자열.
   * @type String
   */
  this.idPrefix = null;
  /**
   * 컨트롤이 디스플레이 되는 document 객체
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 하위에 포함될 컨트롤 저장 객체.
   * @type eXria.data.ArrayCollection
   */
  this.items = new eXria.data.ArrayCollection();
  /**
   * 인스턴스 데이타 연동 객체
   * @type eXria.controls.DataRef
   */
  this.data = null;
  /**
   * 디폴트 값을 설정하기 위한 오브젝트
   * @type Object
   */
  this.df = {};

  this.setDefault();
};
/**
 * 머리말 부분의 실체화.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 실체화 객체
 * @type HTMLDiv
 */
eXria.controls.xhtml.HeaderFooter.prototype.create = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  var voStyle = voCtrl.style;
  this.id = this.idPrefix + this.pageNum;
  voCtrl.setAttribute("id", this.id);
  voStyle.position = "relative";
  voStyle.margin = "0px";
  voStyle.padding = "0px";
  var voTable = poDocument.createElement("table");
  voStyle = voTable.style;
  voTable.setAttribute("cellSpacing", "0px");
  voTable.setAttribute("cellPadding", "0px");
  voStyle.position = "relative";
  voStyle.left = "0px";
  voStyle.top = "0px";
  var voTbody = poDocument.createElement("tbody");
  var voTr = poDocument.createElement("tr");
  var voTd = poDocument.createElement("td");
  voStyle = voTd.style;
  voStyle.textAlign = "center";
  voStyle.verticalAlign = "middle";
  voTr.appendChild(voTd);
  voTbody.appendChild(voTr);
  voTable.appendChild(voTbody);
  voCtrl.appendChild(voTable);

  this.setDefault(voCtrl, poDocument);
  this.setAttrs(voCtrl, poDocument);

  this.document = poDocument;

  return voCtrl;
};
/**
 * 디폴트 값 설정
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.setDefault = function(poCtrl, poDocument) {
  this.df = {};
  var voPrintObject = this.printObject;
  var voDf = this.df;
  voDf.left = this.getAttrValue("left");
  voDf.top = this.getAttrValue("top");
  voDf.borderWidth = this.getAttrValue("borderWidth");
  voDf.borderStyle = this.getAttrValue("borderStyle");
  voDf.borderColor = this.getAttrValue("borderColor");
  voDf.backgroundColor = this.getAttrValue("backgroundColor");
  voDf.backgroundImage = this.getAttrValue("backgroundImage");
  voDf.width = this.getAttrValue("width");
  voDf.height= this.getAttrValue("height");
  this.innerWidth = voDf.width - 2 * voDf.borderWidth;
  this.innerHeight = voDf.height - 2 * voDf.borderWidth;
};
/**
 * 디폴트 속성값을 구함.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 디폴트 속성값
 * @type String|Number
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.getAttrValue = function(psAttrName, psAttrValue) {
  if(psAttrValue != null) {
    switch(psAttrName) {
    case "width" :
      var vnWidth = this.getSpecificDefaultValue("width");
      if(psAttrValue > vnWidth) psAttrValue = vnWidth;
      break;
    case "height" :
      var vnHeight = this.getSpecificDefaultValue("height");
      if(psAttrValue > vnHeight) psAttrValue = vnHeight;
    }
    return psAttrValue;
  } else {
    var vsAttrValue = this.getSpecificDefaultValue(psAttrName);
    return vsAttrValue;
  }
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.getSpecificDefaultValue = function(psAttrName) {
  var voPrintObject = this.printObject;
  var vsDefaultValue = null;
  switch(psAttrName) {
  case "left" :
    vsDefaultValue = voPrintObject.marginLeft;
    break;
  case "top" :
    vsDefaultValue = voPrintObject.marginTop;
    break;
  case "width" :
    vsDefaultValue = voPrintObject.pageWidth;
    vsDefaultValue -= voPrintObject.marginLeft + voPrintObject.marginRight;
    break;
  default :
    vsDefaultValue = eXria.controls.xhtml.Default.Print.HeaderFooter[psAttrName];
    break;
  }

  if(vsDefaultValue === undefined) {
    return null;
  }
  return vsDefaultValue;
};
/**
 * 속성값 설정.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.setAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voTable = poCtrl.childNodes[0];
  var voStyle = poCtrl.style;
  voStyle.left = voDf.left + "px";
  voStyle.top = voDf.top + "px";
  voStyle.width = this.innerWidth + "px";
  voStyle.height = this.innerHeight + "px";
  voTable.style.width = this.innerWidth + "px";
  voTable.style.height = this.innerHeight + "px";
  var voTd = voTable.rows[0].cells[0];
  voStyle.borderWidth = voDf.borderWidth + "px";
  voStyle.borderStyle = voDf.borderStyle;
  voStyle.borderColor = voDf.borderColor;
  poCtrl.className = this.className;
  voStyle.backgroundColor = voDf.backgroundColor;
  voStyle.backgroundImage = voDf.backgroundImage;

  var voNode = null;
  while(voTd.childNodes.length > 0) {
    voNode = voTd.childNodes[0];
    this.printObject.control.clearCtrlNode(voNode);
    if(voNode.nodeType == 1) {
      voTd.removeChild(voNode);
    }
  }
  var voIterator = this.items.iterator();
  var voControl = null;
  var voCtrl = null;
  var vsPosition = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    vsPosition = voControl.position;
    voControl.position = "relative";
    if(voControl.width > this.innerWidth) voControl.width = this.innerWidth;
    if(voControl.height > this.innerHeight) voControl.height = this.innerHeight;
    voCtrl = voControl.create(poDocument);
    voTd.appendChild(voCtrl);
    if(voControl.toString() == "Label") voControl.setValue(voControl.value, voCtrl, poDocument);
    voControl.position = vsPosition;
  }
};
/**
 * 새로고침.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.refresh = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  if(voCtrl == null) return;
  this.removeAttrDefault(voCtrl, poDocument);
  this.setAttrs(voCtrl, poDocument);
};
/**
 * removeAttrDefault
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.removeAttrDefault = function(poCtrl, poDocument) {
  this.df = {};
  var voTable = this.getCtrl(poDocument);
  var voTd = voTable.rows[0].cells[0];
  var voStyle = voTd.style;
  voStyle.borderWidth = "";
  voStyle.borderStyle = "";
  voStyle.borderColor = "";
  voStyle.backgroundColor = "";
  voStyle.backgroundImage = "";
};
/**
 * 실체화 객체 반환.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 실체화 객체
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.HeaderFooter.prototype.getCtrl = function(poDocument) {
  if(poDocument == null) poDocument = this.document;
  var voCtrl = poDocument.getElementById(this.id);

  return voCtrl;
};
/**
 * 영역에 지정된 문자열 표시.
 * @param {String} psTitle 표시될 문자열 값
 */
eXria.controls.xhtml.HeaderFooter.prototype.setTitle = function(psTitle) {
  if(this.width == null) this.width = this.getSpecificDefaultValue("width");
  if(this.height == null) this.height = this.getSpecificDefaultValue("height");
  if(this.borderWidth == null) this.borderWidth = this.getSpecificDefaultValue("borderWidth");
  var voLabel = new eXria.controls.xhtml.Label(this.printObject.control.id + "_header", 0, 0, this.innerWidth, this.innerHeight);
  voLabel.printMode = true;
  voLabel.value = eXria.controls.xhtml.Util.parseLang(psTitle);
  this.addItem(voLabel);
};
/**
 * 하위 영역에 컨트롤을 포함시키는 메소드.
 * @param {eXria.controls.xhtml.Control} poControl 포함될 컨트롤
 */
eXria.controls.xhtml.HeaderFooter.prototype.addItem = function(poControl) {
  this.items.add(poControl);
  var voCtrl = null;
  if(this.document) voCtrl = this.getCtrl(this.document);
  if(voCtrl != null) {
    var voTable = voCtrl.childNodes[0];
    var voTd = voTable.rows[0].cells[0];
    var vsPosition = poControl.position;
    poControl.position = "relative";
    poControl.width = this.innerWidth;
    poControl.height = this.innerHeight;
    voTd.appendChild(poControl.create(this.document));
    if(poControl.setValue) poControl.setValue(poControl.value);
    poControl.position = vsPosition;
  }
};



/**
 * Concreate xhtml ReportHeader
 * @author 조영진
 * @version 1.0
 * @param {eXria.controls.xhtml.Print} poPrint 상위 프린트 객체
 * @constructor
 * @base eXria.controls.xhtml.HeaderFooter
 * @private
 */
eXria.controls.xhtml.ReportHeader = function(poPrint) {

  eXria.controls.xhtml.HeaderFooter.call(this, poPrint);
  /**
   * id prefix.<br>
   * 디폴트 값 "RepoartHeader_"
   * @type String
   */
  this.idPrefix = "RepoartHeader_";
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.HeaderFooter, eXria.controls.xhtml.ReportHeader);


/**
 * Concreate xhtml ReportFooter
 * @author 조영진
 * @version 1.0
 * @param {eXria.controls.xhtml.Print} poPrint 상위 프린트 객체
 * @constructor
 * @base eXria.controls.xhtml.HeaderFooter
 * @private
 */
eXria.controls.xhtml.ReportFooter = function(poPrint) {

  eXria.controls.xhtml.HeaderFooter.call(this, poPrint);

  /**
   * id prefix.<br>
   * 디폴트 값 "RepoartFooter_"
   * @type String
   */
  this.idPrefix = "RepoartFooter_";
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.HeaderFooter, eXria.controls.xhtml.ReportFooter);


/**
 * Concreate xhtml PageHeader
 * @author 조영진
 * @version 1.0
 * @param {eXria.controls.xhtml.Print} poPrint 상위 프린트 객체
 * @constructor
 * @base eXria.controls.xhtml.HeaderFooter
 * @private
 */
eXria.controls.xhtml.PageHeader = function(poPrint) {

  /**
   * id prefix.<br>
   * 디폴트 값 "PageHeader_"
   * @type String
   */
  this.idPrefix = "PageHeader_";
  eXria.controls.xhtml.HeaderFooter.call(this, poPrint);
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.HeaderFooter, eXria.controls.xhtml.PageHeader);


/**
 * Concreate xhtml PageFooter
 * @author 조영진
 * @version 1.0
 * @param {eXria.controls.xhtml.Print} poPrint 상위 프린트 객체
 * @constructor
 * @base eXria.controls.xhtml.HeaderFooter
 * @private
 */
eXria.controls.xhtml.PageFooter = function(poPrint) {

  eXria.controls.xhtml.HeaderFooter.call(this, poPrint);

  /**
   * id prefix.<br>
   * 디폴트 값 "PageFooter_"
   * @type String
   */
  this.idPrefix = "PageFooter_";
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.HeaderFooter, eXria.controls.xhtml.PageFooter);
