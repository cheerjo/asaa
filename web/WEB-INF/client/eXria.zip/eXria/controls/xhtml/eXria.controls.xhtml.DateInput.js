/**
 * @fileoverview
 * Concreate xhtml DateInput(XHTML DateInput 컨트롤)
 * @author 이종녕
 */

/**
 * @class 날짜 입력필드이며 입력받은 숫자를 설정한 DateFormat에 유효한값으로 나타내어 줍니다.<br />
 * XHTML DateInput Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.DateInput 객체
 * @type eXria.controls.xhtml.DateInput
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.DateInput = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 200 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.InputCommon.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);
  //////////////////////////////////////////////////////////////////
  //  속성
  /**
   * 컨트롤 설정 값.
   * @type String
   */
  this.value = null;
  /**
   * 읽기 전용 여부.
   * @type String
   */
  this.readOnly = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 텍스트에 밑줄을 넣을때.
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 하위 컨트롤인 calendar에 대한 참조.
   * @type eXria.controls.xhtml.Calendar
   */
  this.calendar = null;
  /**
   * DateInput에 속한 calendar 컨트롤의 활성화 여부.<br>
   * @type boolean
   */
  this.calendarEnable = null;
  /**
   * format type
   * @type String
   * @private
   */
  this.formatType = "date";
  /**
   * mask string
   * @type String
   */
  this.mask = null;
  /**
   * Date의 출력 포맷
   * @type String
   */
  this.dateFormat = null;
  /**
   * 날짜 입력란에 표시될 문자를 지정한다.<br>
   * "Underscore" | "WhiteSpace" | "Asterisk" | "Dash"
   * @type String
   */
  this.maskPrompt = null;
  /**
   * 날짜의 최소.
   * @type Date
   */
  this.min = null;
  /**
   * 날짜의 최대.
   * @type Date
   */
  this.max = null;
  /**
   * calendar를 실행시키는 이미지의 url.
   * @type String
   */
  this.calendarImageUrl = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   */
  this.innerHeight = this.height;
  /**
   * 이미지가 위치한 영역의 가로 길이.
   * @type Number
   */
  this.imgAreaWidth = 20;
  /**
   * 컨트롤의 안쪽 여백(단위 px).
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤의 안쪽 상단여백(단위 px).
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤의 안쪽 우측여백(단위 px).
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤의 안쪽 하단여백(단위 px).
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 컨트롤의 안쪽 좌측여백(단위 px).
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 버튼의 커서모양.
   * @type String
   */
  this.btnCursor = null;
  /**
   * 숫자가 아닌 문자 체크를 위한 정규식 표현(/[^\d]/gi).
   * @type RegExp
   */
  this.noDigits = /[^\d]/gi;
  /**
   * 공백 문자 체크를 위한 정규식 표현(/\s/g).
   * @type RegExp
   */
  this.blank = /\s/g;
  /**
   * date mask 체크를 위한 정규식 표현(/[YMDhms]/gi).
   * @type RegExp
   */
  this.regDateMask = /[YMDhms]/gi;
  /**
   * 한글 필터링 정규식 구문([ㄱ-ㅎ가-힝])
   * @type String
   */
  this.regExpHG = "[ㄱ-ㅎ가-힝]";
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
  /**
   * 이벤트 키값 상수 저장 오브젝트<br>
   * SHIFT: 16<br>
   * LEFT: 37<br>
   * UP: 38<br>
   * RIGHT: 39<br>
   * DOWN: 40<br>
   * ENTER: 13<br>
   * TAB: 9<br>
   * BACKSPACE: 8<br>
   * DEL: 46<br>
   * @type Object
   */
  this.constKey = {
    SHIFT: 16,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    ENTER: 13,
    TAB: 9,
    BACKSPACE: 8,
    DEL: 46
  };
  /**
   * 그리드 달력 활용을 위한 Defaults.xml의 경로 설정
   * @type String
   */
  this.defaultFileName = null;
  /**
   * 그리드 달력 활용을 위한 Text.xml의 경로 설정
   * @type String
   */
  this.textFileName = null;
  /**
   * readOnly속성과 Calendar동기화
   */
  this.readOnlyWithCalendar = null;

  /**
   * 시분초 입력영역 hide 처리
   * @type Boolean
   * @private
   */
  this.noUseHMS = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.InputCommon, eXria.controls.xhtml.DateInput);

//////////////////////////////////////////////////////////////////
//  메소드

eXria.controls.xhtml.DateInput.prototype.createSubCtrl = function(poCtrl, poDocument) {
  if(this.calendar == null) this.calendar = new eXria.controls.xhtml.Calendar(this.id + "calendar", this.width, this.height, 180, 180, true);
};

eXria.controls.xhtml.DateInput.prototype.setTemplate = function(poCtrl, poDocument) {

  this.calendar.defaultFileName = this.getAttrValue("defaultFileName", this.defaultFileName);
  this.calendar.textFileName = this.getAttrValue("textFileName", this.textFileName);
  this.calendar.loadDefaultSpce();

  this.template = [];
  var vaTemplate = this.template;
  //데이터를 입력받는 입력 태그
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<input id='" + this.id + "_text' type='text' class='" + vsClass + "' onclick = \"");
  vaTemplate.push(this.getEHandler(this.id, "updateCursorPosition"));
  vaTemplate.push("\" ");
  vaTemplate.push("@attStrBuf"); // 0 input attribute
  vaTemplate.push(" style=\"");
  vaTemplate.push("@cssStrBuf"); // 1 input style
  vaTemplate.push("\"/>");
  //미니 달력 아이콘
  vaTemplate.push("<div style=\"");
  vaTemplate.push("@cssStrBuf"); // 2 div style
  vaTemplate.push("\">");
  vaTemplate.push("<table style='width:100%; height:100%' cellspacing='0'><tbody><tr><td style='text-align:center;vertical-align:middle' >");
  vaTemplate.push("<img id='" + this.id + "_icon' style=\"");
  vaTemplate.push("@cssStrBuf"); // 3 img style
  vaTemplate.push("\" ");
  vaTemplate.push("@attStrBuf"); // 4 img attribute
  vaTemplate.push("/>");
  vaTemplate.push("</td></tr></tbody></table></div>");
  vaTemplate.push("<span class='" + vsClass + "' style=\"");
  vaTemplate.push("@cssStrBuf"); // 5 span
  vaTemplate.push("\"/>");
  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};

eXria.controls.xhtml.DateInput.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.noUseHMS = this.getAttrValue("noUseHMS", this.noUseHMS);
  this.verticalAlign = this.getAttrValue("verticalAlign", this.verticalAlign);
  this.value = this.getAttrValue("value",this.value);
  this.readOnly = this.getAttrValue("readonly",this.readOnly);
  this.calendarEnable = this.getAttrValue("calendarEnable",this.calendarEnable);
  this.readOnlyWithCalendar = this.getAttrValue("readOnlyWithCalendar", this.readOnlyWithCalendar);
  this.formatType = this.getAttrValue("formatType", this.formatType);
  this.format = this.getAttrValue("format", this.format);
  this.mask = this.getAttrValue("mask", this.mask);
  if(this.mask == null || this.mask  == "") this.mask = "yyyyMMdd";
  if(this.mask != null && this.mask != "") this.maskLen = this.mask.length;
  if(this.regFormat == null || this.regFormat == "") this.regFormat = "yyyy-MM-dd";
  if(this.regMask == null || this.regMask == "") this.regMask = "yyyyMMdd";
  if(this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
  else this.dataLen = 8;
  this.min = this.getAttrValue("min",this.min);
  this.max = this.getAttrValue("max",this.max);
  this.calendarImageUrl = this.getAttrValue("calendarImageUrl", this.calendarImageUrl);
  this.btnCursor = this.getAttrValue("btnCursor", this.btnCursor);
  if(this.value == null) this.value = "";
  this.maxCanvasWidth = this.getAttrValue("maxCanvasWidth", this.maxCanvasWidth);
  this.maxCanvasHeight = this.getAttrValue("maxCanvasHeight", this.maxCanvasHeight);

  //
  //
  if(this.userAttr == "") this.userAttr = null;
  this.userAttr = this.getAttrValue("userAttr", this.userAttr);
  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    if(!!voUserAttr.keepMultiSelector)  this.calendar.keepMultiSelector = true;
  }
};

eXria.controls.xhtml.DateInput.prototype.setSpecificAttrs = function(poCtrl, poDocument){
  // /////////////////////////////////////////////////////////////////////////////////
  // 블럭 A
  // 이 블럭의 코드는 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  // /////////////////////////////////////////////////////////////////////////////
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  // 반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  // 단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);

  poCtrl.style.cssText = vaCssStrBuf.join("");
  // ////////////////////////////////////////////////////////////////////////////////////////
  // 블럭 A 끝
  // ////////////////////////////////////////////////////////////////////////////////////////

  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "value", this.value);
  if(this.readOnly) vfcSetAttStrBuf(vaAttStrBuf, "readOnly", this.readOnly);
  vfcSetAttStrBuf(vaAttStrBuf, "maxLength", this.maskLen);
  vfcSetAttStrBuf(vaAttStrBuf, "minLength", this.minLength);
  vaTemplate[voIndexMap.get(0)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;top:0px;left:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-transform", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-direction", this.dir);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vaTemplate[voIndexMap.get(1)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;top:0px;");
  var vnWidth = this.innerWidth;
  if(this.imgAreaWidth !== null) vnWidth = vnWidth - this.imgAreaWidth;
  vfcSetCssStrBuf(vaCssStrBuf, "left", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.imgAreaWidth, "px");

  //2010.07.05
  //DateInput 달력선택 이미지 보여짐 수정
  if (! this.calendarEnable){
    vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
  }
  vaTemplate[voIndexMap.get(2)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("border-style:none;");
  if (this.readOnlyWithCalendar === "auto") {
    if (this.readOnly === true) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "inline");
  }
  else {
    if (! this.calendarEnable){
      vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    }
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "inline");
  }
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.btnCursor);
  vaTemplate[voIndexMap.get(3)] = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "src", this.calendarImageUrl);
  vaTemplate[voIndexMap.get(4)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(5)] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");
  voIndexMap.clear();

  var voCalendar = this.calendar;
  voCalendar.canvas = this.canvas;
  voCalendar.window = this.window;
  voCalendar.document = this.document;

  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  this.template = null;
  this.templateIndexMap = null;

  this.setSubElement(poDocument);

  var voInputCtrl = this.subElement.input;
  //this.runDateFormat(this.value, voInput);
  var vsValue = this.value;
  if(vsValue != null && vsValue != ""){
   vsValue = this.getDate(vsValue).getTime();
  }
  voInputCtrl.value = TGP.GetString(vsValue, this.formatType, this.regFormat);

  var voDateinput_icon = poCtrl.getElementsByTagName("img")[0]; // 수정필요
  //voCalendar.style.visibility = "hidden";
  voDateinput_icon.control = this;
  voDateinput_icon.onclick = function(e){
   var voControl = this.control;
   var voCanvas = voControl.canvas;

   var getPositionLeft = function(poControl){
     var vnL = poControl.left;
     if(poControl.parent) vnL = vnL + getPositionLeft(poControl.parent);
     return vnL;
   }

   var getPositionTop = function(poControl){
     var vnT = poControl.top;
     if(poControl.parent) vnT = vnT + getPositionTop(poControl.parent);
     return vnT;
   }

   if(voCanvas.collapseControl && voCanvas.collapseControl.id != voControl.id) {
     voCanvas.doCollapseControl(voCanvas);
   }
   var voCalendar = voControl.calendar;
   var voCalendarCtrl = voCalendar.getCtrl(poDocument);
   if(voCalendarCtrl) {
     voCalendar.hide();
     this.calendarShowed = false;
     voCanvas.collapseControl = null;
     return;
   }

   //voCalendar.style.visibility = "visible";
   var e = e || window.event;
   if(voControl.calendarEnable) {
     var voCtrl = voControl.getCtrl();
     voCalendar.setDate(voControl.getDate(voControl.value));
     voCalendar.type = "Dateinput";
     voCalendar.fontSize = 10;
     voCalendar.setTarget(voControl);

     //전체화면의 크기
     var vnCanvasWidth =  voControl.maxCanvasWidth || voControl.canvas.width;
     var vnCanvasHeight=   voControl.maxCanvasHeight || voControl.canvas.height;

     //컨트롤(DateInput)의 포지션
     var vnLeft = getPositionLeft(voControl);
     var vnTop = getPositionTop(voControl);

     //컨트롤(DateInput)의 크기
     var vnWidth = voControl.width;
     var vnHeight = voControl.height;

     var vsCSSStyle = {
          "GB": {
             "W":169,
             "H":161
          },
          "GL": {
             "W":196,
             "H":150
          },
          "GM": {
             "W":169,
             "H":161
          },
          "GO": {
             "W":169,
             "H":161
          },
          "GP": {
             "W":169,
             "H":161
          },
          "GR": {
             "W":169,
             "H":161
          },
          "GS": {
             "W":169,
             "H":161
          }
       }[voCalendar.CSS];

       //컨트롤(Calendar)의 크기
       var vnCalendarWidth  =  vsCSSStyle["W"];//voCalendar.width;
       var vnCalendarHeight =  vsCSSStyle["H"];//voCalendar.height;

       //컨트롤(Calendar)의 포지션
       var vnCalendarLeft;
       var vnCalendarTop;

       if( (vnLeft + vnWidth) >= vnCalendarWidth ) {
         vnCalendarLeft = voControl.left;
         if( (vnLeft + vnCalendarWidth) >= vnCanvasWidth ){
           vnCalendarLeft = (voControl.left + vnWidth) - vnCalendarWidth;
         }
       }else{
         vnCalendarLeft = (voControl.left + vnWidth) - vnCalendarWidth;
         if(vnCalendarLeft < 0){
           vnCalendarLeft = 0;
         }
       }

       if( vnCanvasHeight - (vnTop + vnHeight) >= vnCalendarHeight){
          vnCalendarTop = voControl.top + vnHeight;
       }else{
          vnCalendarTop = (voControl.top + 10) - vnCalendarHeight;
       }

       voCalendar.left = vnCalendarLeft;
       voCalendar.top = vnCalendarTop;
       voCalendar.position = "absolute";
       voCalendar.zIndex = 10000;


       if(voControl.parent && voControl.parent.ctrl){
        voControl.parent.ctrl.oriZindex = voControl.parent.ctrl.style.zIndex;
        voControl.parent.ctrl.style.zIndex = 50000;
       }

       voCalendar.show(voControl.parent);

       if(voControl.mask.length > 14 && !voControl.noUseHMS) {
          var vnTmp = voControl.getDate(voControl.value).getTime();
          voCalendar._showTimesInfo(TGP.GetString(vnTmp, voControl.formatType, 'HH:mm:ss'));
       }

       voControl.calendarShowed = true;
       voCanvas.collapseControl = voControl;
       var voCtrl = voCalendar.ctrl;
       voControl.setAttrCtrl("zIndex", 50000, voCtrl);
       voParent = voCalendar.parent;
       while(voParent) {
         if(voParent.ctrl) voControl.setAttrCtrl("zIndex", 50000, voParent.ctrl);
         voParent = voParent.parent;
       }
       voControl.lifted = true;
     }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.input = this.getSubCtrl("input", voCtrl, poDocument);
  voSubElement.divDate = this.getSubCtrl("div", voCtrl, poDocument);
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
  voSubElement.imgCtrl = this.getSubCtrl("img", voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voDiv = this.subElement.divDate;
  var voInput = this.subElement.input;
  var voDf  = this.df;
  switch(psAttrName) {
  case "width" :
    this.setInputWidth();
    this.calendar.left = this.width;
    break;
  case "height" :
    this.setAttrCtrl("height", this.innerHeight, voDiv);
    this.calendar.top = this.height;
    this.setVerticalAlign(voInput, poCtrl, this.verticalAlign);
    break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.dofocus = function() {
  if(this.calendarShowed) return;
  var voInput = this.subElement.input;
  try { voInput.focus(); }catch(err) {}
};

eXria.controls.xhtml.DateInput.prototype.setSpecificEvents = function(poCtrl){
  var voInput = this.subElement.input;
  //@data  TODO: 테스트 필요...
  voInput.control = this;
  //this.eventManager.addListener(voInput, "onchange", this.mediateEvent);
  this.eventManager.addListener(voInput, "onfocus", this.mediateEvent);
  this.eventManager.addListener(voInput, "onblur", this.mediateEvent);
  this.eventManager.addListener(voInput, "onselect", this.mediateEvent);

  var add = "";
  var tt = this.regFormat && this.regFormat.indexOf('t')>=0 && this.regFormat.indexOf('h')>=0;
  if(tt) add+=Formats.AMDesignator.toUpperCase()+Formats.PMDesignator.toUpperCase();
  voInput.onkeypress = function(ev){ TestKey(ev?ev:event,this,TestKeyDate,add); }
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.atkeydown = function(e){
  if(e.keyCode == 13) {
    this.isEnter = true;
    if(true === this.calendar.keepMultiSelector){
      var voDf = this.df;
      var voCtrl = this.ctrl;
      var voInput = this.subElement.input;
      this.tempValue = voInput.value;
      var vsValue = voInput.value;
      vsValue = this.filterDateInput(vsValue);
      var vsRegMask = this.regMask;
      if(vsValue.length == 6) {
        vsValue = vsValue + '01';
        this.regMask = 'yyyy/MM/dd';
      }
      if(vsValue != null && vsValue != "") {
        vsValue = TGP.GetValueInput(vsValue, this.formatType, this.regMask);
        var voDate = new Date();
        voDate.setTime(vsValue);
        vsValue = this.getDateString(voDate);
        if(this.min != null && this.min != "") {
          if(this.getDate(vsValue).getTime() < this.getDate(this.min).getTime()) vsValue = this.min;
        }
        if(this.max != null && this.max != "") {
          if(this.getDate(vsValue).getTime() > this.getDate(this.max).getTime()) vsValue = this.max;
        }
      }
      this.regMask = vsRegMask;
      this.setValueWithNotify(vsValue);
    }else{
      var voCtrl = this.ctrl;
      var voInput = this.subElement.input;
      var vsInput = this.filterDateInput(voInput.value);
      vsInput = TGP.GetValueInput(vsInput, this.formatType, this.regMask);
      if(vsInput != null && vsInput != "") {
        var voDate = new Date();
        voDate.setTime(vsInput);
        vsInput = this.getDateString(voDate);
      }
      this.setValueWithNotify(vsInput);
     //voInput.blur();
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.atfocus = function(e) {
  var voInput = this.subElement.input;
  var vsValue = this.value;
  if(vsValue != null && vsValue != "") {
   vsValue = this.getDate(vsValue).getTime();
  }
  voInput.value = TGP.GetString(vsValue, this.formatType, this.regMask);
  if(this.focused != true) {
    var voCalendar = this.calendar;
    var voCalendarCtrl = voCalendar.getCtrl();
    if(voCalendarCtrl) {
      voCalendar.hide();
      this.calendarShowed = false;
      this.canvas.collapseControl = null;
    }
    this.selectText();
  }
  this.focused = true;
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.atkeyup = null;
//eXria.controls.xhtml.DateInput.prototype.atkeyup = function(e) {
//  e = new eXria.event.Event(e, this.window);
//  this.checkKey(e);
//};
//eXria.controls.xhtml.DateInput.prototype.atselect = function(e) {
//  var voInput = this.subElement.input;
//  if (voInput.selectionEnd) {
//    this.selectionSize = voInput.selectionEnd - voInput.selectionStart;
//  } else if(document.selection && document.selection.createRange) {
//    var voRange = document.selection.createRange().duplicate();
//    this.selectionSize = voRange.text.length;
//  }
//};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.atblur = function(e) {
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  this.setInputHeight(voCtrl);
  this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
  this.focused = false;
  this.tempValue = voInput.value;
  var vsValue = voInput.value;
  vsValue = this.filterDateInput(vsValue);
  var vsRegMask = this.regMask;
  if(vsValue.length == 6) {
    vsValue = vsValue + '01';
    this.regMask = 'yyyy/MM/dd';
  }
  if(vsValue != null && vsValue != "") {
    vsValue = TGP.GetValueInput(vsValue, this.formatType, this.regMask);
  //if(this.formatType == "date") {
    var voDate = new Date();
    voDate.setTime(vsValue);
    vsValue = this.getDateString(voDate);
    if(this.min != null && this.min != "") {
      if(this.getDate(vsValue).getTime() < this.getDate(this.min).getTime()) vsValue = this.min;
    }
    if(this.max != null && this.max != "") {
      if(this.getDate(vsValue).getTime() > this.getDate(this.max).getTime()) vsValue = this.max;
    }
  //}
  }
  this.regMask = vsRegMask;
  this.setValueWithNotify(vsValue);
  this.atkeydown({'keyCode':13});
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
  var voText = this.subElement.input;

  var voEventManager = this.eventManager;
  voEventManager.removeListener(voText, "onblur", this.mediateEvent);
  voEventManager.removeListener(voText, "onchange", this.mediateEvent);
  voEventManager.removeListener(voText, "onfocus", this.mediateEvent);
  voEventManager.removeListener(voText, "onselect", this.mediateEvent);
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.refreshMainStyle = function(poCtrl, poDocument) {
  this.setMainCtrlStyles(poCtrl, poDocument);
};
/**
* @ignore
*/
eXria.controls.xhtml.DateInput.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voInputCtrl = this.subElement.input;
  var voDivCtrl = this.subElement.divDate;
  var voImgCtrl = this.subElement.imgCtrl;
  var voSpanCtrl = this.subElement.span;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  if(this.readOnly != null) voInputCtrl ["readOnly"] = this.readOnly;
  if(this.maskLen != null) voInputCtrl["maxLength"] = this.maskLen;
  if(this.minLength != null) voInputCtrl["minLength"] = this.minLength;

  if(this.className != null) voInputCtrl.className = this.getCSSClass(this, 1);

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;top:0px;left:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-transform", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-direction", this.dir);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  voInputCtrl.style.cssText = vaCssStrBuf.join("");

  var vsValue = this.value;
  if(vsValue != null && vsValue != ""){
    vsValue = this.getDate(vsValue).getTime();
  }
  voInputCtrl.value = TGP.GetString(vsValue, this.formatType, this.regFormat);

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;top:0px;");
  var vnLeft = this.innerWidth;
  if(this.imgAreaWidth !== null) vnLeft = vnLeft - this.imgAreaWidth;
  vfcSetCssStrBuf(vaCssStrBuf, "left", vnLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.imgAreaWidth, "px");

  //2010.07.05
  //DateInput 달력선택 이미지 보여짐 수정
  if (! this.calendarEnable){
    vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
  }

  voDivCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("border-style:none;");
  if (this.readOnlyWithCalendar === "auto") {
    if (this.readOnly === true) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "inline");
  }
  else {
    if (! this.calendarEnable) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "inline");
  }
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.btnCursor);
  voImgCtrl.style.cssText = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  voImgCtrl["src"] = this.calendarImageUrl;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  voSpanCtrl.style.cssText = vaCssStrBuf.join("");

  this.setInputWidth();
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;
  var vsRefData = this.data.getData();
  if(vsRefData != null && vsRefData != "") {
    this.dataLen = vsRefData.length;
  } else if(this.dataLen == null) {
    if(this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
    else this.dataLen = 8;
  }
  this.setValue(vsRefData);
};
/**
 * oldclear
 * @private
 */
eXria.controls.xhtml.DateInput.prototype.oldclear = eXria.controls.xhtml.DateInput.prototype.clear;

eXria.controls.xhtml.DateInput.prototype.clear = function() {
  if(this.calendar) this.calendar.clear();
  this.oldclear();
};
/**
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  var voDivDate = this.subElement.divDate;
  var voSpan = this.subElement.span;
  var voImgCtrl = this.subElement.imgCtrl;
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName){
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
  case "disabled" :
    if(psAttrValue == true) this.doblur();
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "outerClassName":
  case "className":
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setInputWidth();
    this.calendar.left = this.width;
    //this.calendar.refresh(poDocument);
    this.refresh(poDocument);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.calendar.top = this.height;
    //this.calendar.refresh(poDocument);
    this.refresh(poDocument);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setInputWidth();
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setVerticalAlign(voInput, voCtrl, "middle");
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setInputWidth();
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setVerticalAlign(voInput, voCtrl, "middle");
    break;
  case "padding" :
    this.paddingTop = this.padding;
    this.paddingRight = this.padding;
    this.paddingBottom = this.padding;
    this.paddingLeft = this.padding;
    this.setAttrCtrl("paddingTop", this.paddingTop + "px", voInput);
    this.setAttrCtrl("paddingRight", this.paddingRight + "px", voInput);
    this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voInput);
    this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voInput);
    this.setInputWidth();
    break;
  case "paddingTop" :
  case "paddingRight" :
  case "paddingBottom" :
  case "paddingLeft" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voInput);
    this.setInputWidth();
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
  case "verticalAlign":
//    var voTd = this.getSubCtrl("td", voCtrl, poDocument);
//    this.setAttrCtrl(psAttrName, psAttrValue, voTd);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
  case "fontFamily" :
  case "fontSize" :
  case "fontStyle" :
  case "fontWeight" :
  case "textDecoration":
  case "textTransform":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
    break;
//  case "value" :
  case "dateFormat" :
  case "maskPrompt" :
    this.runDateFormat(this.value, voInput);
    break;
  case "readOnly" :
    this.setAttrCtrl(psAttrName, psAttrValue, voInput);
  // this.readOnlyWithCalendar상황에서는 this.calendarEnable는 don't care
  if (this.readOnlyWithCalendar === "auto") {
    if (this.readOnly === true) this.setAttrCtrl("visible", false, voImgCtrl);
    else this.setAttrCtrl("visible", true, voImgCtrl);
  }
  break;
  case "readOnlyWithCalendar" :
  if (this.readOnlyWithCalendar === "auto") {
    if (this.readOnly === true) this.setAttrCtrl("visible", false, voImgCtrl);
    else this.setAttrCtrl("visible", true, voImgCtrl);
  }
  else {
    if (! this.calendarEnable) this.setAttrCtrl("visible", false, voImgCtrl);
  }
  break;
  case "textAlign" :
    this.setAttrCtrl(psAttrName, psAttrValue, voInput);
    break;
  case "calendarEnable" :
    if (this.readOnlyWithCalendar !== "auto")
      this.setAttrCtrl("visible", psAttrValue, voImgCtrl);
    break;
  case "value" :
  case "format" :
    if(this.format == null || this.format == "") this.format = "yyyy-MM-dd";
    this.setValue(this.value);
    break;
  case "mask" :
    if(this.mask == null || this.mask == "") this.mask = "yyyyMMdd";
    this.maskLen = this.mask.length;
    if(this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
    else this.dataLen = 8;
    voInput.maxLength = this.maskLen;
    break;
  default:
    this.refresh(poDocument);
    break;
  }
};
/**
 * 현재에서의 커서 위치를 반환합니다.
 * @return 현재의 커서위치
 * @type Number
 * @private
 */
eXria.controls.xhtml.DateInput.prototype.getCursorPosition = function() {
  var voDocument = this.document;
  var voInput = this.subElement.input;
  var vnCursorPosition = -1;
  if (voInput.selectionEnd) {
    vnCursorPosition = voInput.selectionEnd;
  } else if(voDocument.selection && voDocument.selection.createRange) {
    var voRange = voDocument.selection.createRange().duplicate();
    voRange.moveStart('textedit', -1);
    vnCursorPosition = voRange.text.length;
  }
  return vnCursorPosition;
};
/**
 * 현재 커서의 위치값을 갱신합니다.
 */
eXria.controls.xhtml.DateInput.prototype.updateCursorPosition = function() {
  var vnPos = this.getCursorPosition();
  this.cursorPosition = vnPos;
};
/**
 * 숫자만  입력받아서 format에 맞게 변환합니다.
 * @param {HTMLEvent} e 윈도우이벤트
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.checkKey = function(e){
  var voDf = this.df;
  var vnPos = this.getCursorPosition();
  var voInputCtrl = this.subElement.input;
  var vnKeyCode = e.e.keyCode;
  var vsValue = voInputCtrl.value;

  if(vnKeyCode == 229 && e.type != "keyup")  // 한글 입력 상태에서 마우스 클릭시 keyup 이벤트가 발생하여 이를 제외하여 체크
  {
    alert("숫자 이외의 입력은 허용이 되지 않습니다.");
    vsValue = vsValue.replace(this.noDigits,"");
    e.stopEvent();
  } else if(vnKeyCode == 229 && e.type == "keyup") {
    return;
  }
  vnKeyCode = this.matchNumberPad(vnKeyCode);
  var vsKeyCharacter = String.fromCharCode(vnKeyCode);
  if(/[0-9]/.test(vsKeyCharacter) == false) {
    vnPos--;
    vsValue = vsValue.substring(0, vnPos) + vsValue.substring(vnPos + 1);
  }


  if(this.checkDate(vsValue) == false) {
    vnPos--;
    vsValue = vsValue.substring(0, vnPos) + vsValue.substring(vnPos + 1);
  }
  vsValue = vsValue.replace(this.noDigits, "");

  var voConstKey = this.constKey;
  switch(vnKeyCode) {
  case voConstKey["ENTER"] :
  case voConstKey["TAB"] :
  case voConstKey["DEL"] :
  case voConstKey["BACKSPACE"] :
  case voConstKey["SHIFT"] :
  case voConstKey["LEFT"] :
  case voConstKey["RIGHT"] :
    return true;
  }

  vsValue = this.toDateFormatValue(vsValue);
  voInputCtrl.value = vsValue;
  var vsChar = null;
  if(vsValue != null) {
    while(vsValue.charAt(vnPos)) {
      vsChar = vsValue.charAt(vnPos);
      if(/[0-9]/.test(vsChar) == false && this.maskPrompt != vsChar) {
        vnPos++;
      } else {
        break;
      }
    }
  }
  if(vsValue.indexOf(this.maskPrompt) > -1) vnPos = vsValue.indexOf(this.maskPrompt);
  this.setCursorPosition(vnPos);
//  this.skipBlur = true;
  return true;
};
/**
 * 넘버패드의 keycode를 기본 숫자 keycode로 변환합니다.
 * @param {Number} keyCode
 * @return 변환된 keyCOde
 * @type Number
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.matchNumberPad = function(vnKeyCode){
  if(vnKeyCode > 95 && vnKeyCode < 106) return vnKeyCode -= 48;
  else return vnKeyCode;
}
/**
 * 설정된 maskFormat에 유효한 날짜를 검사합니다.
 * @param {String} 검사할 날짜값
 * @return 유효한지의 여부
 * @type Boolean
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.checkDate = function(psValue){
  var voDf = this.df;
  psValue = psValue.replace(this.noDigits, "");
  if(psValue == "") return false;
  var vsFormat = this.dateFormat;
  vsFormat = vsFormat.replace(/[^YyMDdhms]/g, "");

  var vnYearPos = vsFormat.search(/yyyy/i);
  var vnMonthPos = vsFormat.search(/mm/i);
  var vnDatePos = vsFormat.search(/dd/i);
  var vnYear = psValue.substr(vnYearPos, 4);
  if(vnYear != "") vnYear = parseInt(vnYear);
  var vnMonth = psValue.substr(vnMonthPos, 2);
  if(vnMonth.length == 1) vnMonth += "0"; ;
  if(vnMonth != "") vnMonth = parseInt(vnMonth) - 1;
  var vnDate = psValue.substr(vnDatePos, 2);
  if(vnDate.length == 1) vnDate += "0";
  if(vnDate != "") vnDate = parseInt(vnDate);

  var voDate = new Date();
  if(vnYear === "" || vnYear === 0) vnYear = voDate.getFullYear();
  if(vnMonth === "" || vnMonth === -1) { vnMonth = voDate.getMonth() }
  if(vnDate === "" || vnDate === 0) vnDate = voDate.getDate();

  voDate.setFullYear(vnYear);
  voDate.setMonth(vnMonth);
  voDate.setDate(vnDate);

  if( voDate.getFullYear() != vnYear
      || voDate.getMonth() != vnMonth
      || voDate.getDate() != vnDate) {
    return false;
  }
  return true;
};
/**
 * 입력된값을 설정된 날짜포멧으로 변환합니다.
 * @param {String} psValue 입력값
 * @return 날짜 포맷이 적용된 문자열 값
 * @type String
 * @private
 */
eXria.controls.xhtml.DateInput.prototype.toDateFormatValue = function(psValue){
  var vsFormat = this.dateFormat.replace(this.regDateMask,this.maskPrompt);
  // 개체의 값 얻어오기
  var vsReg = new RegExp('['+this.maskPrompt+']','gi');
  //var vsValue = psValue.replace(vsReg,"a");
  var vsRegValue = vsFormat;
  var vsRegFormat = new RegExp('['+this.maskPrompt+']','i');
  for(var i=0;i < psValue.length;i++) {
    vsRegValue = vsRegValue.replace(vsRegFormat, psValue.charAt(i));
  }
  vsRegValue = vsRegValue.replace(/[YMDhms]/g,this.maskPrompt);
  return vsRegValue;
};
/**
 * dateformat 과  maskPrompt 가 적용되는 메소드입니다.
 * @param {String} psValue 적용할 값
 * @param {HTMLInput(text)} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.DateInput.prototype.runDateFormat = function(psValue, poCtrl){
  var vsDateFormat = this.dateFormat;
  if(this.maskPrompt != null) {
    vsDateFormat = vsDateFormat.replace(this.regDateMask,this.maskPrompt);
  }
  psValue = eXria.controls.xhtml.Util.parseLang(psValue);
  if(psValue == null) psValue = "";
  psValue = psValue.replace(this.noDigits,"");

  // yhkim 2009.10.08  firefox date값 길이 맞춰주기
  if(psValue.length > 0) {
    var vnMinLen = this.min.length;
    var vnMaxLen = this.max.length;
    var vnValueLen = psValue.length;
    // 값이길이가 min길이보다 작은 경우
    if(vnValueLen < vnMinLen) {
      for(var i = 0; i < vnMinLen - vnValueLen; i++) psValue += '0';
    }
    // 값의 길이가  max길이보다 작은 경우
    if(vnMaxLen > vnValueLen) {
      for(var i = 0; i < vnMaxLen - vnValueLen; i++) psValue += '0';
    }
  }
  if (psValue !== null && psValue != "") {
    if (this.toDate(psValue).getTime() < this.toDate(this.min).getTime())
      psValue = this.min;
    else
      if (this.toDate(psValue).getTime() > this.toDate(this.max).getTime())
        psValue = this.max;
  }

  var vsValue = this.toDateFormatValue(psValue,vsDateFormat);
  this.setAttrCtrl("value", vsValue, poCtrl);

  if(vsValue == vsDateFormat) {
    this.value = "";
    this.value = "";
  }
};
/**
 * 'YYYYMMDD' 포맷의 날짜값을 Date형태로 변환하여 반환합니다.
 * @param {String} psValue 'YYYYMMDD' 포맷의 날짜 값
 * @return Date객체
 * @type Date
 */
eXria.controls.xhtml.DateInput.prototype.toDate = function(psValue){
  var voDate = new Date();
  var vsValue = psValue.substring(0, 4) + "/";
  vsValue += psValue.substring(4, 6) + "/";
  vsValue += psValue.substring(6);
  voDate.setTime(Date.parse(vsValue));
  return voDate;
};
/**
 * Date객체를 반환합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return Date형으로 변환된 컨트롤 박스의 값
 * @type Date
 */
eXria.controls.xhtml.DateInput.prototype.getDate = function(poDocument) {
  var voCtrl = this.ctrl;
  var voDateinputCtrl = this.subElement.input;
  var voDate = new Date();
  var vsValue = voDateinputCtrl.value;
  var vsFormat = this.dateFormat.replace(/[^YMD]/gi,"");
  vsValue = vsValue.replace(/[^0-9]/gi,"");
  var vnIndex = vsValue.length;
  //year
  var temp = vsFormat.indexOf("YYYY",0);
  var vnYear = vsValue.substring(temp,temp+4);
  if(vnYear.length == 4) voDate.setFullYear(vnYear);
  //month
  var temp = vsFormat.indexOf("MM",0);
  var vnMonth = vsValue.substring(temp,temp+2);
  if(vnMonth.length == 2) voDate.setMonth(vnMonth-1);
  //date
  var temp = vsFormat.indexOf("DD",0);
  var vnDate = vsValue.substring(temp,temp+2);
  if(vnDate.length == 2) voDate.setDate(vnDate);
  //initialize time
  voDate.setHours(0);
  voDate.setMinutes(0);
  voDate.setSeconds(0);
  voDate.setMilliseconds(0);
  //hour
  temp = vsFormat.indexOf("hh",0);
  if(temp != -1) {
    var vnHour = vsValue.substring(temp,temp+2);
    if(vnHour.length == 2) voDate.setHours(vnHour);
  }
  //minute
  temp = vsFormat.indexOf("mm",0);
  if(temp != -1) {
    var vnMinute = vsValue.substring(temp,temp+2);
    if(vnMinute.length == 2) voDate.setMinutes(vnMinute);
  }
  //second
  temp = vsFormat.indexOf("ss",0);
  if(temp != -1) {
    var vnSecond = vsValue.substring(temp,temp+2);
    if(vnSecond.length == 2) voDate.setSeconds(vnSecond);
  }
  return voDate;
};
/**
 * 넘겨받은 Date 객체로 컨트롤의 값을 설정합니다.
 * @param {Date} poDate 컨트롤 값으로 설정될 date형 데이타
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document(생략가능)
 */
eXria.controls.xhtml.DateInput.prototype.setDate = function(poDate, poDocument){
  var voCtrl = this.ctrl;
  var voDateinputCtrl = this.subElement.input;
  var vnYear = new String(poDate.getFullYear());
  var vnMonth = new String(poDate.getMonth()+1);
  if(vnMonth.length == 1) vnMonth = "0" + vnMonth;
  var vnDate = new String(poDate.getDate(poDocument));
  if(vnDate.length == 1) vnDate = "0" + vnDate;
  var vnHours = new String(poDate.getHours());
  if(vnHours.length == 1) vnHours = "0" + vnHours;
  var vnMinutes = new String(poDate.getMinutes());
  if(vnMinutes.length == 1) vnMinutes = "0" + vnMinutes;
  var vnSeconds = new String(poDate.getSeconds());
  if(vnSeconds.length == 1) vnSeconds = "0" + vnSeconds;
//  var vsValue = this.dateFormat.replace(/[^YMDhms]/g,"");
  var vsValue = "YYYYMMDDhhmmss";
  vsValue = vsValue.replace(/YYYY/g,vnYear);
  vsValue = vsValue.replace(/MM/g,vnMonth);
  vsValue = vsValue.replace(/DD/g,vnDate);
  vsValue = vsValue.replace(/hh/g,vnHours);
  vsValue = vsValue.replace(/mm/g,vnMinutes);
  vsValue = vsValue.replace(/ss/g,vnSeconds);
  if(this.dataLen < 14) vsValue = vsValue.substring(0, 8);
  //this.runDateFormat(vsValue, voDateinputCtrl);

  this.setValue(vsValue)
  //voDateinputCtrl.onblur();
};
/**
 * 입력값을 정해진 날짜 포맷으로 설정합니다.
 * @param {String} psData 설정 값
 */
eXria.controls.xhtml.DateInput.prototype.setValue = function(psData) {
  var voInput = this.subElement.input;
  if(this.mask && /^\d*$/g.test(psData) == false) {
    var vsRegMask = this.mask
    vsRegMask = vsRegMask.replace("yyyy", "\\d{4}");
    vsRegMask = vsRegMask.replace("MM", "\\d{2}");
    vsRegMask = vsRegMask.replace("dd", "\\d{2}");
    if(new RegExp(vsRegMask).test(psData)) {
      psData = TGP.GetValueInput(psData, "date", this.mask);
      var voDate = new Date();
      voDate.setTime(psData);
      psData = this.getDateString(voDate);
    }
  }
  if(psData == null) psData = "";
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psData) {
    vbChanged = true;
  }
  this.onchangeInitValue = psData;
  this.value = psData;
  if(vbChanged) {
    this.data.setData(this.value);
  }
  if(psData != null && psData != "") {
    psData = this.getDate(psData).getTime();
    voInput.value = TGP.GetString(psData, this.formatType, this.regFormat);
  } else {
    voInput.value = "";
  }
};
/**
 * 컨트롤에 값을 설정하며 값의 변경이 있으면 onchange 이벤트를 발생시킵니다.
 * @param {String} psData 설정 값
 * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능.
 */
eXria.controls.xhtml.DateInput.prototype.setValueWithNotify = function(psData, poCtrl) {
  var voInput = this.subElement.input;
  if(this.mask && /^\d*$/g.test(psData) == false) {
    var vsRegMask = this.mask
    vsRegMask = vsRegMask.replace("yyyy", "\\d{4}");
    vsRegMask = vsRegMask.replace("MM", "\\d{2}");
    vsRegMask = vsRegMask.replace("dd", "\\d{2}");
    if(new RegExp(vsRegMask).test(psData)) {
      psData = TGP.GetValueInput(psData, "date", this.mask);
      var voDate = new Date();
      voDate.setTime(psData);
      psData = this.getDateString(voDate);
    }
  }
  if(psData == null) psData = "";
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psData) {
    vbChanged = true;
  }
  this.onchangeInitValue = psData;
  this.value = psData;
  if(psData != null && psData != "") {
    psData = this.getDate(psData).getTime();
    voInput.value = TGP.GetString(psData, this.formatType, this.regFormat);
  } else {
    voInput.value = "";
  }
  if(vbChanged) {
    this.data.setData(this.value)
    var voEvent = new eXria.event.Event(null);
    voEvent.object = this;
    if(this.onchange) this.onchange(voEvent);
    if(this.changeEventCallback) this.changeEventCallback(voEvent);
  }
};
/**
 * addClass
 * @param {HTMLElement} poElement
 * @param {String} poClassName
 * @private
 */
eXria.controls.xhtml.DateInput.prototype.addClass = function(poElement,poClassName) {
  if(!poElement.className) {
    poElement.className = poClassName;
  } else {
    var newClassName = poElement.className;
    newClassName += " ";
    newClassName += poClassName;
    poElement.className = newClassName;
  }
};
/*
 * @ignore
 */
eXria.controls.xhtml.DateInput.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.DateInput[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "DateInput"
 * @type String
 */
eXria.controls.xhtml.DateInput.prototype.toString = function() {
  return "DateInput";
};