/**
 * @fileoverview
 * Concreate xhtml MDIGroup, MDIButton, MDIPage
 * @author 박상찬
 */

/**
 * MDI 컨트롤 헤더의 버튼 공통 속성을 저장하기 위한 클래스.
 * @version 2.0
 * @type eXria.controls.xhtml.MDIButtons
 * @constructor
 */
eXria.controls.xhtml.MDIButtons = function() {
  /**
   * MDI 버튼의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * MDI 버튼의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * MDI 버튼의 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * MDI 버튼의 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * MDI 버튼의 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * MDI 버튼의 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * MDI 버튼의 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * MDI 버튼에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * MDI 버튼에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * MDI 버튼에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * MDI 버튼에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * MDI 버튼에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * MDI 버튼간 간격(px).
   * @type Number
   */
  this.cellSpacing = null;
  /**
   * MDI 버튼의 가로 길이.
   * @type Number
   */
  this.width = null;
  /**
   * MDI 버튼의 세로 길이.
   * readOnly 속성.
   * @type Number
   * @private
   */
  this.height = null;
  /**
   * MDI 버튼의 Top.
   * @type Number
   */
  this.top = null;
  /**
   * MDI 버튼의 Left.
   * readOnly 속성.
   * @type Number
   * @private
   */
  this.left = null;
  /**
   * MDI 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 선택된 MDI 버튼의 배경이미지 url.
   * @type String
   */
  this.imageFocused = null;
  /**
   * MDI 버튼 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * MDI 버튼 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;
  /**
   * MDI 버튼의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * MDI 버튼이 선택되었을 때의 배경 색상.
   * @type String
   */
  this.focusBackgroundColor = null;
  /**
   * MDI 버튼의 텍스트 색상.
   * @type String
   */
  this.color = null;
  /**
   * MDI 버튼이 선택되었을 때의 텍스트 색상.
   * @type String
   */
  this.focusColor = null;
  /**
   * MDI 버튼에 표시될 텍스트의 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * MDI 버튼에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * MDI 버튼에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * MDI 버튼에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * MDI 버튼에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트 밑줄 적용 속성.
   * @type String
   */
  this.textDecoration = null;
  /**
   * MDI 버튼에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * MDI 버튼에 외곽에 적용될 css 클래스 명.
   * @type String
   */
  this.outerClassName = null;
  /**
   * MDI 컨트롤 헤더의 MDI 버튼 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  /**
   * MDI 컨트롤 헤더의 MDI 버튼 cursor값
   * @type String
   * @private
   */
  this.cursor = null;

  this.df = {};
};

/**
 * @class Concreate xhtml MDIButton
 * XHTML MDI 컨트롤 헤더에 포함되는 MDI 버튼 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MDIButton 객체
 * @type eXria.controls.xhtml.MDIButton
 * @constructor
 * @base eXria.controls.xhtml.Button
 */
eXria.controls.xhtml.MDIButton = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  eXria.controls.xhtml.Button.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * MDIButtons 참조
   * @type eXria.controls.xhtml.MDIButtons
   * @private
   */
  this.parent = null;
  /**
   * Button의 subId 참조(MDI 컨트롤 id가 제외된 값)
   * @private
   */
  this.subId = null;
  /**
   * 링크된 페이지 아이디(MDI 컨트롤 id와 조합된 값) 참조
   * @type String
   * @private
   */
  this.pageId = null;
  /**
   * 링크된 페이지 아이디 참조(MDI 컨트롤 id가 제외된 값)
   * @type String
   * @private
   */
  this.pageSubId = null;
  /**
   * @ignore
   */
  this.position = "relative";
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Button, eXria.controls.xhtml.MDIButton);
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<button hidefocus='true' type='button' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_btn' style=\"");
  vaTemplate.push("@cssStrbuf"); //setSpecificAttrs메소드에서  스타일 속성이 대체될  부분은 @cssStrBuf로 마크(Element 속성의 경우엔 @attStrBuf로 마크)
  vaTemplate.push("\" class='" + vsClass + "'>");
  vaTemplate.push("@innStrBuf"); //setSpecificAttrs메소드에서 innerHTML이 대체될 부분은 @innStrBuf로 마크
  vaTemplate.push("</button>");
//  vaTemplate.push("<div style=\"");
//  vaTemplate.push("@cssStrBuf");
//  vaTemplate.push("\"><table style=\"position:absolute;left:0px;top:0px;width:100%;height:100%;font-family:Arial;font-weight:bold;\">");
//  vaTemplate.push("<tr><td align=\"center\" vAlign=\"middle\">x</td></tr></table></div>");
//  var vcTab = this.parent.parent;
//    if(vcTab.type == "minimizedWindow") {
//    vaTemplate.push("<input type=\"button\" value=\"x\" HIDEFOCUS=\"true\" style=\"");
//    vaTemplate.push("@cssStrBuf");
//    vaTemplate.push("\" onclick=\"");
//    vaTemplate.push(this.getEHandler2(this.pageId));
//    vaTemplate.push("\"/>");
//  }
  vaTemplate.push("<span style=\"");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("\"/>");
  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  ///////////////////////////////////////////////////////////////////////////////////
  // 블럭 A
  // 이 블럭의 코드는 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  ///////////////////////////////////////////////////////////////////////////////
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.09.21 기존에 이와같은 코드가 있었는데 아예 동작을 안했는데 여기서는 동작이 되서 side effect 생김
  //if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", "hand");
  poCtrl.style.cssText = vaCssStrBuf.join("");
  //////////////////////////////////////////////////////////////////////////////////////////
  // 블럭 A 끝
  //////////////////////////////////////////////////////////////////////////////////////////

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;left:0px;top:0px;border-style:none;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);

  // AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
  // backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.
  if(this.backgroundImage) {
    if(this.backgroundImage.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
      var vsSplit = this.backgroundImage.split("\'");
      if(vsSplit[0] == "url(")
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[2] + "')");
      else
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[1] + "')");
    } else {
      vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
      if(poCtrl.style["filter"]) poCtrl.style["filter"] = "";
    }
  }

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else if(this.wordWrap == true) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", "hand");

  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");
  vaTemplate[voIndexMap.get(1)] = this.getLabelText(this.value);

  var vnIndex = 2;
//  var vcTab = this.parent.parent;
//  if(vcTab.type == "minimizedWindow") {
//    vaCssStrBuf = [];
//    vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;border-width:0px;left:" + (this.innerWidth - 20) + "px;top:0px;");
//    vaCssStrBuf.push("border-style:none;font-family:Arial;font-weight:bold;text-align:center;outline-style:none;");
//    vfcSetCssStrBuf(vaCssStrBuf, "width", 20, "px");
//    vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
//    vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
//    vaTemplate[voIndexMap.get(vnIndex++)] = vaCssStrBuf.join("");
//  }

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(vnIndex)] = vaCssStrBuf.join("");
  poCtrl.innerHTML = vaTemplate.join("");

  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;

  this.setSubElement(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  voEvent.object = poControl;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsEventCallback = vsType + "EventCallback";
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리

  if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if (poControl[vsOnEvent]) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(poControl[vsEventCallback]) { poControl[vsEventCallback](voEvent); }
  if(poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
};
eXria.controls.xhtml.MDIButton.prototype.setSpecificEvents = function(poCtrl) {
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.atmouseover = function(poEvent) {
}
/**
* @ignore
*/
eXria.controls.xhtml.MDIButton.prototype.atmouseout = function(poEvent) {
}
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.atclick = function(poEvent) {
  var vsPageId = this.id.substring(0, this.id.indexOf("_button"));
  var vsPageNum = this.parent.getIndexById(vsPageId);
  
  var voMdiPage = this.parent.mdiPageSet.elements[vsPageNum];
  var voMdiPageCtrl = this.document.getElementById(voMdiPage.id);
  var voMdiButton = this.document.getElementById(this.id);
  var voResizeLabel = this.document.getElementById(voMdiPageCtrl.id+"_resize");
  this.parent.zIndexSeq++;
  var vnZIndex = this.parent.zIndexSeq;
  
  voMdiPageCtrl.style["display"] = "block";
  voResizeLabel.style["display"] = "block";
  voMdiButton.style["background-color"] = "cornflowerblue";
  
  vnZIndex += 200;
  voMdiPageCtrl.style["zIndex"] = vnZIndex;
  voResizeLabel.style["zIndex"] = vnZIndex+1;
  
  //zIndex 증가
  this.parent.zIndexSeq++;

  // 조영진 선임 추가 코드
//  var voTabHeader = this.parent;
//  var voTab = voTabHeader.parent;
//  var voButton = poEvent.object;
//  var vnIndex = voTab.getIndexById(voButton.pageId);
//  if(vnIndex != voTab.selectedIndex) voTabHeader.select(vnIndex);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voBtn = voCtrl.childNodes[0];
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
//    if(this.borderLeftWidth == null) this.borderLeftWidth = this.borderWidth;
//    if(this.borderRightWidth == null) this.borderRightWidth = this.borderWidth;
//    if(this.borderTopWidth == null) this.borderTopWidth = this.borderWidth;
//    if(this.borderBottomWidth == null) this.borderBottomWidth = this.borderWidth;
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;

    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  //case "borderTopHeight" :
  case "borderBottomWidth" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "value" :
    this.setValue(psAttrValue, voBtn, poDocument);
    break;
  case "backgroundImage" :
  case "imageFocused" :
    if(this.focused) this.setAttrCtrl("backgroundImage", this.imageFocused, voBtn);
    else this.setAttrCtrl("backgroundImage", this.backgroundImage, voBtn);
    break;
  case "backgroundPosition":
  case "backgroundRepeat":
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "outerClassName" :
  case "className" :
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  var vsDefaultValue = eXria.controls.xhtml.Default.MDIGroup.MDIButtons[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIButton.prototype.getEHandler2 = function(psPageId) {
  var voTabHeader = this.parent;
  var voTab = voTabHeader.parent;
  var vnIndex = voTab.getIndexById(psPageId);
  var vaStrBuf = [];
  vaStrBuf.push("var voControl=page.getControl('");
  vaStrBuf.push(voTab.id);
  vaStrBuf.push("');");
  vaStrBuf.push("voControl.")
  vaStrBuf.push("removeMinimizedWindowTab(" + vnIndex + ");");
  vaStrBuf.push("var voEvent = new eXria.event.Event(event);");
  vaStrBuf.push("voEvent.stopEvent();");
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};

/**
 * 클래스 명을 반환.
 * @return "MDIButton"
 * @type String
 */
eXria.controls.xhtml.MDIButton.prototype.toString = function() {
  return "MDIButton";
};

/**
 * @class Concreate xhtml MDIPageButton<br>
 * XHTML MDIPageButton control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MDIPageButton 객체
 * @type eXria.controls.xhtml.MDIPageButton
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.MDIPageButton = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 상위 컨트롤과의 위치 관계(absolute | relative | static).
   * @type String
   */
  this.position = "absolute";
  /**
   * 버튼에 라벨값(아이콘 url정보 포함) 저장.
   * @type String
   */
  this.value = null;
  /**
   * 컨트롤 외곽 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 컨트롤 외곽 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 컨트롤 외곽 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 컨트롤 외곽 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 컨트롤에 표시될 텍스트 가로정렬.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트에 밑줄을 넣을때.
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 버튼이 눌려을 때 표시될 이미지.
   * @type String
   */
  this.imagePushed = null;
  /**
   * 버튼에 포커스가 위치했을 때 표시될 이미지.
   * @type String
   */
  this.imageFocused = null;
  /**
   * 버튼에 마우스가 위치했을 때 표시될 이미지.
   * @type String
   */
  this.imageMouseover = null;
  /**
   * 버튼의 이미지가 바뀌기전의 이미지.
   * @type String
   * @type private
   */
  this.oldImage = null;
  /**
   * 버튼에 포커스가 위치했는지 여부.
   * @type boolean
   * @private
   */
  this.focused = false;
  /**
   * MDIPages 버튼 cursor값
   * @type String
   * @private
   */
  this.cursor = null;
  /**
   * 자동줄바꿈 여부.
   * @type Boolean
   */
  this.wordWrap = null;
   /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * default로 eXria_CSS_Configure.xml에 정의된 값으로 설정(최소 default 설정 필요함)
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.MDIPageButton);
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<button hidefocus='true' type='button' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_btn' style=\"");
  vaTemplate.push("@cssStrbuf"); //setSpecificAttrs메소드에서  스타일 속성이 대체될  부분은 @cssStrBuf로 마크(Element 속성의 경우엔 @attStrBuf로 마크)
  vaTemplate.push("\" class='" + vsClass + "'>");
  vaTemplate.push("@innStrBuf"); //setSpecificAttrs메소드에서 innerHTML이 대체될 부분은 @innStrBuf로 마크
  vaTemplate.push("</button>");
  vaTemplate.push("<span style=\"");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("\"/>");
};

eXria.controls.xhtml.MDIPageButton.prototype.refreshTemplate = null;
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    this.showContextByClick = voUserAttr.showContextByClick;
    this.labelName = voUserAttr.labelName;
  }
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.width = this.getAttrValue("width", this.width);
  this.value = this.getAttrValue("value", this.value);
  this.backgroundImage = this.getAttrValue("backgroundImage", this.backgroundImage);
  this.imagePushed = this.getAttrValue("imagePushed", this.imagePushed);
  //if(this.imagePushed) this.imagePushed = eXria.controls.xhtml.Util.getBackgroundImagePath(this.imagePushed, this.window);
  this.imageFocused = this.getAttrValue("imageFocused", this.imageFocused);
  //if(this.imageFocused) this.imageFocused = eXria.controls.xhtml.Util.getBackgroundImagePath(this.imageFocused, this.window);
  this.imageMouseover = this.getAttrValue("imageMouseover", this.imageMouseover);
  //if(this.imageMouseover) this.imageMouseover = eXria.controls.xhtml.Util.getBackgroundImagePath(this.imageMouseover, this.window);
  this.wordWrap = this.getAttrValue("wordWrap", this.wordWrap);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  ///////////////////////////////////////////////////////////////////////////////////
  // 블럭 A
  // 이 블럭의 코드는 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  ///////////////////////////////////////////////////////////////////////////////
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.09.21 기존에 이와같은 코드가 있었는데 아예 동작을 안했는데 여기서는 동작이 되서 side effect 생김
  //if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", "hand");
  poCtrl.style.cssText = vaCssStrBuf.join("");
  //////////////////////////////////////////////////////////////////////////////////////////
  // 블럭 A 끝
  //////////////////////////////////////////////////////////////////////////////////////////

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;left:0px;top:0px;border-style:none;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);

  // AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
  // backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.
  if(this.backgroundImage) {
    if(this.backgroundImage.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
      var vsSplit = this.backgroundImage.split("\'");
      if(vsSplit[0] == "url(")
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[2] + "')");
      else
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[1] + "')");
    } else {
      vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
      if(poCtrl.style["filter"]) poCtrl.style["filter"] = "";
    }
  }

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else if(this.wordWrap == true) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", "hand");

  vaTemplate[3] = vaCssStrBuf.join("");
  vaTemplate[5] = this.getLabelText(this.value);
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[8] = vaCssStrBuf.join("");
  poCtrl.innerHTML = vaTemplate.join("");

  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;

  this.setSubElement(poDocument);
};
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.button = this.getSubCtrl("button", voCtrl, poDocument);
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.setSpecificEvents = function(poCtrl) {
  var voBtn = this.subElement.button;
  this.eventManager.addListener(voBtn, "onblur", this.mediateEvent);
  this.eventManager.addListener(voBtn, "onfocus", this.mediateEvent);
  voBtn.control = this;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.dofocus = function() {
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  if(this.visible != false)
    voBtn.focus();
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.atfocus = function(poEvent) {
  var voDf = this.df;
  this.focused = true;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var vsImage = voBtn.style.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(this.imageFocused) {
    vsImage = this.imageFocused;
  }
  this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.atblur = function(poEvent) {
  var voDf = this.df;
  this.focused = false;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.atmousedown = function(poEvent) {
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  if(poEvent.target == voBtn) this.focused = true;
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(this.imagePushed) vsImage = this.imagePushed;
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.atmouseup = function(poEvent) {
  var voDf = this.df;
  if(!this.imagePushed) return;
  var voBtn = this.subElement.button;
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.atmouseover = function(poEvent) {
  if(this.focused == null) return;  //조건절이 true가 될 수 없는 코드

  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(this.imageFocused && this.imageFocused == vsImage) return;
  if(this.imageMouseover) vsImage = this.imageMouseover;
//  if(poEvent.target.id == this.id) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.atmouseout = function(poEvent) {
  if(this.focused == null) return;  //조건절이 true가 될 수 없는 코드

  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
//if(poEvent.target.id == this.id) this.setAttrCtrl("backgroundImage", this.oldImage, voBtn);
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.atclick = function(poEvent) {
  //to-do button 제어
  var voMdiGroup = this.parent.parent;
  var voMdiPage = this.parent;
  
  var vnPageNum = voMdiGroup.getIndexById(voMdiPage.id);
  var voPageCtrl = voMdiGroup.mdiPageSet.elements[vnPageNum];
  var voResizeLable = this.document.getElementById(voMdiPage.id+"_resize");
  var vnPageLabelNum = voMdiGroup.getIndexLabelById(voResizeLable.id);
  var voMdiButton = this.document.getElementById(voMdiPage.id+"_button");
  var vsResourceBaseUrl = (this.canvas.page.metadata.resourceBaseUrl == "/") ? "" : this.canvas.page.metadata.resourceBaseUrl;
  var voMdiSubpage = null;
  if(voMdiPage.pagebody.controls) {
    var vnPageBodyCtrlCnt = voMdiPage.pagebody.controls.size();
    var voCtrl = null;
    for(var i = 0; i < vnPageBodyCtrlCnt; i++){
      voCtrl = voMdiPage.pagebody.controls.elements[i];
      if(voCtrl.toString() == "SubPage") voMdiSubpage = voCtrl;
    }
  }
  
  if(this.backgroundImage.indexOf("up.jpg") > - 1){
    voMdiPage.applyAttr("visible", false);
    voResizeLable.style["display"] = "none";
    voMdiButton.style["background-color"] = "red";
  }else if(this.backgroundImage.indexOf("Enlargement.jpg") > - 1 || this.backgroundImage.indexOf("minimal.jpg") > - 1){
    
    if(this.backgroundImage.indexOf("Enlargement.jpg") > - 1){
      voMdiPage.currentCodinate(voMdiPage);
      this.applyAttr("backgroundImage", "url("+vsResourceBaseUrl+"/eXria/controls/xhtml/images/minimal.jpg)");
      voMdiPage.applyAttr("top", 1);
      voMdiPage.applyAttr("left", 1);
      voMdiPage.applyAttr("height", voMdiGroup.height - voMdiGroup.titleBarHeight);
      voMdiPage.applyAttr("width", voMdiGroup.width - 3);
      
      voMdiPage.pagebody.applyAttr("top", voMdiPage.pagecaption.height);
      voMdiPage.pagebody.applyAttr("left", 1);
      voMdiPage.pagebody.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
      voMdiPage.pagebody.applyAttr("width", voMdiGroup.width - 3);
      
      if(voMdiSubpage){
        voMdiSubpage.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
        voMdiSubpage.applyAttr("width", voMdiGroup.width - 3);
      }
    }else{
      //to-do 위치값 저장 변수 선언 mdipage 것
      this.applyAttr("backgroundImage", "url("+vsResourceBaseUrl+"/eXria/controls/xhtml/images/Enlargement.jpg)");
      voMdiPage.applyAttr("top", voMdiPage.currentTop);
      voMdiPage.applyAttr("left", voMdiPage.currentLeft);
      voMdiPage.applyAttr("height", voMdiPage.currentHeight);
      voMdiPage.applyAttr("width", voMdiPage.currentWidth);
      
      voMdiPage.pagebody.applyAttr("top", voMdiPage.pagecaption.height);
      voMdiPage.pagebody.applyAttr("left", 1);
      voMdiPage.pagebody.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
      voMdiPage.pagebody.applyAttr("width", voMdiPage.width);
      
      if(voMdiSubpage){
        voMdiSubpage.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
        voMdiSubpage.applyAttr("width", voMdiPage.width);
      }
    }
    this.mdiPageButtonMove(voPageCtrl);
    voMdiPage.mdiLabelMove();
  }else if(this.backgroundImage.indexOf("close.jpg") > - 1){
    if(page.voFncListAdd) page.voFncListAdd(voMdiPage.id);
    this.canvas.removeControl(voResizeLable.id);
    this.canvas.removeControl(voMdiButton.id);
    this.canvas.removeControl(voMdiPage.id);
    // TODO 추후 mdiGroupSet 도 제거해 줘야 함
    voMdiGroup.mdiPageSet.remove(vnPageNum);
    if(voMdiSubpage)  voMdiGroup.mdiPageSet.remove(vnPageNum);
    voMdiGroup.mdiPageResizeSet.remove(vnPageLabelNum);
    voMdiGroup.mdiButtonMove();
  }
    
  if(this.showContextByClick == null) return;
  var vcCtl = this.canvas.page.getControl(this.showContextByClick);
  vcCtl.left = this.left;
  vcCtl.top = this.top + this.height;
  if(this.showContext) {
    vcCtl.isShowing = false;
    this.showContext = null;
  } else {
    vcCtl.isShowing = true;
    this.showContext = true;
  }
  vcCtl.refresh();
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.mdiPageButtonMove = function(poPageCtrl) {
  if(!this.id) return;
  
  var poBtn1 = this.document.getElementById(poPageCtrl.id+"_button_1");
  var poBtn2 = this.document.getElementById(poPageCtrl.id+"_button_2");
  var poBtn3 = this.document.getElementById(poPageCtrl.id+"_button_3");
  
  poBtn1.style.left = parseInt(poPageCtrl.width) - (25 + 25 + 35 + 6) + "px";
  poBtn2.style.left = parseInt(poPageCtrl.width) - (25 + 35 + 4) + "px";
  poBtn3.style.left = parseInt(poPageCtrl.width) - (35 + 2) + "px";
};
  
/**
 * 텍스트 박스의 텍스트 세로정렬을 새로고침 합니다.
 * @param {HTMLDiv} poCtrl
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.setInputHeight = function(poCtrl){
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  var vsText = voBtn.value;
  if(vsText == "") voSpan.innerHTML = "&nbsp;";
  else voSpan.innerHTML = vsText;
  //var vnHeight = voSpan.offsetHeight;
  //this.setAttrCtrl("height", vnHeight, voBtn);
}
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.loadComplete = function(poDocument) {
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  if(this.canvas.page.metadata.browser.opera){
    this.setInputHeight(voCtrl);
    this.setVerticalAlign(voBtn, voCtrl);
  }
};
/**
 * 수직정렬 처리.
 * @param {HTMLElement} poCtrl 수직정렬 대상 Element
 * @param {HTMLElement} poParent 수직정렬 대상 Element 의 상위 Element
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.setVerticalAlign = function(poCtrl, poParent) {
  var vnHeight = this.subElement.span.offsetHeight;
  var vnParentHeight = parseInt(poParent.style.height);
  var vnPadding = vnParentHeight - vnHeight;
  if(vnPadding < 0) vnPadding = 0;
  vnPadding = vnPadding / 2;
  if(vnParentHeight < vnHeight) vnPadding = 0;
  poCtrl.style.paddingTop = vnPadding + "px";
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voBtn, psAttrValue);
    break;
  case "width" :
    this.setAttrCtrl("width", this.innerWidth, voBtn);
    break;
  case "height" :
    if(this.canvas.page.metadata.browser.opera){
      this.setVerticalAlign(voBtn, poCtrl);
    }
    this.setAttrCtrl("height", this.innerHeight, voBtn);
    break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageButton.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};

/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voBtn = this.subElement.button;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  voBtn.className = this.getCSSClass(this, 1);
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.09.21 기존 voDF.disabed는 아예 동작을 안했는데 여기서는 동작이 되서 side effect 생김
  //if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;left:0px;top:0px;border-style:none;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);

  // AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
  // backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.
  if(this.backgroundImage) {
    if(this.backgroundImage.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
      var vsSplit = this.backgroundImage.split("\'");
      if(vsSplit[0] == "url(")
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\'" + vsSplit[2] + "\')");
      else
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\'" + vsSplit[1] + "\')");
    } else {
      vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
      if(voBtn.style["filter"]) voBtn.style["filter"] = "";
    }
  }

  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else if(this.wordWrap == true) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");

  voBtn.style.cssText = vaCssStrBuf.join("");
  if(this.canvas.page.metadata.browser.opera){
  //20091125 최현종 수정 voCtrl -> poCtrl (opera bug)
    this.setVerticalAlign(voBtn, poCtrl, "middle");
  }
  voBtn.innerHTML = this.getLabelText(this.value)
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.refreshSpecificEvents = function(poCtrl) {
  this.setSpecificEvents(poCtrl);
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    if(this.canvas.page.metadata.browser.opera){
      this.setInputHeight(voCtrl);
      this.setVerticalAlign(voBtn, voCtrl, "middle");
    }
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    voCtrl.style[psAttrName] = psAttrValue + "px";
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.setAttrCtrl(psAttrName, this.df[psAttrName] + "px", voCtrl);
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "padding" :
    if(this.paddingLeft == null) this.paddingLeft = this.padding;
    if(this.paddingRight == null) this.paddingRight = this.padding;
    if(this.paddingTop == null) this.paddingTop = this.padding;
    if(this.paddingBottom == null) this.paddingBottom = this.padding;
    this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voBtn);
    this.setAttrCtrl("paddingRight", this.paddingRight + "px", voBtn);
    this.setAttrCtrl("paddingTop", this.paddingTop + "px", voBtn);
    this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voBtn);
    break;
  case "paddingLeft" :
  case "paddingRight" :
  case "paddingTop" :
  case "paddingBottom" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voBtn);
    break;
  case "backgroundImage" :
    psAttrValue = eXria.controls.xhtml.Util.getBackgroundImagePath(psAttrValue, this.window);
    if(voObj) voObj[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "value" :
    this.setValue(psAttrValue);
    break;
  case "backgroundColor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
  case "fontFamily" :
  case "fontSize" :
  case "fontStyle" :
  case "fontWeight" :
  case "textAlign" :
  case "textDecoration" :
  case "backgroundPosition":
  case "backgroundRepeat":
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "outerClassName" :
  case "className" :
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * loadData
 * @param {HTMLElement} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null || this.data.isRelativeRef()) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var vsRefValue = this.data.getData();
  this.setValue(vsRefValue);
};
/**
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
};
/**
 * 버튼에 라벨(아이콘 이미지 포함)을 표시합니다.
 * @param {String} psLabel 라벨명
 */
eXria.controls.xhtml.MDIPageButton.prototype.setValue = function(psLabel) {
  var voBtnCtrl = this.subElement.button;
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psLabel) {
    vbChanged = true;
  }
  this.value = psLabel;
  if(vbChanged) {
    this.data.setData(this.value);
  }

  voBtnCtrl.innerHTML = this.getLabelText(psLabel);
};
/**
 * 지정된 값을 버튼에 표시할 라벨 텍스트로 변경시켜 주는 메소드입니다.
 * @param {String} psValue 입력 텍스트
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.getLabelText = function(psValue) {
  if(psValue == null) return "";
  this.value = psValue;
//  this.df.value = psValue;

  var vaLabel = psValue.split(";");
  var vaStrBuf = [];
  var vsStr = null;
  vsStr = vaLabel[0];
  if(vsStr) {
    vsStr = vsStr.replace(/</g, "&lt;");
    vsStr = vsStr.replace(/>/g, "&gt;");
    vsStr = vsStr.replace(/\n/g, "<br/>");
    vsStr = eXria.controls.xhtml.Util.parseLang(vsStr);
    vaStrBuf.push(vsStr);
  }
  vsStr = vaLabel[1];
  if(vsStr) {
    vaStrBuf.push("<img src='");
    vaStrBuf.push(vsStr);
    vaStrBuf.push("'>");
  }

  return vaStrBuf.join("");
};
/**
 * 버튼에 표시된 라벨값을 반환합니다.
 * @return 컨트롤 value속성 값
 * @type String
 */
eXria.controls.xhtml.MDIPageButton.prototype.getValue = function() {
  return this.value;
};
/**
 * 버튼의 포커스를 해제합니다.
 */
eXria.controls.xhtml.MDIPageButton.prototype.blur = function() {
  this.ctrl.blur();
};
/**
 * 버튼에 클릭 이벤트를 발생시킵니다.
 */
eXria.controls.xhtml.MDIPageButton.prototype.click  = function() {
  this.ctrl.click();
};
/**
 * 버튼에 포커스를 발생시켜 줍니다.
 */
eXria.controls.xhtml.MDIPageButton.prototype.focus  = function() {
  this.ctrl.focus();
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @private
 */
eXria.controls.xhtml.MDIPageButton.prototype.getSpecificDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.Button[psAttrName];
  if(vsDefaultValue === undefined) {
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "MDIPageButton"
 * @type String
 */
eXria.controls.xhtml.MDIPageButton.prototype.toString = function() {
  return "MDIPageButton";
};

/**
 * 제목표시줄
 * @member eXria.controls.xhtml
 * @author ParkSC at 13. 4. 8 오후 1:53
 */
eXria.controls.xhtml.MDIPageCaption = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.Label.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Label, eXria.controls.xhtml.MDIPageCaption);
//////////////////////////////////////////////////////////////////

/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageCaption.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<div class=\"" + vsClass + "\" style=\"");
  vaTemplate.push("@cssStrBuf"); //0
  vaTemplate.push("\">&nbsp;</div>");
  vaTemplate.push("<span style=\"");
  vaTemplate.push("@cssStrBuf"); //1
  vaTemplate.push("\"/>");
  
  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};

/**
 * MDIPages의 공통속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.MDIPages = function() {
  /**
   * MDIPages의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * MDIPages의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * MDIPages의 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * MDIPages의 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * MDIPages의 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * MDIPages의 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * MDIPages의 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * MDI 바디에 담긴 컨트롤이 영역을 벗어날때 스크롤 처리.
   * @type String
   */
  this.overflow = null;
  /**
   * MDI 바디에 담긴 컨트롤이 영역을 벗어날때 횡 스크롤 처리.
   * @type String
   */
  this.overflowX = null;
  /**
   * MDI 바디에 담긴 컨트롤이 영역을 벗어날때 종 스크롤 처리.
   * @type String
   */
  this.overflowY = null;
  /**
   * MDIPages의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * MDIPages의 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * MDIPages의 외곽 div에 적용될 css 클래스 명.
   * @type String
   */
  this.outerClassName = null;
  /**
   * MDIPages의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};

/**
 * @class Concreate xhtml MDIPage.<br>
 * XHTML MDIPage 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MDIPage 객체
 * @type eXria.controls.xhtml.MDIPage
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 * @base eXria.controls.MDIGroup
 */
eXria.controls.xhtml.MDIPage = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight =  pnHeight == null ? 300 : pnHeight;

  eXria.controls.MDIGroup.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight); // UIControl을 상속받는다.
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * movable 속성
   * @type Boolean
   */
  this.movable = true;
  /**
   * 하위 컨트롤들의 readOnly 여부 설정
   * @type Boolean
   */
  this.readOnly = null;
  /**
   * 컨트롤이 디스플레이 되는 document
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 하위 컨트롤 id에 붙일 suffix 문자열
   * @type String
   * @private
   */
  this.idSuffix = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * MDIPage 의 최대화 기능 여부.
   * @type Boolean
   * @private
   */
  this.maximize = null;
  /**
   * MDIPage 의 최소화 기능 여부.
   * @type Boolean
   * @private
   */
  this.minimize = null;
  /**
   * MDIPage 의 복원 기능 여부.
   * @type Boolean
   * @private
   */
  this.restore = null;
  /**
   * MDIPage 의 Cursor.
   * @private
   */
  this.cursor = null;
  /*
   * MDIPage의 현재 Left위치
   * @Type Number
   */
  this.currentLeft = null;
  /*
   * MDIPage의 현재 Top위치
   * @Type Number
   */
  this.currentTop = null;
  /*
   * MDIPage의 현재 Width값
   * @Type Number
   */
  this.currentWidth = null;
  /*
   * MDIPage의 현재 Height값
   * @Type Number
   */
  this.currentHeight = null;
  /**
  * @private
  */
  this.impList = new eXria.data.Collection();
  /**
   * MDIPage Body 에 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.MDIPageBody
   */
  this.pagebody = new eXria.controls.xhtml.MDIPageBody(psId+"_body", pnLeft, pnTop+20, pnWidth, pnHeight-20);
  this.pagebody.parent = this;
  /**
   * Top_Label 에 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.MDIPageCaption
   */
  this.pagecaption = new eXria.controls.xhtml.MDIPageCaption(psId+"_caption", 4, 1, parseInt((pnWidth*0.8)), 18);
  this.pagecaption.parent = this;
  /**
   * MDIPage Button 에 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.MDIPageButton
   */
  this.pagebutton_1 = new eXria.controls.xhtml.MDIPageButton(psId+"_button_1", pnWidth - (25 + 25 + 35 + 6), 3, 25, 15);
  this.pagebutton_1.parent = this;
  /**
   * MDIPage Button 에 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.MDIPageButton
   */
  this.pagebutton_2 = new eXria.controls.xhtml.MDIPageButton(psId+"_button_2", pnWidth - (25 + 35 + 4), 3, 25, 15);
  this.pagebutton_2.parent = this;
  /**
   * MDIPage Button 에 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.MDIPageButton
   */
  this.pagebutton_3 = new eXria.controls.xhtml.MDIPageButton(psId+"_button_3", pnWidth - (35 + 2), 3, 35, 15);
  this.pagebutton_3.parent = this;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.MDIPage);
eXria.controls.xhtml.Util.createInheritance(eXria.controls.MDIGroup, eXria.controls.xhtml.MDIPage);
//////////////////////////////////////////////////////////////////
// 메소드

eXria.controls.xhtml.MDIPage.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsEventCallback = vsType + "EventCallback";
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;
//if(vsType == "change")
  switch(vsType) {
  case "mousedown" :
    break;
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }

  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
//  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(poControl[vsEventCallback]) { poControl[vsEventCallback](voEvent); }
  if(poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }

  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};

/**
 * @ignore
 */
eXria.controls.xhtml.MDIPage.prototype.atmousedown = function(e) {
  if(this.document == null) return;
  var voCanvas = this.canvas;
  // 컨트롤 이동을 처리
  if(this.movable) {
    if(this.document.ondragstart !== "undefined")
    {
      this.document.ondragstart = function() { return false; };
    }
    if((this.top <= (e.clientY-this.parent.top) && (e.clientY-this.parent.top) <= this.top + this.pagecaption.height)){
      this.startMove(e);
      e.stopEvent();
    }     
  } else if(this.dragDrop) {
    if(this.document.ondragstart !== "undefined")
    {
      this.document.ondragstart = function() { return false; };
    }
    this.startDrag(e);
    e.stopEvent();
  }else {
    if(voCanvas.page.metadata.browser.opera) {
    } else {
      this.document.ondragstart = function() { this.body.dragDrop(); };
    }
  }
};

eXria.controls.xhtml.MDIPage.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  
  var voPageCaptionCtrl = poDocument.createElement("div");
  voPageCaptionCtrl["id"] = this.id+"_caption";
  voPageCaptionCtrl["accesskey"] = this.accessKey;
  if(this.canvas.page.metadata.browser.ie > 0) voPageCaptionCtrl["hideFocus"] = true;
  
  voCtrl.appendChild(voPageCaptionCtrl);
  
  this.ctrl = voCtrl;
  this.document = poDocument;
  return voCtrl;
};

eXria.controls.xhtml.MDIPage.prototype.mdiLabelMove = function() {
  var voPageCtrl = this.document.getElementById(this.id);
  var voResizeLabelCtrl = this.document.getElementById(this.id + "_resize");
  this.parent.zIndexSeq++;
  var vnZIndex = this.parent.zIndexSeq;
  
  voResizeLabelCtrl.style.top = (parseInt(voPageCtrl.style.top) + parseInt(voPageCtrl.style.height) - parseInt(voResizeLabelCtrl.style.height)) + "px";
  voResizeLabelCtrl.style.left = (parseInt(voPageCtrl.style.left) + parseInt(voPageCtrl.style.width) - parseInt(voResizeLabelCtrl.style.width)) + "px";
  
  vnZIndex += 200;
  voPageCtrl.style["zIndex"] = vnZIndex;
  voResizeLabelCtrl.style["zIndex"] = vnZIndex+1;
  
  this.parent.zIndexSeq++;
};

eXria.controls.xhtml.MDIPage.prototype.currentCodinate = function(voMdiPage){
  this.currentLeft = voMdiPage.left;
  this.currentTop = voMdiPage.top;
  this.currentHeight = voMdiPage.height;
  this.currentWidth = voMdiPage.width;
};

eXria.controls.xhtml.MDIPage.prototype.startMove = function(e) {
  if (this.disabled == true) {
    return;
  }
  var voDocument = this.document;
  var voParent = this.parent;
  if (voParent == null) voParent = this.canvas;
  var voCtrl = this.getCtrl();
  
  var voGlassPane = new eXria.controls.xhtml.GlassPane(voParent);
  this.glassPane = voGlassPane;
  voGlassPane.opacity = 10;
  voParent.ctrl.parentNode.appendChild(voGlassPane.create(voDocument));
  
  var voPane = this.paneHandler.createPane();
  var voPaneStyle = voPane.style;
  
  var voEvent = e;
  var voTarget = voEvent.target;
  this.mode = voTarget.style.cursor;
  
  this.clientAbsLeft = this.getClientAbsLeft();
  this.clientAbsTop = this.getClientAbsTop();
  
  var vnMouseX = voEvent.e.clientX - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY - this.clientAbsTop;
  
  var vnPaneLeft = parseInt(voPaneStyle.left);
  var vnPaneTop = parseInt(voPaneStyle.top);
  this.leftOffset = vnPaneLeft - vnMouseX;
  this.topOffset = vnPaneTop - vnMouseY;
  
  this.backupCtrlCsr = this.getCtrl().style.cursor;
  voPaneStyle.display = "block";
  voDocument.body.style.cursor = "default";
  this.getCtrl().style.cursor = "default";
  
  voPane.control = this;
  voPane.onmousemove = function(e) {
    this.control.onMove(e);
  };
  voPane.onmouseup = function(e) {
    this.control.stopMove(e);
    this.control.mdiLabelMove(e);
  };
  voDocument.control = this;
  voDocument.onmousemove = function(e) {
    this.control.onMove(e);
  };
  if (typeof voPane.onselectstart != "undefined") {
    voPane.onselectstart = function(e) {
      return false;
    };
  } else {
    voPane.onmousedown = function(e) {
      return false;
    };
  }
}

eXria.controls.xhtml.MDIPage.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
};

eXria.controls.xhtml.MDIPage.prototype.setSpecificAttrs = function(poCtrl, poDocument, psDiv) {
  var vsClass = this.getCSSClass(this, 1);
  poCtrl.className = poCtrl.className + " " + vsClass;
  var vsResourceBaseUrl = (this.canvas.page.metadata.resourceBaseUrl == "/") ? "" : this.canvas.page.metadata.resourceBaseUrl;
  
  var voDf = this.df;
  this.setTemplate();
  var vaTemplate = this.template;
  var mdiSubpage = this.parent.mdisubpage;
  var vsOverFlow = null;
  var vaCssStrBuf = null;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;

  if(mdiSubpage) !!mdiSubpage.id? vsOverFlow="hidden": vsOverFlow = "auto";
//  else vsOverFlow = "auto";
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  // 2009.10.12 동적인 코드에서는 disabled를 제어하지 않으며 FF에서는 없는 속성이다
  //if(this.disabled) poCtrl["disabled"] = true;

  var vsBackgroundImage = "url("+vsResourceBaseUrl+"/eXria/controls/xhtml/images/groupBack.jpg)";
  var vsBackgroundRepeat = "repeat-x";
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "tooltip", this.tooltip);
  vfcSetCssStrBuf(vaCssStrBuf, "disabled", this.disabled);
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", vsBackgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", vsBackgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", vsOverFlow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", vsOverFlow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", vsOverFlow);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  vaCssStrBuf = null;
//  poCtrl.outerHTML = vaTemplate.join("");
  
  /////////////////////////////////////////////////////////////////////////////////////////////////
  //Group 속성 끝//
  ////////////////////////////////////////////////////////////////////////////////////////////////
  
  var voCaptionDf = this.pagecaption;
  var poCaptionCtrl = this.document.getElementById(this.id+"_caption");
  voCaptionDf.setTemplate();
  var vaTemplate = voCaptionDf.template;
  
  // 반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  // 단, 함수 내부에 voCaptionDf라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = voCaptionDf.setCssStrBuf;
  var vfcSetAttStrBuf = voCaptionDf.setAttStrBuf;
  var voIndexMap = voCaptionDf.templateIndexMap;
  poCaptionCtrl["tabIndex"] = voCaptionDf.tabIndex;
  
  poCaptionCtrl["tooltip"] = voCaptionDf.tooltip;
  if(voCaptionDf.disabled) poCaptionCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;outline-style:none;");
  if(voCaptionDf.visible == false) vaCssStrBuf.push("display:none;");
//  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", voCaptionDf.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", voCaptionDf.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voCaptionDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", voCaptionDf.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", voCaptionDf.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", voCaptionDf.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", voCaptionDf.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", voCaptionDf.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", voCaptionDf.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", voCaptionDf.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", voCaptionDf.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", voCaptionDf.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", voCaptionDf.borderBottomWidth, "px");

  //외각DIV
  //2010.06.03
  //내부DIV 영역에 스크롤이 생성되는 경우를 막기 위해
  //visible 과 hidden 이 아닌경우에는 auto가 되게 수정
  if(!!voCaptionDf.overflow && !!(voCaptionDf.overflow === "scroll" || voCaptionDf.overflow === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "auto");
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", voCaptionDf.overflow);

  if(!!voCaptionDf.overflowX && !!(voCaptionDf.overflowX === "scroll" || voCaptionDf.overflowX === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", auto);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", voCaptionDf.overflowX);

  if(!!voCaptionDf.overflowY && !!(voCaptionDf.overflowY === "scroll" || voCaptionDf.overflowY === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", voCaptionDf.overflowY);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", voCaptionDf.overflowY);


  vfcSetCssStrBuf(vaCssStrBuf, "cursor", voCaptionDf.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voCaptionDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voCaptionDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", voCaptionDf.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", voCaptionDf.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", voCaptionDf.backgroundImage);

  poCaptionCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;position:absolute;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", voCaptionDf.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", voCaptionDf.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", voCaptionDf.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", voCaptionDf.paddingBottom, "px");
  var vnWidth = voCaptionDf.innerWidth;
  if(voCaptionDf.paddingLeft !== null) vnWidth = vnWidth - voCaptionDf.paddingLeft;
  if(voCaptionDf.paddingRight !== null) vnWidth = vnWidth - voCaptionDf.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", voCaptionDf.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", voCaptionDf.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", voCaptionDf.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", voCaptionDf.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", voCaptionDf.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", voCaptionDf.color);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voCaptionDf.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", voCaptionDf.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");

  if(voCaptionDf.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else{
    vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
    //2010.06.01
    //영문자 개행 관련 word-wrap 추가
    vfcSetCssStrBuf(vaCssStrBuf, "word-wrap","break-word");
  }

  //2010.06.03
  //내부 div 스크롤 관련 버그 수정
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow", voCaptionDf.overflow);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", voCaptionDf.overflowX);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", voCaptionDf.overflowY);

  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", voCaptionDf.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", voCaptionDf.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", voCaptionDf.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", voCaptionDf.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voCaptionDf.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", voCaptionDf.textDecoration);
  vaTemplate[voIndexMap.get(1)] = vaCssStrBuf.join("");

  poCaptionCtrl.innerHTML = vaTemplate.join("");
  
  voIndexMap.clear();
  vaCssStrBuf = null;
  vaTemplate = null;
  voCaptionDf.template = null;
  voCaptionDf.templateIndexMap = null;
  /////////////////////////////////////////////////////////////////////////////////////////////////
  //MDIPageCaption 속성 끝//
  ////////////////////////////////////////////////////////////////////////////////////////////////
  
};

/*
 * 제목표시줄 value
 */
eXria.controls.xhtml.MDIPage.prototype.setCaptionText = function() {
  var voCaptionDf = this.pagecaption;
  var poCaptionCtrl = this.document.getElementById(voCaptionDf.id);
  
  voCaptionDf.setText(poCaptionCtrl, this.btn.value);
};

eXria.controls.xhtml.MDIPage.prototype.maxMdiPage = function() {
  var voMdiGroup = this.parent;
  
  var vnPageNum = voMdiGroup.getIndexById(this.id);
  var voPageCtrl = voMdiGroup.mdiPageSet.elements[vnPageNum];
  var vsResourceBaseUrl = (this.canvas.page.metadata.resourceBaseUrl == "/") ? "" : this.canvas.page.metadata.resourceBaseUrl;
  
  this.currentCodinate(this);
  this.pagebutton_2.applyAttr("backgroundImage", "url("+vsResourceBaseUrl+"/eXria/controls/xhtml/images/minimal.jpg)");
  this.applyAttr("top", 1);
  this.applyAttr("left", 1);
  this.applyAttr("height", voMdiGroup.height - voMdiGroup.titleBarHeight);
  this.applyAttr("width", voMdiGroup.width - 3);
  
  this.pagebody.applyAttr("top", this.pagecaption.height);
  this.pagebody.applyAttr("left", 1);
  this.pagebody.applyAttr("height", this.height - this.pagecaption.height);
  this.pagebody.applyAttr("width", voMdiGroup.width - 3);
  
  this.parent.mdisubpage.applyAttr("height", this.height - this.pagecaption.height);
  this.parent.mdisubpage.applyAttr("width", voMdiGroup.width - 3);
  
  this.pagebutton_2.mdiPageButtonMove(voPageCtrl);
  this.mdiLabelMove();
};

eXria.controls.xhtml.MDIPage.prototype.refreshTemplate = function(poCtrl, poDocument) {
  if(this.setTemplate) this.setTemplate(poCtrl, poDocument);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.refreshTemplate) voChild.refreshTemplate(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIPage.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  this.setSpecificDefaults(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshSpecificDefaults(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIPage.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshSpecificAttrs(voChild.ctrl, voChild.document);
  }
};

 eXria.controls.xhtml.MDIPage.prototype.reloadData = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
  if(voChild.reloadData) voChild.reloadData(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIPage.prototype.refreshComplete = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshComplete(voChild.ctrl, voChild.document);
  }
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  this.setDisable(poCtrl, this.disabled);
  this.hideFocusLine(poCtrl, true);
};

eXria.controls.xhtml.MDIPage.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPage.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;

  var voTable = poCtrl.childNodes[0];

  switch(psAttrName) {
    case "disabled" :
      poCtrl.disabled = psAttrValue;
      this.applyAttrToChildren("disabled", psAttrValue);
      break;
    //case "borderWidth" :
    //  this.innerWidth = this.width - 2 * this.borderWidth;
    //  this.innerHeight = this.height - 2 * this.borderWidth;
    //  poCtrl.style.width = this.innerWidth + "px";
    //  poCtrl.style.height = this.innerHeight + "px";
    //  break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPage.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
//  var voCtrl = this.lookup(poDocument.id, poDocument);
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
    break;
  case "className" :
  case "outerClassName" :
  case "overflow" :
    this.refresh(poDocument);
    break;
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue)
    this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
    var voChild = null;
    var voIterator = this.controls.iterator();
    while(voIterator.hasNext()) {
      voChild = voIterator.next();
      if(voChild.refreshVerticalAlign) {
        voChild.refreshVerticalAlign();
      }
    }
    break;
  case "readOnly" :
    this.setReadOnly(psAttrValue);
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  }
};

eXria.controls.xhtml.MDIPage.prototype.clear = function() {
  this.removeChildren();
  this.clearCtrl();
  this.clearControl();
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPage.prototype.loadComplete = function() {
  this.createChildren();
  this.addChild(this.pagebutton_1);
  this.addChild(this.pagebutton_2);
  this.addChild(this.pagebutton_3);
  this.addChild(this.pagebody);
  var vsResourceBaseUrl = (this.canvas.page.metadata.resourceBaseUrl == "/") ? "" : this.canvas.page.metadata.resourceBaseUrl;
  this.pagebutton_1.applyAttr("backgroundImage", "url("+ vsResourceBaseUrl +"/eXria/controls/xhtml/images/up.jpg)");
  this.pagebutton_2.applyAttr("backgroundImage", "url("+ vsResourceBaseUrl +"/eXria/controls/xhtml/images/Enlargement.jpg)");
  this.pagebutton_3.applyAttr("backgroundImage", "url("+ vsResourceBaseUrl +"/eXria/controls/xhtml/images/close.jpg)");
  this.setCaptionText();
  //subpage 일때 max 로 창키움 현재는 막음
//  if(this.pagebody.get(this.id+"_subpage"))  this.maxMdiPage();
  if (this.parent.mdiCallFnc == "addMdiSubPage") this.parent.mdiInitLayout();
  
  if(this.readOnly != null) this.setReadOnly(this.readOnly);
};
/**
 * 컨트롤에 하위 컨트롤를 추가합니다.
 * @param {eXria.controls.xhtml.Control} poControl 추가 대상 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document(생략가능)
 */
eXria.controls.xhtml.MDIPage.prototype.addChild = function(poControl, poDocument) {
  var that = null;
  if(poControl.id.indexOf("_button_") > -1 || poControl.id.indexOf("_body") > -1) that = this;
  else that = this.pagebody;
  
  var voCanvas = that.canvas;
  if(poDocument == null) poDocument = that.document;
  var voCanvas = that.canvas;
  poControl.parent = that;
  poControl.canvas = voCanvas;
  poControl.window = that.window;
  poControl.document = that.document;
  that.addItem(poControl);
  if(voCanvas) voCanvas.registerControl(poControl);
  var voCtrl = that.getCtrl(poDocument);
  if((that.visible || that.visible == null) && voCtrl) {
    voCtrl.appendChild(poControl.create(poDocument));
    poControl.load(poDocument);
  // TODO 추후 수정
    var name = poControl.toString();
    if(name == "Rectangle" || name == "Roundrect" || name == "Ellipse" ) {poControl.getCtrl(poDocument).blur();};
  }
};
/**
 * 하위 컨트롤을 제거 시킵니다.
 * @param {String} psId 제거대상 컨트롤 id
 */
eXria.controls.xhtml.MDIPage.prototype.removeChild = function(psId) {
  var vnIndex = this.getIndex(psId);
  var voControl = this.controls.remove(vnIndex);
  voControl.clear();
};
/**
 * 하위 컨트롤 id에 매칭되는 컨트롤 식별 인덱스 번호를 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 하위 컨트롤 식별 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.MDIPage.prototype.getIndex = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vnIndex = -1;
  while(voIterator.hasNext()) {
    vnIndex++;
    voControl = voIterator.next();
    if (voControl.id == psId) break;
  }
  return vnIndex;
};
/**
 * 지정된 id에 해당하는 하위 컨트롤을 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 지정된 id에 해당하는 하위 컨트롤 객체
 * @type eXria.controls.xhtml.Control
 */
eXria.controls.xhtml.MDIPage.prototype.get = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    if (voControl.id == psId) { return voControl; }
  }
  return null;
};
/**
 * 포함된 하위 컨트롤의 실체화 객체를 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {String} psIdSuffix 실체화된 컨트롤 id에 따라붙을 문자열
 * @private
 */
eXria.controls.xhtml.MDIPage.prototype.createChildren = function(poDocument, psIdSuffix) {
  if(poDocument == null) poDocument = this.document;
  if(psIdSuffix == null && this.idSuffix) psIdSuffix = this.idSuffix;
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vsId = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    vsId = voControl.id;
    if(psIdSuffix != null) voControl.id += psIdSuffix;
    if(voControl.canvas == null) {
      voControl.canvas = this.canvas;
      voControl.window = this.window;
      voControl.document = this.document;
      this.canvas.registerControl(voControl);
    }
    if(voControl.toString() != "Timer") {
      this.appendChild(voControl.create(poDocument), poDocument);
      //voControl.refresh(poDocument);
      voControl.load(this.document);
    }
    voControl.id = vsId;
  }
};
/**
 * 하위 컨트롤에 일괄적으로 속성을 적용합니다.
 * @param {String} psAttrValue 지정된 속성값
 * @param {String} psAttrName 속성명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.MDIPage.prototype.applyAttrToChildren = function(psAttrName, psAttrValue, poDocument) {
  if(this.getCtrl(poDocument) == null) return;

  var voIterator = this.controls.iterator();
  var voControl = null;
  var voCtrl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    voCtrl = voControl.getCtrl(poDocument);
    if(voCtrl) voControl.applyAttr(psAttrName, psAttrValue, poDocument);
  }
};
/**
 * 모든 하위 컨트롤을 제거 시킵니다.
 */
eXria.controls.xhtml.MDIPage.prototype.removeChildren = function() {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
//debugger;
    this.canvas.unregisterControl(voControl.id);
    if(voControl.toString() == "SubPage") {
//      var voWindow = voControl.ctrl.contentWindow;
//      if(voWindow) {
//        voWindow.close();
//      }
        voControl.setSrc("javascript:false");
    }
    voControl.clear();
  }
  this.controls.clear();
};

eXria.controls.xhtml.MDIPage.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.MDIGroup.mdipages.mdipage[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 하위 컨트롤의 readOnly속성을 설정
 * @param {String} pbEnable readOnly속성을 활성화할지 여부
 */
eXria.controls.xhtml.MDIPage.prototype.setReadOnly = function(pbEnable) {
  var voIterator = this.controls.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.readOnly !== undefined) voChild.applyAttr("readOnly", pbEnable);
  }
};
/**
 * 클래스 명을 반환합니다.
 * @return "MDIPage"
 * @type String
 */
eXria.controls.xhtml.MDIPage.prototype.toString = function() {
  return "MDIPage";
};

/**
 * @class Concreate xhtml MDIPageBody.<br>
 * XHTML MDIPageBody 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MDIPageBody 객체
 * @type eXria.controls.xhtml.MDIPageBody
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 * @base eXria.controls.MDIGroup
 */
eXria.controls.xhtml.MDIPageBody = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight =  pnHeight == null ? 300 : pnHeight;

  eXria.controls.MDIGroup.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight); // UIControl을 상속받는다.
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * movable 속성
   * @type Boolean
   */
  this.movable = null;
  /**
   * 하위 컨트롤들의 readOnly 여부 설정
   * @type Boolean
   */
  this.readOnly = null;
  /**
   * 컨트롤이 디스플레이 되는 document
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 하위 컨트롤 id에 붙일 suffix 문자열
   * @type String
   * @private
   */
  this.idSuffix = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  
  this.cursor = null;
  /**
  * @private
  */
  this.impList = new eXria.data.Collection();
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.MDIPageBody);
eXria.controls.xhtml.Util.createInheritance(eXria.controls.MDIGroup, eXria.controls.xhtml.MDIPageBody);
//////////////////////////////////////////////////////////////////
// 메소드

eXria.controls.xhtml.MDIPageBody.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsEventCallback = vsType + "EventCallback";
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;
//if(vsType == "change")
  switch(vsType) {
  case "mousedown" :
    break;
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }

  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(poControl[vsEventCallback]) { poControl[vsEventCallback](voEvent); }
  if(poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }

  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};

eXria.controls.xhtml.MDIPageBody.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  
  this.ctrl = voCtrl;
  this.document = poDocument;
  return voCtrl;
};

eXria.controls.xhtml.MDIPageBody.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
};

eXria.controls.xhtml.MDIPageBody.prototype.setSpecificAttrs = function(poCtrl, poDocument, psDiv) {
  var vsClass = this.getCSSClass(this, 1);
  poCtrl.className = poCtrl.className + " " + vsClass;

  var voDf = this.df;
  this.setTemplate();
  var vaTemplate = this.template;
  var vaCssStrBuf = null;
  var voParent = this.parent;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  // 2009.10.12 동적인 코드에서는 disabled를 제어하지 않으며 FF에서는 없는 속성이다
  //if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "tooltip", this.tooltip);
  vfcSetCssStrBuf(vaCssStrBuf, "disabled", this.disabled);
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", (this.parent.top + 20), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  vaCssStrBuf = null;
//  poCtrl.outerHTML = vaTemplate.join("");
  
  /////////////////////////////////////////////////////////////////////////////////////////////////
  //MDIPageBody 속성 끝//
  ////////////////////////////////////////////////////////////////////////////////////////////////
};

eXria.controls.xhtml.MDIPageBody.prototype.refreshTemplate = function(poCtrl, poDocument) {
  if(this.setTemplate) this.setTemplate(poCtrl, poDocument);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.refreshTemplate) voChild.refreshTemplate(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIPageBody.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  this.setSpecificDefaults(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshSpecificDefaults(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIPageBody.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshSpecificAttrs(voChild.ctrl, voChild.document);
  }
};

 eXria.controls.xhtml.MDIPageBody.prototype.reloadData = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
  if(voChild.reloadData) voChild.reloadData(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIPageBody.prototype.refreshComplete = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshComplete(voChild.ctrl, voChild.document);
  }
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  this.setDisable(poCtrl, this.disabled);
  this.hideFocusLine(poCtrl, true);
};

eXria.controls.xhtml.MDIPageBody.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageBody.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;

  var voTable = poCtrl.childNodes[0];

  switch(psAttrName) {
    case "disabled" :
      poCtrl.disabled = psAttrValue;
      this.applyAttrToChildren("disabled", psAttrValue);
      break;
    //case "borderWidth" :
    //  this.innerWidth = this.width - 2 * this.borderWidth;
    //  this.innerHeight = this.height - 2 * this.borderWidth;
    //  poCtrl.style.width = this.innerWidth + "px";
    //  poCtrl.style.height = this.innerHeight + "px";
    //  break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageBody.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
//  var voCtrl = this.lookup(poDocument.id, poDocument);
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
    break;
  case "className" :
  case "outerClassName" :
  case "overflow" :
    this.refresh(poDocument);
    break;
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue)
    this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
    var voChild = null;
    var voIterator = this.controls.iterator();
    while(voIterator.hasNext()) {
      voChild = voIterator.next();
      if(voChild.refreshVerticalAlign) {
        voChild.refreshVerticalAlign();
      }
    }
    break;
  case "readOnly" :
    this.setReadOnly(psAttrValue);
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  }
};

eXria.controls.xhtml.MDIPageBody.prototype.clear = function() {
  this.removeChildren();
  this.clearCtrl();
  this.clearControl();
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageBody.prototype.loadComplete = function() {
  this.createChildren();
  if(this.readOnly != null) this.setReadOnly(this.readOnly);
};
/**
 * 컨트롤에 하위 컨트롤를 추가합니다.
 * @param {eXria.controls.xhtml.Control} poControl 추가 대상 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document(생략가능)
 */
eXria.controls.xhtml.MDIPageBody.prototype.addChild = function(poControl, poDocument) {
  if(poDocument == null) poDocument = this.document;
  var voCanvas = this.canvas;
  poControl.parent = this;
  poControl.canvas = voCanvas;
  poControl.window = this.window;
  poControl.document = this.document;
  this.addItem(poControl);
  if(voCanvas) voCanvas.registerControl(poControl);
  var voCtrl = this.getCtrl(poDocument);
  if((this.visible || this.visible == null) && voCtrl) {
    voCtrl.appendChild(poControl.create(poDocument));
    poControl.load(poDocument);
  // TODO 추후 수정
    var name = poControl.toString();
    if(name == "Rectangle" || name == "Roundrect" || name == "Ellipse" ) {poControl.getCtrl(poDocument).blur();};
  }
};
/**
 * 하위 컨트롤을 제거 시킵니다.
 * @param {String} psId 제거대상 컨트롤 id
 */
eXria.controls.xhtml.MDIPageBody.prototype.removeChild = function(psId) {
  var vnIndex = this.getIndex(psId);
  var voControl = this.controls.remove(vnIndex);
  voControl.clear();
};
/**
 * 하위 컨트롤 id에 매칭되는 컨트롤 식별 인덱스 번호를 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 하위 컨트롤 식별 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.MDIPageBody.prototype.getIndex = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vnIndex = -1;
  while(voIterator.hasNext()) {
    vnIndex++;
    voControl = voIterator.next();
    if (voControl.id == psId) break;
  }
  return vnIndex;
};
/**
 * 지정된 id에 해당하는 하위 컨트롤을 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 지정된 id에 해당하는 하위 컨트롤 객체
 * @type eXria.controls.xhtml.Control
 */
eXria.controls.xhtml.MDIPageBody.prototype.get = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    if (voControl.id == psId) { return voControl; }
  }
  return null;
};
/**
 * 포함된 하위 컨트롤의 실체화 객체를 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {String} psIdSuffix 실체화된 컨트롤 id에 따라붙을 문자열
 * @private
 */
eXria.controls.xhtml.MDIPageBody.prototype.createChildren = function(poDocument, psIdSuffix) {
  if(poDocument == null) poDocument = this.document;
  if(psIdSuffix == null && this.idSuffix) psIdSuffix = this.idSuffix;
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vsId = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    vsId = voControl.id;
    if(psIdSuffix != null) voControl.id += psIdSuffix;
    if(voControl.canvas == null) {
      voControl.canvas = this.canvas;
      voControl.window = this.window;
      voControl.document = this.document;
      this.canvas.registerControl(voControl);
    }
    if(voControl.toString() != "Timer") {
      this.appendChild(voControl.create(poDocument), poDocument);
      //voControl.refresh(poDocument);
      voControl.load(this.document);
    }
    voControl.id = vsId;
  }
};
/**
 * 하위 컨트롤에 일괄적으로 속성을 적용합니다.
 * @param {String} psAttrValue 지정된 속성값
 * @param {String} psAttrName 속성명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.MDIPageBody.prototype.applyAttrToChildren = function(psAttrName, psAttrValue, poDocument) {
  if(this.getCtrl(poDocument) == null) return;

  var voIterator = this.controls.iterator();
  var voControl = null;
  var voCtrl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    voCtrl = voControl.getCtrl(poDocument);
    if(voCtrl) voControl.applyAttr(psAttrName, psAttrValue, poDocument);
  }
};
/**
 * 모든 하위 컨트롤을 제거 시킵니다.
 */
eXria.controls.xhtml.MDIPageBody.prototype.removeChildren = function() {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    this.canvas.unregisterControl(voControl.id);
    if(voControl.toString() == "SubPage") {
//      var voWindow = voControl.ctrl.contentWindow;
//      if(voWindow) {
//        voWindow.close();
//      }
//        voControl.setSrc("javascript:false");
    }
    voControl.clear();
  }
  this.controls.clear();
};

eXria.controls.xhtml.MDIPageBody.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.MDIGroup.mdipages.mdipage[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 하위 컨트롤의 readOnly속성을 설정
 * @param {String} pbEnable readOnly속성을 활성화할지 여부
 */
eXria.controls.xhtml.MDIPageBody.prototype.setReadOnly = function(pbEnable) {
  var voIterator = this.controls.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.readOnly !== undefined) voChild.applyAttr("readOnly", pbEnable);
  }
};
/**
 * 클래스 명을 반환합니다.
 * @return "MDIPageBody"
 * @type String
 */
eXria.controls.xhtml.MDIPageBody.prototype.toString = function() {
  return "MDIPageBody";
};

/**
 * @class MDIPage의 사이즈를 조절하기 위한 컨트롤 클래스입니다. <br />
 * XHTML MDIPageResize Contorl.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MDIPageResize 객체
 * @type eXria.controls.xhtml.MDIPageResize
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */

eXria.controls.xhtml.MDIPageResize = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 텍스트에 줄을 넣을때.
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 컨트롤에 설정된 값.
   * @type String
   */
  this.value  = null;
  /**
   * movable
   * @type Boolean
   */
  this.movable = true;
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflow = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflowX = null;
  /**
   * 라벨 컨텐츠 오버플로우 타입.
   * @type String
   */
  this.overflowY = null;
  /**
   * 자동줄바꿈 여부.
   * @type Boolean
   */
  this.wordWrap = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @ignore
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @ignore
   */
  this.innerHeight = this.height;
  /**
   * 컨트롤의 텍스트 패딩
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤의 상단 패딩
   * @type Number
   * @private
   */
  this.paddingTop = null;
  /**
   * 컨트롤의 우측 패딩
   * @type Number
   * @private
   */
  this.paddingRight = null;
  /**
   * 컨트롤의 하단 패딩
   * @type Number
   * @private
   */
  this.paddingBottom = null;
  /**
   * 컨트롤의 좌측 패딩
   * @type Number
   * @private
   */
  this.paddingLeft = null;
  /**
   * 컨트롤이 디스플레이 되는 document객체 지정
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  /**
   * 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;

  /**
  * @private
  */
  this.divOffsetHeight = null;
  /**
  * @private
  */
  this.subElement = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.MDIPageResize);
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  voCtrl["accesskey"] = this.accessKey;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  
  this.document = poDocument;
  this.ctrl = voCtrl;

  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<div class=\"" + vsClass + "\" style=\"");
  vaTemplate.push("@cssStrBuf"); //0
  vaTemplate.push("\">&nbsp;</div>");

  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};

eXria.controls.xhtml.MDIPageResize.prototype.startMove = function(e) {
  if (this.disabled == true) {
    return;
  }
  var voDocument = this.document;
  var voParent = this.parent;
  if (voParent == null) voParent = this.canvas;
  var voCtrl = this.getCtrl();
  
  var voGlassPane = new eXria.controls.xhtml.GlassPane(voParent);
  this.glassPane = voGlassPane;
  voGlassPane.opacity = 10;
  voParent.ctrl.parentNode.appendChild(voGlassPane.create(voDocument));
  
  var voPane = this.paneHandler.createPane();
  var voPaneStyle = voPane.style;
  
  var voEvent = e;
  var voTarget = voEvent.target;
  this.mode = voTarget.style.cursor;
  
  this.clientAbsLeft = this.getClientAbsLeft();
  this.clientAbsTop = this.getClientAbsTop();
  
  var vnMouseX = voEvent.e.clientX - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY - this.clientAbsTop;
  
  var vnPaneLeft = parseInt(voPaneStyle.left);
  var vnPaneTop = parseInt(voPaneStyle.top);
  this.leftOffset = vnPaneLeft - vnMouseX;
  this.topOffset = vnPaneTop - vnMouseY;
  
  this.backupCtrlCsr = this.getCtrl().style.cursor;
  voPaneStyle.display = "block";
  voDocument.body.style.cursor = "se-resize";
  this.getCtrl().style.cursor = "se-resize";
  
  voPane.control = this;
  voPane.onmousemove = function(e) {
    this.control.onMove(e);
  };
  voPane.onmouseup = function(e) {
    this.control.stopMove(e);
    this.control.mdiMove(e);
  };
  voDocument.control = this;
  voDocument.onmousemove = function(e) {
    this.control.onMove(e);
  };
  if (typeof voPane.onselectstart != "undefined") {
    voPane.onselectstart = function(e) {
      return false;
    };
  } else {
    voPane.onmousedown = function(e) {
      return false;
    };
  }
}

eXria.controls.xhtml.MDIPageResize.prototype.mdiMove = function(poEvent) {
  var vsPageId = this.id.substr(0, this.id.indexOf("_resize"));
  var vnPageNum = this.parent.getIndexById(vsPageId);
  var voMdiPage = this.parent.mdiPageSet.elements[vnPageNum];
  var voPageCtrl = this.document.getElementById(vsPageId);
  var voResizeLabelCtrl = this.document.getElementById(this.id);
  this.parent.zIndexSeq++;
  var vnZIndex = this.parent.zIndexSeq;
  var voMdiSubpage = null;
  if(voMdiPage.pagebody.controls) {
    var vnPageBodyCtrlCnt = voMdiPage.pagebody.controls.size();
    var voCtrl = null;
    for(var i = 0; i < vnPageBodyCtrlCnt; i++){
      voCtrl = voMdiPage.pagebody.controls.elements[i];
      if(voCtrl.toString() == "SubPage") voMdiSubpage = voCtrl;
    }
  }
  
  if(parseInt(voResizeLabelCtrl.style.top) + parseInt(voResizeLabelCtrl.style.height) < parseInt(voPageCtrl.style.top)
    || parseInt(voResizeLabelCtrl.style.left) + parseInt(voResizeLabelCtrl.style.width) < parseInt(voPageCtrl.style.left)
    || parseInt(voResizeLabelCtrl.style.left) + parseInt(voResizeLabelCtrl.style.width) > voPageCtrl.parentNode.offsetWidth){
    //group 컨트롤의 범위를 넘어갔을때
    voMdiPage.applyAttr("height", parseInt(voPageCtrl.style.height) / 2 + 1);
    voMdiPage.applyAttr("width", parseInt(voPageCtrl.style.width) / 2 + 2);
    
    voMdiPage.pagebody.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
    voMdiPage.pagebody.applyAttr("width", voMdiPage.width);

    this.applyAttr("top", parseInt(voPageCtrl.style.top) + parseInt(voPageCtrl.style.height) - parseInt(voResizeLabelCtrl.style.height));
    this.applyAttr("left", parseInt(voPageCtrl.style.left) + parseInt(voPageCtrl.style.width) - parseInt(voResizeLabelCtrl.style.width));
  }else{
    voMdiPage.applyAttr("height", parseInt(voResizeLabelCtrl.style.top) + parseInt(voResizeLabelCtrl.style.height) - parseInt(voPageCtrl.style.top) + 2);
    voMdiPage.applyAttr("width", parseInt(voResizeLabelCtrl.style.left) + parseInt(voResizeLabelCtrl.style.width) - parseInt(voPageCtrl.style.left) + 2);
    
    voMdiPage.pagebody.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
    voMdiPage.pagebody.applyAttr("width", voMdiPage.width);
    
    if(voMdiSubpage){
      voMdiSubpage.applyAttr("height", voMdiPage.height - voMdiPage.pagecaption.height);
      voMdiSubpage.applyAttr("width", voMdiPage.width);
    }
  }
  voMdiPage.pagebutton_2.mdiPageButtonMove(voMdiPage);
  
  vnZIndex += 200;
  voPageCtrl.style["zIndex"] = vnZIndex;
  voResizeLabelCtrl.style["zIndex"] = vnZIndex+1;
  
  this.parent.zIndexSeq++;
};

/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.refreshTemplate = null;
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    this.innerHTML = voUserAttr.innerHTML;
    if(voUserAttr.useHtmlTag != null &&  voUserAttr.useHtmlTag === true){
      this.value = "";
      this.innerHTML = this.data.getData();
    }
    this.funcNec = voUserAttr.funcNec;
    this.labelName = voUserAttr.labelName;
    this.type = voUserAttr.type;
  }
  if(this.type == "SPLITTER") {
    if(this.height > this.width) this.type = "HSPLITTER";
    else this.type = "VSPLITTER";
    this.ltCtls = voUserAttr.ltCtls ? voUserAttr.ltCtls : [];
    this.rbCtls = voUserAttr.rbCtls ? voUserAttr.rbCtls : [];
  }
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.verticalAlign = this.getAttrValue("verticalAlign", this.verticalAlign);
  this.value = this.getAttrValue("value", this.value);
  this.imagePushed = this.getAttrValue("imagePushed", this.imagePushed);
  this.imageFocused = this.getAttrValue("imageFocused", this.imageFocused);
  this.imageMouseover = this.getAttrValue("imageMouseover", this.imageMouseover);
  this.wordWrap = this.getAttrValue("wordWrap", this.wordWrap);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  // 반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  // 단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;outline-style:none;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
//  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");

  //외각DIV
  //2010.06.03
  //내부DIV 영역에 스크롤이 생성되는 경우를 막기 위해
  //visible 과 hidden 이 아닌경우에는 auto가 되게 수정
  if(!!this.overflow && !!(this.overflow === "scroll" || this.overflow === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "auto");
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);

  if(!!this.overflowX && !!(this.overflowX === "scroll" || this.overflowX === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", auto);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);

  if(!!this.overflowY && !!(this.overflowY === "scroll" || this.overflowY === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  
  var vsResourceBaseUrl = (this.canvas.page.metadata.resourceBaseUrl == "/") ? "" : this.canvas.page.metadata.resourceBaseUrl;
  this.backgroundImage = "url("+vsResourceBaseUrl+"/eXria/controls/xhtml/images/resizeJ.jpg)";

  vfcSetCssStrBuf(vaCssStrBuf, "cursor", "se-resize");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "#f0f0f0");
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);

  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;position:absolute;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else{
    vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
    //2010.06.01
    //영문자 개행 관련 word-wrap 추가
    vfcSetCssStrBuf(vaCssStrBuf, "word-wrap","break-word");
  }

  //2010.06.03
  //내부 div 스크롤 관련 버그 수정
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(1)] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");
  
  voIndexMap.clear();
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
  this.templateIndexMap = null;

  this.setSubElement(poDocument);
};
/**
 * @ignroe
 */
eXria.controls.xhtml.MDIPageResize.prototype.setSpecificEvents = function(poCtrl) {
  if(this.type != "HSPLITTER" && this.type != "VSPLITTER") return;
  this.movable = true;
  this.onMove = function(e) {
    var voCtrl = this.getCtrl();
    var voParentNode = voCtrl.parentNode;
    var voPaneCtrl = this.paneHandler.getCtrl();
    if(voCtrl == null || voPaneCtrl == null) {
        return;
    }

    var voStyle = voPaneCtrl.style;

    var voEvent = new eXria.event.Event(e, this.window);
    var voTarget = voEvent.target;
    if(voTarget == voPaneCtrl || voTarget == voPaneCtrl.parentNode) {
    } else {
      return;
    }
    var vnMouseX = voEvent.e.clientX; // - this.clientAbsLeft;
    var vnMouseY = voEvent.e.clientY; // - this.clientAbsTop;

    var vnNewLeft = vnMouseX + this.leftOffset;
    var vnNewTop = vnMouseY + this.topOffset;

    if(voParentNode.style.left == null || voParentNode.style.left == "") voParentNode.style.left = 0;
    if(voParentNode.style.top == null || voParentNode.style.top == "") voParentNode.style.top = 0;
    if(this.type == "HSPLITTER") voStyle.left = vnNewLeft + "px";
    else voStyle.top = vnNewTop + "px";
  };

  this.stopMove = function(e) {
    if (this.disabled == true) { return; }

    var voDocument = this.document;
    var voCtrl = this.getCtrl();
    var voPane = this.paneHandler.getCtrl();
    var voPaneStyle = voPane.style;

    var voParent = this.parent;
    if(voParent == null) voParent = this.canvas;
    var vnOldPos = null;
    if(this.type == "HSPLITTER") {
      vnOldPos = this.left;
      this.left = parseInt(voPaneStyle.left);
      if(this.left < 0) this.left = 0;
      else if(this.left + this.width > voParent.width) this.left = voParent.width - this.width;
      this.resizeHorz(this.left - vnOldPos);
    } else {
      vnOldPos = this.top;
      this.top = parseInt(voPaneStyle.top);
      if(this.top < 0) this.top = 0;
      else if(this.top + this.height > voParent.height) this.top = voParent.height - this.height;
      this.resizeVert(this.top - vnOldPos);
    }
    this.refresh();
    this.paneHandler.removePane();
    this.glassPane.removeCtrl();
    // Check
    voDocument.body.style.cursor = 'auto';
    voCtrl.style.cursor = this.backupCtrlCsr;

    voPane.onmousemove = null;
    voPane.onmouseup = null;
    voDocument.onmousemove = null;
    voDocument.onmouseup = null;
    if (typeof voPane.onselectstart != "undefined") {
      voPane.onselectstart = null;
    } else {
      voPane.onmousedown = null;
    }

    this.mode = null;
    this.leftOffset = -1;
    this.topOffset = -1;
    this.rightOffset = -1;
    this.bottomOffset = -1;
  };
};
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.MDIPageResize.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.div = this.getSubCtrl("div", voCtrl, poDocument);
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voDivCtrl = this.subElement.div;
  var voSpanCtrl = this.subElement.span;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;

  if(this.className) voDivCtrl.className = this.getCSSClass(this, 1);

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");

  //외각DIV
  //2010.06.03
  //내부DIV 영역에 스크롤이 생성되는 경우를 막기 위해
  //visible 과 hidden 이 아닌경우에는 auto가 되게 수정
  if(!!this.overflow && !!(this.overflow === "scroll" || this.overflow === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", "auto");
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);

  if(!!this.overflowX && !!(this.overflowX === "scroll" || this.overflowX === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", auto);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);

  if(!!this.overflowY && !!(this.overflowY === "scroll" || this.overflowY === "auto"))
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  else
    vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);

  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;position:absolute;left:0px;top:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else{
    vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
    //2010.06.01
    //영문자 개행 관련 word-wrap 추가
    vfcSetCssStrBuf(vaCssStrBuf, "word-wrap","break-word");
  }

  //2010.06.03
  //내부 div 스크롤 관련 버그 수정
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  //vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);

  voDivCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  voSpanCtrl.style.cssText = vaCssStrBuf.join("");
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voDf = this.df;
  var voDiv = this.subElement.div;
  var voSpan = this.subElement.span;

  switch(psAttrName) {
  case "width" :
    var vnWidth = this.innerWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    if(vnWidth < 0) vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voDiv);
    //var vsLabel = this.getWordWrapped(this.value, voSpan);
    var vsLabel = this.value;
    this.setText(voDiv, vsLabel);
    this.setVerticalAlign(voDiv, poCtrl, this.verticalAlign);
    break;
  case "height" :
    this.setVerticalAlign(voDiv, poCtrl, this.verticalAlign);
    break;
  }
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MDIPageResize.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voDiv = this.subElement.div;
  var voSpan = this.subElement.span;
  var vaAttrName = psAttrName.split(".");
  var voDf = this.df;
  this.setAttr(psAttrName, psAttrValue);
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    voCtrl.style[psAttrName] = psAttrValue + "px";
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "padding" :
    this.paddingTop = this.padding;
    this.paddingRight = this.padding;
    this.paddingBottom = this.padding;
    this.paddingLeft = this.padding;
    this.setAttrCtrl("paddingTop", this.paddingTop + "px", voDiv);
    this.setAttrCtrl("paddingRight", this.paddingRight + "px", voDiv);
    this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voDiv);
    this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voDiv);
    var vnWidth = this.innerWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    this.setAttrCtrl("Width", vnWidth, voDiv);
    this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
    break;
  case "paddingTop" :
  case "paddingBottom" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voDiv);
    this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
    break;
  case "paddingLeft" :
  case "paddingRight" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voDiv);
    var vnWidth = this.innerWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    this.setAttrCtrl("Width", vnWidth, voDiv);
    break;
  break;
  case "value" :
    this.setValue(psAttrValue);
    break;
  case "outerClassName" :
  case "className" :
    this.refresh(poDocument);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * 데이타 로딩완료 후에 처리작업을 수행합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MDIPageResize.prototype.loadComplete = function(poDocument) {
  if(this.value == null) this.value = "";
  if(this.value == "" && this.innerHTML) {
    this.subElement.div.innerHTML = this.innerHTML;
    this.setVerticalAlign(this.subElement.div, this.ctrl, this.verticalAlign);
  } else {
    this.setValue(this.value);
  }
};
/**
 * loadData.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MDIPageResize.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;

  if(!!this.innerHTML) this.value = "";
  else this.value = this.data.getData();

//  this.value = this.data.getData();
//  this.df.value = this.value;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
  this.loadComplete(poDocument);
};
/**
 * 컨트롤에 값을 설정합니다.
 * @param {String} psLabel 컨트롤에 설정할 라벨 값
 */
eXria.controls.xhtml.MDIPageResize.prototype.setValue = function(psLabel) {
  var voCtrl = this.ctrl;
  var voDiv = this.subElement.div;
  var voSpan = this.subElement.span;
  var voDf = this.df;
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psLabel) {
    vbChanged = true;
  }
  this.onchangeInitValue = psLabel;
  this.value = psLabel;
//  this.df.value = psLabel;
  if(vbChanged) this.data.setData(this.value);

  //var vsLabel = this.getWordWrapped(psLabel, voSpan);
  var vsLabel = "" + psLabel;
  if(this.funcNec) {
    this.funcNec(this, voDiv, vsLabel);
  } else {
    this.setText(voDiv, vsLabel);
  }
  this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
  var vnWidth = voCtrl.offsetWidth - this.borderLeftWidth - this.borderRightWidth;;
  var vnPaddingLeft = parseInt(this.getStyleCurrentValue(voDiv, "padding-left", "paddingLeft"), 10);
  var vnPaddingRight = parseInt(this.getStyleCurrentValue(voDiv, "padding-right", "paddingRight"), 10);
  if(vnPaddingLeft > 0 || vnPaddingRight > 0) {
  if(vnWidth > 0)
      this.setAttrCtrl("width", vnWidth - (vnPaddingRight+vnPaddingLeft), this.subElement.div);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.getWordWrapped = function(psLabel, poSpan) {
  var voDf = this.df;
  psLabel = eXria.controls.xhtml.Util.parseLang(psLabel);
  var vsLabel = "";
  if(psLabel != null) {
    if(this.wordWrap == false) {
      //var vnStrLen = Math.round(vsLabel.length * this.fontSize / 0.75); //pt -> px : pt / 0.75
      //voSpan.innerHTML = psLabel;
      //this.setAttrCtrl("width", voSpan.offsetWidth, voDiv);
      vsLabel = psLabel;
    } else {
      var voIdxCollection = new eXria.data.ArrayCollection();
      var vnSt = 0;
      for(var i = 1; i < psLabel.length; i++) {
        poSpan.innerHTML = psLabel.substring(vnSt, i);
        var vnWidth = this.innerWidth;
        if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
        if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
        if(poSpan.offsetWidth > vnWidth) {
          vnSt = i - 1;
          voIdxCollection.add(vnSt);
        } else if(psLabel.substring(vnSt, i).indexOf("\n") != -1) {
          vnSt = i - 1;
          psLabel = psLabel.substring(0, vnSt) + psLabel.substring(vnSt + 1);
          voIdxCollection.add(vnSt)
          i--;
        }
      }
      var voIterator = voIdxCollection.iterator();
      vnSt = 0;
      var vnIdx = 0;
      while(voIterator.hasNext()) {
        vnIdx = voIterator.next();
        vsLabel += psLabel.substring(vnSt, vnIdx) + "\n";
        vnSt = vnIdx;
      }
      vsLabel += psLabel.substring(vnSt);
    }
  }
  return vsLabel;
};
/**
 * 컨트롤에 할당된 값을 반환합니다.
 * @return 컨트롤에 할당된 값
 * @type String
 */
eXria.controls.xhtml.MDIPageResize.prototype.getValue = function() {
  return this.value;
};
/**
 * 컨트롤 텍스트 수직정렬을 새로고침 합니다.
 */
eXria.controls.xhtml.MDIPageResize.prototype.refreshVerticalAlign = function() {
  var voCtrl = this.ctrl;
  if(voCtrl == null) return;
  var voDf = this.df;
  var voDiv = this.subElement.div;
  this.setVerticalAlign(voDiv, voCtrl, this.verticalAlign);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.MDIPageResize.prototype.getSpecificDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.Label[psAttrName];
  if(vsDefaultValue === undefined) {
    return null;
  }
  if((psAttrName == "backgroundImage")
  && vsDefaultValue != null) {
    if(vsDefaultValue.indexOf("http://") != -1) {
      vsDefaultValue = "url(" + this.canvas.page.metadata.resourceBaseUrl + vsDefaultValue + ")";
    } else {
      vsDefaultValue = "url(" + vsDefaultValue + ")";
    }
  }
  return vsDefaultValue;
};
/** MDIPageResize 컨트롤의 Vertical Align을 설정한다
 * @private
 */
// IE6의 예외 처리문제로 추가 되었으며 UIControl에서 if..else문대신 재정의 형태로 함
eXria.controls.xhtml.MDIPageResize.prototype.setVerticalAlign = function(poCtrl, poParent, psVAlign) {
  if(poCtrl.offsetHeight !== 0)
    this.divOffsetHeight = poCtrl.offsetHeight;

  if(!this.divOffsetHeight)
  this.divOffsetHeight = 0;

  var vnHeight = this.divOffsetHeight;

  if(this.canvas.page.metadata.browser.ie == 6) {
    var voFont = this.getStyleCurrentValue(poCtrl, "font-size", "fontSize");
    vnHeight = parseInt(voFont);
    vnHeight = vnHeight * 1.333;
    // IE6에서  특정 높이보다 작아지면 높이를 제대로 못가져오는 문제로 font-size로 설정하게 했으나
    // 멀티라인처럼 높이가 커진경우에는 원래 경우대로 하게끔 한다.
    if(this.divOffsetHeight > vnHeight) vnHeight = this.divOffsetHeight;
  }
  if(psVAlign == null) psVAlign = "middle";
  var vnParentHeight = poParent.style.height;
  if(vnParentHeight == "") vnParentHeight = "0";
  vnParentHeight = parseInt(vnParentHeight);
  var vnPadding = vnParentHeight - vnHeight;

  //2010.06.01
  //아래 로직이 있으면 스크롤이 중첩되서 생성되고
  //VerticalAlign 이 middle로 강제로 고정되는 경우가발생 그래서 주석 처리
  //if(vnPadding < 0) vnPadding = 0;

  switch(psVAlign) {
  case "top" :
    poCtrl.style.top = "0px";
    poCtrl.style.bottom = "";
    break;
  case "bottom" :
    poCtrl.style.top = ""; //(vnParentHeight - vnPadding)
    poCtrl.style.bottom = "0px";
    break;
  case "middle" :
    var vnPadding = vnPadding / 2;

    //2010.06.01
    //아래 로직이 있으면 스크롤이 중첩되서 생성되고
    //VerticalAlign 이 middle로 강제로 고정되는 경우가발생 그래서 주석 처리
    //if(vnParentHeight < vnHeight) vnPadding = 0;

    poCtrl.style.top = vnPadding + "px";
    poCtrl.style.bottom = "";
    break;
  }
};
/**
 * MDIPageResize의 div에 포커스를 사용
 * @private
 */
eXria.controls.xhtml.MDIPageResize.prototype.dofocus = function() {
  this.ctrl.focus();
};
/**
 * 좌우 splitter에 의한 관련 컨트롤들의 위치를 재설정 해주는 메소드
 * @param {Number} pnOffset splitter의 위치 이동 편차
 */
eXria.controls.xhtml.MDIPageResize.prototype.resizeHorz = function(pnOffset) {
  if(pnOffset == 0) return;
  var voPage = this.canvas.page;
  var vaLeftCtls = this.ltCtls;
  var vaRightCtls = this.rbCtls;
  var vnSize = 0;
  var vcCtl = null;
  var vnWidth = null;
  vnSize = vaLeftCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaLeftCtls[i]);
    if(vcCtl.rWidth === undefined) vcCtl.rWidth = vcCtl.width;
    vnWidth = vcCtl.rWidth + pnOffset;
    vcCtl.rWidth = vnWidth;
    if(vnWidth < 0) vnWidth = 0;
    vcCtl.applyAttr("width", vnWidth);
  }
  vnSize = vaRightCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaRightCtls[i]);
    vcCtl.left = vcCtl.left + pnOffset;
    if(vcCtl.rWidth === undefined) vcCtl.rWidth = vcCtl.width;
    vnWidth = vcCtl.rWidth - pnOffset;
    vcCtl.rWidth = vnWidth;
    if(vnWidth < 0) vnWidth = 0;
    vcCtl.width = vnWidth;
    vcCtl.refresh(null, null, true);
  }
};
/**
 * 상하 splitter에 의한 관련 컨트롤들의 위치를 재설정 해주는 메소드
 * @param {Number} pnOffset splitter의 위치 이동 편차
 */
eXria.controls.xhtml.MDIPageResize.prototype.resizeVert = function(pnOffset) {
  if(pnOffset == 0) return;
  var voPage = this.canvas.page;
  var vaUpperCtls = this.ltCtls;
  var vaLowerCtls = this.rbCtls;
  var vnSize = 0;
  var vcCtl = null;
  vnSize = vaUpperCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaUpperCtls[i]);
    vcCtl.applyAttr("height", vcCtl.height + pnOffset);
  }
  vnSize = vaLowerCtls.length;
  for(var i = 0; i < vnSize; i++) {
    vcCtl = voPage.getControl(vaLowerCtls[i]);
    vcCtl.top = vcCtl.top + pnOffset;
    vcCtl.height = vcCtl.height - pnOffset;
    vcCtl.refresh(null, null, true);
  }
};
/**
 * @
 */
eXria.controls.xhtml.MDIPageResize.prototype.atdblclick = function(poEvent) {
  if(this.type != "HSPLITTER" && this.type != "VSPLITTER") return;
  if(this.type == "HSPLITTER") {
    if(this.left != 0) {
      this.orgLeft = this.left;
      this.left = 0;
      this.refresh();
      this.resizeHorz(-this.orgLeft);
    } else {
      this.left = this.orgLeft;
      this.refresh();
      this.resizeHorz(this.left);
    }
  } else {
    if(this.top != 0) {
      this.orgTop = this.top;
      this.top = 0;
      this.refresh();
      this.resizeVert(-this.orgTop);
    } else {
      this.top = this.orgTop;
      this.refresh();
      this.resizeVert(this.top);
    }
  }
};
/**
 * 클래스 명을 반환합니다.
 * @return "MDIPageResize"
 * @type String
 */
eXria.controls.xhtml.MDIPageResize.prototype.toString = function() {
  return "MDIPageResize";
};

/**
 * @fileoverview
 * Concreate xhtml MDIGroup(XHTML MDIGroup 컨트롤)
 * @author 박상찬
 */
/**
 * @class Concreate xhtml MDIGroup.<br>
 * XHTML MDIGroup 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MDIGroup 객체
 * @type eXria.controls.xhtml.MDIGroup
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 * @base eXria.controls.MDIGroup
 */
eXria.controls.xhtml.MDIGroup = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight =  pnHeight == null ? 300 : pnHeight;

  eXria.controls.MDIGroup.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 그룹에 담긴 컨트롤이 영역을 벗어날때 스크롤 처리.
   * @type String
   */
  this.overflow = null;
  /**
   * 그룹에 담긴 컨트롤이 영역을 벗어날때 횡 스크롤 처리.
   * @type String
   */
  this.overflowX = null;
  /**
   * 그룹에 담긴 컨트롤이 영역을 벗어날때 종 스크롤 처리.
   * @type String
   */
  this.overflowY = null;
  /**
   * 하위 컨트롤들의 readOnly 여부 설정
   * @type Boolean
   */
  this.readOnly = null;
  /**
   * 컨트롤이 디스플레이 되는 document
   * @type HTMLDocument
   * @private
   */
  this.document = null;
  /**
   * 하위 컨트롤 id에 붙일 suffix 문자열
   * @type String
   * @private
   */
  this.idSuffix = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * MDIButton 영역의 세로 길이.
   * @type Number
   */
  this.titleBarHeight = null;
  /**
   * MDIButton 의 위치 지정.
   * "top" | "bottom"
   * @type String
   */
  this.minimizePos = null;
  
  this.cursor = null;
  /**
  * @private
  */
  this.impList = new eXria.data.Collection();
  /**
   * MDIGroup(MDIGroup의 컨텐츠 패널 영역)을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   */
  this.mdiGroupSet = new eXria.data.ArrayCollection();
  /**
   * MDIPage(MDIPage의 컨텐츠 패널 영역)을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   */
  this.mdiPageSet = new eXria.data.ArrayCollection();
  /**
   * MDIPageResize(MDIPageResize의 컨텐츠 패널 영역)을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   */
  this.mdiPageResizeSet = new eXria.data.ArrayCollection();
  /**
   * MDI 아이디 생성에 이용되는 순차적인 번호.
   * @type Number
   * @private
   */
  this.mdiSeqNum = 0;
  /**
   * ZIndex 생성에 이용되는 순차적인 번호.
   * @type Number
   * @private
   */
  this.zIndexSeq = 0;
  /**
   * @type Number
   * @ignore
   */
  this.mdiPageZindex = null;
  /**
   * MDIButtons 들의 공통속성을 관리하는 오브젝트
   * @type eXria.controls.xhtml.MDIButtons
   */
  this.mdibuttons = new eXria.controls.xhtml.MDIButtons();
  /**
   * MDIButton 객체.<br>
   * 개별 Button 을 관리하는 오브젝트.
   * readOnly
   * @type eXria.controls.xhtml.MDIButton
   */
  //addMdiPage method 에서 세부속성 정의 해야함
  this.mdibutton = null;
  /**
   * MDIPages 들의 공통속성을 관리하는 오브젝트
   * @type eXria.controls.xhtml.MDIPages
   */
  this.mdipages = new eXria.controls.xhtml.MDIPages();
  /**
   * MDIPage 객체.<br>
   * 개별 Page 을 관리하는 오브젝트.
   * readOnly
   * @type eXria.controls.xhtml.MDIPage
   */
  this.mdipage = null;
  
  this.mdisubpage = null;
  /**
   * resize 객체.<br>
   * readOnly
   * @type eXria.controls.xhtml.MDIPageResize
   */
   this.mdipageresize = null;
   /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
   this.innerWidth = this.width;
   /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
   this.innerHeight = this.height;
   /**
    * layout 의 matrix 속성
    * @member eXria.controls.xhtml.MDIGroup
    * @type String
    * @author ParkSC at 13. 6. 24 오후 6:29
    */
   this.mdiLayout = null;
   /**
    * layout 의 matrix 속성의 행 값
    * @member eXria.controls.xhtml.MDIGroup
    * @type Number
    * @author ParkSC at 13. 6. 24 오후 6:29
    */
   this.rows = null;
   /**
    * layout 의 matrix 속성의 열 값
    * @member eXria.controls.xhtml.MDIGroup
    * @type Number
    * @author ParkSC at 13. 6. 24 오후 6:29
    */
   this.cols = null;
   
   this.mdiCallFnc = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.MDIGroup);
eXria.controls.xhtml.Util.createInheritance(eXria.controls.MDIGroup, eXria.controls.xhtml.MDIGroup);
//////////////////////////////////////////////////////////////////
// 메소드

eXria.controls.xhtml.MDIGroup.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsEventCallback = vsType + "EventCallback";
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;
//if(vsType == "change")
  switch(vsType) {
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }

  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(poControl[vsEventCallback]) { poControl[vsEventCallback](voEvent); }
  if(poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }

  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};

eXria.controls.xhtml.MDIGroup.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;

  this.ctrl = voCtrl;
  this.document = poDocument;
  return voCtrl;
};

eXria.controls.xhtml.MDIGroup.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
};

eXria.controls.xhtml.MDIGroup.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var vsClass = this.getCSSClass(this, 1);
  poCtrl.className = poCtrl.className + " " + vsClass;

  var voDf = this.df;
  var vaCssStrBuf = null;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.10.12 동적인 코드에서는 disabled를 제어하지 않으며 FF에서는 없는 속성이다
  //if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "tooltip", this.tooltip);
  vfcSetCssStrBuf(vaCssStrBuf, "disabled", this.disabled);
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = null;
};

eXria.controls.xhtml.MDIGroup.prototype.refreshTemplate = function(poCtrl, poDocument) {
  if(this.setTemplate) this.setTemplate(poCtrl, poDocument);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.refreshTemplate) voChild.refreshTemplate(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIGroup.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  this.setSpecificDefaults(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshSpecificDefaults(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIGroup.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshSpecificAttrs(voChild.ctrl, voChild.document);
  }
};

 eXria.controls.xhtml.MDIGroup.prototype.reloadData = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
  if(voChild.reloadData) voChild.reloadData(voChild.ctrl, voChild.document);
  }
};

eXria.controls.xhtml.MDIGroup.prototype.refreshComplete = function(poCtrl, poDocument) {
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    voChild.refreshComplete(voChild.ctrl, voChild.document);
  }
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  this.setDisable(poCtrl, this.disabled);
  this.hideFocusLine(poCtrl, true);
};

eXria.controls.xhtml.MDIGroup.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIGroup.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;

  var voTable = poCtrl.childNodes[0];

  switch(psAttrName) {
    case "disabled" :
      poCtrl.disabled = psAttrValue;
      this.applyAttrToChildren("disabled", psAttrValue);
      break;
    //case "borderWidth" :
    //  this.innerWidth = this.width - 2 * this.borderWidth;
    //  this.innerHeight = this.height - 2 * this.borderWidth;
    //  poCtrl.style.width = this.innerWidth + "px";
    //  poCtrl.style.height = this.innerHeight + "px";
    //  break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIGroup.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
    break;
  case "className" :
  case "outerClassName" :
  case "overflow" :
    this.refresh(poDocument);
    break;
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue)
    this.setAttrCtrl("zIndex", this.zIndex, voCtrl);
    var voChild = null;
    var voIterator = this.controls.iterator();
    while(voIterator.hasNext()) {
      voChild = voIterator.next();
      if(voChild.refreshVerticalAlign) {
        voChild.refreshVerticalAlign();
      }
    }
    break;
  case "readOnly" :
    this.setReadOnly(psAttrValue);
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  }
};

eXria.controls.xhtml.MDIGroup.prototype.clear = function() {
  this.removeChildren();
  this.clearCtrl();
  this.clearControl();
};
/**
 * @ignore
 */
eXria.controls.xhtml.MDIGroup.prototype.loadComplete = function() {
  this.createChildren();
  if(this.readOnly != null) this.setReadOnly(this.readOnly);
  this.mdiInitLayout();
};
/**
 * 컨트롤에 하위 컨트롤를 추가합니다.
 * @param {eXria.controls.xhtml.Control} poControl 추가 대상 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document(생략가능)
 */
eXria.controls.xhtml.MDIGroup.prototype.addChild = function(poControl, poDocument) {
  if(poDocument == null) poDocument = this.document;
  var voCanvas = this.canvas;
  poControl.parent = this;
  poControl.canvas = voCanvas;
  poControl.window = this.window;
  poControl.document = this.document;
  this.addItem(poControl);
  if(voCanvas) voCanvas.registerControl(poControl);
  var voCtrl = this.getCtrl(poDocument);
  if((this.visible || this.visible == null) && voCtrl) {
    voCtrl.appendChild(poControl.create(poDocument));
    poControl.load(poDocument);
  // TODO 추후 수정
    var name = poControl.toString();
    if(name == "Rectangle" || name == "Roundrect" || name == "Ellipse" ) {poControl.getCtrl(poDocument).blur();};
  }
};
/**
 * 하위 컨트롤을 제거 시킵니다.
 * @param {String} psId 제거대상 컨트롤 id
 */
eXria.controls.xhtml.MDIGroup.prototype.removeChild = function(psId) {
  var vnIndex = this.getIndex(psId);
  var voControl = this.controls.remove(vnIndex);
  voControl.clear();
};
/**
 * 하위 컨트롤 id에 매칭되는 컨트롤 식별 인덱스 번호를 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 하위 컨트롤 식별 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.MDIGroup.prototype.getIndex = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vnIndex = -1;
  while(voIterator.hasNext()) {
    vnIndex++;
    voControl = voIterator.next();
    if (voControl.id == psId) break;
  }
  return vnIndex;
};
/**
 * 지정된 id에 해당하는 하위 컨트롤을 반환합니다.
 * @param {String} psId 하위 컨트롤 id
 * @return 지정된 id에 해당하는 하위 컨트롤 객체
 * @type eXria.controls.xhtml.Control
 */
eXria.controls.xhtml.MDIGroup.prototype.get = function(psId) {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    if (voControl.id == psId) { return voControl; }
  }
  return null;
};
/**
 * 포함된 하위 컨트롤의 실체화 객체를 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @param {String} psIdSuffix 실체화된 컨트롤 id에 따라붙을 문자열
 * @private
 */
eXria.controls.xhtml.MDIGroup.prototype.createChildren = function(poDocument, psIdSuffix) {
  if(poDocument == null) poDocument = this.document;
  if(psIdSuffix == null && this.idSuffix) psIdSuffix = this.idSuffix;
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vsId = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    vsId = voControl.id;
    if(psIdSuffix != null) voControl.id += psIdSuffix;
    if(voControl.canvas == null) {
      voControl.canvas = this.canvas;
      voControl.window = this.window;
      voControl.document = this.document;
      this.canvas.registerControl(voControl);
    }
    if(voControl.toString() != "Timer") {
      this.appendChild(voControl.create(poDocument), poDocument);
      //voControl.refresh(poDocument);
      voControl.load(this.document);
    }
    voControl.id = vsId;
  }
};
/**
 * 하위 컨트롤에 일괄적으로 속성을 적용합니다.
 * @param {String} psAttrValue 지정된 속성값
 * @param {String} psAttrName 속성명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.MDIGroup.prototype.applyAttrToChildren = function(psAttrName, psAttrValue, poDocument) {
  if(this.getCtrl(poDocument) == null) return;

  var voIterator = this.controls.iterator();
  var voControl = null;
  var voCtrl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    voCtrl = voControl.getCtrl(poDocument);
    if(voCtrl) voControl.applyAttr(psAttrName, psAttrValue, poDocument);
  }
};
/**
 * 모든 하위 컨트롤을 제거 시킵니다.
 */
eXria.controls.xhtml.MDIGroup.prototype.removeChildren = function() {
  var voIterator = this.controls.iterator();
  var voControl = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    this.canvas.unregisterControl(voControl.id);
    if(voControl.toString() == "SubPage") {
//      var voWindow = voControl.ctrl.contentWindow;
//      if(voWindow) {
//        voWindow.close();
//      }
        voControl.setSrc("javascript:false");
    }
    voControl.clear();
  }
  this.controls.clear();
};

eXria.controls.xhtml.MDIGroup.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.MDIGroup[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 하위 컨트롤의 readOnly속성을 설정
 * @param {String} pbEnable readOnly속성을 활성화할지 여부
 */
eXria.controls.xhtml.MDIGroup.prototype.setReadOnly = function(pbEnable) {
  var voIterator = this.controls.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.readOnly !== undefined) voChild.applyAttr("readOnly", pbEnable);
  }
};
/**
 * MDIButton 및 그에 따른 MDIPage 추가 메소드.
 * @param {String} psPageName MDI Page 라벨
 * @param {String} psPageId MDI 페이지 아이디
 * @param {Boolean} pbVisible Visible 여부
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 추가된 MDIPage 의 인덱스
 * @type Number
 */
eXria.controls.xhtml.MDIGroup.prototype.addMdiPage = function(psPageName, psPageId, pbVisible, pnLeft, pnTop, pnWidth, pnHeight) {
  var voCtrl = this.getCtrl();
  var voDf = this.df;
  var voPageDf = this.mdipages;
  var voMdiPage = null;
  var voMdiButton = null;
  var vsButtonId = null;
  var vsPageId = null;
  var vsResizeLableId = null;
  var vnHeight = this.height;
  var vnButtonLeft = 0;
  var vnButtonTop = 0;
  var vnBtnWidth = null;
  var vnBtnHeight = null;
  this.mdiCallFnc = "addMdiPage";
  this.titleBarHeight = this.getAttrValue("titleBarHeight", this.titleBarHeight);
  this.minimizePos = this.getAttrValue("minimizePos", this.minimizePos);
  
  if(this.titleBarHeight == null) this.titleBarHeight = 25;
  if(this.minimizePos == null) this.minimizePos = "bottom";
  
  if(psPageId == null) vsPageId = this.id + "_group";
  else vsPageId = psPageId;
  
  vsButtonId = vsPageId + "_button";
  vsResizeLableId = vsPageId+"_resize";
  
  if(pnLeft == null) {
    pnLeft = 0;
    pnTop = this.titleBarHeight;
    if(this.minimizePos == "bottom") pnTop = 0;
    pnWidth = parseInt(this.innerWidth * 0.5);
    pnHeight = parseInt((this.innerHeight - this.titleBarHeight) * 0.5);
  }
  
  this.mdipageresize = new eXria.controls.xhtml.MDIPageResize(vsResizeLableId, (pnLeft + pnWidth - 17), (pnTop + pnHeight - 16), 17, 16);
  this.mdipageresize.parent = this;
  
  this.mdiGroupSet.add(this.mdipageresize);
  this.mdiPageResizeSet.add(this.mdipageresize);
  
  this.mdipage = new eXria.controls.xhtml.MDIPage(vsPageId, pnLeft, pnTop, pnWidth, pnHeight);
  this.mdipage.parent = this;
  
  voMdiPage = this.mdipage;
  voMdiPage.subId = psPageId;
  
  voMdiPage.maximize = voMdiPage.getAttrValue("maximize", voMdiPage.maximize);
  voMdiPage.minimize = voMdiPage.getAttrValue("minimize", voMdiPage.minimize);
  voMdiPage.restore = voMdiPage.getAttrValue("restore", voMdiPage.restore);
  
  if(pbVisible) voMdiPage.visible = pbVisible;
  voMdiPage.zIndex = this.mdiSeqNum;
  this.mdiPageZindex = this.mdiSeqNum;
  this.mdiGroupSet.add(this.mdipage);
  this.mdiPageSet.add(voMdiPage);
  
  if(voCtrl) {
   voMdiPage.canvas = this.canvas;
   voMdiPage.window = this.window;
   voMdiPage.document = this.document;
   voMdiPage.backgroundColor = this.mdipages.backgroundColor;
   voMdiPage.className = voPageDf.className;
   voMdiPage.outerClassName = voPageDf.outerClassName;
   voMdiPage.borderStyle = voPageDf.borderStyle;
   voMdiPage.borderColor = voPageDf.borderColor;
   voMdiPage.borderWidth = voPageDf.borderWidth;
   voMdiPage.borderLeftWidth = voPageDf.borderLeftWidth;
   voMdiPage.borderRightWidth = voPageDf.borderRightWidth;
   voMdiPage.borderTopWidth = voPageDf.borderTopWidth;
   voMdiPage.borderBottomWidth = voPageDf.borderWidth;
   voMdiPage.overflow = voPageDf.overflow;
   voMdiPage.overflowX = voPageDf.overflowX;
   voMdiPage.overflowY = voPageDf.overflowY;
   voMdiPage.visible = true;
   voMdiPage.zIndex = this.mdiSeqNum;
  }
  
  voMdiPage.zIndex = this.mdiSeqNum;
  this.mdipageresize.zIndex = this.mdiSeqNum+1;
  this.addChild(this.mdipage);
  this.addChild(this.mdipageresize);
  
  if(this.mdibuttons.width == null) vnBtnWidth = 100;
  else vnBtnWidth = this.mdibuttons.width;
  if(this.mdibuttons.height == null)  vnBtnHeight = 20;
  else vnBtnHeight = this.mdibuttons.height;
  
  if(this.mdiSeqNum == 0) {
    vnButtonLeft = 2;
  }else{
    vnButtonLeft = this.mdibuttons.left + vnBtnWidth + 4;
  }
  vnButtonTop = parseInt((vnHeight - 20 * (this.mdiSeqNum+1.1)));
  
  this.mdibuttons.top = vnButtonTop;
  this.mdibuttons.left = vnButtonLeft;
  this.mdibuttons.width = vnBtnWidth;
  this.mdibuttons.height = vnBtnHeight;

  this.mdibutton = new eXria.controls.xhtml.MDIButton(vsButtonId, vnButtonLeft, vnButtonTop, vnBtnWidth, vnBtnHeight);
  this.mdibutton.parent = this;
  voMdiButton = this.mdibutton;
  voMdiButton.subId = vsButtonId;
  voMdiButton.value = psPageName;
  voMdiButton.pageId = vsPageId;
  voMdiButton.pageSubId = psPageId;
  voMdiPage.btn = voMdiButton;
  if(pbVisible != null) voMdiButton.visible = pbVisible;
  this.addMdiButton(voMdiButton);
  this.mdiGroupSet.add(this.mdibutton);
  this.mdiSeqNum++;

  var vnIndex = this.mdiPageSet.size() - 1;
//  if(vnIndex == this.selectedIndex) this.selectTab(vnIndex);

  return this.mdiPageSet.size() - 1;
};

/**
 * MDIButton 및 그에 따른 MDIPage 추가 메소드.
 * @param {String} psPageName MDI Page 라벨
 * @param {String} psPageId MDI 페이지 아이디
 * @param {Boolean} pbVisible Visible 여부
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @param {String} 페이지 Src
 * @return 추가된 MDIPage 의 인덱스
 * @type Number
 */
eXria.controls.xhtml.MDIGroup.prototype.addMdiSubPage = function(psPageName, psPageId, pbVisible, pnLeft, pnTop, pnWidth, pnHeight, psSrc) {
  var voCtrl = this.getCtrl();
  var voDf = this.df;
  var voPageDf = this.mdipages;
  var voMdiPage = null;
  var voMdiSubpage = null;
  var voMdiButton = null;
  var vsButtonId = null;
  var vsPageId = null;
  var vsResizeLableId = null;
  var vnHeight = this.height;
  var vnButtonLeft = 0;
  var vnButtonTop = 0;
  var vnBtnWidth = null;
  var vnBtnHeight = null;
  var vsSrc = psSrc;
  if(!vsSrc) vsSrc = "";
  var vnLeft = pnLeft;
  var vnTop = pnTop;
  if(!vnLeft) vnLeft = 0;
  if(!vnTop) vnTop = 0;
  this.titleBarHeight = this.getAttrValue("titleBarHeight", this.titleBarHeight);
  this.minimizePos = this.getAttrValue("minimizePos", this.minimizePos);
  this.mdiCallFnc = "addMdiSubPage";
  
  if(this.titleBarHeight == null) this.titleBarHeight = 25;
  if(this.minimizePos == null) this.minimizePos = "bottom";
    
  if(psPageName == null) psPageName = this.id + "_name";
  if(psPageId == null) vsPageId = this.id + "page"+""+this.mdiSeqNum;
  else vsPageId = psPageId;
  
  vsButtonId = vsPageId + "_button";
  vsResizeLableId = vsPageId+"_resize";
  if(!vnLeft) {
    vnLeft = 0;
    if(this.minimizePos == "bottom") vnTop = 0;
    else vnTop = this.titleBarHeight;
    if(!pnWidth) pnWidth = parseInt(this.innerWidth * 0.5);
    if(!pnHeight) pnHeight = parseInt((this.innerHeight - this.titleBarHeight) * 0.5);
  }
  
  this.mdipageresize = new eXria.controls.xhtml.MDIPageResize(vsResizeLableId, (vnLeft + pnWidth - 17), (vnTop + pnHeight - 16), 17, 16);
  this.mdipageresize.parent = this;
  this.mdipageresize.zIndex = this.mdiSeqNum;
  
  this.mdiGroupSet.add(this.mdipageresize);
  this.mdiPageResizeSet.add(this.mdipageresize);
  this.mdipage = new eXria.controls.xhtml.MDIPage(vsPageId, vnLeft, vnTop, pnWidth, pnHeight);
  this.mdipage.parent = this;
  
  voMdiPage = this.mdipage;
  voMdiPage.subId = psPageId;
  
  voMdiPage.maximize = voMdiPage.getAttrValue("maximize", voMdiPage.maximize);
  voMdiPage.minimize = voMdiPage.getAttrValue("minimize", voMdiPage.minimize);
  voMdiPage.restore = voMdiPage.getAttrValue("restore", voMdiPage.restore);

  if(pbVisible) voMdiPage.visible = pbVisible;
  voMdiPage.zIndex = this.mdiSeqNum;
  this.mdiPageZindex = this.mdiSeqNum;
  this.mdiGroupSet.add(this.mdipage);
  this.mdiPageSet.add(voMdiPage);
  
  if(voCtrl) {
   voMdiPage.canvas = this.canvas;
   voMdiPage.window = this.window;
   voMdiPage.document = this.document;
   voMdiPage.backgroundColor = this.mdipages.backgroundColor;
   voMdiPage.className = voPageDf.className;
   voMdiPage.outerClassName = voPageDf.outerClassName;
   voMdiPage.borderStyle = voPageDf.borderStyle;
   voMdiPage.borderColor = voPageDf.borderColor;
   voMdiPage.borderWidth = voPageDf.borderWidth;
   voMdiPage.borderLeftWidth = voPageDf.borderLeftWidth;
   voMdiPage.borderRightWidth = voPageDf.borderRightWidth;
   voMdiPage.borderTopWidth = voPageDf.borderTopWidth;
   voMdiPage.borderBottomWidth = voPageDf.borderWidth;
   voMdiPage.overflow = voPageDf.overflow;
   voMdiPage.overflowX = voPageDf.overflowX;
   voMdiPage.overflowY = voPageDf.overflowY;
   voMdiPage.visible = true;
   voMdiPage.zIndex = this.mdiSeqNum;
  }
  
  if(this.mdibuttons.width == null) vnBtnWidth = 100;
  else vnBtnWidth = this.mdibuttons.width;
  if(this.mdibuttons.height == null)  vnBtnHeight = 20;
  else vnBtnHeight = this.mdibuttons.height;
  
  if(this.mdiSeqNum == 0) {
    vnButtonLeft = 2;
  }else{
    vnButtonLeft = this.mdibuttons.left + vnBtnWidth + 4;
  }
  vnButtonTop = parseInt((vnHeight - 20 * (this.mdiSeqNum+1.1)));
  
  this.mdibuttons.top = vnButtonTop;
  this.mdibuttons.left = vnButtonLeft;
  this.mdibuttons.width = vnBtnWidth;
  this.mdibuttons.height = vnBtnHeight;
 
  this.mdibutton = new eXria.controls.xhtml.MDIButton(vsButtonId, vnButtonLeft, vnButtonTop, vnBtnWidth, vnBtnHeight);
  this.mdibutton.parent = this;
  voMdiButton = this.mdibutton;
  voMdiButton.subId = vsButtonId;
  voMdiButton.value = psPageName;
  voMdiButton.pageId = vsPageId;
  voMdiButton.pageSubId = psPageId;
  voMdiPage.btn = voMdiButton;
  if(pbVisible != null) voMdiButton.visible = pbVisible;
  this.addMdiButton(voMdiButton);
  this.mdiGroupSet.add(this.mdibutton);
  
  this.mdiSeqNum++;

  var vnIndex = this.mdiPageSet.size() - 1;
//  if(vnIndex == this.selectedIndex) this.selectTab(vnIndex);
  this.mdisubpage = new eXria.controls.xhtml.SubPage(vsPageId+"_subpage", 0, 0, pnWidth, pnHeight);
  voMdiSubpage = this.mdisubpage;
  var vsResourceBaseUrl = (this.canvas.page.metadata.resourceBaseUrl == "/") ? "" : this.canvas.page.metadata.resourceBaseUrl;
  if(psSrc.indexOf("http://") > -1) voMdiSubpage.src = psSrc;
  else voMdiSubpage.src = vsResourceBaseUrl + psSrc;
  voMdiSubpage.zIndex = this.mdiSeqNum + 1;
  this.mdiGroupSet.add(voMdiSubpage);
  this.mdiPageSet.add(voMdiSubpage);
  voMdiPage.pagebody.addChild(voMdiSubpage);
  
  this.mdipageresize.zIndex = this.mdiSeqNum+1;
  
  this.addChild(this.mdipageresize);
  this.addChild(this.mdipage);
  
  return this.mdiPageSet.size() - 1;
};

/**
 * MdiButton 을 추가
 * @param {eXria.controls.xhtml.MDIGroup.prototype} poMdiButton MDI 버튼
 * @private
 */
eXria.controls.xhtml.MDIGroup.prototype.addMdiButton = function(poMdiButton) {
  var voCtrl = this.getCtrl();
  var voBtnDf = this.mdibuttons;
  if(this.visible == false) {
    this.visible = true;
  }
  poMdiButton.parent = this;
//  this.addItem(poMdiButton);

  if(voBtnDf) {
  //mdibuttons 속성을 mdibutton 에 전달
    poMdiButton.canvas = this.canvas;
    poMdiButton.window = this.window;
    poMdiButton.document = this.document;
    poMdiButton.className = voBtnDf.className;
    poMdiButton.outerClassName = voBtnDf.outerClassName;
    poMdiButton.backgroundColor = voBtnDf.backgroundColor;
    poMdiButton.backgroundImage = voBtnDf.backgroundImage;
    poMdiButton.imageFocused = voBtnDf.imageFocused;
    poMdiButton.backgroundPosition = voBtnDf.backgroundPosition;
    poMdiButton.backgroundRepeat = voBtnDf.backgroundRepeat;
    poMdiButton.color = voBtnDf.color;
    poMdiButton.fontFamily = voBtnDf.fontFamily;
    poMdiButton.fontSize = voBtnDf.fontSize;
    poMdiButton.fontWeight = voBtnDf.fontWeight;
    poMdiButton.fontStyle = voBtnDf.fontStyle;
    poMdiButton.textDecoration = voBtnDf.textDecoration;
    poMdiButton.borderColor = voBtnDf.borderColor;
    poMdiButton.borderStyle = voBtnDf.borderStyle;
    poMdiButton.borderWidth = voBtnDf.borderWidth;
    poMdiButton.borderLeftWidth = voBtnDf.borderLeftWidth;
    poMdiButton.borderRightWidth = voBtnDf.borderRightWidth;
    poMdiButton.borderTopWidth = voBtnDf.borderTopWidth;
    poMdiButton.borderBottomWidth = voBtnDf.borderBottomWidth;
    poMdiButton.padding = voBtnDf.padding;
    poMdiButton.paddingLeft = voBtnDf.paddingLeft;
    poMdiButton.paddingRight = voBtnDf.paddingRight;
    poMdiButton.paddingTop = voBtnDf.paddingTop;
    poMdiButton.paddingBottom = voBtnDf.paddingBottom;
    poMdiButton.position = "relative";
    poMdiButton.cursor = voBtnDf.cursor;
  
    if(poMdiButton.visible != false) {
//      this.checkScroll();
//      poMdiButton.load();
      this.addChild(this.mdibutton);
    }
  }
};

/**
 * 지정된 인덱스에 해당하는 MDI 페이지 반환.
 * @param {Number} pnIndex 인덱스
 * @return 지정된 인덱스에 해당하는 MDI 페이지
 * @type eXria.controls.xhtml.MDIGroup
 */
eXria.controls.xhtml.MDIGroup.prototype.getPage = function(pnIndex) {
  var voPage = null;
  try {
    voPage = this.mdiPageSet.get(pnIndex);
  } catch(err) {}
  return voPage;
};
/**
 * 지정된 페이지 ID에 해당하는 MDI 페이지 반환.
 * @param {String} psPageSubId MDI 페이지 id
 * @return 지정된 페이지 ID에 해당하는 MDI 페이지
 * @type eXria.controls.xhtml.MDIGroup
 */
eXria.controls.xhtml.MDIGroup.prototype.getPageById = function(psPageId) {
  var vnIndex = this.getIndexById(psPageId);
  var voPage = null;
  
  if(vnIndex == -1) voPage = null;
  else voPage = this.mdiPageSet.get(vnIndex);
    
  return voPage;
};

/**
 * 지정된 pageId에 해당하는 인덱스 반환.
 * @param {String} psPageId 지정된 페이지 아이디.
 * @return pageId에 해당하는 인덱스
 * @type Number
 */
eXria.controls.xhtml.MDIGroup.prototype.getIndexById = function(psPageId) {
  var vnIndex = -1;
  var voIterator = this.mdiPageSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == psPageId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};

eXria.controls.xhtml.MDIGroup.prototype.getPageLabelById = function(psPageId) {
  var vnIndex = this.getIndexLabelById(psPageId);

  var voPage = null;
  
  if(vnIndex == -1) voPage = null;
  else voPage = this.mdiPageResizeSet.get(vnIndex);
  
  return voPage;
};

/**
 * 지정된 pageId에 해당하는 인덱스 반환.
 * @param {String} psPageId 지정된 페이지 아이디.
 * @return pageId에 해당하는 인덱스
 * @type Number
 */
eXria.controls.xhtml.MDIGroup.prototype.getIndexLabelById = function(psPageId) {
  var vnIndex = -1;
  var voIterator = this.mdiPageResizeSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == psPageId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};

/**
 * 지정된 컨트롤의 ID로 컨트롤객체 반환.
 * @param {String} psControlId
 * @return 지정된 컨트롤 ID에 해당하는 컨트롤 객체
 * @type eXria.controls.xhtml.MDIGroup
 */
eXria.controls.xhtml.MDIGroup.prototype.getControlById = function(psControlId) {
  var vnIndex = this.getControlIndexById(psControlId);

  var voCtrl = null;
  
  if(vnIndex == -1) voCtrl = null;
  else voCtrl = this.mdiGroupSet.get(vnIndex);
  
  return voCtrl;
};

/**
 * 지정된 ControlId 에 해당하는 인덱스 반환.
 * @param {String} psControlId 지정된 컨트롤 아이디.
 * @return psControlId에 해당하는 인덱스
 * @type Number
 */
eXria.controls.xhtml.MDIGroup.prototype.getControlIndexById = function(psControlId) {
  var vnIndex = -1;
  var voIterator = this.mdiGroupSet.iterator();
  var voCtrl = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voCtrl = voIterator.next();
    cnt++;
    if(voCtrl.id == psControlId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};

/**
 * MDI 버튼의 위치이동
 * @type eXria.controls.xhtml.MDIGroup
 * @private
 */
eXria.controls.xhtml.MDIGroup.prototype.mdiButtonMove = function() {
  var voIterator = this.mdiGroupSet.iterator();
  var vnCnt = 0;
  var vnButtonTop = 0;
  var vnButtonLeft = 0;
  
  while(voIterator.hasNext()){
    var voCtrl = voIterator.next();
    if(voCtrl.toString() == "MDIButton" && !!voCtrl.id){
      if(vnCnt == 0) {
        vnButtonLeft = 2;
        this.mdiSeqNum = 0;
        if(this.minimizePos == "top") vnButtonTop = 0;
        else vnButtonTop = parseInt((this.height - 20 * (vnCnt + 1.1)));
      }else{
        vnButtonLeft = this.mdibuttons.left + this.mdibuttons.width + 4;
        if(this.minimizePos == "top") vnButtonTop = parseInt((-20 * (vnCnt + 1.1)));
        else vnButtonTop = parseInt((this.height - 20 * (vnCnt + 1.1)));
      }
      this.mdibuttons.top = vnButtonTop;
      this.mdibuttons.left = vnButtonLeft;
      
      voCtrl.applyAttr("top", vnButtonTop);
      voCtrl.applyAttr("left", vnButtonLeft);
      voCtrl.applyAttr("tooltip", voCtrl.value);

      vnCnt++;
    }
  }
  if(vnCnt == 0)  this.mdiSeqNum = 0;
};

/**
 * mdipage 들의 초기 layout 배치
 * @type eXria.controls.xhtml.MDIGroup
 * @private
 */
eXria.controls.xhtml.MDIGroup.prototype.mdiInitLayout = function() {
  var voMdiPage = null;
  var vnTop = 0;
  var vnLeft = 0;
  var vaTop = new Array();
  var vaLeft = new Array();
  var mdiPageCnt = 0;
  this.mdiLayout = this.getAttrValue("mdiLayout", this.mdiLayout);
  this.rows = this.getAttrValue("rows", this.rows);
  this.cols = this.getAttrValue("cols", this.cols);
  
  var vnMainHeight = this.height;
  var vnMainWidth = this.width;
  var vnHeight = 0;
  var vnWidth = 0;
  var voIterator = this.mdiPageSet.iterator();
  var voResizeIterator = this.mdiPageResizeSet.iterator();
  
  if(this.minimizePos == "top") vnTop = this.titleBarHeight;
  
  while(voIterator.hasNext()){
    voMdiPage = voIterator.next();
    if(voMdiPage.toString() == "MDIPage"){
      mdiPageCnt++;
    }
  }
  if(this.mdiLayout == "matrix"){
    if(mdiPageCnt > (this.rows * this.cols)){
      alert("matrix의 행, 열의 정의가 잘못되었습니다.");
      return;
    }else{
      mdiPageCnt = 0;
      vnHeight = parseInt((vnMainHeight - (this.titleBarHeight + 4)) / this.rows);
      vnWidth = parseInt((vnMainWidth - 2) / this.cols);
      for(var i = 1; i <= this.rows; i++){
        for(var j = 1; j <= this.cols; j++){
          vaTop.push(vnTop);
          vaLeft.push(vnLeft);
          vnLeft = vnLeft + vnWidth;
        }
        vnTop = vnTop + vnHeight;
        vnLeft = 0;
      }
      voIterator = this.mdiPageSet.iterator();
      while(voIterator.hasNext()){
        voMdiPage = voIterator.next();
        if(voMdiPage.toString() == "MDIPage"){
          voMdiPage.applyAttr("top", vaTop[mdiPageCnt]);
          voMdiPage.applyAttr("left", vaLeft[mdiPageCnt]);
          voMdiPage.applyAttr("height", vnHeight);
          voMdiPage.applyAttr("width", vnWidth);
        
          voMdiPage.mdiLabelMove();
          mdiPageCnt++;  
        }
      }
      while(voResizeIterator.hasNext()){
        voMdiPageResize = voResizeIterator.next();
        voMdiPageResize.mdiMove();
      }
    }
  }else{
    voIterator = this.mdiPageSet.iterator();
    while(voIterator.hasNext()){
      voMdiPage = voIterator.next();
      voMdiPage.applyAttr("top", vnTop);
      voMdiPage.applyAttr("left", vnLeft);
      vnTop = vnTop + 70;
      vnLeft = vnLeft + 70;
      voMdiPage.mdiLabelMove();
    }
  }
  this.mdiButtonMove();
};

/**
 * 클래스 명을 반환합니다.
 * @return "MDIGroup"
 * @type String
 */
eXria.controls.xhtml.MDIGroup.prototype.toString = function() {
  return "MDIGroup";
};