/**
 * @fileoverview
 * Concreate xhtml GridEx
 * @작성자 : 김경태
 * @version 2.0
 */

/**
 * @class GridEx의 toolbar 설정 속성을 저장하기 위한 클래스
 * @return 새로운 eXria.controls.xhtml.GridEx_toolbar 객체
 * @type eXria.controls.xhtml.GridEx_toolbar
 * @constructor
 * @ignore
 */
eXria.controls.xhtml.GridEx_toolbar = function() {
  /**
   * 그리드에 toolbar를 표시할 지 여부
   * @type Boolean
   */
  this.visible = true;
  /**
   * 표시될 툴바 버튼 목록을 정의한 문자열
   * @type String
   * @private
   */
  this.cells = "Save,Reload,Repaint,Print,Export,Add,AddChild,ExpandAll,CollapseAll,Columns,Cfg";
};

/**
 * @class GridEx의 panel 설정 속성을 저장하기 위한 클래스
 * @return 새로운 eXria.controls.xhtml.GridEx_panel 객체
 * @type eXria.controls.xhtml.GridEx_panel
 * @constructor
 */
eXria.controls.xhtml.GridEx_panel = function() {
  /**
   * @private
   */
  this.copy = null;
  /**
   * @private
   */
  this.move = null;
  /**
   * @private
   */
  this.select = null;
  /**
   * @private
   */
  this.del = null;
};

/**
 * @class GridEx에 이벤트 핸들러에 전달되는 이벤트 구조 정의 클래스
 * @return 새로운 eXria.controls.xhtml.GridEx_event 객체
 * @type eXria.controls.xhtml.GridEx_event
 * @constructor
 */
eXria.controls.xhtml.GridEx_event = function() {
  /**
   * GridEx 객체
   * @type eXria.controls.xhtml.GridEx
   */
  this.object = null;
  /**
   * event 타입을 구분하기 위한 속성
   * @type Number
   */
  this.type = null;
  /**
   * 칼럼 id
   * @type Strnig
   */
  this.colId = null;
  /**
   * 이전 칼럼의 id
   * @type Strnig
   */
  this.beforeColId = null;
  /**
   * 그리드에서 이벤트가 발생된 row의 실체화 객체 참조 변수
   * @type HTMLElement
   */
  this.row = null;
  /**
   * 그리드에서 이벤트가 발생된 row의 이전 row 실체화 객체 참조 변수
   * @type HTMLElement
   */
  this.beforeRow = null;
  /**
   * 페이지에서의 위치
   * @type Number
   */
  this.pagePos = null;
  /**
   * 이벤트 발생 x 좌표 값
   * @type Number
   */
  this.x = null;
  /**
   * 이벤트 발생 y 좌표 값
   * @type Number
   */
  this.y = null;
  /**
   * 입력된 키
   * @type Number
   */
  this.key = null;
  /**
   * 데이터 값
   * @type Object
   */
  this.value = null;
  /**
   * 브라우저 이벤트
   * @type HTMLEvent
   */
  this.e = null;

  /**
   * scroll 관련 이벤트
   */
  this.scroll = {
    newLeft : null,
    newTop : null,
    oldLeft : null,
    oldTop : null
  };
};
/**
 * @class 테이블형태의 2차원 데이터를 표시하며 확장된 기능들을 제공하는 컨트롤
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.GridEx 객체
 * @type eXria.controls.xhtml.GridEx
 * @constructor
 * @base eXria.controls.UIControl
 */
eXria.controls.xhtml.GridEx = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 100 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * GridEx의 설정 클래스
   * @private
   */
  this.cfg = new eXria.controls.xhtml.GridEx.Cfg();
  /**
   * Data 연동 객체(노드셋 연동).
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * dataset과 연동하기 위한 dataset id
   * @type String
   */
  this.datasetId = null;
  /**
   * 그리도 연동 데이타 셋 참조 변수
   * @type eXria.data.plugin.DataSetCmd
   */
  this.dataset = null;
  /**
   * 그리드 헤더.
   * 그리드의 헤더정보를 관리하기 위한 오브젝트.
   * @type eXria.controls.xhtml.GridEx.Header
   */
  this.header = null;
  /**
   * 그리드 바디.
   * 그리드 바디에 표시될 컨텐츠를 관리하기 위한 오브젝트
   * @type eXria.controls.xhtml.GridEx.Body
   */
  this.body = null;
  /**
   * 그리드 footer.
   * 그리드 footer에 표시될 컨텐츠를 관리하기 위한 오브젝트
   * @type eXria.controls.xhtml.GridEx.Footer
   */
  this.footer = null;
  /**
   * tree 그리드 객체 참조 변수
   * @type Object
   * @private
   */
  this.grid = null;
  /**
   * 포커스 된 row 객체 참조 변수
   */
  this.focusRow = null;
  /**
   * 포커스된 column 객체 참조 변수
   */
  this.focusCol = null;
  /**
   * 상위 컨트롤과의 위치 관계(absolute | relative | static).
   * @type String
   * @ignore
   */
  this.position = "absolute";
  /**
   * 배경이미지 url.
   * @type String
   * @private
   */
  this.backgroundImage = null;
  /**
   * 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   * @private
   */
  this.backgroundRepeat = null;
  /**
   * 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   * @private
   */
  this.backgroundPosition = null;
  /**
   * default 설정 정보를 정의한는 XML 파일경로
   * @type String
   */
  this.defaultFileName = null;
  /**
   * 출력되는 문자열을 정의한 XML 파일경로
   * @type String
   */
  this.textFileName = null;
  /**
   * DataSet과 TreeGrid 간의 데이타 동기화를 위한 Sorting 정보
   * @type Array Object
   * @private
   */
  this.sortList = new Array();

  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * GridEx에 디폴트로 설정될 style관련 속성을 저장하기 위한 오브젝트
   * @private
   */
  this.styles = {};
  this.styles.style = "Modern";
  this.styles.prefix = "GM";
  this.styles.file = "GridModern.css";
  /**
   * GridEx 툴바 설정 속성을 저장하기 위한 오브젝트
   * @type eXria.controls.xhtml.GridEx_toolbar
   * @private
   */
  this.toolbar = new eXria.controls.xhtml.GridEx_toolbar();
  /**
   * GridEx panel 설정 속성을 저장하기 위한 오브젝트
   * @type eXria.controls.xhtml.GridEx_panel
   */
  this.panel = new eXria.controls.xhtml.GridEx_panel();
  /**
   * GridEx에 이벤트 핸들러에 전달되는 이벤트 객체 참조
   * @type eXria.controls.xhtml.GridEx_event
   */
  this.event = new eXria.controls.xhtml.GridEx_event();
  /**
   * row 타입을 구분하기 위한 상수 값 접근 오브젝트
   * @type Object
   */
  this.RowType = {
    HeadRow : "HeadRow",
    BodyRow : "BodyRow",
    FootRow : "FootRow"
  };
  /*
   * GridEx의 Rendering 상태
   * @private
   */
  this.rendering = false;

  /**
   * 최초 로딩시 바인딩된 데이타 초기화 여부
   * @type Object
   */
  this.hideInitRow = null;

  /**
   * GridEx Page(Fast) 사용시 전체 선택 관련 Flag
   * @private
   */
  this.pageSelectAllChecked = false;

  /**
   * @ignore
   */
  this.init = true;
  /**
   * @ignore
   */
  this.CopiedRow = [];

  this.cursor = null;

  /**
   * GridEx의 locale정보
   * @private
   */
  this.locale = null;

  this.selectedIndexes = null;

  /**
   * page Fast모드에서 렌더링할 총 갯수
   * @private
   */
  this.pageCountWithFastMode = -1;
  /**
   * right button 저장 목록
   * @private
   */
  this.rgtBtnList = new eXria.data.ArrayCollection();
  /**
   * enum column 저장 목록
   * @private
   */
  this.enumColList = new eXria.data.ArrayCollection();
  /**
   * head column id를 통해 head column 객체를 참조하기 위한 맵
   * @private
   */
  this.headColMap = new eXria.data.ArrayMap();
  /**
   * head column id를 통해 body column 객체를 참조하기 위한 맵
   * @private
   */
  this.bodyColHMap = new eXria.data.ArrayMap();
  /**
   * body column id를 통해 body column 객체를 참조하기 위한 맵
   * @private
   */
  this.bodyColMap = new eXria.data.ArrayMap();
  /**
   * function column id를 통해 function column 객체를 참조하기 위한 맵
   * @private
   */
  this.functionColMap = new eXria.data.ArrayMap();
  /**
   * foot column id를 통해 footer column 객체를 참조하기 위한 맵
   * @private
   */
  this.footColMap = new eXria.data.ArrayMap();
  /*
   * 숨겨진 column 명세를 기록하기 위한 Map;
   * @type eXra.data.ArrayMap;
   */
  this.hideColMap = new eXria.data.ArrayMap();
  
  this.isRendered = false;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.GridEx);

/**
 * @class GridEx의 Configration 지정 클래스
 * @return 새로운 eXria.controls.xhtml.GridEx.Cfg 객체
 * @type eXria.controls.xhtml.GridEx.Cfg
 * @constructor
 */
eXria.controls.xhtml.GridEx.Cfg = function() {
  /**
   * Tree 형태로 펼쳐질때 기준이 되는 칼럼 ID
   * @type String
   */
  this.maincol = null;
  /**
   * Panel의 숨김 여부
   * @type Boolean
   */
  this.hidePanel = true;
  /**
   * GridEx의 전체 넓이의 고정 여부
   * @type Boolean
   * @ignore
   */
  this.constWidth = true;
  /**
   * GridEx의 전체 높이의 고정 여부
   * @type Boolean
   * @ignore
   */
  this.constHeight = true;
  /**
   * row들이 서로 다른 높이를 가질 수 있도록 자동 계산될지의 여부
   * 이 높이는 로우의 가장 높은 높이를 가진 cell에 의해서 자동적으로 계산된다.
   * 멀티라인 textarea(cell type Lines)를 사용하거나 various HTML code를 가진 셀들을 포함시키기를 원한다면 VarHeight 값을 1로 설정한다
   * 페이징을 사용하는 경우에는 Variable한 row의 높이는 권장되지 않는다 (Child paging is mostly ok)
   * VarHeight를 1로 설정하게 되면 grid의 렌더링 속도를 저하시킬 수 있고 로우들에 사용되는 grid 이미지들이 꽉 차게 표시되지 않을 수 있다.
   * VarHeight='0' 으로 위에 정의되어 있어야 Defalut Row의 height 속성이 적용된다. 단 Row가 2줄로 지정이된 행을 만나면 그 이후부터 Defalut Row의 height는 적용이 안됨
   * 위에서 MaxHeight='1' MinHeight='1' 높이의 최대값과 최소값 설정을 통해 높이를 지정하도록 한다.
   * @type Boolean
   * @ignore
   */
  this.varHeight = false;
  /**
   * row의 평균 높이 (VarHeight가 1일때만 적용됨)
   * 이 값은 페이지 높이와 몇몇 다른 설정들을 사전에 계산하기 위해 사용된다.
   * @type Boolean
   * @ignore
   */
  this.rowHeight = 18;
  /////////////////////////////////////////////////////////////////
  // Grid 특성
  /**
   * How values of grid can be edited, 0: never, 1: yes, according to other settings, 2: preview (read only) mode
   * @type Number
   */
  this.editing = null;
  /**
   * multiSelect 여부
   * @type Boolean
   */
  this.multiSelect = null;
  /**
   * 다른 row 클릭 시 Selecting 유지 여부
   * @type Boolean
   */
  this.keepSelecting = null;
  /**
   * If selecting individual cells or cells ranges is permitted.
   * @type Boolean
   * @ignore
   */
  this.selectingCells = null;
  /**
   * If text selection by mouse is permitted. For text selection must be also set dragging = 0 or column canDrag = 0
   * @type Boolean
   * @ignore
   */
  this.selectingText = null;

  /**
   * 그리드에 메시지를 표시할 지 여부
   * @type Boolean
   * @private
   */
  this.suppressMessage = null;  // 그리드에 메시지를 표시하지 않는다.

  /**
   * If selecting individual cells or cells ranges is permitted.
   * @type Boolean
   * @ignore
   */
  this.pasting = null;
  /**
   * Rows can be filtered
   * @type Boolean
   * @ignore
   */
  this.filtering = true;
  /**
   * Rows can be moved by mouse (grid can be a source grid for drag / drop)
   * @type Boolean
   * @ignore
   */
  this.dragging = true;

  /**
   * Row의 grouping 가능 여부
   * @type Boolean
   */
  this.grouping = true;
  /**
   * 그룹된 칼럼이 표시되는 칼럼
   * @type String
   */
  this.groupMain = null;
  /**
   * 그룹되어지는 칼럼들
   * @type String
   */
  this.groupCols = null;
  /**
   * Grouping일 경우 전부 ExpandAll 하는 옵션
   * @type Boolean
   */
  this.expandAll = false;

  /**
   * Row의 sorting 가능 여부(false일 경우 헤더의 sorting 아이콘이 표시되지 않으며 sorting이 동작하지 않음)
   * @type Boolean
   */
  this.sorting = true;
  /**
   * 사용자에 의한 sorting 가능 여부(false일 경우 헤더의 sorting 아이콘은 제대로 표시되지만 sorting이 동작하지 않음)
   * @type Boolean
   */
  this.sorted = null;
  /**
   * sort되는 column들의 id
   * @type String
   */
  this.sortCols = null;
  /**
   * sort되는 column들의 올림/내림차순 지정
   * @type String
   */
  this.sortTypes = null;

  /**
   * pageing 사용 여부
   * @type Boolean
   */
  this.paging = null; // none || auto || fast
  /**
   * 하나의 페이지를 이루는 Row 갯수
   * @type Number
   */
  this.pageLength = null;
  /**
   * 현재 페이지 위치 정보
   * @type Number
   * @private
   */
  this.pagePos = 0;
  /**
   * page모드시 paging할때 전체 선택에 대한 상태유지를 하기위한 옵션
   * @type Boolean
   */
  this.pageSelectAll = true;

  /**
   * ID 칼럼으로 지정된 ID(HeadColumn ID)
   * @type String
   */
  this.idColumn = null;
  /**
   * Gantt Chart에서 ID 칼럼으로 지정된 ID(HeadColumn ID)로 idColumn과 중복되서 적용이 안되며 우선순위가 더 높음
   * @type String
   * @ignore
   */
  this.ganttIdColumn = null;
  /**
   * Row ID를 generate할 때 주어진 순서에 따라 허용되는 문자열
   * @type String
   * @ignore
   */
  this.idChars = '0123456789';
  /**
   * Row ID를 number로 generate할지 여부
   * @type Boolean
   * @ignore
   */
  this.numberID = '1';
  /**
   * ID칼럼 앞 부분에 insert 되는 문자열
   * @type String
   */
  this.idPrefix = "";
  /**
   * ID칼럼 뒷 부분에 insert 되는 문자열
   * @type String
   */
  this.idPostfix = "";
};

eXria.controls.xhtml.GridEx.prototype.create = function(poDocument, poDiv) {
  if(poDocument == null) poDocument = this.document;
  var voCtrl = null;

  if(this.createCtrl) { voCtrl = this.createCtrl(poDocument); };                                      // 1. Main Ctrl 생성
  if(this.createSubCtrl && voCtrl) { this.createSubCtrl(voCtrl, poDocument); };                       // 2. Composite Child Ctrl 생성

  if(this.setMainCtrlStyles && voCtrl) { this.setMainCtrlStyles(voCtrl, poDocument); };               // 3. Main Style 적용
  if(this.setSubCtrlStyles && voCtrl) { this.setSubCtrlStyles(voCtrl, poDocument); };                 // 4. Composite Child Style 적용

  if(this.setFormDefaults && voCtrl) { this.setFormDefaults(voCtrl, poDocument); };
  if(this.setUIGeneralDefaults && voCtrl) { this.setUIGeneralDefaults(voCtrl, poDocument); };         // 5. 공통 초기값 설정
  if(this.setSpecificDefaults && voCtrl) { this.setSpecificDefaults(voCtrl, poDocument); };           // 6. 개별 초기값 설정

  if(this.setSpecificAttrs && voCtrl) { this.setSpecificAttrs(voCtrl, poDocument); }                  // 9. 개별 Attrs 적용

  if(!this.printMode) {
    if(this.setGeneralEvents && voCtrl) { this.setGeneralEvents(voCtrl); }                            // 10. 공통 Events 적용
    if(this.setUIGeneralEvents && voCtrl) { this.setUIGeneralEvents(voCtrl); }                        // 11. UI 공통 Events 적용
    if(this.setSpecificEvents && voCtrl) { this.setSpecificEvents(voCtrl); }                          // 12. 개별 Events 적용
  }

  return voCtrl;
};

eXria.controls.xhtml.GridEx.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl.style.position = "absolute";
  voCtrl["id"] = this.id;

  this.template = [];           // grid 생성 과정에서 사용되는 임시데이타 보관소
  this.templateLayout = null;   // grid 레이아웃 정보를 보관하는 임시 보관소
  this.templateData = null;     // grid 데이터 정보를 보관하는  임시 보관소

  this.ctrl = voCtrl;

  return voCtrl;
};

eXria.controls.xhtml.GridEx.prototype.createSubCtrl = function(poCtrl, poDocument) {
  var vaTemplate = this.template;
  var vsCfg = "";
  var vsToolbar = "";

  vaTemplate["Start"] = "<Grid>";
  vaTemplate["End"] = "</Grid>";

  /////////////////////////////////////////////////////////////////
  // Cfg 구성
  var voCfg = this.cfg;
  vsCfg = "<Cfg id='" + this.id + "' StandardFilter='2'  PasteFocused='3' PrintCols='0' BorderCursors='1' ";
  vsCfg = vsCfg + "Code='GTGDONJGPDMUXB' ";
//  vsCfg = vsCfg + "CSS='/guide/eXria/config/gridex/Modern/Grid.css' ";
  // Grid capabilities
//  if(voCfg.editing != null) vsCfg = vsCfg + " Editing='" + voCfg.editing + "'";
  if(voCfg.sorting != null) vsCfg = vsCfg + " Sorting=" + this.getXmlValue(voCfg.sorting);
//  if(voCfg.filtering != null) vsCfg = vsCfg + " Filtering=" + this.getXmlValue(voCfg.filtering);
  if(voCfg.grouping != null) vsCfg = vsCfg + " Grouping=" + this.getXmlValue(voCfg.grouping);
//  if(voCfg.dragging != null) vsCfg = vsCfg + " Dragging=" + this.getXmlValue(voCfg.dragging);
//  if(voCfg.dragging != null) vsCfg = vsCfg + " Dragging='1'";
//  if(voCfg.dropping != null) vsCfg = vsCfg + " Dropping=" + this.getXmlValue(voCfg.dropping);
  if(voCfg.pasting != null) vsCfg = vsCfg + " Pasting=" + this.getXmlValue(voCfg.pasting);
//  if(voCfg.colResizing != null) vsCfg = vsCfg + " ColResizing=" + this.getXmlValue(voCfg.colResizing);
//  if(voCfg.colMoving != null) vsCfg = vsCfg + " ColMoving=" + this.getXmlValue(voCfg.colMoving);
//  if(voCfg.resizingMain != null) vsCfg = vsCfg + " ResizingMain=" + this.getXmlValue(voCfg.resizingMain);
//  if(voCfg.resizingMainLap != null) vsCfg = vsCfg + " ResizingMainLap=" + this.getXmlValue(voCfg.resizingMainLap);
  if(voCfg.selectingCells != null) vsCfg = vsCfg + " SelectingCells=" + this.getXmlValue(voCfg.selectingCells);
  if(voCfg.selectingText != null) vsCfg = vsCfg + " SelectingText=" + this.getXmlValue(voCfg.selectingText);

  vsCfg = vsCfg + " HidePanel=" + this.getXmlValue(voCfg.hidePanel);
//  vsCfg = vsCfg + " VarHeight=" + this.getXmlValue(voCfg.varHeight);
  vsCfg = vsCfg + " RowHeight='" + voCfg.rowHeight + "'";
//  vsCfg = vsCfg + " MaxHeight='0'";// + this.height + "'";
//  vsCfg = vsCfg + " MaxWidth='0'";// + this.width + "'";
  vsCfg = vsCfg + " ConstHeight=" + this.getXmlValue(voCfg.constHeight);

  if(voCfg.groupMain) vsCfg = vsCfg + " GroupMain='" + (voCfg.groupMain == this.cfg.idColumn ? "id" : voCfg.groupMain) + "'";
  if(voCfg.groupCols) vsCfg = vsCfg + " GroupCols='" + (voCfg.groupCols == this.cfg.idColumn ? "id" : voCfg.groupCols) + "'";
  if(voCfg.sorted != null || this.sortUser) {
    if(this.sortUser) vsCfg = vsCfg + " Sorted=" + this.getXmlValue(1);
    else vsCfg = vsCfg + " Sorted=" + this.getXmlValue(voCfg.sorted);
  }
  if(voCfg.sortCols != null || this.sortColsUser) {
    var voMap = new eXria.data.ArrayMap();
    var vaSortCols = voCfg.sortCols;
    if(!!vaSortCols) vaSortCols = vaSortCols.split(",");
    else vaSortCols = [];
    var vaSortTypes = voCfg.sortTypes;
    if(!!vaSortTypes) vaSortTypes = vaSortTypes.split(",");
    vaSortTypes = [];
    var vnSize = vaSortCols.length;
    for(var i = 0; i < vnSize; i++) {
      voMap.put(vaSortCols[i], vaSortTypes[i]);
    }
    if(this.sortColsUser) {
      vaSortCols = this.sortColsUser;
      vaSortTypes = this.sortTyepsUser;
      if(vaSortTypes == null) vaSortTypes = [];
      vnSize = vaSortCols.length;
      for(var i = 0; i < vnSize; i++) {
        voMap.put(vaSortCols[i], vaSortTypes[i]);
      }
      var voCollection = voMap.getKeyCollection();
      vsCfg = vsCfg + " SortCols='" + voCollection.elements.join(",") + "'";
      voCollection = voMap.getValueCollection();
      vsCfg = vsCfg + " SortTypes='" + voCollection.elements.join(",") + "'";
    }
  }

  if(voCfg.suppressMessage != null) {
    if(voCfg.suppressMessage) vsCfg = vsCfg + " SuppressMessage='3'";
    else vsCfg = vsCfg + " SuppressMessage='0'";
   } else {
    var voSuppressMessage = this.getAttrValue("cfg.suppressMessage",this.cfg.suppressMessage);
    if(voSuppressMessage) vsCfg = vsCfg + " SuppressMessage='3'";
    else vsCfg = vsCfg + " SuppressMessage='0'";
  }

  vsCfg = vsCfg + " SuppressCfg='3'";
  vsCfg = vsCfg + " EnumKeys='1'";

  //yhkim 2009.05.18 Paging Data
  this.cfg.paging = this.getAttrValue("cfg.paging",voCfg.paging);
  this.cfg.pageLength = this.getAttrValue("cfg.pageLength", voCfg.pageLength);

  if (this.cfg.paging == "fast") {
    vsCfg = vsCfg + " Paging='3' ";
    vsCfg = vsCfg + " PageLength='" + voCfg.pageLength + "'";
    vsCfg = vsCfg + " Allpages='1' ";
    vsCfg = vsCfg + " NoPager='1' ";
  }else if(this.cfg.paging == "auto"){
    vsCfg = vsCfg + " Paging='2' ";
    vsCfg = vsCfg + " PageLength='" + voCfg.pageLength + "'";
    vsCfg = vsCfg + " Allpages='1' ";
    vsCfg = vsCfg + " NoPager='1' ";
  }

  //yhkim 2009.06.25  row이동 방지
  vsCfg = vsCfg + " Dragging='0'";

  // ID 칼럼 구성
  if(voCfg.idChars) vsCfg = vsCfg + " IdChars='" + voCfg.idChars + "'";
  if(voCfg.numberID) vsCfg = vsCfg + " NumberId='" + voCfg.numberID + "'";
  if(voCfg.idPrefix) vsCfg = vsCfg + " IdPrefix='" + voCfg.idPrefix + "'";
  if(voCfg.idPostfix) vsCfg = vsCfg + " IdPostfix='" + voCfg.idPostfix + "'";

  vsCfg = vsCfg + "/>";

  vaTemplate["Cfg"] = vsCfg;
  vsCfg = null;

  /////////////////////////////////////////////////////////////////
  // Toolbar 구성
  vsToolbar = "<Toolbar";
  vsToolbar = vsToolbar + " Visible='0'"; // 임시 1.0 릴리즈에서 제공 안됨
//  if(this.toolbar.visible) vsToolbar = vsToolbar + " Visible=" + this.getXmlValue(this.toolbar.visible);
//  if(this.toolbar.cells) vsToolbar = vsToolbar + " Save='0'";
  if(this.toolbar.cells) vsToolbar = vsToolbar + " cells=" + this.getXmlValue(this.toolbar.cells);
  vsToolbar = vsToolbar + "/>";

  vaTemplate["Toolbar"] = vsToolbar;

  /////////////////////////////////////////////////////////////////
  // Panel 구성 2009.08.04
  var voPanel = "";
  if(this.panel) {
    voPanel = this.panel;
    var vsPanel = "<Panel";
    if(voPanel.select != null)  vsPanel = vsPanel + " Select="+ this.getXmlValue(voPanel.select);
    if(voPanel.del != null)     vsPanel = vsPanel + " Delete="+ this.getXmlValue(voPanel.del);
  //if(voPanel.copy != null)    vsPanel = vsPanel + " Copy="  + this.getXmlValue(voPanel.copy);
    vsPanel = vsPanel + "/>";
    vaTemplate["Panel"] = vsPanel;
  }

  vaTemplate = null;
};

eXria.controls.xhtml.GridEx.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
  poCtrl.className = this.getCSSClass(this, 2);
};

eXria.controls.xhtml.GridEx.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voCssStyle = this.canvas.getCssStyle(this.outerClassName, poDocument);
  var voCfg = this.cfg;
  var voDf = this.df;
  voDf.position = this.makeSpecificAttrValue(poCtrl, voCssStyle, "position");
  voDf.borderColor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderColor");
  voDf.borderStyle = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderStyle");

  voCssStyle = this.canvas.getCssStyle(this.className, poDocument);
  voDf.color = this.makeSpecificAttrValue(poCtrl, voCssStyle, "color");
  voDf.fontFamily = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontFamily");
  voDf.fontSize = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontSize");
  voDf.fontStyle = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontStyle");
  voDf.fontWeight = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontWeight");
  voDf.textAlign = this.makeSpecificAttrValue(poCtrl, voCssStyle, "textAlign");
  voDf.textDecoration = this.makeSpecificAttrValue(poCtrl, voCssStyle, "textDecoration");
  voDf.padding = this.makeSpecificAttrValue(poCtrl, voCssStyle, "padding");
  voDf.paddingLeft = this.makeSpecificAttrValue(poCtrl, voCssStyle, "paddingLeft");
  voDf.paddingRight = this.makeSpecificAttrValue(poCtrl, voCssStyle, "paddingRight");
  voDf.paddingTop = this.makeSpecificAttrValue(poCtrl, voCssStyle, "paddingTop");
  voDf.paddingBottom = this.makeSpecificAttrValue(poCtrl, voCssStyle, "paddingBottom");
  voDf.cursor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "cursor");
  voDf.backgroundColor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "backgroundColor");
  voDf.backgroundRepeat = this.makeSpecificAttrValue(poCtrl, voCssStyle, "backgroundRepeat");
  voDf.backgroundPosition = this.makeSpecificAttrValue(poCtrl, voCssStyle, "backgroundPosition");
  voDf.backgroundImage = this.makeSpecificAttrValue(poCtrl, voCssStyle, "backgroundImage", "backgroundImage", this.className);
  if(voDf.backgroundImage != null) voDf.backgroundImage = voDf.backgroundImage.replace(/\'/gi, "");

  if(voDf.fontSize != null) voDf.fontSize = parseInt(voDf.fontSize);
  if(voDf.padding != null) voDf.padding = parseInt(voDf.padding);
  else voDf.padding = 0;
  if(voDf.paddingLeft != null) voDf.paddingLeft = parseInt(voDf.paddingLeft);
  else voDf.paddingLeft = voDf.padding;
  if(voDf.paddingRight != null) voDf.paddingRight = parseInt(voDf.paddingRight);
  else voDf.paddingRight = voDf.padding;
  if(voDf.paddingTop != null) voDf.paddingTop = parseInt(voDf.paddingTop);
  else voDf.paddingTop = voDf.padding;
  if(voDf.paddingBottom != null) voDf.paddingBottom = parseInt(voDf.paddingBottom);
  else voDf.paddingBottom = voDf.padding;
  voDf.value = this.getAttrValue("value",this.value);
  voDf.imagePushed = this.getAttrValue("imagePushed",this.imagePushed);
  voDf.imageFocused = this.getAttrValue("imageFocused",this.imageFocused);
  voDf.imageMouseover = this.getAttrValue("imageMouseover",this.imageMouseover);
  this.defaultFileName = this.getAttrValue("defaultFileName", this.defaultFileName);
  this.textFileName = this.getAttrValue("textFileName", this.textFileName);

  this.hideInitRow = this.getAttrValue("hideInitRow",this.hideInitRow);
  voCfg.multiSelect = this.getAttrValue("cfg.multiSelect",voCfg.multiSelect);
  voCfg.keepSelecting = this.getAttrValue("cfg.keepSelecting",voCfg.keepSelecting);
  this.oddRowBg = this.getAttrValue("oddRowBg", this.oddRowBg);
  this.evenRowBg = this.getAttrValue("evenRowBg", this.evenRowBg);
  if(this.userAttr == "") this.userAttr = null;
  this.userAttr = this.getAttrValue("userAttr", this.userAttr);

  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    if(voUserAttr.ganttFlagObj) this.ganttFlagObj = voUserAttr.ganttFlagObj;
    this.labelName = voUserAttr.labelName;
    this.colResizeDiff = voUserAttr.colResizeDiff;
    this.funcRowCanEdit = voUserAttr.funcRowCanEdit;
    if(voUserAttr.sorting != null) voCfg.sorting = voUserAttr.sorting;
    if(!!voUserAttr.colTypeDefine) this.colTypeDefine = voUserAttr.colTypeDefine;
    if(!!voUserAttr.rowMaxHeight) this.rowMaxHeight = voUserAttr.rowMaxHeight;
    if(!!voUserAttr.showTooltip) this.showTooltip = voUserAttr.showTooltip;
    if(!!voUserAttr.hRowSpans) this.hRowSpans = voUserAttr.hRowSpans;
    if(!!voUserAttr.mergeRowCols) this.mergeRowCols = voUserAttr.mergeRowCols;
    if(!!voUserAttr.columnCursor) this.columnCursor = voUserAttr.columnCursor;
    if(!!voUserAttr.childRows) {
      this.childRows = voUserAttr.childRows;
     this.template["Cfg"] = this.template["Cfg"].replace(/ Grouping\=\"[01]*\"/g, " Grouping=\"0\"");
    }
    if(!!voUserAttr.oddRowBg) this.oddRowBg = voUserAttr.oddRowBg;
    if(!!voUserAttr.evenRowBg) this.evenRowBg = voUserAttr.evenRowBg;
    if(voUserAttr.allPages != null) {
      this.allPages = voUserAttr.allPages;
      this.template["Cfg"] = this.template["Cfg"].replace(/ AllPages\=\"[01]*\"/g, " AllPages=\"" + this.allPages + "\"");
    }
  }
  if(this.colResizeDiff == null) this.colResizeDiff = true;
  if(this.funcRowCanEdit == null) this.funcRowCanEdit = true;
  if(this.cacheResource == null) this.cacheResource = this.canvas.page.cacheGridExResource;
  
  var voGrids = this.window.Grids;
  if(voGrids) {
    //Click and Key Event 추가
    if(voGrids.OnClick == null) {
      voGrids.OnClick = function(poTGP, poRow, psCol, pnX, pnY, poEvent) {
        return poTGP.GridEx.control.enGridexClick(poTGP, poRow, psCol, pnX, pnY, poEvent);
      };
    }
    if(voGrids.OnDblClick == null) {
      voGrids.OnDblClick = function(poTGP, poRow, psCol, pnX, pnY, poEvent) {
        return poTGP.GridEx.control.enGridexDblClick(poTGP, poRow, psCol, pnX, pnY, poEvent);
      };
    }
    if(voGrids.OnClickSide == null) {
      voGrids.OnClickSide = function(poTGP, poRow, psCol) {
        return poTGP.GridEx.control.enGridexButtonClick(poTGP, poRow, psCol);
      };
    }
    if(voGrids.OnFocus == null) {
      voGrids.OnFocus = function(poTGP, poRow, psCol, poBeforeRow, psBeforeCol, pnfocusPagePos) {
        return poTGP.GridEx.control.enGridexFocus(poTGP, poRow, psCol, poBeforeRow, psBeforeCol, pnfocusPagePos);
      };
    }
    if(voGrids.OnKeyDown == null) {
      voGrids.OnKeyDown = function(poTGP, pcKey, poEvent, pnKeyCodes, psPrefix) {
        return poTGP.GridEx.control.enGridexKeyDown(poTGP, pcKey, poEvent, pnKeyCodes, psPrefix);
      };
    };
    if(voGrids.OnRightClick == null) {
      voGrids.OnRightClick = function(poTGP, poRow, psCol, pnX, pnY, poEvent) {
        return poTGP.GridEx.control.enGridexRightClick(poTGP, poRow, psCol, pnX, pnY, poEvent);
      };
    };
    if(voGrids.OnSelect == null) {
      voGrids.OnSelect = function(poTGP, poRow, pnType) {
        return poTGP.GridEx.control.enGridexSelect(poTGP, poRow, pnType);
      };
    };
    //End
  
    //Status Event 추가
    if(voGrids.OnAfterValueChanged == null) {
      voGrids.OnAfterValueChanged = function(poTGP, poRow, psCol, poVal) {
        return poTGP.GridEx.control.enGridexAfterValueChanged(poTGP, poRow, psCol, null);
      };
    };
    if(voGrids.OnChange == null) {
      voGrids.OnChange = function(poTGP, poRow, psCol, poEvent) {
        var psNewValue = window.Get(poRow, psCol);
        var psBeforeValue = window.Get(poRow, psCol + "Orig");
        return poTGP.GridEx.control.enGridexCellEditChanged(psNewValue, psBeforeValue, poRow, poEvent);
      };
    };
    if(voGrids.OnScroll == null) {
      voGrids.OnScroll = function(poTGP, pnNewScollLeft, pnNewScrollTop, pnOldScollLeft, pnOldScrollTop, pnNewScollLeft0, pnOldScollLeft0, pnNewScollLeft2, pnOldScollLeft2) {
        return poTGP.GridEx.control.enGridexScroll(poTGP, pnNewScollLeft, pnNewScrollTop, pnOldScollLeft, pnOldScrollTop);
      };
    };
    if(voGrids.OnValueChanged == null) {
      voGrids.OnValueChanged = function(poTGP, poRow, psCol, poNewValue) {
        return poTGP.GridEx.control.enGridexValueChanged(poTGP, poRow, psCol, poNewValue);
      };
    };
    if(voGrids.OnRowDelete == null) {
      voGrids.OnRowDelete = function(poTGP, poRow, pnType) {
        return poTGP.GridEx.control.enGridExDelRow(poTGP, poRow);
      };
    };
    if(voGrids.OnPrint == null) {
      voGrids.OnPrint = function(poTGP, poWindow, psVal) {
        return poTGP.GridEx.control.enGridexPrint(poTGP, poWindow);
      };
    };
    if(voGrids.OnPrintFinish == null) {
      voGrids.OnPrintFinish = function(poTGP, poWindow ) {
        return poTGP.GridEx.control.enGridexPrintFinish(poTGP, poWindow);
      };
    };
    //End

    if(voGrids.OnClickSideDate == null) {
      voGrids.OnClickSideDate = function(poTGP, poRow, psCol, poEvent) {
        return poTGP.GridEx.control.enGridexClickSideDate(poRow, psCol, poEvent);
      };
    }
    if(voGrids.OnStartEdit == null) {
      voGrids.OnStartEdit = function(poTGP, poRow, psCol) {
        return poTGP.GridEx.control.enGridexStartEdit(poRow, psCol);
      };
    }
    if(voGrids.OnEndEdit == null) {
      voGrids.OnEndEdit = function(poTGP, poRow, psCol, pbSave, psVal) {
        return poTGP.GridEx.control.enGridexEndEdit(poRow, psCol, pbSave, psVal);
      };
    }
    if(voGrids.OnGanttChanged == null) {
      this.window.Grids.OnGanttChanged = function(poTGP, poRow, psCol, psKind, psVal1, psVal2) {
        return poTGP.GridEx.control.enGridexGanttChanged(poRow, psCol, psKind, psVal1, psVal2);
      };
    }
  //  if(voGrids.OnStartDrag == null) {
  //    voGrids.OnStartDrag = function(poTGP, poRow, psCol, pbMultiRow) {
  //      return poTGP.GridEx.control.enGridexStartDrag(poRow, psCol, pbMultiRow);
  //    }
  //  }
  //  if(voGrids.OnEndDrag == null) {
  //    voGrids.OnEndDrag = function(poSrcTGP, poSrcRow, poTrgTGP, poTrgRow, pnType, nX, nY)  {
  //      var vcSrcGrx = null;
  //      if(poSrcTGP) vcSrcGrx = poSrcTGP.GridEx.control;
  //      return poTrgTGP.GridEx.control.enGridexEndDrag(vcSrcGrx, poSrcRow, poTrgRow, pnType, nX, nY);
  //    }
  //  }
    if(voGrids.OnRenderStart == null) {
      voGrids.OnRenderStart  = function(poTGP) {
        return poTGP.GridEx.control.enGridexRenderStart();
      };
    }
    if(voGrids.OnRenderFinish == null) {
      voGrids.OnRenderFinish  = function(poTGP) {
        return poTGP.GridEx.control.enGridexRenderFinish();
      };
    }
    if(voGrids.OnDownloadPage == null) {
      voGrids.OnDownloadPage = function(poTGP, poRow, poFunc) {
        return poTGP.GridEx.control.enGridexDownloadPage(poRow, poFunc);
      };
    }
    if(voGrids.OnCustomAjax  == null) {
      voGrids.OnCustomAjax = function(poTGP, poSource, poData, poFunc) {
        if(poSource.Name != "Page") return;
        return poTGP.GridEx.control.enGridexCustomAjax(poSource, poData, poFunc);
      };
    }
    if(voGrids.OnRenderPageFinish == null) {
      voGrids.OnRenderPageFinish = function(poTGP, poRow) {
        return poTGP.GridEx.control.enGridexRenderPageFinish(poRow);
      };
    }
    if(voGrids.OnSort == null) {
      voGrids.OnSort = function(poTGP, psCol, psSort) {
        return poTGP.GridEx.control.enGridexSort(psCol, psSort);
      };
    }
    if(voGrids.OnSortFinish == null) {
      voGrids.OnSortFinish = function(poTGP) {
        return poTGP.GridEx.control.enGridexSortFinish();
      };
    }
    if(voGrids.OnClickOutside == null) {
      voGrids.OnClickOutside = function() {
        return true;
      };
    }
    if(voGrids.OnPasteRow == null) {
        voGrids.OnPasteRow = function(poTGP, poRow, paCols, paValues, pbAdded) {
          return poTGP.GridEx.control.enGridexPasteRow(poRow, paCols, paValues, pbAdded);
        };
      }
      if(voGrids.OnPasteRowFinish == null) {
        voGrids.OnPasteRowFinish = function(poTGP, poRow, paCols, paValues, pbAdded) {
        poTGP.GridEx.control.enGridexPasteRowFinish(poRow, paCols, paValues, pbAdded);
        };
      }
    }
    if(voGrids.OnSelectAll == null) {
      voGrids.OnSelectAll = function(poTGP) {
        poTGP.GridEx.control.enGridexSelectAll();
      };
    }
};

eXria.controls.xhtml.GridEx.prototype.setSpecificAttrs = function(poCtrl, poDocument) {

  // 데이터셋 참조
  if(this.datasetId) this.dataset = this.canvas.page.model.getDataSet(this.datasetId);

  /////////////////////////////////////////////////////////////////
  // 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaTemplate = this.template;
  this.headColMap.clear();
  this.bodyColMap.clear();
  this.bodyColHMap.clear();
  this.functionColMap.clear();
  this.footColMap.clear();
  this.rgtBtnList.clear();
  this.enumColList.clear();

  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = voDf.tabIndex;
  poCtrl["tooltip"] = voDf.tooltip;
  if(voDf.disabled) poCtrl["disabled"] = true;
  poCtrl["accessKey"] = voDf.accessKey;

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", voDf.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", voDf.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", voDf.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", voDf.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", voDf.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", "12px");        // 버튼 타입내의 폰트의 상하 align이 깨지는 현상 방지

  poCtrl.style.cssText = vaCssStrBuf.join("");

  /////////////////////////////////////////////////////////////////
  // Def 구성
  var voRow = this.body.cols["center"].rows[0];

  var voCols = new Array();
  voBody = this.body;
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  var vsDef = "<Def>";
  var vsDefC = "<D Name='C' CanMove='2'/>";

  // HighGarden Modify Start
  var vsDefR = "";
  var vsDefF = "<D Name='Fixed' ";
  var vsDefBodyRow = "<D Name='R' Calculated='1' ";

  if(voBody.height != null) vsDefF = vsDefF + "Height='" + voBody.height + "' ";
  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      if(voCols[i].rows.length > 1) { new Error("GridEx' body.cols have one row"); return; }
      for(j=0; voCols[i].rows.length>j; j++) {
        var voRow = voCols[i].rows[j];
        var voColumn = null;
        for(k=0; voRow.columns.length>k; k++) {
          voColumn = voRow.columns[k];

          if(voColumn.type != null) {
            if(voColumn.colId == this.cfg.idColumn) {
              voColumn.colId = 'id';
              voColumn.canEdit = 0;
            }
            vsDefF = vsDefF + voColumn.colId + "Type='Text' "; //Fixed Row Def

            if(voColumn.type == "Image") vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Type='Img'";
            else if(voColumn.type == "Radio" || voColumn.type == "CheckBox") vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Type='Radio'";
            else if(voColumn.type == "Lines") vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Type='Lines'";
            else if(!!this.colTypeDefine && !!this.colTypeDefine[voColumn.colId]){
              //사용자 정의 속성에 colTypeDefine 가 있으면 해당 컬럼을 Lines로 바꿔
              //주기 위해서 추가. 현재 eXria 의 그리드에서 Lines를 지원 안해서
              //이화여대 요청을 반영하기 위해서 추가
              if(this.colTypeDefine[voColumn.colId] === 'Lines') vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Type='" + this.colTypeDefine[voColumn.colId] + "'";
            }
            else vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Type='" + voColumn.type + "'";

            if(voColumn.type == "Enum") {
              this.enumColList.add(voColumn);
              var voItemGData = voColumn.itemgroup.data;
              voItemGData.control = this;
              if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
                voColumn.itemgroup.addToItemset();
              }
              var vsValues = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
              var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);
              vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Enum='" + vsLabels + "'" + " " + voColumn.colId + "EnumKeys='" + vsValues + "'";
            }
            if(voColumn.type == "Select") {
              var voItemGData = voColumn.itemgroup.data;
              voItemGData.control = this;
              if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
                voColumn.itemgroup.addToItemset();
              }
              voValue = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
              var vsDefaults = " " + voColumn.colId + "Defaults='" + voValue + "'";
              vsDefBodyRow = vsDefBodyRow + vsDefaults;
            }
            // HighGarden Add Start
            if(voColumn.type == "Radio" || voColumn.type == "CheckBox") {
              vsDefF = vsDefF + voColumn.colId + "Enum='|' "; //Fixed Row Def
              if(voColumn.formatMask == null) voColumn.formatMask = new eXria.controls.xhtml.GridEx.FormatMask(voColumn, this);

              var voItemGData = voColumn.itemgroup.data;
              voItemGData.control = this;
              if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
                voColumn.itemgroup.addToItemset();
              }
              var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);
              vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Enum='" + vsLabels + "'";
              if(voColumn.type == "CheckBox") vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Range='1'";
              vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Wrap='0'";
            }
            if(voColumn.type == "Date") {
              if(voColumn.dateType == null) {
                if(voColumn.mask && /ss/.test(voColumn.mask)) {
                  voColumn.dateType = "DateTime";
                  voColumn.maxLength = 14;
                } else {
                  voColumn.dateType = "Date";
                  voColumn.maxLength = 8;
                }
              }
              if(voColumn.format === null) voColumn.format = "yyyy-MM-dd";
              if(!voColumn.calendarEnable) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Button='None'";
            }
            // HighGarden Add End
          }
          //Highgarden Start 090407
          if(voColumn.format != null || voColumn.mask != null) {
            vsDefF = vsDefF + voColumn.colId + "Format='' " + voColumn.colId + "ResultMask='' "; //Fixed Row Def
            if(voColumn.formatMask == null) voColumn.formatMask = new eXria.controls.xhtml.GridEx.FormatMask(voColumn, this);
            var vsFormat = voColumn.format;
            if(vsFormat && vsFormat.indexOf("TG:") == 0) {
              voColumn.regFormat = vsFormat.replace(/^TG:/, "");
            }
            var vsMask = voColumn.mask;
            if(vsMask && vsMask.indexOf("TG:") == 0) {
              voColumn.regMask = vsMask.replace(/^TG:/, "");
            }
            vsDefBodyRow = vsDefBodyRow + voColumn.formatMask.createFormatAndMask(voColumn);
          }
          //Highgarden End 090407
          if(voColumn.textAlign != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Align='" + voColumn.textAlign + "' ";
          //userAttr 를 통한 각 셀마다 커서 정의 가능 13.7.23 박상찬
          if(!!this.columnCursor && !!this.columnCursor[voColumn.colId]){
            vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Cursor='"+ this.columnCursor[voColumn.colId] +"' ";
          }
          if(voColumn.enums != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Enum='" + voColumn.enums + "' ";
          if(voColumn.enumType != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "EnumType='" + voColumn.enumType + "' ";
          if(voColumn.canEdit != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "CanEdit='" + voColumn.canEdit + "' ";
          if(voColumn.mask != null && (voColumn.maxLength == null && voColumn.type == "Text")) voColumn.maxLength = voColumn.mask.length;
          else if(voColumn.mask != null && (voColumn.maxLength != null && (voColumn.type == "Int" || voColumn.type == "Float")))  voColumn.maxLength = voColumn.maxLength;
          else if(voColumn.mask == null && voColumn.type == "Date") voColumn.maxLength = 8;
          if(voColumn.maxLength != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Size='" + voColumn.maxLength + "' ";
          if(voColumn.maxByteLength != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "ByteSize='" + voColumn.maxByteLength + "' ";
          if(voColumn.formula != null){
            voColumn.formula = voColumn.formula.split("\"").join("'");
            vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Formula=\"" + voColumn.formula + "\" ";
          }
          if(voColumn.rightButton != null) {
            this.rgtBtnList.add(voColumn);
            voRButton = voColumn.rightButton;

            if(voRButton.type == "Defaults") {
              if(vsRButton != "Enum" && vsRButton != "Select" && vsRButton != "Radio" && vsRButton != "List") {
                var voItemGData = voColumn.itemgroup.data;
                voItemGData.control = this;
                if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
                  voColumn.itemgroup.addToItemset();
                }
                voValue = voColumn.itemgroup.getItemValuesToString('|');
                vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Defaults='" + voValue + "'";
              }
            }
          }

          // 조영진 추가코드
          if(voColumn.backgroundColor != null) vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Color='" + this.getRGBValue(voColumn.backgroundColor) + "' ";
          if(voColumn.className != null){
            vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "ClassInner='" + voColumn.className + "' ";
            vsDefF = vsDefF + " " + voColumn.colId + "ClassInner='' ";
          }
          if(voColumn.outerClassName != null){
            vsDefBodyRow = vsDefBodyRow + " " + voColumn.colId + "Class='" + voColumn.outerClassName + "' ";
            vsDefF = vsDefF + " " + voColumn.colId + "Class='' ";
          }
          // HighGarden Modify End
        }
      }
    }
  }
  vsDefF = vsDefF + "/>"; // Fixed Row Def
  vsDefBodyRow = vsDefBodyRow + "/>";

  vsDef = vsDef + vsDefC + vsDefR + vsDefF + vsDefBodyRow;
  var vsDefG = "<D Name='Group' Calculated='1' ";
  var vaDefGCalcCol = new Array();
  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      if(voCols[i].rows.length > 1) { new Error("GridEx' body.cols have one row"); return; }
      for(var j=0, jl=voCols[i].rows.length; jl>j; j++) {
        var voRow = voCols[i].rows[j];
        var voColumn = null;
        for(var k=0, kl=voRow.columns.length; kl>k; k++) {
          voColumn = voRow.columns[k];
          if(voColumn.groupFormula) {
            voColumn.groupFormula = voColumn.groupFormula.split("\"").join("'");
            vaDefGCalcCol.push(voColumn.colId);
            vsDefG = vsDefG + voColumn.colId + "Formula=\"" + voColumn.groupFormula + "\" ";
          }
          if(voColumn.groupFormat) vsDefG = vsDefG + voColumn.colId + "Format='" + voColumn.groupFormat + "' ";
        }
      }
    }
  }
  var vsDefGCalc = "CalcOrder='";
  vsDefGCalc = vsDefGCalc + vaDefGCalcCol.join(",");
  vsDefGCalc = vsDefGCalc + "' ";

  vsDefG = vsDefG + vsDefGCalc + "/>";
  vsDef = vsDef + vsDefG + "</Def>"; // + "<Colors Default='255,255,255'/>";
  vaTemplate["Def"] = vsDef;

  /////////////////////////////////////////////////////////////////
  // LeftCols, Cols, RightCols 구성
  var voCols = new Array();
  var voBody = this.body;

  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];
  var vsCols = "";
  var voHideColMap = this.hideColMap;
  for(var i = 0; i < 3; i++) {
    if(voCols[i]) {
      if(i == 0) vsCols = vsCols + "<LeftCols>";
      if(i == 1) vsCols = vsCols + "<Cols>";
      if(i ==2 ) vsCols = vsCols + "<RightCols>";
      if(voCols[i].rows.length > 1) { new Error("GridEx' body.cols have one row"); return; }

      for(j=0; voCols[i].rows.length>j; j++) {
        var voRow = voCols[i].rows[j];
        var vsRow = "";
        for(k=0; voRow.columns.length>k; k++) {
          var voColumn = voRow.columns[k];

          vsColumn = "<C Spanned='1' Name='" + voColumn.colId + "' " + "Width='" + voColumn.width + "'";
          if(voHideColMap.get(voColumn.colId) != null) vsColumn += " Visible='0'";
          if(voColumn.type != null) {
            if(!!this.colTypeDefine && !!this.colTypeDefine[voColumn.colId]){
              if(this.colTypeDefine[voColumn.colId] === 'Lines') vsColumn = vsColumn + " AcceptEnters='1' Type='" + this.colTypeDefine[voColumn.colId] + "'";
            }else if(voColumn.type === "Lines"){
              vsColumn = vsColumn + " AcceptEnters='1' Type='Lines'";
            }else{
              vsColumn = vsColumn + " Type='" + voColumn.type + "'";
              if(voColumn.type != "Bool") vsColumn = vsColumn + " EmptyValue='' CanEmpty='1'";
              if(voColumn.type == "Radio" || voColumn.type == "CheckBox"){
                if(voColumn.labelPos != null && "left" === voColumn.labelPos) vsColumn = vsColumn + " RadioRight='1'";
              }
            }
          }
//        if(voColumn.textAlign != null) vsColumn = vsColumn + " TextAlign='" + voColumn.textAlign + "' "; // treeGrid 6.0에서는 cell 속성으로  변경됨
          if(voColumn.visible != null) vsColumn = vsColumn + " Visible=" + this.getXmlValue(voColumn.visible);
          if(voColumn.canSort != null) vsColumn = vsColumn + " CanSort=" + this.getXmlValue(voColumn.canSort);
          if(voColumn.canFocus != null) vsColumn = vsColumn + " CanFocus=" + this.getXmlValue(voColumn.canFocus);
          if(voColumn.canEdit != null) vsColumn = vsColumn + " CanEdit=" + this.getXmlValue(voColumn.canEdit)+ " ";
          if(voColumn.rightButton != null) {
            if(voColumn.rightButton.width  == null) voColumn.rightButton.width = 10;
            vsColumn = vsColumn + " WidthPad=\'" + voColumn.rightButton.width + "\'";
          }
          if(voColumn.className != null) vsColumn = vsColumn + " " + voColumn.colId + "ClassInner='" + voColumn.className + "' ";
          if(voColumn.outerClassName != null) vsColumn = vsColumn + " " + voColumn.colId + "Class='" + voColumn.outerClassName + "' ";

          if(voColumn.type == "Gantt") {
            vsColumn = vsColumn + " MinWidth='" + voColumn.width + "'";
            if(voColumn.ganttStart != null) vsColumn = vsColumn + " GanttStart='" + voColumn.ganttStart + "'";
            if(voColumn.ganttEnd != null) vsColumn = vsColumn + " GanttEnd='" + voColumn.ganttEnd + "'";
            if(voColumn.ganttComplete != null) vsColumn = vsColumn + " GanttComplete='" + voColumn.ganttComplete + "'";
            if(voColumn.ganttTooltipText != null) vsColumn = vsColumn + " GanttText='" + voColumn.ganttTooltipText + "'";
            if(voColumn.ganttDependencies != null) vsColumn = vsColumn + " GanttDescendants='" + voColumn.ganttDependencies + "'";
            if(voColumn.ganttDependencyTypes != null) vsColumn = vsColumn + " GanttDescendants='" + voColumn.ganttDependencyTypes + "'";
            if(voColumn.ganttUnits != null) vsColumn = vsColumn + " GanttUnits='" + voColumn.ganttUnits + "'";
            if(voColumn.ganttTrimUnits != null) vsColumn = vsColumn + " GanttChartRound='" + voColumn.ganttTrimUnits + "'";
            if(voColumn.ganttEditMain || voColumn.ganttEditDependency || voColumn.ganttEditResources || voColumn.ganttStart) {
              var vsEdit = "";
              if(voColumn.ganttEditMain) vsEdit = "Main";
              if(vsEdit != "") { if(voColumn.ganttEditDependency) vsEdit = vsEdit + "," + "Dependency";
              } else { if(voColumn.ganttEditDependency) vsEdit = "Dependency"; }
              if(vsEdit != "") { if(voColumn.ganttEditResources) vsEdit = vsEdit + "," + "Resources";
              } else { if(voColumn.ganttEditResources) vsEdit = "Resources";}
              vsColumn = vsColumn + " GanttEdit='" + vsEdit + "'";
//              vsColumn = vsColumn + " GanttEdit='All'";
            }
            var voObj = this.ganttFlagObj;
            if(voObj) {
              if(voObj.flagTag) {
                voObj.data = new eXria.controls.DataRefNodeset(this);
                var voData = voObj.data;
                voData.setNodesetRef(voObj.instanceId, voObj.nodeset);
                var voCollectionNode = voData.getNodesetData2();
                if (voCollectionNode && voCollectionNode.getLength() > 0) {
                  var vnLoop = voCollectionNode.getLength();
                  var voItem = null;
                  var voValueNode = null;
                  var vaFlag = [];
                  var vaText = [];
                  var vaIcons = [];
                  var vsFlag = null;
                  var vsText = null;
                  for ( var l = 0; l < vnLoop; l++) {
                    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(l));
                    vsFlag = String(voMapNode.get(voObj.flagTag));
                    if(vsFlag == null || vsFlag == "") break;
                    vsTemp = parseInt(vsFlag.substring(4,6));
                    vsTemp += "/" + parseInt(vsFlag.substring(6));
                    vsTemp += "/" + vsFlag.substring(0,4)
                    if(voObj.textTag) {
                      vsText = voMapNode.get(voObj.textTag);
                    } else {
                      vsText = vsTemp;
                    }
                    vaFlag.push(vsTemp);
                    vaText.push(vsText);
                    vaIcons.push(voObj.icon)
                  }
                  voColumn.ganttFlags = vaFlag.join(";");
                  vsColumn = vsColumn + " GanttMark='" + voColumn.ganttFlags + "'";
                  voColumn.ganttFlagTexts = vaText.join(";");
                  voColumn.ganttFlagIcons = vaIcons.join(";");
                }
              }
              if(voObj.todayIcon) {
                var voDate = new Date();
                vsDate = (voDate.getMonth() + 1) + "/" + voDate.getDate() + "/" + voDate.getFullYear();
                vsColumn = vsColumn + " GanttFlags='" + vsDate + "'";
                vsColumn = vsColumn + " GanttFlagTexts='today'";
                vsColumn = vsColumn + " GanttFlagIcons='"+ voObj.todayIcon + "'";
              }
            }

            if(voColumn.ganttBackground != null) vsColumn = vsColumn + " GanttBackground='" + voColumn.ganttBackground + "'";
            if(voColumn.ganttBackgroundRepeat != null) vsColumn = vsColumn + " GanttBackgroundRepeat='" + voColumn.ganttBackgroundRepeat + "'";
            if(voColumn.ganttResources != null) vsColumn = vsColumn + " GanttResources='" + voColumn.ganttResources + "'";
            if(voColumn.ganttUnitWidth != null) vsColumn = vsColumn + " GanttWidth='" + voColumn.ganttUnitWidth + "'";
            if(voColumn.ganttClass != null) vsColumn = vsColumn + " GanttClass='" + voColumn.ganttClass + "'";

            var voHeadCols = null;
            if(i == 0) voHeadCols = this.header.cols["left"];
            if(i == 1) voHeadCols = this.header.cols["center"];
            if(i == 2) voHeadCols = this.header.cols["right"];
            var voHeadColumn = voHeadCols.rows[j].columns[k];

            if(voHeadColumn.ganttHeader1 != null) vsColumn = vsColumn + " GanttHeader1='" + voHeadColumn.ganttHeader1 + "'";
            if(voHeadColumn.ganttHeader2 != null) vsColumn = vsColumn + " GanttHeader2='" + voHeadColumn.ganttHeader2 + "'";
            if(voHeadColumn.ganttHeader3 != null) vsColumn = vsColumn + " GanttHeader3='" + voHeadColumn.ganttHeader3 + "'";
            if(voHeadColumn.ganttHeader4 != null) vsColumn = vsColumn + " GanttHeader4='" + voHeadColumn.ganttHeader4 + "'";
            if(voHeadColumn.ganttHeader5 != null) vsColumn = vsColumn + " GanttHeader5='" + voHeadColumn.ganttHeader5 + "'";
            if(voHeadColumn.ganttFormat1 != null) vsColumn = vsColumn + " GanttFormat1='" + voHeadColumn.ganttFormat1 + "'";
            if(voHeadColumn.ganttFormat2 != null) vsColumn = vsColumn + " GanttFormat2='" + voHeadColumn.ganttFormat2 + "'";
            if(voHeadColumn.ganttFormat3 != null) vsColumn = vsColumn + " GanttFormat3='" + voHeadColumn.ganttFormat3 + "'";
            if(voHeadColumn.ganttFormat4 != null) vsColumn = vsColumn + " GanttFormat4='" + voHeadColumn.ganttFormat4 + "'";
            if(voHeadColumn.ganttFormat5 != null) vsColumn = vsColumn + " GanttFormat5='" + voHeadColumn.ganttFormat5 + "'";
          }

          vsColumn = vsColumn + "/>";
          var vsRow = vsRow + vsColumn;
        }
        vsCols = vsCols + vsRow;
      }
      if(i==0) vsCols = vsCols + "</LeftCols>";
      if(i==1) vsCols = vsCols + "</Cols>";
      if(i==2) vsCols = vsCols + "</RightCols>";
    }
  }
  vaTemplate["Cols"] = vsCols;

  // yhkim 2009.05.25 헤더포맷 수정
  vaTemplate["Header"] = this.getHeaderFormat();
  var vnSorting = this.cfg.sorting;
  if(vnSorting) vnSorting = 1;
  else vnSorting = 0;
  vaTemplate["Cfg"] = vaTemplate["Cfg"].replace(/ Sorting\=\"[01]*\"/g, " Sorting=\"" + vnSorting + "\"");

  vaTemplate = null;

  this.makeLayout();
};
/**
 * 헤더 구조를 정의하는 문자열을 얻어오는 메소드
 * @type String
 * @return 헤더 구조를 정의하는 문자열
 */
eXria.controls.xhtml.GridEx.prototype.getHeaderFormat = function(){
  // header.cols로 부터 Header 구성
  var voCols = new Array();
  voCols[0] = this.header.cols["left"];
  voCols[1] = this.header.cols["center"];
  voCols[2] = this.header.cols["right"];

  var vsTitle, vsColumnText = "";
  var vaHeader = [];
  var vaMainCols = [[], [], []];
  // yhkim 2009.05.19 head 컬럼
  var voColumn = null;

  for ( var i = 0; i < 3; i++) {
    if (voCols[i] && !!voCols[i].rows[0].columns.length){
      for ( var j = 0; voCols[i].rows.length > j; j++) {
        var voRow = voCols[i].rows[j];

        for ( var k = 0; voRow.columns.length > k; k++){
          voColumn = voRow.columns[k];
          if(voColumn == null) continue;
          if(voColumn.id == this.cfg.idColumn) {
            voColumn.id = "id";  // id 칼럼에 대한 처리
            break;
          }
        }
      }
      break;
    }
  }

  if (this.header.mainRow == null)  this.header.mainRow = 0;
  for ( var i = 0; i < 3; i++) {
    if (voCols[i]) {
      for ( var j = 0; voCols[i].rows.length > j; j++) {
        if(this.header.mainRow != j) continue;
        var voRow = voCols[i].rows[j];

        for ( var k = 0; voRow.columns.length > k; k++) {
          voColumn = voRow.columns[k];
          if(voColumn instanceof eXria.controls.xhtml.GridEx.FunctionColumn) continue;
          vaMainCols[i][k] = voColumn.id;
        }
      }
    }
  }

  for ( var i = 0; i < 3; i++) {
    if (voCols[i]) {
      for ( var j = 0; voCols[i].rows.length > j; j++) {
        var voRow = voCols[i].rows[j];
        var vsRow = "";
        if(vaHeader[j] == null) {
          vaHeader[j] = "";
         }

        var vnColIdx = 0;
        var vnColSpan = null;
        var vnRowSpan = null;
        var voRowSpans = null;
        var vsCol = null;
        if(this.hRowSpans) voRowSpans = this.hRowSpans[j];
        for ( var k = 0; voRow.columns.length > k; k++) {
          var vsAlign = "";
          vsColumnText = "";
          voColumn = voRow.columns[k];
          vsCol = vaMainCols[i][vnColIdx];

          if(voColumn instanceof eXria.controls.xhtml.GridEx.FunctionColumn) {
            vnColIdx += voColumn.colspan;
            continue;
          }
          if (voColumn.instanceId && voColumn.ref) {
            var voNode = null, voNodeValue = "";
            voColumn.data.instanceId = voColumn.instanceId;
            voColumn.data.instancePath = voColumn.ref;
            voNode = voColumn.data.getNodeData();
            if (voNode) {
              voNodeValue = voNode.getValue();
              voColumn.value = voNodeValue;
            } else {
              voColumn.value = "";
            }
          }
          vsColumnText = voColumn.value;
          if(vsColumnText == null) vsColumnText = "";
          vsTitle = vsCol + "='" + vsColumnText + "'";
          if(this.header.mainRow != j && vsColumnText == "") vsTitle += " " + vsCol + "Visible=\"-1\"";
          else if(this.header.mainRow != j) vsTitle += " " + vsCol + "Button=\"\"";

          vsRow = vsRow + vsTitle;
          if (voColumn.textAlign == "left")
            vsAlign = " " + vsCol + "Align='0'";
          if (voColumn.textAlign == "center")
            vsAlign = " " + vsCol + "Align='1'";
          if (voColumn.textAlign == "right")
            vsAlign = " " + vsCol + "Align='2'";

          vsRow = vsRow + vsAlign;
          if(voColumn.className != null) vsRow = vsRow + " " + vsCol + "Class=\"" + voColumn.className + "\"";
          if(voColumn.hoverClassName != null) vsRow = vsRow + " " + vsCol + "ClassOuterHover=\"" + voColumn.hoverClassName + "\"";
          vnColspan = voColumn.colspan;
          if(vnColspan == null) vnColspan = 1;
          if(vnColspan != 1) {
            vsRow = vsRow + " " + vsCol + "Span=" + this.getXmlValue(vnColspan);
          }
          if(voRowSpans) {
            vnRowSpan = voRowSpans[vsCol == "id" ? this.cfg.idColumn : vsCol];
            if(vnRowSpan == null) vnRowSpan = 1;
            if(vnRowSpan != 1) {
              vsRow = vsRow + " " + vsCol + "RowSpan=" + this.getXmlValue(vnRowSpan);
            }
          }
          vnColIdx += vnColspan;
        }
        vaHeader[j] += vsRow;
      }
    }
  }

  var vnSize = vaHeader.length;
  vsHeader = "<Head>";
  for(var i = 0; i < vnSize; i++) {
    if(vaHeader[i] == "") continue;
    vaHeader[i] = "<Header Spanned=\"1\" " + vaHeader[i];
    if(i == this.header.mainRow) {
      var vbSelect = this.panel.select;
      var vbDel = this.panel.del;
      if(this.cfg.hidePanel == false) {
        if(vbSelect == null) vbSelect = true;
        if(vbDel == null) vbDel = true;
      } else {
        if(vbSelect == null) vbSelect = false;
        if(vbDel == null) vbDel = false;
      }
      if(vbSelect) vaHeader[i] += " CanSelect=\"1\"";
      if(vbDel) vaHeader[i] += " CanDelete=\"1\"";
    }
    if(this.header.visible != null) vaHeader[i] += " Visible=" + this.getXmlValue(this.header.visible);
    vaHeader[i] += "/>";
    vsHeader += vaHeader[i];
  }
  vsHeader += "<Header id=\"Header\" Visible=\"0\"/>";
  vsHeader += "</Head>"
  return vsHeader;
};
/**
 * TreeGrid의 Format, Mask 관련 속성의 문자열 반환
 * @param {Object} psFormat Format
 * @return String
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.createFormatAndMask = function(poColumn){
  var vsFormat = poColumn.format;
  var vsMask = poColumn.mask;
  var vsType = poColumn.type;
  var vaRegExp = {"x": "A-Za-z", "#": "0-9", "*": "A-Za-z0-9" };
  var vsEditFormat = "", vsEditMask = "", vsResultMask = "", vsRet = "";

  if(!vsFormat && vsMask) vsFormat = vsMask;
  if(!vsFormat && vsType=="Date") vsFormat = "yyyy-MM-dd";
  if(!vsMask && vsType=="Date") vsMask = "yyyyMMdd";
  switch(vsType){
    case "Int" :
    case "Float" :
//      if(vsMask.lastIndexOf(".")){ vsMask = vsMask.replace(vsMask.charAt(vsMask.lastIndexOf(".")-1), "0"); }
      if(vsMask){
        vsEditMask = "^[0-9]*\\.*[0-9]*$";
        vsResultMask = "^[0-9]*\\.*[0-9]*$";
      }
      break;
    case "Text" :
    case "Lines" :
      if(vsMask){
        var vsNoFormat = vsFormat.replace(/[^\#\x\*]/g, "");
        vsEditMask = "^";

        //문자가 일치하는 마지막 index를 리턴
        var getLastIndex = function(pnIndex){
          if(pnIndex > vsNoFormat.length) return vsNoFormat.length;
          if(vsNoFormat.charAt(pnIndex) == vsNoFormat.charAt(pnIndex + 1)) pnIndex = getLastIndex(pnIndex + 1);
          return pnIndex;
        }

        //editmask 생성
        var getEditMask = function(pnIndex){
          if(!pnIndex) pnIndex = 0;
          var vnStartIdx = pnIndex;
          var vnLastIdx = getLastIndex(pnIndex);
          var vnCnt = vnLastIdx + 1 - vnStartIdx;

          vsEditMask = vsEditMask + "[" + vaRegExp[vsNoFormat.charAt(pnIndex)] + "]{" + 0 + "," + vnCnt + "}";
          if(vsNoFormat.charAt(vnLastIdx + 1)) vsEditMask = getEditMask(vnLastIdx + 1);
          return vsEditMask;
        }

        //resultmask 생성
        var getResultMask = function(pnIndex){
          if(!pnIndex) pnIndex = 0;
          var vnStartIdx = pnIndex;
          var vnLastIdx = getLastIndex(pnIndex);
          var vnCnt = vnLastIdx + 1 - vnStartIdx;

          vsResultMask = vsResultMask + "[" + vaRegExp[vsNoFormat.charAt(pnIndex)] + "]{" + vnCnt + "}";
          if(vsNoFormat.charAt(vnLastIdx + 1)) vsResultMask = getResultMask(vnLastIdx + 1);
          return vsResultMask;
        }

        vsEditMask = getEditMask() + "$";
        vsResultMask = getResultMask() + "$";
      }
      break;
    case "Date" :
      vsFormat = vsFormat.split("Y").join("y");
      vsFormat = vsFormat.split("D").join("d");
      vsFormat = vsFormat.split("h").join("H");

//      if(vsMask){
//        vsMask = vsMask.split("Y").join("y");
//        vsMask = vsMask.split("D").join("d");
//        vsMask = vsMask.split("h").join("H");
//        var vsNoFormat = vsMask.replace(/[^ymdhs]/gi, "");
//        vsEditMask = "^";
//        vsEditMask = vsEditMask + "[0-9]{0," + vsNoFormat.length + "}$";
//        vsResultMask = vsResultMask + "[0-9]{" + vsNoFormat.length + "}$";
//      }
      break;
    case "Radio" :
    case "CheckBox" :
      var pnFormat = 1;
      if(poColumn.displayMode){
        if(poColumn.displayMode == "horizontal") pnFormat -= 1;
        else if(poColumn.displayMode == "vertical") pnFormat += 1;
      }
      if(poColumn.labelPos == "left") pnFormat += 4;
      if(poColumn.type == "CheckBox") pnFormat = pnFormat + 8 + 16 + 32;

      vsFormat = "|" + pnFormat + "|||||";
      return vsFormat;
      break;
  }
  var vsRet = "";
  if(vsFormat) vsRet = vsRet + " Format='" + vsFormat + "'";
  if(vsMask) vsRet = vsRet + " EditFormat='" + vsMask + "'";
  return  vsRet;
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  voEvent.object = poControl;

  //FF에서 voEvent.target 이 undefined 로 넘어옴
  if(!!voEvent.target)
  voEvent.target.id = "GridEx";

  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  if(vsType == "mousedown" || vsType == "mouseup") return;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsEventCallback = vsType + "EventCallback";
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;

  switch(vsType) {
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }

  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if(poControl[vsEventCallback]) { poControl[vsEventCallback](voEvent); }
  if(poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }

  switch(vsType) {
  case "keydown" :
  case "keyup" :
  case "mousemove" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};

eXria.controls.xhtml.GridEx.prototype.setSpecificEvents = function(poCtrl) {
  var base = this;

  this.enGridexColResize = function(poGrid, psCol) {
    var voCols = new Array();
    var voBodyCols = new Array();
    var voHeader = this.header;
    var voBody = this.body;

    voCols[0] = voHeader.cols["left"];
    voCols[1] = voHeader.cols["center"];
    voCols[2] = voHeader.cols["right"];
    voBodyCols[0] = voBody.cols["left"];
    voBodyCols[1] = voBody.cols["center"];
    voBodyCols[2] = voBody.cols["right"];

    var nColLen = 0;
    for(var i=0; i<3; i++) {
      if(voCols[i]) {
        voRow = voCols[i].rows[0];
      if(voRow && voRow.columns) {
        for(var j=0; j<voRow.columns.length; j++) {
            voColumn = voRow.columns[j];
        // 비교는 헤더컬럼과 비교해도 값은 바디 컬럼에 설정해야한다
        if(voColumn.id === psCol) {
          voBodyCols[i].rows[0].columns[j].width =  this.grid.Cols[psCol].Width;
        }
        }
      }
      }
    }
  }
  // 내부 그리드 컨트롤의 OnClick 발생 시 호출되는 이벤트  (pbIgnored는 항상 false 임)
  /**
   * @ignore
   */
  this.enGridexClick = function(poGrid, poRow, psCol, pnX, pnY, poEvent) {
    // yhkim 2009.08.19 (pageSelectAll) 리턴값 지정
    var ret = false;
    if(poGrid) {
      base.selectedIndexes = base.getSelectedIndexes();
      if(base.selectedIndexes) {
        base.clearDataSetRowKeyValue("selected__RowIndex");
        base.setDataSetRowKeyValue("selected__RowIndex", "U");
      }
      base.focusRow = base.grid.FRow;
      base.focusCol = base.grid.FCol;
      if(base.grid.FRow && base.grid.FCol) {
        base.clearDataSetRowKeyValue("focus__RowIndex");
        if(base.focusCol == null) base.focusCol = psCol;
        base.setDataSetRowKeyValue("focus__RowIndex", base.focusCol);
      }
      base.focusPagePos  = base.grid.FPagePos;
        // yjcho 2009.09.21 헤더를 선택하여 sort 수행 시 디폴트 row 선택이 일어나지 않도록 조치
  //      if(poRow && poRow.id == "Header") {
  //        var voBodyCol = null;
  //        if(psCol) voBodyCol = this.getBodyColumn(null, psCol);
  //        if(voBodyCol && voBodyCol.canSort != false) {
  //          this.grid.FRow = null;
  //          this.grid.FCol = null;
  //        }
  //      }
      vaSelRows = poGrid.GetSelRows();
      var vnSize = 0;
      if(vaSelRows) vnSize = vaSelRows.length;
      if (psCol != "Panel") {                    // Panel이 아닐경우
        if (base.cfg.multiSelect == false) {
          for(var i=0; i < vnSize; i++){
            poGrid.SelectRow(vaSelRows[i]);
          }
          if(poEvent.shiftKey) {
            poGrid.SelectRow(poRow);
            ret = true;
          }
        } else {
          if(psCol && (base.cfg.keepSelecting != true)) {
            if (!poEvent.ctrlKey){
              for(var i=0; i < vnSize; i++){
                poGrid.SelectRow(vaSelRows[i]);
              }
            }
            if (poRow.Kind != "Header") base.clearDataSetRowKeyValue("selected__RowIndex");
          }
        }

      } else {                                                // Panel일 경우
        if (poRow.Kind != "Header") {                         // Panel 헤더가 아닐경우
          if (base.cfg.multiSelect == false) {
            for(var i=0; i < vaSelRows.length; i++){
              poGrid.SelectRow(vaSelRows[i]);
            }
          }
        } else {                                               // Panel 해더일 경우
          if (base.cfg.multiSelect == false) {
            for(var i=0; i < vnSize; i++){
              poGrid.SelectRow(vaSelRows[i]);
            }
            ret = true;
          } else {
            if(base.cfg.pageSelectAll == true && base.cfg.paging == "fast") {
              if(base.pageSelectAllChecked == true) base.pageSelectAllChecked = false;
              else base.pageSelectAllChecked = true;
              base.enGridexSelectAll();
              base.setPageSelection();
              ret = true;
            }
          }
        }

      }

      base.resetEvent();
      var voEvent = base.event;
      voEvent.object = base;
      voEvent.row = poRow;
      voEvent.colId = psCol;
      voEvent.x = pnX;
      voEvent.y = pnY;
      voEvent.e = poEvent;
    }

    if(base.onGridexClick && poRow && psCol) ret = base.onGridexClick(voEvent);
    if(poRow && psCol) {
      base.runEvent(poEvent, base);   // 기본 이벤트를 전파함
    }

    return ret;
  };
  /**
   * @ignore
   */
  this.enGridexMouseDown = function(poEvent) {
    base.runEvent(poEvent, base);   // 기본 이벤트를 전파함
  };
  /**
   * @ignore
   */
  this.enGridexMouseMove = function(poEvent) {
    base.runEvent(poEvent, base);   // 기본 이벤트를 전파함
  };
  /**
   * @ignore
   */
  this.enGridexMouseUp = function(poGrid, poRow, psCol, pnX, pnY, poEvent) {
    //컨텍스트 메뉴를 refresh(display 표시) 하는 순간 firefox에서는 이벤트 발생이 끊기고 focus가 작동안함
    //따라서 UIControl의 finalmouseup을 호출하지 않도록 처리
    if(base["on" + poEvent.type]) base["on" + poEvent.type](poEvent);
  };
  /**
   * @ignore
   */
  this.enGridexMouseOut = function(poEvent) {
    base.runEvent(poEvent, base);   // 기본 이벤트를 전파함
  };
  // 내부 그리드 컨트롤의 OnDblClick 발생 시 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexDblClick = function(poGrid, poRow, psCol, pnX, pnY, poEvent) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    voEvent.x = pnX;
    voEvent.y = pnY;
    voEvent.e = poEvent;
    if(this.onGridexDblClick) return this.onGridexDblClick(voEvent);
    this.runEvent(poEvent, this);   // 기본 이벤트를 전파함
  };
  /**
   * @ignore
   */
  this.enGridexRightClick = function(poGrid, poRow, psCol, pnX, pnY, poEvent) {
    base.showContextMenu(poEvent.clientX, poEvent.clientY);
    base.event.object = base;
    base.event.type = null;
    base.event.row = poRow;
    base.event.beforeRow = null;
    base.event.colId = psCol;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = pnX;
    base.event.y = pnY;
    base.event.key = null;
    base.event.value = null;
    base.event.e = poEvent;
    if(base.onGridexRightClick) return base.onGridexRightClick(base.event);
    base.runEvent(poEvent, base);   // 기본 이벤트를 전파함
    base.grid.Focus(base.focusRow, base.focusCol, base.focusPagePos);
  };
  /**
   * @ignore
   */
  this.enGridexKeyDown = function(poGrid, pcKey, poEvent, pnKeyCodes, psPrefix) {
    base.event.object = base;
    base.event.type = null;
    base.event.row = null;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColid = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = pcKey;
    base.event.value = null;
    base.event.e = poEvent;
    if(base.onGridexKeyDown) base.onGridexKeyDown(base.event);
  };
  // 내부 그리드 컨트롤의 OnFocus 발생 시 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexFocus = function(poGrid, poRow, psCol, poBeforeRow, psBeforeCol, pnfocusPagePos ) {
    base.focusRow = poRow;
    base.focusCol = psCol;
    base.focusPagePos = pnfocusPagePos ;

    base.event.object = base;
    base.event.type = null;
    base.event.row = poRow;
    base.event.beforeRow = poBeforeRow;
    base.event.colId = psCol;
    base.event.beforeColId = psBeforeCol;
    base.event.pagePos = pnfocusPagePos ;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(this.onGridexFocus && !this.noFocusEvent) this.onGridexFocus(this.event);
    if(this.GridexFocusEventCallback && !this.noFocusEvent) this.GridexFocusEventCallback(this.event);
    if(poRow != poBeforeRow) {
      if(this.onGridexFocusRowChange && !this.noFocusEvent) this.onGridexFocusRowChange(this.event);
      if(this.GridexFocusRowChangeEventCallback && !this.noFocusEvent) this.GridexFocusRowChangeEventCallback(this.event);
    }
  };
  // 내부 그리드 컨트롤의 OnSelect 발생 시 호출되는 이벤트 (pnType = 0이면 select, 1이면 unselect, 2이면 change)
  /**
   * @ignore
   */
  this.enGridexSelect = function(poGrid, poRow, pnType) {
    var voRow = base.grid.FRow;

    // yhkim 2009.05.11 multiSelect 관련
    /*
    if(voRow) {
      base.grid.Focus(null, null);
      base.grid.SelectRow(voRow);
    }
    */

    base.event.object = base;
    base.event.type = pnType;
    base.event.row = poRow;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(base.onGridexSelect) base.onGridexSelect(base.event);
  };
  /**
   * @ignore
   */
  this.enGridExDelRow = function(G, poRow){
    base.event.object = base;
    base.event.type = null;
    base.event.row = poRow;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(base.onGridexDelRow) base.onGridexDelRow(base.event);
  };

  //Studio 추가 필요
  /**
   * @ignore
   */
  this.enGridexMarkDelRow = function(poGrid, poRow, pnType) {
    base.event.object = base;
    base.event.type = pnType;
    base.event.row = poRow;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    // 2009.07.15 yhkim markdel관련 dataset 상태 바꾸기
    base.SetMarkDelStatus(poRow, true);
    if(base.onGridexMarkDelRow) base.onGridexMarkDelRow(base.event);
  };

  this.enGridexUnMarkDelRow = function(poGrid, poRow) {
    base.event.object = base;
    base.event.row = poRow;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColid = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    // 2009.07.15 yhkim markdel관련 dataset 상태 바꾸기
    base.SetMarkDelStatus(poRow, false);
    if(base.onGridexUnMarkDelRow) base.onGridexUnMarkDelRow(base.event);
  };

  // 2009.06.16 yhkim
  /**
   * @ignore
   */
  this.enGridexAddRow = function(G, poRow) {
    base.event.object = base;
    base.event.type = null;
    base.event.row = poRow;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(base.onGridexAddRow) base.onGridexAddRow(base.event);
  };

  // 2009.06.16 yhkim
  /**
   * @ignore
   */
  this.enGridexPrint = function(G, poWindow) {
    base.event.object = base;
    base.event.type = null;
    base.event.row = null;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(base.onGridexPrint) base.onGridexPrint(base.event);
  };

  // 2009.06.16 yhkim
  /**
   * @ignore
   */
  this.enGridexPrintFinish = function(G, poWindow) {
    base.event.object = base;
    base.event.type = null;
    base.event.row = null;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(base.onGridexPrintFinish) base.onGridexPrintFinish(base.event);
  };

//내부 그리드 컨트롤의 OnRenderFinish 발생 시 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexRenderStart = function() {
    if(base.cfg.paging === "fast") this.pageCountWithFastMode = 0;
    base.event.object = base;
    base.event.type = null;
    base.event.row = null;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos  = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    if(base.onGridexRenderStart) base.onGridexRenderStart(base.event);
  };
  
  /**
   * @ignore
   */
  this.enGridexLoaded = function(poGrid) {
    base.event.object = base;
    base.event.type = null;
    base.event.row = null;
    base.event.beforeRow = null;
    base.event.colId = null;
    base.event.beforeColId = null;
    base.event.pagePos = null;
    base.event.x = null;
    base.event.y = null;
    base.event.key = null;
    base.event.value = null;
    base.event.e = null;
    //if(base.onGridexLoaded) base.onGridexLoaded(base);
    if (base.onGridexLoaded) base.onGridexLoaded(base.event);
  };
  
  // 내부 그리드 컨트롤의 OnRenderFinish 발생 시 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexRenderFinish  = function(poGrid) {
    function voFunc() {
      base.grid.OnCanRowAdd = function(){}; // onGridExPasteRow 이후 TreeGird의 로직 수행 방지 (이 이벤트 등록시 Row Add 수행안함)

      base.rendering = false;
      base.setDisable(base.getCtrl(), base.disabled);
      base.resetEvent();
      var voEvent = base.event;
      voEvent.object = base;
      if(base.onGridexRenderFinish) base.onGridexRenderFinish(voEvent);
      if(base.getDataRowCnt() == 0) base.enGridexRenderComplete(voEvent);
    };
    var voPage = base.canvas.page;
    if(voPage.isUnload) return;
    if(voPage.isRendered) voFunc();
    else voPage.eventQueue.push(voFunc);
  };

  // variable row 형태도 RenderFinish인경우 >> SetFocusRowIndex 호출이 가능해짐
  /**
   * @ignore
   */
  this.enGridexRenderPageFinish  = function(poRow) {
    if(this.canvas.page.isUnload) return;
    if(poRow["State"] != "4") return;
    var voGrid = this.grid;
    this.resizeTreeImg(); // 트리 이미지의 리사이징
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    if(this.onGridexRenderPageFinish) this.onGridexRenderPageFinish(voEvent);
    this.enGridexRenderComplete(voEvent);
//    if(this.onGridexRenderCompleteAll || this.GridexRenderCompleteAllEventCallback) {
    var vnRowTop = voGrid.GetRowTop(poRow);
    var vnRowHeight = voGrid.GetRowHeight(poRow);
    var vnScrollTop = voGrid.GetScrollTop();
    var vnBodyHeight = voGrid.GetBodyHeight();
    if(vnRowTop - vnScrollTop + vnRowHeight >= vnBodyHeight) {
      this.isRendered = true;
      if(this.onGridexRenderCompleteAll) this.onGridexRenderCompleteAll(voEvent);
      if(this.GridexRenderCompleteAllEventCallback) this.GridexRenderCompleteAllEventCallback(voEvent);
    }
//    }
    
    
  };

  /** 렌더링이 최종 완료시
   * @ignore
   */
  this.enGridexRenderComplete = function(voEvent) {
    var voFunc = function() {
      base.onGridexRenderComplete(voEvent);
    };
    var voPage = base.canvas.page;
    if(this.cfg.paging === "fast") {
      if(this.pageCountWithFastMode > -1) this.pageCountWithFastMode--;
      if(this.pageCountWithFastMode === 0) {
        if (base.onGridexRenderComplete) {
          if(voPage.isRendered) voFunc();
          else voPage.eventQueue.push(voFunc);
          this.runWithDataSetColumnType("focus__RowIndex");
          this.runWithDataSetColumnType("selected__RowIndex");
        }
      }
    } else {
        if (base.onGridexRenderComplete) {
          if(voPage.isRendered) voFunc();
          else voPage.eventQueue.push(voFunc);
        }
        this.runWithDataSetColumnType("focus__RowIndex");
        this.runWithDataSetColumnType("selected__RowIndex");
    }

    if(this.cfg.pageSelectAll == true && this.cfg.paging == "fast" && this.pageSelectAllChecked == true) {
      this.enGridexSelectAll();
      this.setPageSelection();
    }
    if(this.cfg.expandAll == true) this.grid.ExpandAll();
  };

  // 내부 그리드 컨트롤의 OnValueChanged 발생 시 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexValueChanged = function(poGrid, poRow, psCol, poNewValue) {
    var vsType = this.getType(poRow, psCol);
    var vsRowType = this.getRowType(poRow);

    if(vsRowType == this.RowType.BodyRow)
      voColumn = this.getBodyColumn(null, psCol);
    else if(vsRowType == this.RowType.HeadRow)
      voColumn = this.getFunctionColumn(poRow, null , psCol);
    else if(vsRowType == this.RowType.FootRow)
      voColumn = this.getFootColumn(poRow, null , psCol);

    if(vsType == "Text" && voColumn.mask) {
      poNewValue = this.getOrgValueFromMask(String(poNewValue), voColumn.mask);
    }

    if(!voColumn.mask && !!voColumn.inputMode){
      poNewValue = eXria.controls.xhtml.Util.getValueFromInputMode(String(poNewValue), voColumn.inputMode);
    }

    if(voColumn.regMask) {
      var vsType = null;
      switch(voColumn.type) {
      case "Text" :
        vsType = "string";
        break;
      case "Int" :
      case "Float" :
        vsType = "number";
        break;
      case "Date" :
        vsType = "date";
        break;
      }
      poNewValue = TGP.GetString(poNewValue, vsType, voColumn.regMask, 1);
      poNewValue = TGP.GetValueInput(poNewValue, vsType, voColumn.regMask, 1);
    }

    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    voEvent.value = poNewValue;
    if(this.onGridexValueChanged) this.onGridexValueChanged(voEvent);
    return voEvent.value;
  };

  // 내부 그리드 컨트롤의  OnAfterValueChanged 발생 시 호출되는 이벤트
  /**
   * @ignore  (pbSimple이 true일 경우에는 DataSet의 status를 변경하지 않고 단지 value만을 변경함)
   */
  this.enGridexAfterValueChanged = function(poGrid, poRow, psCol, pbSimple) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    
    // DataSet과의 데이타 동기화
    var voDataSet, voColumn, vsDatasetCol,voValue = null;
    var vnChildIdx = poRow["ChildIdx"];
    var vnRowSpan = poRow[psCol + "RowSpan"];
    if(vnRowSpan != null) vnRowSpan = eval(vnRowSpan);
    else vnRowSpan = 1;
    if(base.datasetId != null) {
      if(base.dataset) voDataSet = base.dataset;
      else voDataSet = base.canvas.page.model.getDataSet(base.datasetId);
      if(base.dataset) {
        voColumn = base.getBodyColumn(null, psCol);
        if(voColumn) {
          vsDatasetCol = voColumn.datasetCol;
          if(vnChildIdx != null) vsDatasetCol = this.childRows[vnChildIdx][psCol];
          if(vsDatasetCol == null) {
            vsDatasetCol = voColumn.ref;
            if(vsDatasetCol != null) {
              var vaPath = vsDatasetCol.split("/");
              vsDatasetCol = vaPath[vaPath.length - 1];
            }
          }
          if(vsDatasetCol) {
            var vnRowIndex = base.getIndexOfRow(poRow);
            voValue = base.grid.GetValue(poRow, psCol);
            voValue = this.convertValueExria(poRow, psCol, voValue);
            if(voValue === null) voValue = "";
            if(voColumn.type == "Int" && voValue != "") {
              if(voValue >= 0) voValue = Math.round(voValue);
              else voValue = -1 * Math.round(-1 * voValue);
            }
            var vbResult;
            if(vnRowIndex != null) {
              for(var i = 0; i < vnRowSpan; i++) {
                 vbResult = true;
                 if(pbSimple) {
                   vbResult = base.dataset.simpleSet(vnRowIndex + 1 + i, vsDatasetCol, voValue);
                 } else {
                   vbResult = base.dataset.set(vnRowIndex + 1 + i, vsDatasetCol, voValue);
                 }
                 if(!vbResult) alert("data sync error");
               }
            }
          }
        }
      }
    } else if (!!base.data.nodesetInstanceId && !!base.data.nodesetInstancePath) {
      if (base.getRowType(poRow) == base.RowType.BodyRow) {
        voColumn = base.getBodyColumn(null, psCol);
        var vnInstIdx = poRow ["InstIdx"];
        if(vnChildIdx != null) vnInstIdx = poRow.parentNode["InstIdx"];
        if (vnInstIdx == null) vnInstIdx = poRow.getAttribute("InstIdx");
        vnInstIdx = parseInt(vnInstIdx);
        var voMapNode = base.data.getNodesetData2(vnInstIdx);
        var voRowNode = null;
        
        if (!pbSimple) {
          voRowNode = voMapNode.node;
          var vsStatus = voRowNode.getUserAttribute("status");
          if (vsStatus == null) vsStatus = "";
          if (vsStatus.indexOf("U") == -1) voRowNode.setUserAttribute("status", vsStatus + "U");
        }

        var vsRef = voColumn.ref;
        if(vnChildIdx != null) vsRef = this.childRows[vnChildIdx][psCol];
        if (!!vsRef) {
          var vnRowIndex = base.getIndexOfRow(poRow);
          voValue = base.grid.GetValue(poRow, psCol);
          voValue = this.convertValueExria(poRow, psCol, voValue);
          if (voValue === null) voValue = "";
          if (voColumn.type == "Int" && voValue != "") {
            if (voValue >= 0) voValue = Math.round(voValue);
            else voValue = - 1 * Math.round(- 1 * voValue);
          }
          vsRef = vsRef.split("/");
          vsRef = vsRef [vsRef.length - 1];
          voMapNode.put(vsRef, voValue);
          for(var i = 1; i < vnRowSpan; i++) {
            voMapNode = base.data.getNodesetData2(vnInstIdx + i);
          }
        }
        //수정
        if(poRow["Changed"] == "1") {
          if(poRow["Added"] == "1") voRowNode.setUserAttribute("status", "IU");
          if(poRow["Deleted"] == "1") voRowNode.setUserAttribute("status", "D");
        } else {
          if(poRow["Deleted"] == "1") voRowNode.setUserAttribute("status", "D");
          else  {
            vsStatus = poRow["InstStatus"];
            if(vsStatus == null) vsStatus = "";
            if(vsStatus.indexOf("U") != -1) poRow["Changed"] = "1";
            voRowNode.setUserAttribute("status", vsStatus);
          }
        }
      }
    }

    //컬럼별 showTooltip 기능이 동작 되야 할때
    var vbShowTooltip = !!this.showTooltip,
        vaShowTooltip = this.showTooltip,
        vsDsColId,
        vsColId;

    if(vbShowTooltip){
      for(var z=0, vnRowCnt = vaShowTooltip.length; z < vnRowCnt; z++){
        vsDsColId = vaShowTooltip[z]['dsColId'];
        vsColId = vaShowTooltip[z]['colId'];
        if(psCol === vsColId){
          poRow[vsColId+'Tip'] = voValue.simpleReplace('\n','<br/>');
        }
      }
    };

    if(this.onGridexAfterValueChanged) this.onGridexAfterValueChanged(this.event);
    if(this.GridexAfterValueChangedEventCallback) this.GridexAfterValueChangedEventCallback(this.event);
  };

  // 내부 그리드 컨트롤의  OnButtonClick 발생 시 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexButtonClick = function(poGrid, poRow, psCol) {
    var voCol = null;
    if(poRow) {
      if(poRow.Fixed) {
        if(poRow.Fixed == "Head")
          voCol = this.getFunctionColumn(poRow, null , psCol);
        else if(poRow.Fixed == "Foot")
          voCol = this.getFootColumn(poRow, null , psCol);
      }
      else {
        voCol = this.getBodyColumn(null, psCol);
      }
    }
    if(voCol) {
      if(voCol.rightButton.enableMode == "auto" || voCol.rightButton.enableMode === null) {
        var vbEdit = Get(poRow, psCol + "CanEdit");
        if(vbEdit === 0 || vbEdit === false)
          return;
      }
      else if(voCol.rightButton.enableMode == "disabled")
        return;
      // enabled는 해줄게 없다
    }
    
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    if(this.onGridexButtonClick) this.onGridexButtonClick(voEvent);
  };
  // GridEx에 Paste시 발생하는 이벤트
  /**
   * @ignore
   */
  this.enGridexPasteRow = function(poRow, paCols, paValues, pbAdded){
    var vbRet = false;
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = paCols;
    voEvent.pastedtext = paValues;
    if(this.onGridexPasteRow) vbRet = this.onGridexPasteRow(voEvent);
    return vbRet;
  };
  /**
   * @ignore
   */
  this.enGridexPasteRowFinish = function(poRow, paCols, paValues, pbAdded){
    // DataSet과의 데이타 동기화
    var voDataSet, vsCol, voColumn, vsDatasetCol, vnRowPan, voValue = null;
    var vnChildIdx = poRow["ChildIdx"];
    var vnSize = paValues.length;
    if(this.datasetId != null) {
      if(this.dataset) voDataSet = this.dataset;
      else voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
      if(this.dataset) {
        for(var i = 0; i < vnSize; i++) {
          vsCol = paCols[i];
          vnRowSpan = poRow[vsCol + "RowSpan"];
          if(vnRowSpan != null) vnRowSpan = eval(vnRowSpan);
          else vnRowSpan = 1;
          voColumn = base.getBodyColumn(null, vsCol);
          if(voColumn) {
            vsDatasetCol = voColumn.datasetCol;
            if(vnChildIdx != null) vsDatasetCol = this.childRows[vnChildIdx][vsCol];
            if(vsDatasetCol == null) {
              vsDatasetCol = voColumn.ref;
              if(vsDatasetCol != null) {
                var vaPath = vsDatasetCol.split("/");
                vsDatasetCol = vaPath[vaPath.length - 1];
              }
            }
            if(vsDatasetCol) {
              var vnRowIndex = this.getIndexOfRow(poRow);
              voValue = this.grid.GetValue(poRow, vsCol);
              voValue = this.convertValueExria(poRow, vsCol, voValue);
              if(voValue === null) voValue = "";
              if(voColumn.type == "Int" && voValue != "") {
                if(voValue >= 0) voValue = Math.round(voValue);
                else voValue = -1 * Math.round(-1 * voValue);
              }
              var vbResult;
              if(vnRowIndex != null) {
                for(var j = 0; j < vnRowSpan; j++) {
                   vbResult = true;
                   vbResult = this.dataset.set(vnRowIndex + 1 + j, vsDatasetCol, voValue);
                   if(!vbResult) alert("data sync error");
                 }
              }
            }
          }
        }
      }
    } else if (!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
      if (this.getRowType(poRow) == this.RowType.BodyRow) {
        for(var i = 0; i < vnSize; i++) {
          vsCol = paCols[i];
          vnRowSpan = poRow[vsCol + "RowSpan"];
          if(vnRowSpan != null) vnRowSpan = eval(vnRowSpan);
          else vnRowSpan = 1;
          voColumn = this.getBodyColumn(null, vsCol);
          var vnInstIdx = poRow ["InstIdx"];
          if(vnChildIdx != null) vnInstIdx = poRow.parentNode["InstIdx"];
          if (vnInstIdx == null) vnInstIdx = poRow.getAttribute("InstIdx");
          vnInstIdx = parseInt(vnInstIdx);
          var voMapNode = this.data.getNodesetData2(vnInstIdx);
          var voRowNode = voMapNode.node;
          var vsStatus = voRowNode.getUserAttribute("status");
          if (vsStatus == null) vsStatus = "";
          if (vsStatus.indexOf("U") == -1) voRowNode.setUserAttribute("status", vsStatus + "U");
  
          var vsRef = voColumn.ref;
          if(vnChildIdx != null) vsRef = this.childRows[vnChildIdx][vsCol];
          if (!!vsRef) {
            var vnRowIndex = this.getIndexOfRow(poRow);
            voValue = this.grid.GetValue(poRow, vsCol);
            voValue = this.convertValueExria(poRow, vsCol, voValue);
            if (voValue === null) voValue = "";
            if (voColumn.type == "Int" && voValue != "") {
              if (voValue >= 0) voValue = Math.round(voValue);
              else voValue = - 1 * Math.round(- 1 * voValue);
            }
            vsRef = vsRef.split("/");
            vsRef = vsRef [vsRef.length - 1];
            voMapNode.put(vsRef, voValue);
            for(var j = 1; j < vnRowSpan; j++) {
              voMapNode = base.data.getNodesetData2(vnInstIdx + j);
            }
          }
          if(poRow["Changed"] == "1") {
            if(poRow["Added"] == "1") voRowNode.setUserAttribute("status", "IU");
            if(poRow["Deleted"] == "1") voRowNode.setUserAttribute("status", "D");
          } else {
            if(poRow["Deleted"] == "1") voRowNode.setUserAttribute("status", "D");
            else  voRowNode.setUserAttribute("status", "");
          }
        }
      }
    }
  };

  // 사용자에 Action에 의해 sort 될때 발생하는 이벤트
  /**
   * @ignore (-1을 리턴하면 디폴트로 설정된 sorting 관련 동작을 모두 중지시키고, 1을 리턴하면 sorting 만 중지시키고 sort icon에 대한 디폴트 변경 동작은 허용된다.)
   */
  this.enGridexSort = function(psCol, psSort) {
    var voGrid = this.grid;
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.colId = psCol;
    var vnResult = 0;

    if(this.onGridexSort) {
      vnResult = base.onGridexSort(voEvent);
    }
    if(!vnResult) {
      var voDst = this.dataset;
      if(voDst) {
        var vnPaging = this.grid.Paging;
        if(vnPaging == 3) return;
        var vaSortCol = psSort.split(",");
        var vsCol = null;
        var vbSortAsc = null;
        var vaSortType = [];
        for(var i = 0; i < vaSortCol.length; i++) {
          vsCol = vaSortCol[i];
          vbSortAsc = true;
          if(vsCol.indexOf("-") == 0) {
            vsCol = vsCol.substring(1);
            vaSortType.push(1);
            vaSortCol[i] = vsCol;
          } else {
            vaSortType.push(0);
          }
        }
        this.grid.Paging = 3;
        this.sort(1, vaSortCol, vaSortType);
        this.grid.Paging = vnPaging;
        vnResult = 1;
      }
    }
    return vnResult;
  };
  /**
   * @ignore
   */
  this.enGridexSortFinish = function() {
    if(this.oddRowBg || this.evenRowBg) {
      var voXB = this.grid.XB;
      var voFuncSetColor, vsBg, vnIdx;
      var voBase = this;
      voFuncSetColor = function(poNode){
        if(poNode.childNodes.length > 0 && poNode["InstIdx"] == null && poNode["ChildIdx"] == null){
          vnIdx = -1;
          for(var r=poNode.firstChild;r;r=r.nextSibling){
            voFuncSetColor(r);
          }
        } else {
          if(poNode && poNode.nodeName && poNode.nodeName == "I" && poNode["InstIdx"] != null) vnIdx++;
          if(vnIdx % 2 == 1) vsBg = voBase.evenRowBg;
          else vsBg = voBase.oddRowBg;
          poNode["Color"] = vsBg;
          for(var rr=poNode.firstChild;rr;rr=rr.nextSibling){
            voFuncSetColor(rr);
          }
        }
      };
      if(voXB != undefined) voFuncSetColor(voXB);
      this.grid.RenderBody();
    }
  };
  /**
   * @ignore
   */
  this.enGridexScroll = function(poGrid, pnNewScollLeft, pnNewScrollTop, pnOldScollLeft, pnOldScrollTop) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.scroll.newLeft = pnNewScollLeft;
    voEvent.scroll.newTop = pnNewScrollTop;
    voEvent.scroll.oldLeft = pnOldScollLeft;
    voEvent.scroll.oldTop = pnOldScrollTop;
    if(this.onGridexScroll) return this.onGridexScroll(voEvent);
  };
  /**
   * @ignore
   */
  this.enGridexClickSideDate = function(poRow, psCol, poEvent) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    voEvent.e = poEvent;
    if(this.onGridexClickSideDate) return this.onGridexClickSideDate(voEvent);
  };
  /**
   * @ignore
   */
  this.enGridexStartEdit = function(poRow, psCol, poEvent) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    voEvent.e = poEvent;
    this.isEditing = true;
    var vbRet = false;
    if(this.onGridexStartEdit) vbRet = this.onGridexStartEdit(voEvent);
    if(vbRet == null) vbRet = false;
    return vbRet;
  };
  // cell에 editing이 종료되거나 Enum 리스트가 닫힐때 호출되는 이벤트
  /**
   * @ignore
   */
  this.enGridexEndEdit = function(poRow, psCol, pbSave, psValue) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.type = pbSave;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    voEvent.value = psValue;
    if(this.grid.isEntered) voEvent.isEntered = true;

    this.isEditing = false;
    if (this.onGridexEndEdit) this.onGridexEndEdit(voEvent);
    voEvent.isEntered = null;
    this.grid.isEntered = null;
  };
  /**
   * @ignore
   */
  this.enGridexGanttChanged = function(poRow, psCol, psKind, psVal1, psVal2) {
    var voBodyColumn = base.getBodyColumn(null, psCol);
    var vsGanttCol = null;
    switch(psKind) {
    case "Main" :
      if(psVal1 != null) {
        vsGanttCol = voBodyColumn.ganttStart;
        base.enGridexAfterValueChanged(base, poRow, vsGanttCol);
      }
      if(psVal2 != null) {
        vsGanttCol = voBodyColumn.ganttEnd;
        base.enGridexAfterValueChanged(base, poRow, vsGanttCol);
      }
      break;
    case "Dependency" :
      if(psVal1 != null) {
        vsGanttCol = voBodyColumn.ganttDependencies;
        base.enGridexAfterValueChanged(base, poRow, vsGanttCol);
      }
      if(psVal2 != null) {
        vsGanttCol = voBodyColumn.ganttDependencyTypes;
        base.enGridexAfterValueChanged(base, poRow, vsGanttCol);
      }
      break;
    case "UpdateDependency" :
      vsGanttCol = psVal1;
      base.enGridexAfterValueChanged(base, poRow, vsGanttCol);
      break;
    }
  };

  this.enGridexPostRender = function() {};

  this.enGridexScrollUpdate = function() {
    if(this.onGridexScrollUpdate || this.onGridexRenderCompleteAll) {
      this.resetEvent();
      var voEvent = this.event;
      voEvent.object = this;
      voEvent.row = this.grid.GetPage(this.cfg.pagePos);
      voEvent.pagePos = this.cfg.pagePos;
      
      if(voEvent.row == null || voEvent.row["State"] != "4") return;
      var voGrid = this.grid;
      var voPage = voEvent.row;
      var vnHeight = voGrid.GetRowHeight(voPage);
      if(this.onGridexScrollUpdate) this.onGridexScrollUpdate(voEvent);
      if(this.onGridexRenderCompleteAll) this.onGridexRenderCompleteAll(voEvent);
      if(this.cfg.ganttIdColumn) {
        this.grid.RefreshGanttDependencies(1);
        setTimeout(function() { base.moveToToday(); }, 100);
      }
    }
  };

  this.enGridexStartDrag = function(poRow, psCol, pbMultiRow) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.row = poRow;
    voEvent.colId = psCol;
    voEvent.isMulti = pbMultiRow;
    if(this.onGridexStartDrag) return this.onGridexStartDrag(voEvent);
  };

  this.enGridexEndDrag = function(pcSrcGrx, poSrcRow, poTrgRow, pnType, nX, nY) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.beforeObject = pcSrcGrx;
    voEvent.dropType = pnType;
    voEvent.row = poTrgRow;
    voEvent.beforeRow = poSrcRow;
    voEvent.x = nX;
    voEvent.y = nY;
    
    if(this == pcSrcGrx) {
      // TODO :
    }
    var vnType = null;
    if(this.onGridexEndDrag) vnType = this.onGridexEndDrag(voEvent);
    if(vnType == null) vnType = pnType;
    return pnType;
  };

  this.enGridexCellEditChanged = function(psNewValue, psBeforeValue, poRow, poEvent) {
    this.resetEvent();
    var voEvent = this.event;
    voEvent.object = this;
    voEvent.value = psNewValue;
    voEvent.row = poRow;
    voEvent.e = poEvent;
    
    if(this.onGridexCellEditChanged) this.onGridexCellEditChanged(voEvent);
  };

  this.enGridexDownloadPage = function(poRow, poFunc) {
      this.cfg.pagePos = poRow.Pos;
  };

  this.enGridexCustomAjax = function(poSource, psData, poFunc) {
    var vsData = this.getPagingData(this.cfg.pagePos);
    if(!vsData) poFunc(-1, "Error");
    else poFunc(0, vsData);
    return true;
  };
  
  this.enGridexSelectAll = function() {
    var voGrid = this.grid;
    var vaFixedRows = voGrid.GetFixedRows();
    var vnSize = vaFixedRows.length;
    var vbCheck = false;
    var vcCtrl = null;
    if(this.cfg.pageSelectAll == true && this.cfg.paging == "fast") {
      if(this.pageSelectAllChecked) vbCheck = true;
    } else {
      if(voGrid.GetSelRows().length == 0) vbCheck = true;
    }
    for(var i = 0; i < vnSize; i++){
      var vsSection = vaFixedRows[i].Fixed;
      if(vsSection == "Head") {
        vcCtrl = voGrid.GetCell(vaFixedRows[i], "Panel");
        if(vbCheck) vcCtrl = vcCtrl.childNodes[0].style.backgroundPosition = "-150px 0px";
        else vcCtrl = vcCtrl.childNodes[0].style.backgroundPosition = "-100px 0px";
      }
    }
    
  };
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.resizeTreeImg = function(){
  if(this.cfg.grouping === false || !this.cfg.groupMain || !this.cfg.groupCols) return;
  var vaCenter = document.getElementsByTagName("center");
  for(var i=0, il=vaCenter.length; i<il; i++){
    if(vaCenter[i].parentNode){
      var voParent = vaCenter[i].parentNode;
      if(voParent.className){
        var vsClass = voParent.className;
        var vsClassTree = vsClass.substring(vsClass.length-8, vsClass.length);
        if(vsClassTree == "TreeIcon"){
          var vnHeight = voParent.parentNode.parentNode.parentNode.parentNode.parentNode.offsetHeight - 2;
          if(vnHeight < 0) vnHeight = 0;
          if(this.canvas.page.metadata.browser.ie > 0 && vaCenter[i].firstChild) vaCenter[i].firstChild.style.height = vnHeight + "px";
          else vaCenter[i].style.height = vnHeight + "px";
        }
      }
    }
  }
};
/**
 * 2009.05.19 yjcho - Tab키에 의한 focus이동을 위해 추가
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.dofocus = function(poEvent) {
  if(poEvent && poEvent.type == "keydown") {
    poEvent.stopEvent();
    var base = this;
    this.temp = function() {
      var voGrid = base.grid;
      var voFRow = voGrid.FRow;
      var voFCol = voGrid.FCol;
      if(voFRow) {
        voGrid.Focus(voFRow, voFCol);
      } else {
        if(poEvent && poEvent.shiftKey) {
          voGrid.ActionGoLast();
        } else {
          voGrid.ActionGoFirst();
        }
      }
    }
    this.canvas.delayedKeydown.add(this.temp);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.doblur = function(){
  this.grid.EndEdit(this.grid.FRow,this.grid.FCol,true);
  // yhkim 2009.07.16 탭이동간 차일드  Window들 닫기
  this.grid.CloseDialog();
  // yhkim 2009. 05.07
  if(this.window.Grids) this.window.Grids.Focused = null;
};
/**
 * 그리드 layout data 구성하기 위해 호출되는 메소드
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.makeLayout = function(){
  /////////////////////////////////////////////////////////////////
  // layout data 구성
  var vsLayOutData = "";
  vsLayOutData = this.template["Start"] + this.template["Cfg"];

  vsLayOutData = vsLayOutData + this.template["Def"];
  vsLayOutData = vsLayOutData + this.template["Cols"];
  vsLayOutData = vsLayOutData + this.template["Header"];
//vsLayOutData = vsLayOutData + "<Body><B/></Body>";
  // yhkim 2009.08.29 Data영역에서 <B/>를 설정한다
  vsLayOutData = vsLayOutData + "<Body></Body>";

  vsLayOutData = vsLayOutData + this.template["Toolbar"] + "\n";

  // 2009.08.04 Panel Layout
  vsLayOutData = vsLayOutData + this.template["Panel"];

  vsLayOutData = vsLayOutData + this.template["End"];
  this.templateLayout = vsLayOutData;
  vsLayOutData = null;
};

eXria.controls.xhtml.GridEx.prototype.loadData = function(poDocument) {
  if(this.datasetId == null) {
    this.loadDataFromInstance(poDocument);
    this.loadFunctionColumnDataFromInstance();
    this.loadFooterDataFromInstance();
    this.makeData();
  } else {
    this.loadDataFromDataSet(poDocument);
    this.loadFunctionColumnDataFromInstance();
    this.loadFooterDataFromInstance();
    this.makeData();
  }
};
// yhkim 2009. 05.25
/**
 * loadFunctionColumnDataFromInstance
 * @param {HTMLDocument} poDocument 윈도우 document 객체
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.loadFunctionColumnDataFromInstance = function(poDocument) {
  this.template["FunctionColumn"] = "";
  this.template["FunctionColumn"] = this.makeFunctionRowDataFromInstance();
};
//yhkim 2009. 05.25
/**
 * makeFunctionRowDataFromInstance
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.makeFunctionRowDataFromInstance = function(){
  var voCols = new Array();
  var voColumn = null;
  voCols[0] = this.header.cols["left"];
  voCols[1] = this.header.cols["center"];
  voCols[2] = this.header.cols["right"];

  var vsFunctionColumns = "";
  var vnFunctionHeaderCnt = 0;
  var vnHeaderCnt = 0;
  var voTmpCols;

  for ( var i = 0; i < 3; i++) {
    if (voCols[i] && !!voCols[i].rows[0].columns.length){
      for ( var j = 0; voCols[i].rows.length > j; j++) {
        var voRow = voCols[i].rows[j];
        if(voRow.columns == null) continue;
        var vnColumns = voRow.columns.length;
        for(var k = 0; k < vnColumns; k++) {
          voColumn = voRow.columns[k];
          if(voColumn instanceof eXria.controls.xhtml.GridEx.FunctionColumn){
            vnFunctionHeaderCnt++;
          }
          else if(voColumn instanceof eXria.controls.xhtml.GridEx.HeadColumn){
            vnHeaderCnt++;
          }
          break; //row 수 판단을 위한 코드이므로 한 컬럼만을 체크
        }
      }
      voTmpCols = voCols[i];
      break; // row 수 판단을 위한 코드이므로 한 Cols만을 체크
    }
  }
  if(vnFunctionHeaderCnt > 0) {
    var vsTitle, vsColumnText = "";
    vsFunctionColumns = "<Head Height='" + this.header.height + "'>";
    var vsRow = "";
    var voCfg = this.cfg;

    for(var cnt = 0; cnt < vnHeaderCnt + vnFunctionHeaderCnt; cnt++){
      vsRow = "<I Calculated='1' Spanned='1' ";
      if(this.funcRowCanEdit == false) {
        vsRow += "CanEdit='0' CanFocus='0' "
      }else{
        if(voCfg.editing != null) vsRow = vsRow + " CanEdit='" + voCfg.editing + "'";
      }

      var voFirstCol = null;
      //if(voCols[0]) voFirstCol = voCols[0].rows[cnt].columns[0];
      //else if(voCols[1]) voFirstCol = voCols[1].rows[cnt].columns[0];
      voFirstCol = voTmpCols.rows[cnt].columns[0];
      vsRow = vsRow + this.makeHeaderRowColorData(voFirstCol.id);

      for ( var i = 0; i < 3; i++) {  // left,center,right가 순서대로 가야 한다.
        if (voCols[i]) {
          var voRow = voCols[i].rows[cnt];  // cnt갯수에 따라 결정되어야 한다.
          var voColumn = null;
          if(voRow.columns == null) continue;
          for ( var k = 0; voRow.columns.length > k; k++) {
            voColumn = voRow.columns[k];

            if(this.cfg.idColumn != null && voColumn.colId == this.cfg.idColumn) { // id 칼럼에 대한 처리
              if(!!voColumn.value){
                vsColumn = " id='" + voColumn.value + "'";
              }else{
//                vsColumn = " id='" + "H" + (cnt+1-vnHeaderCnt) + "'";
                vsColumn = " id='&#x90;'";
              }
            } else {
              if(voColumn instanceof eXria.controls.xhtml.GridEx.HeadColumn){
                vsRow = "";
                continue;
              }

              vsColumn = "";
              vsColumnText = "";

              // itemgroup
              if(voColumn.itemgroup.data){
                var voItemGData = voColumn.itemgroup.data;
                voItemGData.control = this;
                if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
                  voColumn.itemgroup.addToItemset();
                }
              }

              // value
              var voInstance = null;
              var vsValue = "";
              if(voColumn.instanceId){
                voInstance = this.canvas.page.getInstance(voColumn.instanceId);
              }
              if(voInstance && voColumn.ref) {
                //voValue = voInstance.getValueNode(voColumn.ref).getValue();
                //voColumn.value = voValue;
                voColumn.data = new eXria.controls.DataRefNodeset(this);
                    voColumn.data.setRef(voColumn.instanceId, voColumn.ref);
                    vsValue = voColumn.data.getData();  // 리스트값이 필요
              }
              // 기본  text/caption/값
              if (voColumn.type == "Radio" || voColumn.type == "CheckBox"){
                vsValue = this.convertValueTGrid(voColumn, vsValue);
                vsColumn = vsColumn + " " + voColumn.colId + "='" + vsValue + "'";
              }else if(voColumn.type == "Button"){
                if(vsValue.length == 0)
                  vsValue = voColumn.value;
                vsColumn = " " + voColumn.colId + "Caption='" + vsValue + "'";
              }else if(voColumn.type == "Date"){
                vsColumn = vsColumn + " " + voColumn.colId + "='" + vsValue + "'";
              }else if(voColumn.type == "Bool" || voColumn.type == "Int" || voColumn.type == "Float"){
                if(vsValue.length == 0)
                  vsValue = voColumn.value;
                      try {
                        vsValue = eval(vsValue);
                        //vsValue = this.getXml(vsValue,2);
                        vsColumn = vsColumn + " " + voColumn.colId + "='" + vsValue + "'";
                      } catch(err) {
                        throw new Error("Column miss type error");
                      }
              }else if(voColumn.type == "Image"){// 텍스트가 필요없다
              }else {
                if(voColumn.value == null)
                  voColumn.value = "";
                if(vsValue.length == 0){
                    vsValue = voColumn.value;
                }
                vsValue = this.getXmlValue(vsValue);
                vsColumn = vsColumn + " " + voColumn.colId + "=" + vsValue + "";
              }
            }

            // type
            if (voColumn.type == "Image"){
              var voHrefValue, voWidthValue, voHeightValue, voLeftValue, voTopValue, voTargetValue;
              vsColumn = vsColumn + " " + voColumn.colId + "Type='Img'";

              var vsRef = voColumn.imageItem.href;
              if (voInstance && vsRef)
                voHrefValue = voInstance.getValueNode(vsRef).getValue();
              else
                voHrefValue = "";

              vsRef = voColumn.imageItem.target;
              if (voInstance && vsRef)
                voTargetValue = voInstance.getValueNode(vsRef).getValue();
              else
                voTargetValue = "";

              vsRef = voColumn.imageItem.width;
              if (voColumn.instanceId && vsRef)
                voWidthValue = voInstance.getValueNode(vsRef).getValue();
              else
                voWidthValue = "";

              vsRef = voColumn.imageItem.height;
              if (voInstance && vsRef)
                voHeightValue = voInstance.getValueNode(vsRef).getValue();
              else
                voHeightValue = "";

              vsRef = voColumn.imageItem.left;
              if (voInstance && vsRef)
                voLeftValue = voInstance.getValueNode(vsRef).getValue();
              else
                voLeftValue = "";

              vsRef = voColumn.imageItem.top;
              if (voInstance && vsRef)
                voTopValue = voInstance.getValueNode(vsRef).getValue();
              else
                voTopValue = "";

              if (vsValue != null) {
                vsColumn = vsColumn + " " + voColumn.colId
                    + "=" + "\"|" + voHrefValue + "|"
                    + voWidthValue + "|"
                    + voHeightValue + "|" + voLeftValue
                    + "|" + voTopValue + "|"
                    + voTargetValue + "\"";
              }

            }
            else if (voColumn.type == "Radio" || voColumn.type == "CheckBox"){
              vsColumn = vsColumn + " " + voColumn.colId +"Type='Radio'";
              var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);
              vsLabels =  " " + voColumn.colId + "Enum='" + vsLabels + "'";
              if(voColumn.type == "CheckBox") vsLabels = " " + voColumn.colId + "Range='1'";
              vsColumn = vsColumn + " " + voColumn.colId + "Wrap='0'";
            }
            else
              vsColumn = vsColumn + " " + voColumn.colId +"Type='" + voColumn.type + "'";

            // 리스트 형태들 추가속성들
            if (voColumn.type == "Enum") {
              var vsValues = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
              var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);
              vsColumn = vsColumn + " " + voColumn.colId + "Enum='" + vsLabels + "'"
                + voColumn.colId + "EnumKeys='" + vsValues + "'";
              if(voColumn.enumType) vsColumn = vsColumn + " " + voColumn.colId + "EnumType='" + voColumn.enumType + "'";
            }
            else if (voColumn.type == "Select") {
              voValue = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
              var vsDefaults = " " + voColumn.colId + "Defaults='" + voValue + "'";
              vsColumn = vsColumn + vsDefaults;
            }
            else if (voColumn.type == "Button"){
              for(var vsAttr in voColumn.buttonItem){
                      var vsRef = voColumn.buttonItem[vsAttr];
                      if(vsRef == null) continue;
                      var voValueNode = voInstance.getValueNode(vsRef);
                      if(voValueNode == null) continue;
                      var vsAttrValue = voValueNode.getValue();
                      if(vsAttrValue) vsAttrValue = this.getXml(vsAttrValue, 2);

                      if(vsAttrValue != ""){
                        if(vsAttr == "width") vsColumn = vsColumn + " " + voColumn.colId + "Width=" + vsAttrValue;
                        else if(vsAttr == "height") vsColumn = vsColumn + " " + voColumn.colId + "Height=" + vsAttrValue;
                        else if(vsAttr == "icon") vsColumn = vsColumn + " " + voColumn.colId + "Icon=" + vsAttrValue;
                        else if(vsAttr == "iconChecked") vsColumn = vsColumn + " " + voColumn.colId + "IconChecked=" + vsAttrValue;
                        else if(vsAttr == "tooltip") vsColumn = vsColumn + " " + voColumn.colId + "ToolTip=" + vsAttrValue;
                        else if(vsAttr == "tooltipChecked") vsColumn = vsColumn + " " + voColumn.colId + "ToolTipChecked=" + vsAttrValue;
                      }
                    }
            }
            else if (voColumn.type == "Date") {
            if (!voColumn.calendarEnable)
              vsColumn = vsColumn + " " + voColumn.colId +"Button='None'";
            }

            // Mask
            if(voColumn.format != null || voColumn.mask != null) {
              if(voColumn.formatMask == null) voColumn.formatMask = new eXria.controls.xhtml.GridEx.FormatMask(voColumn, this);
              vsColumn = vsColumn + voColumn.formatMask.createFormatAndMask(voColumn);
            }

            // rightbutton
            if(voColumn.rightButton != null) {
              if(voColumn.rightButton.instanceId){
                voInstance = this.canvas.page.getInstance(voColumn.rightButton.instanceId);
                  var vsRButtonRef = voColumn.rightButton.ref;
                  if(vsRButtonRef != null){
                      var voNode = voInstance.getValueNode(vsRButtonRef);
                      if(voNode)
                        voRButtonValue = voNode.getValue();
                  }
                  else
                    voRButtonValue = voColumn.rightButton.value;

                  if(voRButtonValue != null) {
                      vsColumn = vsColumn + " " + voColumn.colId + "Button='" + voRButtonValue + "'";
                  } else {
                      voRButtonValue = voColumn.rightButton.value;
                      if(voRButtonValue)
                        vsColumn = vsColumn + " " + voColumn.colId + "Button='" + voRButtonValue + "'";
                  }
              }
              var voRButton = voColumn.rightButton;
              if(voRButton.type == "Defaults") {
                if(vsRButton != "Enum" && vsRButton != "Select" && vsRButton != "Radio" && vsRButton != "List") {
                  voValue = voColumn.itemgroup.getItemValuesToString('|');
                  vsColumn = vsColumn + " " + voColumn.colId + "Defaults='" + voValue + "'";
                }
              }
              if(voRButton.type == "Normal") {
                vsColumn = vsColumn + " " + voColumn.colId + "Button=\"Button\"";
                if(voRButton.width == null) voRButton.width = 10;
                vsColumn = vsColumn + " " + voColumn.colId + "WidthPad=\"" + voRButton.width + "\"";
              }
              if(voRButton.type == "Image") {
                vsColumn = vsColumn + " " + voColumn.colId + "Button=\"Img\"";
                if(voRButton.width == null) voRButton.width = 10;
                vsColumn = vsColumn + " " + voColumn.colId + "WidthPad=\"" + voRButton.width + "\"";
              }
            }

            // align
            if (voColumn.textAlign == "left")
              vsColumn = vsColumn + " " + voColumn.colId + "Align='0'";
            else if (voColumn.textAlign == "center")
              vsColumn = vsColumn + " " + voColumn.colId + "Align='1'";
            else if (voColumn.textAlign == "right")
              vsColumn = vsColumn + " " + voColumn.colId + "Align='2'";

            if (voColumn.colspan != null)
              vsColumn = vsColumn + " " +voColumn.colId + "Span='" + voColumn.colspan + "'";

            if (voColumn.canEdit != null)
              vsColumn = vsColumn + " " +voColumn.colId + "CanEdit='" + voColumn.canEdit + "'";

            if(voColumn.mask != null && (voColumn.maxLength == null && voColumn.type == "Text")) voColumn.maxLength = voColumn.mask.length;

            if (voColumn.maxLength != null)
              vsColumn = vsColumn + " " +voColumn.colId + "Size='" + voColumn.maxLength + "'";

            if (voColumn.canFocus != null){
              var vbFocus = eval(voColumn.canFocus);
              if(vbFocus == true)
                vsColumn = vsColumn + " " +voColumn.colId + "CanFocus='1'";
              else
                vsColumn = vsColumn + " " +voColumn.colId + "CanFocus='0'";
              //else
                //vsColumn = vsColumn + " " +voColumn.colId + "CanFocus=" + this.getXml(voColumn.canFocus, 1);
            }

//            if (voColumn.canDrag != null) vsColumn = vsColumn + " " + voColumn.colId + "CanDrag=" + this.getXml(voColumn.canDrag, 1);
//            vsColumn = vsColumn + " " + voColumn.colId + "CanDrag='1' ";
            if(voColumn.formula != null){
              voColumn.formula = voColumn.formula.split("\"").join("'");
              vsColumn = vsColumn + " " + voColumn.colId + "Formula=\"" + voColumn.formula + "\"";
            }
//            if(voColumn.backgroundColor != null) vsColumn = vsColumn + " " + voColumn.colId + "Background='" + this.getRGBValue(voColumn.backgroundColor) + "' ";
            /*
            if(voColumn.color != null) {
              vsColumn = vsColumn + " " + voColumn.colId + "ClassInner=\"" + this.id + voColumn.colId + this.styles.prefix + "Text\" ";
            }
            */
            if(voColumn.className != null) {
              var vsColId = voColumn.colId;
              if(vsColId == this.cfg.idColumn) { // id 칼럼에 대한 처리
//                if(!!voColumn.value){
//                  vsColId = voColumn.value;
//                }else{
//                  vsColId = "H" + (cnt+1-vnHeaderCnt);
//                }
                vsColId = "";
                vsColumn = vsColumn + " " + vsColId + "SkipReadOnly='1'";
                var vsCssStyle = "CssStyle='";
                var vsColor = voColumn.color;
                if(vsColor == null) vsColor = this.getStyleCurrentValue(voColumn, "color", "color");
                if(vsColor) vsCssStyle += "color:" + vsColor + ";";
                var vsFontFamily = this.getStyleCurrentValue(voColumn, "font-family", "fontFamily");
                if(vsFontFamily) vsCssStyle += "font-family:" + vsFontFamily + ";";
                var vsFontSize = this.getStyleCurrentValue(voColumn, "font-size", "fontSize");
                if(vsFontSize) vsCssStyle += "font-size:" + vsFontSize + ";";
                var vsFontStyle = this.getStyleCurrentValue(voColumn, "font-style", "fontStyle");
                if(vsFontStyle) vsCssStyle += "font-style:" + vsFontStyle + ";";
                var vsFontWeight = this.getStyleCurrentValue(voColumn, "font-weight", "fontWeight");
                if(vsFontWeight) vsCssStyle += "font-weight:" + vsFontWeight + ";";
                if(vsCssStyle != "CssStyle='") {
                  vsCssStyle += "'";
                  vsColumn = vsColumn + " " + vsColId + vsCssStyle;
                }
              }
              vsColumn = vsColumn + " " + vsColId + "ClassInner='" + voColumn.className + "' ";
              if(voColumn.outerClassName == null) vsColumn = vsColumn + " " + vsColId + "Class='" + voColumn.className + "' ";
              var vsBackgroundColor = voColumn.backgroundColor;
              if(vsBackgroundColor == null) vsBackgroundColor = this.getStyleCurrentValue(voColumn, "background-color", "backgroundColor");
              if(vsBackgroundColor) vsColumn = vsColumn + " " + vsColId + "Background='" + this.getRGBValue(vsBackgroundColor) + "' ";

            }
            if(voColumn.outerClassName != null) vsColumn = vsColumn + " " + vsColId + "Class='" + voColumn.outerClassName + "' ";

            vsRow = vsRow + vsColumn;
          }   // for ( var k = 0; voRow.columns.length > k; k++)
        }     // end if (voCols[i])
      }       // end for ( var i = 0; i < 3; i++)
      if(vsRow != "")
        vsRow = vsRow + "/>";
      vsFunctionColumns = vsFunctionColumns + vsRow;
    }         // end for(var cnt = 0; cnt < vnHeaderCnt + vnFunctionHeaderCnt; cnt++)
    vsFunctionColumns = vsFunctionColumns + "</Head>";
  }           // end if(vnFunctionHeaderCnt > 0) {
  return vsFunctionColumns;
};
/**
 * loadFooterDataFromInstance
 * @param {HTMLDocument} poDocument 윈도우 document 객체
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.loadFooterDataFromInstance = function(poDocument) {
  if(this.footer == null){
    this.template["Footer"] = "";
    return;
  }
  var vsTemplate = "";
  vsTemplate = vsTemplate + "<Foot>";
  var vsRow = "";
  var vsColumn = "";

  if(this.footer.rows){
    var vaRows = this.footer.rows;
    for(var i=0; i<vaRows.length; i++){ // rows
      if(vaRows[i] instanceof eXria.controls.xhtml.GridEx.FootRow){ // FootRow 추가
        vsRow = this.makeFootRowDataFromInstance(vaRows[i], i);
      }
      vsTemplate = vsTemplate + vsRow;
      if(vaRows.length >= i) vsTemplate = vsTemplate;
    }
  }
  vsTemplate = vsTemplate + "</Foot>";
  this.template["Footer"] = vsTemplate;
};
/**
 * makeFootRowDataFromInstance
 * @param {eXria.controls.xhtml.GridEx.FootRow} footer row
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.makeFootRowDataFromInstance = function(poRow, pnRowIndex){
  if(poRow == null) return "";
  var vsRow = "<I Calculated='1'";
  var voCfg = this.cfg;
  if(voCfg.editing != null) vsRow = vsRow + " CanEdit='" + voCfg.editing + "'";
  var vsColumn = "";
  var voValue = null;
  var vaCols = poRow.cols;

  var voFirstCol = null;
  if(vaCols["left"]) voFirstCol = vaCols["left"].columns[0];
  else if(vaCols["center"]) voFirstCol = vaCols["center"].columns[0];
  vsRow = vsRow + this.makeFooterRowColorData(voFirstCol.id);

  for(var vsCols in vaCols){ // cols
    var voCols = vaCols[vsCols];
    if(voCols.columns == null) continue;
    for(var j=0; j<voCols.columns.length; j++){ // columns
      var voColumn = voCols.columns[j];
      if(voColumn.colId == this.cfg.idColumn) { // id 칼럼에 대한 처리
        if(!!voColumn.value){
          vsColumn = " id='" + voColumn.value + "'";
        }else{
          vsColumn = " id='" + "F" + (pnRowIndex+1) + "'";
        }
      } else {
        var vsRef = voColumn.ref;
        var vsValue = null;

        if(vsRef != null && voColumn.type != "Radio" && voColumn.type != "CheckBox"){
          voColumn.data = new eXria.controls.DataRefNode(this);
          voColumn.data.setRef(voColumn.instanceId, vsRef)
          vsValue = voColumn.data.getData();
        }else if(voColumn.type == "Radio" || voColumn.type == "CheckBox"){
          voColumn.data = new eXria.controls.DataRefNodeset(this);
          voColumn.data.setRef(voColumn.instanceId, vsRef);
          vsValue = voColumn.data.getData();
        }

        var voInstance = null;
        if(voColumn.instanceId) voInstance = this.canvas.page.getInstance(voColumn.instanceId);

        var getXmlVal = this.getXml;
        function getRefValue(psRef){
          var retValue = "";
          if(psRef) {
            retValue = voInstance.getValueNode(psRef).getValue();
            if(!retValue) retValue = "";
          }
          return retValue;
        }

        var voItemGData = voColumn.itemgroup.data;
        voItemGData.control = this;
        if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
          voColumn.itemgroup.addToItemset();
        }
        if(voColumn.value){
          vsColumn = " " + voColumn.colId + "=" + this.getXml(voColumn.value, 2);
        } else if(vsValue != null) {
          switch(voColumn.type) {
            case "Enum" :
              vsValue = this.getXml(vsValue,2);
              vsColumn = " " + voColumn.colId + "=" + vsValue;
              break;
            case "Number" :
            case "Bool" :
            case "Int" :
            case "Float" :
              vsValue = eval(vsValue);
              vsValue = this.getXml(vsValue,2);
              vsColumn = " " + voColumn.colId + "=" + vsValue;
              break;
            case "CheckBox" :
            case "Radio" :
              vsValue = this.convertValueTGrid(voColumn, vsValue);
              vsValue = this.getXml(vsValue,2);
              vsColumn = " " + voColumn.colId + "=" + vsValue;
              break;
            case "Select" :
              if(voColumn.selectionDataType == "Numeric") vsValue = eval(vsValue);
              vsValue = this.getXml(vsValue,2);
              vsColumn = " " + voColumn.colId + "=" + vsValue;
              break;
            case "Text" :
            case "Date" :
              vsValue = this.getXml(vsValue,2);
              vsColumn = " " + voColumn.colId + "=" + vsValue;
              break;
            case "Button" :
              vsValue = this.getXml(vsValue,2);
              vsColumn = " " + voColumn.colId + "Caption=" + vsValue;

              for(var vsAttr in voColumn.buttonItem){
                var vsRef = voColumn.buttonItem[vsAttr];
                var vsAttrValue = getRefValue(vsRef);
                if(vsAttrValue) vsAttrValue = this.getXml(vsAttrValue, 2);

                if(vsAttrValue != ""){
                  if(vsAttr == "width") vsColumn = vsColumn + " " + voColumn.colId + "Width=" + vsAttrValue;
                  else if(vsAttr == "height") vsColumn = vsColumn + " " + voColumn.colId + "Height=" + vsAttrValue;
                  else if(vsAttr == "icon") vsColumn = vsColumn + " " + voColumn.colId + "Icon=" + vsAttrValue;
                  else if(vsAttr == "iconChecked") vsColumn = vsColumn + " " + voColumn.colId + "IconChecked=" + vsAttrValue;
                  else if(vsAttr == "tooltip") vsColumn = vsColumn + " " + voColumn.colId + "ToolTip=" + vsAttrValue;
                  else if(vsAttr == "tooltipChecked") vsColumn = vsColumn + " " + voColumn.colId + "ToolTipChecked=" + vsAttrValue;
                }
              }
              break;
            case "Image" :
              var vaImageItem = new Array(5);

              for(var vsAttr in voColumn.imageItem){
                var vsRef = voColumn.imageItem[vsAttr];
                var vsAttrValue = getRefValue(vsRef);
                var vnIndex = null;
                if(vsAttr == "href") vnIndex = 0;
                else if(vsAttr == "width") vnIndex = 1;
                else if(vsAttr == "height") vnIndex = 2;
                else if(vsAttr == "left") vnIndex = 3;
                else if(vsAttr == "top") vnIndex = 4;
                else if(vsAttr == "target") vnIndex = 5;

                if(vnIndex != null) vaImageItem[vnIndex] = vsAttrValue;
              }
              var vsImage = "|" + vaImageItem.join("|");
              if(vsValue != null) {
                vsColumn = vsColumn + " " + voColumn.colId + "=" + "\"" + vsImage + "\"";
              }
              break;
          }
          vbEmptyRow = false;
          vsValue = null;
        } else {
          vsColumn = " " + voColumn.colId + "=\"\"";
          if(voColumn.type == "Enum") vsColumn = vsColumn + " " + voColumn.colId + "IconAlign='Right'";
        }

        if(voColumn.rightButton) {
          vsRButtonRef = voColumn.rightButton.ref;
          if(vsRButtonRef != null) {
            if(voInstance == null) voInstance = this.canvas.page.getInstance(voColumn.rightButton.instanceId);
            voRButtonValue = getRefValue(vsRButtonRef);
            if(voRButtonValue != null) {
              vsColumn = vsColumn + " " + voColumn.colId + "Button='" + voRButtonValue + "'";
            }
          } else {
            voRButtonValue = voColumn.rightButton.value;
            if(voRButtonValue) vsColumn = vsColumn + " " + voColumn.colId + "Button='" + voRButtonValue + "'";
          }
        }
      }
      if(voColumn.format != null || voColumn.mask != null) {
        if(voColumn.formatMask == null) voColumn.formatMask = new eXria.controls.xhtml.GridEx.FormatMask(voColumn, this);
        var vsFormat = voColumn.format;
        if(vsFormat && vsFormat.indexOf("TG:") == 0) {
          voColumn.regFormat = vsFormat.replace(/^TG:/, "");
        }
        var vsMask = voColumn.mask;
        if(vsMask && vsMask.indexOf("TG:") == 0) {
          voColumn.regMask = vsMask.replace(/^TG:/, "");
        }
        vsColumn = vsColumn + voColumn.formatMask.createFormatAndMask(voColumn);
      }
      vsColumn = vsColumn + this.makeFootColumnAttr(voColumn); // 속성구성
      vsRow = vsRow + vsColumn;
      if(voColumn.colspan != null) {
        if(vsRow.indexOf("Spanned='1' ") == -1) vsRow += "Spanned='1' ";
      }
    }
  }
  vsRow = vsRow + " />";

  return vsRow;
};
/**
 * column의 속성정보들을 구성하여 반환
 * @param {eXria.controls.xhtml.GridEx.FootColumn} poColumn footer column
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.makeFootColumnAttr = function(poColumn){
  var voColumn = poColumn;
  var vsColAttr = "";
  if(voColumn.type != null) {
    if(voColumn.type == "Image") vsColAttr = vsColAttr + " " + voColumn.colId + "Type='Img'";
    else if(voColumn.type == "Radio" || voColumn.type == "CheckBox") vsColAttr = vsColAttr + " " + voColumn.colId + "Type='Radio'";
    else vsColAttr = vsColAttr + " " + voColumn.colId + "Type='" + voColumn.type + "'";
    if(voColumn.type == "Enum") {
      var voItemGData = voColumn.itemgroup.data;
      voItemGData.control = this;
      if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
        voColumn.itemgroup.addToItemset();
      }
      var vsValues = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
      var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);
      vsColAttr = vsColAttr + " " + voColumn.colId + "Enum='" + vsLabels + "'" + " " + voColumn.colId + "EnumKeys='" + vsValues + "'";

      if(voColumn.enumType != null)
        vsColAttr = vsColAttr + " " + voColumn.colId + "EnumType='" + voColumn.enumType + "'";
    }
    if(voColumn.type == "Select") {
      var voItemGData = voColumn.itemgroup.data;
      voItemGData.control = this;
      if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
        voColumn.itemgroup.addToItemset();
      }
      voValue = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
      var vsDefaults = " " + voColumn.colId + "Defaults='" + voValue + "'";
      vsColAttr = vsColAttr + vsDefaults;
    }
    // HighGarden Add Start
    if(voColumn.type == "Radio" || voColumn.type == "CheckBox") {
      if(voColumn.formatMask == null) voColumn.formatMask = new eXria.controls.xhtml.GridEx.FormatMask(voColumn, this);

      var voItemGData = voColumn.itemgroup.data;
      voItemGData.control = this;
      if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
        voColumn.itemgroup.addToItemset();
      }
      var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);
      var vsFormat = voColumn.formatMask.createFormatAndMask(voColumn);
      vsLabels = vsFormat + vsLabels;
      vsColAttr = vsColAttr + " " + voColumn.colId + "Format='" + vsLabels + "'";
    }
    if(voColumn.type == "Date") {
      if(!voColumn.calendarEnable) vsColAttr = vsColAttr + " " + voColumn.colId + "Button='None'";
    }
    // HighGarden Add End
  }
  //Highgarden Start 090407
  if(voColumn.format != null || voColumn.mask != null) {
    if(voColumn.formatMask == null) voColumn.formatMask = new eXria.controls.xhtml.GridEx.FormatMask(voColumn, this);
    vsColAttr = vsColAttr + voColumn.formatMask.createFormatAndMask(voColumn);
  }
  //Highgarden End 090407
  if(voColumn.enums != null)vsColAttr = vsColAttr + " " + voColumn.colId + "Enum='" + voColumn.enums + "'";
  if(voColumn.canEdit != null) vsColAttr = vsColAttr + " " + voColumn.colId + "CanEdit='" + voColumn.canEdit + "'";
  if(voColumn.canSort != null)vsColAttr = vsColAttr + " " + voColumn.colId + "CanSort='" + voColumn.canSort + "'";
  if(voColumn.mask != null && (voColumn.maxLength == null && voColumn.type == "Text")) voColumn.maxLength = voColumn.mask.length;
  if(voColumn.maxLength != null)vsColAttr = vsColAttr + " " + voColumn.colId + "Size='" + voColumn.maxLength + "'";
  if(voColumn.formula != null){
    voColumn.formula = voColumn.formula.split("\"").join("'");
    vsColAttr = vsColAttr + " " + voColumn.colId + "Formula=\"" + voColumn.formula + "\"";
  }
  if(voColumn.rightButton != null) {
    voRButton = voColumn.rightButton;

    if(voRButton.type == "Defaults") {
      if(vsRButton != "Enum" && vsRButton != "Select" && vsRButton != "Radio" && vsRButton != "List") {
        var voItemGData = voColumn.itemgroup.data;
        voItemGData.control = this;
        if(voItemGData.nodesetInstanceId && voItemGData.nodesetInstancePath) {
          voColumn.itemgroup.addToItemset();
        }
        voValue = voColumn.itemgroup.getItemValuesToString('|');
        vsColAttr = vsColAttr + " " + voColumn.colId + "Defaults='" + voValue + "'";
      }
    }
    if(voRButton.type == "Normal") {
      vsColAttr = vsColAttr + " " + voColumn.colId + "Button=\"Button\"";
      if(voRButton.width == null) voRButton.width = 10;
      vsColAttr = vsColAttr + " " + voColumn.colId + "WidthPad=\"" + voRButton.width + "\"";
    }
    if(voRButton.type == "Image") {
      vsColAttr = vsColAttr + " " + voColumn.colId + "Button=\"Img\"";
      if(voRButton.width == null) voRButton.width = 10;
      vsColAttr = vsColAttr + " " + voColumn.colId + "WidthPad=\"" + voRButton.width + "\"";
    }
  }
  if(voColumn.backgroundColor != null) vsColAttr = vsColAttr + voColumn.colId + "Color='" + this.getRGBValue(voColumn.backgroundColor) + "' ";
  /*
  if(voColumn.color != null) {
//      vsDefR = vsDefR + " " + voColumn.colId + "ClassOuter=\"" + this.id + voColumn.colId + this.styles.prefix + "Cell\" " + voColumn.colId + "ClassInner=\"" + this.id + voColumn.colId + this.styles.prefix + "Text\" ";
    vsColAttr = vsColAttr + " " + voColumn.colId + "ClassInner=\"" + this.id + voColumn.colId + this.styles.prefix + "Text\" ";
  }
  */
  // 조영진 추가코드
  if(voColumn.className != null) {
    vsColAttr = vsColAttr + " " + voColumn.colId + "ClassInner='" + voColumn.className + "' ";
    if(voColumn.outerClassName == null) vsColAttr = vsColAttr + " " + voColumn.colId + "Class='" + voColumn.className + "' ";
  }
  if(voColumn.outerClassName != null) vsColAttr = vsColAttr + " " + voColumn.colId + "Class='" + voColumn.outerClassName + "' ";
  if (voColumn.textAlign == "left")
    vsColAttr = vsColAttr + " " + voColumn.colId + "Align='0'";
  else if (voColumn.textAlign == "center")
    vsColAttr = vsColAttr + " " + voColumn.colId + "Align='1'";
  else if (voColumn.textAlign == "right")
    vsColAttr = vsColAttr + " " + voColumn.colId + "Align='2'";
  if(voColumn.colspan != null) vsColAttr = vsColAttr + " " + voColumn.colId + "Span='" + voColumn.colspan + "' ";
  return vsColAttr;
};
/**
 * load data from instance
 * @param {HTMLDocument} poDocument 윈도우 document
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.loadDataFromInstance = function(poDocument) {
  if(this.hideInitRow === true && this.init === true){
    var vsInsId = this.data.nodesetInstanceId;
    var vsInsRef = this.data.nodesetInstancePath;
    if(vsInsId) {
      var voInstance = this.canvas.page.getInstance(vsInsId);
      if(voInstance) {
        var voInst =  voInstance.selectNodes(vsInsRef);
        var vnLoop = 0;
        if(voInst == null) {
          vnLoop = 0;
        } else {
          vnLoop = voInst.getLength();
        }
        for(var i=0; i<vnLoop; i++) {
          voInstance.removeNode(voInst.item(0));
        }
      }
    }

    this.init = false;
  }

  var voCollectionNode = null;
  var vnLoop = null;
  if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    voCollectionNode = this.data.getNodesetStr();
    if(voCollectionNode) {
      voCollectionNode = eval(voCollectionNode);
      vnLoop = voCollectionNode.length;
    } else {
      vnLoop = 0;
    }
  } else {
    voCollectionNode = this.data.getNodesetData();
    if(!voCollectionNode) vnLoop = 0;
    else vnLoop = voCollectionNode.size();
  }
  this.lastId = vnLoop;
  // yhkim 2009.05.18 Paging Data
  if (this.cfg.paging == "fast") {
    // yhkim 2009.08.29 page + 1 를 해줘야 전체가 보임
    var vnPageCnt = parseInt(vnLoop / this.cfg.pageLength);
    if(vnLoop > 0 && vnPageCnt == 0) vnPageCnt = 1;
    var vsTemp = "<Body>";
    for ( var i = 0; i < vnPageCnt; i++)
      vsTemp = vsTemp + "<B/>";
    vsTemp = vsTemp + "</Body>";
    this.template["Body"] = vsTemp;
    return;
  } else {
    vsBody = "<Body><B>";
    vsBody = vsBody + this.makeRowData(voCollectionNode, 0, vnLoop);
    vsBody = vsBody + "</B></Body>";
    this.template["Body"] = vsBody;
  }
};
/**
 * load data from dataset
 * @param {HTMLDocument} poDocument 윈도우 document
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.loadDataFromDataSet = function(poDocument, pbKeepStatus) {
  var vnLoop = 0, voDataSet = null;
  if (this.dataset){
    voDataSet = this.dataset;
  }else {
    voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
  }
  if (voDataSet && !pbKeepStatus) {
    voDataSet.rebuild(false);
  }

  if(this.hideInitRow === true && this.init === true){
    var vbSync = voDataSet.isDataSync();
    if(!vbSync) voDataSet.setDataSync(true);
    voDataSet.reset(true);
    voDataSet.setDataSync(vbSync);

    this.init = false;
  }

  if(voDataSet) vnLoop = voDataSet.getRowCnt();
  this.lastId = vnLoop;

  // Grouping과 Sourting 처리
  var vaSortItem, vsColRef = null;
  var i, j, k = 0;
  var vaSortCols, vaSortTypes = null;
  if(this.cfg.grouping && this.cfg.groupCols) {
  this.cfg.groupCols = this.cfg.groupCols.replace(/\s+/g, ""); // eXria.util.StringUtil.trim 얘는 한글자만 적용됨
  var vaGroupCols = this.cfg.groupCols.split(",");
    for(i=0;i<vaGroupCols.length;i++) {
      vaColRefAndTextFlag = this.getColRefAndTextFlag(vaGroupCols[i]);
      vaSortItem = new Array();
      vaSortItem[0] = vaColRefAndTextFlag[0];
      vaSortItem[1] = vaColRefAndTextFlag[1];
      vaSortItem[2] = true;  // GroupMain 칼럼은 디폴트로 올림차순으로 동작
      this.sortList[i] = vaSortItem;
    }
  }
    if(this.cfg.sorting) {
      if(this.sortUser) {
        vaSortCols = this.sortColsUser;
        vaSortTypes = this.sortTyepsUser;
      } else if (this.cfg.sortCols && this.cfg.sortTypes) {
        vaSortCols = this.cfg.sortCols.split(",");
        vaSortTypes = this.cfg.sortTypes.split(",");
      }
      if(vaSortCols) {
        for(j=0;j<vaSortCols.length;j++) {
          if(vaSortCols[j] == this.cfg.groupMain) {   // GroupMain 칼럼에 대한 Sorting 지정
            vaColRefAndTextFlag = this.getColRefAndTextFlag(vaSortCols[j]);
            if(vaColRefAndTextFlag) { // 해당 칼럼에 데이타가 하나도 없을 경우의 오류발생 제거
              if((vaSortTypes[j]&1) == 0) {
                vaSortItem = new Array();
                vaSortItem[0] = vaColRefAndTextFlag[0];
                vaSortItem[1] = vaColRefAndTextFlag[1];
                vaSortItem[2] = true;
                this.sortList[0] = vaSortItem;
              } else {
                vaSortItem = new Array();
                vaSortItem[0] = vaColRefAndTextFlag[0];
                vaSortItem[1] = vaColRefAndTextFlag[1];
                vaSortItem[2] = false;
                this.sortList[0] = vaSortItem;
              }
            }
          } else {         // GroupMain 이외의 칼럼에 대한 Sorting 지정
            vaColRefAndTextFlag = this.getColRefAndTextFlag(vaSortCols[j]);
            if(vaColRefAndTextFlag) { // 해당 칼럼에 데이타가 하나도 없을 경우의 오류발생 제거
              if((vaSortTypes[j]&1) == 0) {
                vaSortItem = new Array();
                vaSortItem[0] = vaColRefAndTextFlag[0];
                vaSortItem[1] = vaColRefAndTextFlag[1];
                vaSortItem[2] = true;
                this.sortList[j] = vaSortItem;
              } else {
                vaSortItem = new Array();
                vaSortItem[0] = vaColRefAndTextFlag[0];
                vaSortItem[1] = vaColRefAndTextFlag[1];
                vaSortItem[2] = false;
                this.sortList[j] = vaSortItem;
              }
            }
          }
        }
      }
    }
    voDataSet.clearSortItem();
    for(k=0; k<this.sortList.length; k++) {
      voDataSet.setSortItem(this.sortList[k][0], this.sortList[k][1], this.sortList[k][2]);
    }
    try {
      voDataSet.sort();
    } catch(err) {}
//    this.sortUser = false;
//    this.sortColsUser = null;
//    this.sortTyepsUser = null;


  // yhkim 2009.05.18 Paging Data
  if (this.cfg.paging == "fast") {
    // yhkim 2009.08.29 page + 1 를 해줘야 전체가 보임
    var vnPageCnt = parseInt(vnLoop / this.cfg.pageLength, 10) + 1;
    var vsTemp = "<Body>";
    for ( var i = 0; i < vnPageCnt; i++)
      vsTemp = vsTemp + "<B/>";
    vsTemp = vsTemp + "</Body>";
    this.template["Body"] = vsTemp;
    return;
  } else {
    vsBody = "<Body><B>";
    // yhkim 2009.05.18 공통함수 분리 ( 1 > dataset은 1부터 시작)
    vsBody = vsBody + this.makeRowData(voDataSet, 1, vnLoop);
    vsBody = vsBody + "</B></Body>";
    this.template["Body"] = vsBody;
  }
};
/**
 * Row의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.ColsRow|eXria.controls.xhtml.GridEx.FootRow} poRow row object
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveRowColor = function(poRow, psColor){
  var vsRowType = this.getRowType(poRow);
  switch(vsRowType){
    case this.RowType.HeadRow :
      return this.saveHeadRowColor(poRow, psColor)
      break;
    case this.RowType.BodyRow :
      return this.saveBodyRowColor(poRow, psColor);
      break;
    case this.RowType.FootRow :
      return this.saveFootRowColor(poRow, psColor);
      break;
  }
};
/**
 * HeadRow의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.ColsRow} poRow row object
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveHeadRowColor = function(poRow, psColor){
  if(!this.colorData) this.colorData = new eXria.controls.xhtml.GridEx.ColorData();
  var vnIdx = this.getIndexOfHeadRow(poRow);
  var sections = this.grid.GetSections();
  var nSec = sections[0];
  var colID = this.grid.GetFirstCol(nSec);
  var voColumn = this.getFunctionColumn(poRow, null, colID);

  var voRowData = null;
  if(this.colorData.getHeaderRowData(voColumn.id)){
    voRowData = this.colorData.getHeaderRowData(voColumn.id);
    voRowData.rowColor = psColor;
  }else{
    voRowData = new eXria.controls.xhtml.GridEx.ColorData.RowData();
    voRowData.columnId = voColumn.id;
    voRowData.rowColor = psColor;
    this.colorData.headColorData.push(voRowData);
  }
};
/**
 * FootRow의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.FootRow} poRow row object
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveFootRowColor = function(poRow, psColor){
  if(!this.colorData) this.colorData = new eXria.controls.xhtml.GridEx.ColorData();
  var sections = this.grid.GetSections();
  var nSec = sections[0];
  var colID = this.grid.GetFirstCol(nSec);
  var voColumn = this.getFootColumn(poRow, null, colID);

  var voRowData = null;
  if(this.colorData.getFooterRowData(voColumn.id)){
    voRowData = this.colorData.getFooterRowData(voColumn.id);
    voRowData.rowColor = psColor;
  }else{
    voRowData = new eXria.controls.xhtml.GridEx.ColorData.RowData();
    voRowData.columnId = voColumn.id;
    voRowData.rowColor = psColor;
    this.colorData.footColorData.push(voRowData);
  }
};
/**
 * BodyRow의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.ColsRow} poRow row object
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveBodyRowColor = function(poRow, psColor){
  if(this.dataset == null) return;
  var vsPK = this.dataset.getPrimaryKeys("");
  if(!vsPK || vsPK == "") return;

  if(typeof(poRow) == "Number"){
    if(this.getRowType(poRow) == this.RowType.BodyRow) poRow = this.getRowIndex();
    else return;
  }

  if(!this.colorData) this.colorData = new eXria.controls.xhtml.GridEx.ColorData();

  var vaPK = vsPK.split(",");

  var vaPrimaryKeys = this.colorData.primaryKeys;

  for(var i=0; i<vaPK.length; i++){
    if(vaPK[i] != "") vaPrimaryKeys[i] = vaPK[i].split(":")[0];
  }

  var voRowData = null;

  var vnRowIdx = this.getIndexOfRow(poRow);

  var vmPrimaryKeys = new eXria.data.ArrayMap();

  for(var i=0, il=vaPrimaryKeys.length; i<il; i++){
    var vsKeyValue = this.dataset.get(vnRowIdx+1, vaPrimaryKeys[i]);
    if(vsKeyValue == "") return;
    vmPrimaryKeys.put(vaPrimaryKeys[i], vsKeyValue);
  }

  if(this.getRowColorData(vmPrimaryKeys) != null){
    voRowData = this.getRowColorData(vmPrimaryKeys);
    voRowData.rowColor = psColor;
  }else{
    voRowData = new eXria.controls.xhtml.GridEx.ColorData.RowData();
    voRowData.primaryKeyValues = vmPrimaryKeys;
    voRowData.rowColor = psColor;
    this.colorData.bodyColorData.push(voRowData);
  }
};
/**
 * Cell의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.ColsRow|eXria.controls.xhtml.GridEx.FootRow} poRow row object
 * @param {String} psCol column id
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveCellColor = function(poRow, psCol, psColor){
  var vsRowType = this.getRowType(poRow);
  switch(vsRowType){
    case this.RowType.HeadRow :
      return this.saveHeadCellColor(poRow, psCol, psColor)
      break;
    case this.RowType.BodyRow :
      return this.saveBodyCellColor(poRow, psCol, psColor);
      break;
    case this.RowType.FootRow :
      return this.saveFootCellColor(poRow, psCol, psColor);
      break;
  }
};
/**
 * HeadCell의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.ColsRow} poRow row object
 * @param {String} psCol column id
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveHeadCellColor = function(poRow, psCol, psColor){
  if(!this.colorData) this.colorData = new eXria.controls.xhtml.GridEx.ColorData();
  var vnIdx = this.getIndexOfHeadRow(poRow);
  var sections = this.grid.GetSections();
  var nSec = sections[0];
  var colID = this.grid.GetFirstCol(nSec);
  var voColumn = this.getFunctionColumn(poRow, null, colID);

  var voRowData = null;
  if(this.colorData.getHeaderRowData(voColumn.id)){
    voRowData = this.colorData.getHeaderRowData(voColumn.id);
    voRowData.columnsColor.put(psCol, psColor);
  }else{
    voRowData = new eXria.controls.xhtml.GridEx.ColorData.RowData();
    voRowData.columnId = voColumn.id;
    voRowData.columnsColor.put(psCol, psColor);
    this.colorData.headColorData.push(voRowData);
  }
};
/**
 * BodyCell의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.ColsRow} poRow row object
 * @param {String} psCol column id
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveBodyCellColor = function(poRow, psCol, psColor){
  if(this.dataset == null) return;
  var vsPK = this.dataset.getPrimaryKeys("");
  if(!vsPK || vsPK == "") return;

  if(typeof(poRow) == "Number"){
    if(this.getRowType(poRow) == this.RowType.BodyRow) poRow = this.getRowIndex();
    else return;
  }

  if(!this.colorData) this.colorData = new eXria.controls.xhtml.GridEx.ColorData();

  var vaPK = vsPK.split(",");

  var vaPrimaryKeys = this.colorData.primaryKeys;

  for(var i=0; i<vaPK.length; i++){
    if(vaPK[i] != "") vaPrimaryKeys[i] = vaPK[i].split(":")[0];
  }

  var voRowData = null;

  var vnRowIdx = this.getIndexOfRow(poRow);

  var vmPrimaryKeys = new eXria.data.ArrayMap();

  for(var i=0, il=vaPrimaryKeys.length; i<il; i++){
    var vsKeyValue = this.dataset.get(vnRowIdx+1, vaPrimaryKeys[i]);
    if(vsKeyValue == "") return;
    vmPrimaryKeys.put(vaPrimaryKeys[i], vsKeyValue);
  }

  if(this.getRowColorData(vmPrimaryKeys) != null){
    voRowData = this.getRowColorData(vmPrimaryKeys);
    voRowData.columnsColor.put(psCol, psColor);
  }else{
    voRowData = new eXria.controls.xhtml.GridEx.ColorData.RowData();
    voRowData.primaryKeyValues = vmPrimaryKeys;
    voRowData.columnsColor.put(psCol, psColor);
    this.colorData.bodyColorData.push(voRowData);
  }
};
/**
 * FootCell의 색상 변경정보를 저장한다.
 * @param {eXria.controls.xhtml.GridEx.FootRow} poRow row object
 * @param {String} psCol column id
 * @param {String} psColor 색상값
 */
eXria.controls.xhtml.GridEx.prototype.saveFootCellColor = function(poRow, psCol, psColor){
  if(!this.colorData) this.colorData = new eXria.controls.xhtml.GridEx.ColorData();
  var sections = this.grid.GetSections();
  var nSec = sections[0];
  var colID = this.grid.GetFirstCol(nSec);
  var voColumn = this.getFootColumn(poRow, null, colID);

  var voRowData = null;
  if(this.colorData.getFooterRowData(voColumn.id)){
    voRowData = this.colorData.getFooterRowData(voColumn.id);
    voRowData.columnsColor.put(psCol, psColor);
  }else{
    voRowData = new eXria.controls.xhtml.GridEx.ColorData.RowData();
    voRowData.columnId = voColumn.id;
    voRowData.columnsColor.put(psCol, psColor);
    this.colorData.footColorData.push(voRowData);
  }
};
/**
 * Row의 Color정보를 획득한다.
 * @param {eXria.data.ArrayMap} pmPrimaryKeys primary key map
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getRowColorData = function(pmPrimaryKeys){
  if(!this.colorData) return null;
  var vaDataRows = this.colorData.bodyColorData;
  var retData = null;
  var vaKeys = this.colorData.primaryKeys;
  for(var i=0, il=vaDataRows.length; i<il; i++){
    var vbData = true;
    var vaKeyValues = vaDataRows[i].primaryKeyValues;

    for(j=0, jl=vaKeys.length; j<jl;j++){
      if(vaKeyValues.get(vaKeys[j]) != pmPrimaryKeys.get(vaKeys[j])) vbData = false;
    }
    if(vbData) retData = vaDataRows[i];
  }
  return retData;
};
/**
 * Row의 색상정보들을 설정하여 문자열로 반환한다.
 * @param {Number} pnIndex row index
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.makeRowColorData = function(pnIndex){
  var vsColor = "";
  if(!this.colorData) return null;
  var vaColId = this.colorData.primaryKeys;
  var vmPrimaryKeyValues = new eXria.data.ArrayMap();
  var voDataset = this.canvas.page.model.getDataSet(this.datasetId);
  for(var i=0, il=vaColId.length; i<il;i++){
    var vsValue = voDataset.get(pnIndex, vaColId[i]);
    vmPrimaryKeyValues.put(vaColId[i], vsValue);
  }
  var voRowColorData = this.getRowColorData(vmPrimaryKeyValues);
  if(voRowColorData == null) return null;

  if(voRowColorData.rowColor) vsColor = vsColor + " Color='" + this.getRGBValue(voRowColorData.rowColor) + "'";
  var vaColumnColor = voRowColorData.columnsColor.getEntries();
  for(var vsCol in vaColumnColor){
    if(vaColumnColor[vsCol]) vsColor = vsColor + " " + vsCol + "Color='" + this.getRGBValue(vaColumnColor[vsCol]) + "'";
  }
  return vsColor;
};
/**
 * HeadRow의 색상정보들을 설정하여 문자열로 반환한다.
 * @param {String} psColId column id
 */
eXria.controls.xhtml.GridEx.prototype.makeHeaderRowColorData = function(psColId){
  var vsColor = "";
  if(!this.colorData) return vsColor;
  var voRowColorData = this.colorData.getHeaderRowData(psColId);
  if(voRowColorData == null) return vsColor;

  if(voRowColorData.rowColor) vsColor = vsColor + " Color='" + this.getRGBValue(voRowColorData.rowColor) + "'";
  var vaColumnColor = voRowColorData.columnsColor.getEntries();
  for(var vsCol in vaColumnColor){
    if(vaColumnColor[vsCol]) vsColor = vsColor + " " + vsCol + "Color='" + this.getRGBValue(vaColumnColor[vsCol]) + "'";
  }
  return vsColor;
};
/**
 * FootRow의 색상정보들을 설정하여 문자열로 반환한다.
 * @param {String} psColId column id
 */
eXria.controls.xhtml.GridEx.prototype.makeFooterRowColorData = function(psColId){
  var vsColor = "";
  if(!this.colorData) return vsColor;
  var voRowColorData = this.colorData.getFooterRowData(psColId);
  if(voRowColorData == null) return vsColor;

  if(voRowColorData.rowColor) vsColor = vsColor + " Color='" + this.getRGBValue(voRowColorData.rowColor) + "'";
  var vaColumnColor = voRowColorData.columnsColor.getEntries();
  for(var vsCol in vaColumnColor){
    if(vaColumnColor[vsCol]) vsColor = vsColor + " " + vsCol + "Color='" + this.getRGBValue(vaColumnColor[vsCol]) + "'";
  }
  return vsColor;
};
/**
 * makeData
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.makeData = function(){
  // data 구성
  var vsDataData = "";
  vsDataData = this.template["Start"];
//  if(pbReloadData){
//    vsDataData = vsDataData + this.template["Cfg"] + this.template["Header"];
//  }
//  vsDataData = vsDataData + this.template["Def"]
//yhkim 2009.05.19 head 컬럼
  vsDataData = vsDataData + this.template["FunctionColumn"];;
  vsDataData = vsDataData + this.template["Body"];
  vsDataData = vsDataData + this.template["Footer"];
  vsDataData = vsDataData + this.template["End"];

  this.templateData = vsDataData;
  vsDataData = null;
};
/**
 * 모든 로딩이 완료된 이후의 최종 처리
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.loadComplete = function(poDocument) {

    this.setStyleCurrentBorderValue(this);
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;

    this.ctrl.style["width"] = this.innerWidth + "px";
    this.ctrl.style["height"] = this.innerHeight + "px";

    var D = new this.window.TDataIO();
    D.Defaults.Url = this.defaultFileName;
    D.Text.Url = this.textFileName;
    D.Cache = this.cacheResource;
    D.Layout.Data = this.templateLayout;
    D.Data.Data = this.templateData;
    D.Page.Url = "getData";
    D.Page.Format = "Internal";
    D.Page.Data = "TGData";
    D.Debug = "";
//  newWin=window.open('','','toolbar=no,scrollbars=no,width=300,height=150,left=300,top=200');
//  newWin.document.open('text/html','replace');
//  newWin.document.write(D.Layout.Data);
//  newWin.document.close();

//    alert(D.Layout.Data);
//    alert(this.templateData);
    this.rendering = true;
    this.grid = this.window.TreeGrid(D, this.id, this.id, null, null);
    this.grid.GridEx = {};
    this.grid.GridEx.control = this;
};
/**
 * 데이타 영역(body)을 새로고침
 * @param {HTMLDocument} poCtrl 실체화 객체 (생략가능)
 * @param {HTMLDocument} poDocument 윈도우 document 객체 (생략가능)
 * @param {Boolean} pbKeepStatus 데이타셋 바인딩시 rebuild 여부
 * @param {Boolean} pbReRender 데이타 영역에 대한 rerendering 여부
 */
eXria.controls.xhtml.GridEx.prototype.refreshData = function(poCtrl, poDocument, pbKeepStatus, pbReRender) {
//  if(this.cfg.idColumn != null) {
//    this.refresh(poDocument, pbKeepStatus, null, true);
//    return;
//  }
  if(!this.isRendered) {
    var base = this;
    this.window.setTimeout(function(){base.refreshData();}, 100);
    return;
  }
  this.isRendered = false;
  this.grid.Focus(null, null);
  this.grid.LastId = "";
  this.templateData = null;
  if(this.datasetId == null) {
    if(page.metadata.useJsonInstance) this.data.setNodesetRef(this.data.nodesetInstanceId, this.data.nodesetInstancePath);
    this.loadDataFromInstance(this.document);
    this.loadFunctionColumnDataFromInstance();
    this.loadFooterDataFromInstance();
    this.makeData();
  } else {
    this.dataset = this.canvas.page.model.getDataSet(this.datasetId);
    this.loadDataFromDataSet(this.document, pbKeepStatus);
    this.loadFunctionColumnDataFromInstance();
    this.loadFooterDataFromInstance();
    this.makeData();
  }

  this.checkRender(pbReRender);
};
/*
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.resize = function() {
  if(this.isResize === false) {
    this.refreshPos();
    return;
  }
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.ctrl.style["left"] = this.left + "px";
  this.ctrl.style["top"] = this.top + "px";
  this.ctrl.style["width"] = this.innerWidth + "px";
  this.ctrl.style["height"] = this.innerHeight + "px";
};
/*
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.checkRender = function(pbReRender){
//  if(this.rendering == true){
//    var voGrid = this;
//    this.window.setTimeout(function(){voGrid.checkRender();}, 100);
//  }else{
    this.refreshDataComplete(this.document, pbReRender);
//  }
};
/**
 * 데이타 새로고침에 대한 최종 처리
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.refreshDataComplete = function(poDocument, pbReRender) {
  if(this.grid) {
//    alert(this.templateData);
    this.Initialize();
    this.focusRow = null;
    this.focusCol = null;
    if(this.templateData) this.grid.Data.Data.Data = this.templateData;
    if(pbReRender == null) pbReRender = true;
    this.grid.ReloadBody(null, pbReRender);
  } else {
    alert("GridEx create error. please refresh page.");
  }
};

eXria.controls.xhtml.GridEx.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};

eXria.controls.xhtml.GridEx.prototype.refreshSpecificAttrs = function(poCtrl, poDocument, pbKeepSort, pbHideCol) {
  this.templateLayout = null;
  this.templateData = null;
  if(pbKeepSort == false) {
    this.sortUser = false;
    this.sortColsUser = null;
    this.sortTyepsUser = null;
    this.sortList.length = 0;
  }
  if(!pbHideCol) {
    this.hideColMap.clear();
  }
  this.createSubCtrl(poCtrl, poDocument);

  var vnCurInnerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth === vnCurInnerWidth) {    // 사용자 width의 값 변경이 없는경우
    if(poCtrl && poCtrl.style && poCtrl.style["width"])
    vnCurInnerWidth = poCtrl.style["width"].replace("px", "");
  }
  if(vnCurInnerWidth !== this.innerWidth) {
    if(this.colResizeDiff) this.setColumnDiffWidth(this.innerWidth, vnCurInnerWidth);  // this.innerWidth는 Old값
    this.innerWidth = vnCurInnerWidth;
  }

  var vnCurInnerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight === vnCurInnerHeight) {  // 사용자  height의 값 변경이 없는경우
    if(poCtrl && poCtrl.style && poCtrl.style["height"])
    vnCurInnerHeight = poCtrl.style["height"].replace("px", "");
  }
  if(vnCurInnerHeight !== this.innerHeight) this.innerHeight = vnCurInnerHeight;

  this.setSpecificAttrs(poCtrl, poDocument);
};

eXria.controls.xhtml.GridEx.prototype.reloadData = function(poCtrl, poDocument, pbKeepStatus) {
  if(this.datasetId == null) {
    this.loadDataFromInstance(poDocument);
    this.loadFunctionColumnDataFromInstance();
    this.loadFooterDataFromInstance();
    this.makeData();
  } else {
    this.loadDataFromDataSet(poDocument, pbKeepStatus);
    this.loadFunctionColumnDataFromInstance();
    this.loadFooterDataFromInstance();
    this.makeData();
  }
};
/**
 * 새로고침에 대한 최종 처리
 */
eXria.controls.xhtml.GridEx.prototype.refreshComplete = function(poCtrl, poDocument) {
  if(this.grid) this.grid.Clear(1);
  if(this.grid) this.grid.Dispose(); // 기존 그리드 삭제
  if(this.grid) this.grid.DelIdentity();
  this.grid = null;
  this.focusRow = null;
  this.focusCol = null;

  var D = new this.window.TDataIO();
  D.Defaults.Url = this.defaultFileName;
  D.Text.Url = this.textFileName;
  D.Cache = this.cacheResource;
  D.Layout.Data = this.templateLayout;
  D.Data.Data = this.templateData;
  D.Page.Url = "getData";  // Paging fast시 Page.Url에 임의의 값이 설정되어 있어야 함.
  D.Page.Format = "Internal";
  D.Page.Data = "TGData";
  D.Debug = "";
//  alert("Layout\n" + this.templateLayout);
//  alert("Data\n" + this.templateData);
  this.rendering = true;
  var tag = this.ctrl;
  var id = this.id;
  this.grid = this.window.TreeGrid(D, tag, id, null, null, this);
  this.grid.GridEx = {};
  this.grid.GridEx.control = this;
};

eXria.controls.xhtml.GridEx.prototype.refresh = function(poDocument, pbKeepStatus, pbKeepSort, pbHideCol) {
  if(!this.isRendered) {
    var base = this;
    this.window.setTimeout(function(){base.refresh();}, 100);
    return;
  }
  this.isRendered = false;
  if(poDocument == null) poDocument = this.document;

  if(this.removeUIGeneralDefaults) { this.removeUIGeneralDefaults(this.ctrl, poDocument); };           // 공통 초기값으로 지정된 속성값을 제거
  if(this.removeSpecificDefaults) { this.removeSpecificDefaults(this.ctrl, poDocument); };             // 개별 초기값으로 지정된 속성값을 제거

  if(this.refreshTemplate) { this.refreshTemplate(this.ctrl, poDocument); };
  if(this.refreshMainStyles) { this.refreshMainStyles(this.ctrl, poDocument); };                       // Main Style 새로고침
  if(this.refreshSubStyles) { this.refreshSubStyles(this.ctrl, poDocument); };                         // Composite Child Style 새로고침

  if(this.refreshUIGeneralDefaults) { this.refreshUIGeneralDefaults(this.ctrl, poDocument); };         // 공통 초기값으로 새로고침
  if(this.refreshSpecificDefaults) { this.refreshSpecificDefaults(this.ctrl, poDocument); };           // 개별 초기값으로 새로고침

  if(this.refreshSpecificAttrs) { this.refreshSpecificAttrs(this.ctrl, poDocument, pbKeepSort, pbHideCol); };                 // 개별 속성으로 새로고침

  if(this.refreshSpecificEvents) { this.refreshSpecificEvents(this.ctrl); };                           // 개별 Events로 새로고침

  if(this.reloadData) { this.reloadData(this.ctrl, poDocument, pbKeepStatus); };                       // Data 새로고침
  if(this.refreshComplete) {this.refreshComplete(this.ctrl, poDocument); };                            // 새로고침 최종 처리
};
/**
 * treegrid body reload 메소드
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.reloadBody = function() {
  if(this.grid) {
    var vbResult = this.grid.ReloadBody(null, true);
    return vbResult;
  } else {
    alert("GridEx create error. please refresh page");
  }
};
/**
 * treegrid reload 메소드
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.reload = function() {
  if(this.grid) {
    var vbResult = this.grid.Reload(null,this.id,this);
    return vbResult;
  } else {
    alert("GridEx create error. please refresh page");
  }
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type String|Number
 */
eXria.controls.xhtml.GridEx.prototype.getSpecificDefaultValue = function(psAttrName) {
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if (vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.GridEx[psAttrName];
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.GridEx[vaAttrName[0]][vaAttrName[1]] != null ? eXria.controls.xhtml.Default.GridEx[vaAttrName[0]][vaAttrName[1]] : vsDefaultValue;
  }

  if(vsDefaultValue === undefined) {
    return null;
  }

  return vsDefaultValue;
};

/**
 * 클래스 명을 반환합니다.
 * @return "GridEx"
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.toString = function() {
  return "GridEx";
};
/**
 * 16진수형태의 색상 값을 255,255,255 형태의 문자열 값으로 변환하는 메소드
 * @param {String} psValue 16진수형태의 color 값
 * @return 255,255,255 형태의 색상 문자열 값
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getRGBValue = function(psValue) {
  var colorHexCode = parseInt(psValue.substr(1), 16);
  var red = (colorHexCode & 0xff0000) >> 16;
  var green = (colorHexCode & 0xff00) >> 8;
  var blue = (colorHexCode & 0xff);
  return (red + "," + green + "," + blue);
};
/**
 * 문자열 값을 xml 문자열로 변환하는 메소드
 * @param {String} pValue 문자열
 * @param {Number} pnQuotMark 문자열을 감싸는 따움표 종료를 구분짓는 정수 값
 * @return xml 문자열
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getXml = function(pValue, pnQuotMark) {
  var t = typeof(pValue);
  var v = "";
  if(pnQuotMark == 1) {
    if(t=="string") v = "'"+pValue.replace(/\&/g,"&amp;").replace(/\"/g,"&quot;").replace(/\</g,"&lt;").replace(/\>/g,"&gt;").replace(/\n/g,"&#x0A;")+"'";
    else if(t=="number") v = "'"+pValue+"'";
    else if(t=="boolean") v = "'"+(pValue?1:0)+"'";
  } else if(pnQuotMark == 2) {
    if(t=="string") v = "\""+pValue.replace(/\&/g,"&amp;").replace(/\"/g,"&quot;").replace(/\</g,"&lt;").replace(/\>/g,"&gt;").replace(/\n/g,"&#x0A;")+"\"";
    else if(t=="number") v = "\""+pValue+"\"";
    else if(t=="boolean") v = "\""+(pValue?1:0)+"\"";
  } else {
    if(t=="string") v = pValue.replace(/\&/g,"&amp;").replace(/\"/g,"&quot;").replace(/\</g,"&lt;").replace(/\>/g,"&gt;").replace(/\n/g,"&#x0A;");
    else if(t=="number") v = pValue;
    else if(t=="boolean") v = pValue?1:0;
  }
  return v;
};
/**
 * 문자열 값을 xml value 문자열로 변환하는 메소드
 * @param {String|Number|Boolean} pValue 문자열
 * @type String
 * @return xml value 문자열
 */
eXria.controls.xhtml.GridEx.prototype.getXmlValue = function(pValue) {
  var t = typeof(pValue);
  var v = null;
  if(t=="string") v = "\""+pValue.replace(/\&/g,"&amp;").replace(/\</g,"&lt;").replace(/"/g,"&quot;").replace(/\n/g,"&#x0A;")+"\"";
  else if(t=="number") v = "\""+pValue+"\"";
  else if(t=="boolean") v = "\""+(pValue?1:0)+"\"";
  return v;
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.stringToXml = function(psValue){
  if(typeof(psValue)!="string" || psValue.search(/[\&\"\<\>\n]/)<0) return psValue;
  return psValue.replace(/\&/g,"&amp;").replace(/\"/g,"&quot;").replace(/\</g,"&lt;").replace(/\>/g,"&gt;").replace(/\n/g,"&#x0A;");
};

/////////////////////////////////////////////////////////////////
// Value 관련 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.valueToString = function(poValue, pnType, psFormat) {
  if(this.grid) return this.grid.ValueToString(poValue, pnType, psFormat);
  else alert("valueToString call Error");
};
/**
 * Cell 값을 문자열 형태로 반환하는 메소드
 * @param {Object} poRow row object
 * @param {String} psColId column id
 */
eXria.controls.xhtml.GridEx.prototype.getString = function(poRow, psCol) {
  if(this.grid){
    var vsString = this.grid.GetString(poRow, psCol);
    vsString = this.convertStringExria(poRow, psCol, vsString);
    return vsString;
  }else{
    alert("getString call Error");
  }
};
/**
 * Cell 값을 반환하는 메소드
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @return cell value
 * @type String|Array(String)
 */
eXria.controls.xhtml.GridEx.prototype.getValue = function(poRow, psCol) {
  if(this.grid){
    var vsValue = this.grid.GetValue(poRow, psCol);
    var vsType = this.getType(poRow, psCol);
    switch(vsType){ 
      case "Int": 
      case "Float": 
      case "Date": 
        if(!vsValue) vsValue = (vsValue == "0") ? 0 : ""; 
        if(typeof(vsValue) != "string") vsValue = vsValue - 0;
        break;
      case "Bool": 
        if(vsValue==null || vsValue==="") vsValue = ""; 
        vsValue = (vsValue) ? vsValue-0 : 0;
        break;
      case "Radio": 
      case "Enum": 
        if(typeof(vsValue)=="number") vsValue = "" + vsValue;
        break;
      default:
        vsValue = (vsValue == null) ? "" : vsValue + "";
    }
    vsValue = this.convertValueExria(poRow, psCol, vsValue);
    return vsValue;
  }else{
    alert("getValue call Error");
  }
};
//Highgarden Start 090407
/**
 * TreeGrid의 Value를 eXria에 맞는 Format으로 반환
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @param {String} psValue Value
 * @return eXria에 맞는 Format으로 변환된 TreeGrid의 Value
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.convertValueExria = function(poRow, psCol, psValue) {
  if(poRow == null || psCol == null || psCol == undefined) return psValue;
  var vsType = this.getType(poRow, psCol);
  var vsRowType = this.getRowType(poRow);
  var voColumn = null;

  if(vsRowType == this.RowType.HeadRow) voColumn = this.getFunctionColumn(poRow, null, psCol);
  else if(vsRowType == this.RowType.BodyRow) voColumn = this.getBodyColumn(null, psCol);
  else if(vsRowType == this.RowType.FootRow) voColumn = this.getFootColumn(poRow, null, psCol);
  switch(vsType){
    case "Date" :
      if(psValue !== null && psValue !== ""){
        var voDate = new Date(psValue);
        var vsYear = voDate.getUTCFullYear() + "";
        // DateMask 추가코드
        var vsMonth = (voDate.getUTCMonth() + 1) + "";
        var vsDate = voDate.getUTCDate() + "";
        var vsHour = voDate.getUTCHours() + "";
        var vsMinute = voDate.getUTCMinutes() + "";
        var vsSecond = voDate.getUTCSeconds() + "";
        if(vsMonth.length == 1) vsMonth = "0" + vsMonth;
        if(vsDate.length == 1) vsDate = "0" + vsDate;
        if(vsHour.length == 1) vsHour = "0" + vsHour;
        if(vsMinute.length == 1) vsMinute = "0" + vsMinute;
        if(vsSecond.length == 1) vsSecond = "0" + vsSecond;
        var vsRetValue = psValue;
        var vsRegFormat = null;
        var vsRegMast = null
        var vsNoFormat = null;
        var vsNoMask = null;
        //getValue 시에 format 에서 mask 형식으로 수정 13.8.9 박상찬
        if(voColumn.regMask) {
//          vsRegFormat = voColumn.regFormat;
//          vsNoFormat = vsRegFormat.replace(/[^ymdhs]/gi, "");
          vsRegMast = voColumn.regMask;
          vsNoMask = vsRegMast.replace(/[^ymdhs]/gi, "");
          if(vsNoMask.length == 14) voColumn.dateType = "DateTime";
          else if(vsNoMask.length == 8) voColumn.dateType = "Date";
          else if(vsNoMask.length == 6) voColumn.dateType = "Time";
        }
        if(voColumn.dateType == "DateTime") vsRetValue = vsYear + vsMonth + vsDate + vsHour + vsMinute + vsSecond;
        else if(voColumn.dateType == "Date") vsRetValue = vsYear + vsMonth + vsDate;
        else if(voColumn.dateType == "Time") vsRetValue = vsHour + vsMinute + vsSecond;
        return vsRetValue;
      }else{
        return psValue;
      }
      break;
    case "Enum" :
      // 허용운 추가코드
      /*
      var vaEnumKeys = null;
      vaEnumKeys = Get(poRow, psCol + "EnumKeys").split('|');// this.grid.GetEnumKeys(poRow, psCol);

      if(vaEnumKeys) vaEnumKeys = vaEnumKeys.slice(1);
      if(psValue !== "" && vaEnumKeys) psValue = vaEnumKeys[psValue];*/


      /*
      // 허용운 추가코드
      var vaEnumKeys = null;
      vaEnumKeys = Get(poRow, psCol + "EnumKeys").split('|');// this.grid.GetEnumKeys(poRow, psCol);
      vaEnumKeys = vaEnumKeys.slice(1);
      for(var i=0, il=vaEnumKeys.length; i<il; i++){
        if(vaEnumKeys[i] == psValue){
          vsRetValue = i;
          break;
        }
      }
      */

      return psValue;
      break;
    case "Radio" :
    case "CheckBox" :
      var vaRet = new Array();
      if(psValue == "") return null;
      var vaValues = voColumn.itemgroup.getItemValuesToArray();
      var vaLabels = voColumn.itemgroup.getItemLabelsToArray();

      var getMatchValue = function(pnIdx){
        return vaValues[pnIdx];
      }

      var vaTreeLabels = String(psValue).split(";");
      var vaRet = [];
      for(var i=0; i<vaTreeLabels.length; i++) {
        for(var j=0; j<vaLabels.length; j++)
          if(vaTreeLabels[i] == vaLabels[j])
            vaRet.push(vaValues[j]);
      }
      var vsRet = vaRet.join(",");
      // radio일 경우에 초기값 설정이 없는 경우와 있는 경우에 따라서 value를 가져오는 방식이 상이해서
      // 아래의 조건문 처럼 경우수를 한가지 더 넣음(실제로는 treegrid의 버그임)
      if(psValue !== null && psValue !== "" && vsRet == "") {
        if(getMatchValue(psValue) != undefined) vaRet.push(getMatchValue(psValue));
      }
      return vaRet;
      break;
    case "Bool" :
      if(psValue === 0) return "false";
      else if(psValue === 1) return "true";
    default :
      if(voColumn) {
        if(vsType == "Text" && voColumn.mask) {
          psValue = this.getOrgValueFromMask(String(psValue), voColumn.mask);
        } else if(vsType == "Text" && typeof(psValue) == "number") {
          psValue += "";
        }
      }
      return psValue;
      break;
  }

};
/**
 * TreeGrid의 String을 eXria에 맞는 Format으로 반환
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.convertStringExria = function(poRow, psCol, psString){
  if(poRow == null || psCol == null || psCol == undefined) return psString;
  var vsType = this.getType(poRow, psCol);
  var vsRowType = this.getRowType(poRow);
  var voColumn = null;
  var vsValue = this.getValue(poRow, psCol);

  if(vsRowType == this.RowType.HeadRow) voColumn = this.getFunctionColumn(poRow, null, psCol);
  else if(vsRowType == this.RowType.BodyRow) voColumn = this.getBodyColumn(null, psCol);
  else if(vsRowType == this.RowType.FootRow) voColumn = this.getFootColumn(poRow, null, psCol);
  switch (vsType) {
    case "Enum" :
      if(vsValue == "") return "";
      return psString;
      break;
    case "Radio" :
    case "CheckBox" :
      if(psString == "&nbsp") return "";
      break;
    default :
      return psString;
      break;
  }
};
/**
 * eXria의 Value를 TreeGrid에 맞는 Format으로 반환
 * @param {String} poColumn GridEx BodyColumn
 * @param {String} psValue Value
 * @return String
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.convertValueTGrid = function(poColumn, psValue, poRow, psColId) {
  if(poColumn == null) return psValue;

  switch(poColumn.type){
    case "Date" :
      var vnTime = "";
      if (psValue != "" && psValue != null) {
      // DateMask 추가코드
        var tempDate = new Date(this.addSeparator(psValue, 2, poRow, psColId));
        var ut = new Date(tempDate);
        var voDate = new Date(Date.UTC(ut.getFullYear(), ut.getMonth(), ut.getDate(), ut.getHours(), ut.getMinutes(), ut.getSeconds()));
        vnTime = voDate.getTime();
    }
      return vnTime;
      break;
    case "Bool" :
      if(psValue != null && psValue != "") {
        psValue = eval(psValue);
        return psValue;
      }
      break;
    case "Radio" :
    case "CheckBox" :
      if(psValue == null) return null; // 2009.12.01 yhkim(bug6398) 이 조건문 자체는 맨위로 가야할듯 하나 Date가 ""리턴하는 side-effect 문제로 이조건문에만 넣음 > 향후고려 필요
      var vaValues = poColumn.itemgroup.getItemValuesToArray();
      var getMatchValueIdx = function(psVal){
        for(var i=0; i<vaValues.length; i++){
          if(vaValues[i] == psVal) return i;
        }
        return false;
      }
//      if(typeof(psValue) == "string") psValue = new Array(psValue);
      if(typeof(psValue) == "string") psValue = psValue.split(",");

      vsRet = "";
      var vaAllValues = poColumn.itemgroup.getItemValuesToArray();
      var vaAllLabels = poColumn.itemgroup.getItemLabelsToArray();
      var vaSelectedValues = psValue;
      var vaSelectedLabels = [];
      for(var p=0; p< vaAllValues.length; p++) {
        for(var q=0; q<vaSelectedValues.length; q++)
        if(vaAllValues[p] == vaSelectedValues[q])
          vaSelectedLabels.push(vaAllLabels[p]);
      }
      vsRet = vaSelectedLabels.join(";");
      if(psValue !== null && psValue !== "" && vsRet == "") {
        vaSelectedLabels.push(getMatchValueIdx(psValue[psValue.length-1]));
        vsRet = vaSelectedLabels.join(";");
      }
      return vsRet;

      break;
    case "Enum" :
      // 허용운 추가코드
      var vsRetValue = "";

      var vaEnumKeys = Get(poRow, psColId + "EnumKeys").split('|');
      vaEnumKeys = vaEnumKeys.slice(1);
      for(var i=0, il=vaEnumKeys.length; i<il; i++){
        if(vaEnumKeys[i] == psValue){
          vsRetValue = i;
          break;
        }
      }
      return psValue;
      break;
    default :
      return psValue;
      break;
  }

};
//Highgarden End 090407
//HighGarden Modify 090420 Date 처리
/**
 * setString
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setString = function(poRow, psCol, psValue, pbRefresh) {
  if(this.grid){
    var vsOVal = this.getValue(poRow, psCol); // AfterValueChanged Event 를 위한 수정전 value 획득

    // TreeGrid는 UTC를 기준으로 Date를 처리하기 때문에 입력 값을 UTC 기준 시간으로 변환하여 입력해야 함
    if(this.getType(poRow, psCol) == "Date")
    {
      var vnlen = psValue.length;
      if(psValue.length == 14) {
        var vsYear = psValue.substring(0, 4);
        var vsMonth = psValue.substring(4, 6);
        var vsDay = psValue.substring(6, 8);
        var vsHour = psValue.substring(8, 10);
        var vsMinute = psValue.substring(10, 12);
        var vsSecond = psValue.substring(12, 14);
        psValue = Date.UTC(vsYear,vsMonth-1,vsDay,vsHour,vsMinute,vsSecond);
      } else if(psValue.length == 8) {
        var vsYear = psValue.substring(0, 4);
        var vsMonth = psValue.substring(4, 6);
        var vsDay = psValue.substring(6, 8);
        psValue = Date.UTC(vsYear,vsMonth-1,vsDay);
      } else if(psValue.length == 6) {
        var voNow = new Date();
        var vsYear = voNow.getUTCFullYear();
        var vsMonth = voNow.getUTCMonth();
        var vsDay = voNow.getUTCDate();
        var vsHour = psValue.substring(0, 2);
        var vsMinute = psValue.substring(2, 4);
        var vsSecond = psValue.substring(4, 6);
        var voNow = new Date();
        psValue = Date.UTC(vsYear,vsMonth,vsDay,vsHour,vsMinute,vsSecond);
      }
    }
    this.grid.SetString(poRow, psCol, psValue, pbRefresh);
    var vsNVal = this.getValue(poRow, psCol); // AfterValueChanged Event 를 위한 수정후 value 획득
    if(vsOVal !== vsNVal) this.enGridexAfterValueChanged(this.grid, poRow, psCol); // 두 값을 비교후 바뀌었을 경우 event 발생
  }else{
    alert("setString call Error");
  }
};
//yhkim 2009.05.08
/**
 * RightButton인 경우 (Normal또는Image) 타입에 따라 (image Path 또는 Button Text)와  Width 값을 설정한다
 * @param {Object} poRow row object
 * @param {String} psCol 현재 컬럼명
 * @param {String} psValue Image Path 또는 Button Text
 * @param {String} pnWidth 사이즈 (default:저장된 기본 설정값)
 * @param {Boolean} pbRefresh (default:true)
 */
eXria.controls.xhtml.GridEx.prototype.setRightButton = function(poRow, psCol, psValue, pnWidth, pbRefresh) {
  if(pnWidth != null)
    this.setRowAttribute(poRow, psCol, "WidthPad", String(pnWidth), 0);

  var voColumn = this.getBodyColumn(null, psCol);

  if(voColumn == null) return;
  if(voColumn.rightButton == null) return;

  if(voColumn.rightButton.type.toUpperCase() == "NORMAL") {
    this.setRowAttribute(poRow, psCol, "Button", "Button", pbRefresh);
    this.setRowAttribute(poRow, psCol, "ButtonText", psValue, pbRefresh);
  }
  else {
    if(psValue) {
    var vsBaseUrl = "";
    if(psValue.indexOf("http://") != -1) {
      psValue = psValue;
    }
    else {
      var vsBaseUrl = this.canvas.page.metadata.resourceBaseUrl;
      if(vsBaseUrl == "" || vsBaseUrl == null)
        psValue = psValue;
      else
        psValue = vsBaseUrl + psValue;
      }
    }

    this.setRowAttribute(poRow, psCol, "Button", psValue, pbRefresh);
  }
};
//yhkim 2009.05.08
/**
 * Button Type 컬럼에 Label값을 설정한다
 * @param {Object} poRow row object
 * @param {String} psCol 현재 컬럼명
 * @param {String} psValue 속성값
 * @param {Boolean} pbRefresh (default:true)
 */
eXria.controls.xhtml.GridEx.prototype.setButtonLabel = function(poRow, psCol, psValue, pbRefresh) {
  this.setRowAttribute(poRow, psCol, "Caption", psValue, pbRefresh);
};
/**
 * 내부사용 함수(Row의 특정컬럼에 추가속성을 설정한다)
 * @param {Object} poRow row object
 * @param {String} psCol 현재 컬럼명
 * @param {String} psAttr 컬럼명과 합쳐질 속성명
 * @param {String} psValue 속성값
 * @param {Boolean} pbRefresh 새로고침 여부
 * @private
 * //yhkim 2009.05.06
 */
eXria.controls.xhtml.GridEx.prototype.setRowAttribute = function(poRow, psCol, psAttr, psValue, pbRefresh) {
  var vsAttr = psCol + psAttr;

  poRow[vsAttr] = psValue;

  // default는 항상 Refresh
  if(pbRefresh == null || pbRefresh == true)
    this.refreshRow(poRow);
};
//HighGarden Modify 090420 Date 처리
/**
 * Cell value 설정
 * @param {Object} poRow row object
 * @param {String} psCol column id
 * @param {Object} poValue value
 * @param {Boolean} pbRefresh 화면 새로고침 여부
 * @param {Boolean} pbRowTypeChecked
 */
eXria.controls.xhtml.GridEx.prototype.setValue = function(poRow, psCol, poValue, pbRefresh, pbRowTypeChecked) {
  if(this.grid){
    var voColumn;

    if(!!pbRowTypeChecked){
      var vsRowType = this.getRowType(poRow);
      if(vsRowType == this.RowType.BodyRow){
        voColumn = this.getBodyColumn(null, psCol);
      }else if(vsRowType == this.RowType.HeadRow){
        voColumn = this.getFunctionColumn(poRow, null , psCol);
        voColumn.value = poValue;
      }else if(vsRowType == this.RowType.FootRow){
        voColumn = this.getFootColumn(poRow, null , psCol);
      }
    }else{
      voColumn = this.getBodyColumn(null, psCol);
    }

    var vsOVal = this.getValue(poRow, psCol); // AfterValueChanged Event 를 위한 수정전 value 획득
    poValue = this.convertValueTGrid(voColumn, poValue, poRow, psCol);
    if(this.grid.FRow && this.grid.FCol) this.grid.EndEdit(this.grid.FRow,this.grid.FCol,true);
    this.grid.SetValue(poRow, psCol, poValue, pbRefresh);
    var vsNVal = this.getValue(poRow, psCol); // AfterValueChanged Event 를 위한 수정후 value 획득
    if(vsOVal !== vsNVal) this.enGridexAfterValueChanged(this.grid, poRow, psCol); // 두 값을 비교후 바뀌었을 경우 event 발생
  }else{
    alert("setValue call Error");
  }
};

/**
 * Cell value 설정 (DataSet의 status를 변경하지 않고 단지 value만을 변경함)
 * @param {Object} poRow row object
 * @param {String} psCol column id
 * @param {Object} poValue value
 * @param {Boolean} pbRefresh 화면 새로고침 여부
 */
eXria.controls.xhtml.GridEx.prototype.simpleSetValue = function(poRow, psCol, poValue, pbRefresh) {
  if(this.grid){
    var voColumn = this.getBodyColumn(null, psCol);
    var vsOVal = this.getValue(poRow, psCol); // AfterValueChanged Event 를 위한 수정전 value 획득
    poValue = this.convertValueTGrid(voColumn, poValue, poRow, psCol);

    this.grid.SetValue(poRow, psCol, poValue, pbRefresh);

    var vsNVal = this.getValue(poRow, psCol); // AfterValueChanged Event 를 위한 수정후 value 획득
    if(vsOVal !== vsNVal) this.enGridexAfterValueChanged(this.grid, poRow, psCol, true); // 두 값을 비교후 바뀌었을 경우 event 발생
  }else{
    alert("setValue call Error");
  }
};

/**
 * Cell type 반환 메소드
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @return Cell type
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getType = function(poRow, psCol) {
  if(this.grid) return this.grid.GetType(poRow, psCol);
  else alert("getType call Error");
};
/**
 * getFormat
 * @param {Object} poRow row object
 * @param {String} psColId column id
 */
eXria.controls.xhtml.GridEx.prototype.getFormat = function(poRow, psCol, bEdit) {
  if(this.grid) return this.grid.GetFormat(poRow, psCol, bEdit);
  else alert("getFormat call Error");
};
/**
 * Cell에 지정된 Enum 반환
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @return Cell에 지정된 Enum
 * @type Array
 */
eXria.controls.xhtml.GridEx.prototype.getEnum = function(poRow, psCol) {
  if(this.grid) return Get(poRow, psCol+"Enum");
  else alert("getEnum call Error");
//  if(this.grid) return this.grid.GetEnum(poRow, psCol);
//  else alert("getEnum call Error");
};
/**
 * Enum에서 지정 value를 갖는 아이템의 인덱스 반환.
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @param {String} psValue value
 * @return Enum에서 지정 value를 갖는 아이템의 인덱스
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getEnumIndex = function(poRow, psColId, psValue) {
  if(this.grid){
    var vsRetValue = null;
    var vaEnumKeys = Get(poRow, psColId + "EnumKeys").split('|');
      vaEnumKeys = vaEnumKeys.slice(1);
      for(var i=0, il=vaEnumKeys.length; i<il; i++){
        if(vaEnumKeys[i] == psValue){
          vsRetValue = i;
          break;
        }
      }
      return vsRetValue;
  }else{alert("getEnumIndex call Error");}
};
/**
 * Cell의 편집 가능 여부를 반환하는 메소드.
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @return Cell의 편집 가능 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.canEdit = function(poRow, psColId) {
  if(this.grid) return this.grid.CanEdit(poRow, psColId);
  else alert("canEdit call Error");
};
/**
 * Cell의 focusing 가능 여부를 반환하는 메소드.
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @return Cell의 focusing 가능 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.canFocus = function(poRow, psColId) {
  if(this.grid) return this.grid.CanFocus(poRow, psColId);
  else alert("canFocus call Error");
};
/////////////////////////////////////////////////////////////////
//Cell 관련 메소드
/**
 * setColor
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setColor = function(poRow, psColId) {
  var voRow = this.getRowIndex(2);
  voRow[psColId+"Marked"]=true;
  this.grid.ShowRow(voRow);
  this.grid.ColorRow(voRow);
};
/**
 * 지정된 Cell에 focus를 주기 위한 메소드
 * @param {Object} poRow row object
 * @param {String} psCol column id
 * @param {Number} pnfocusPagePos 포커스될 페이지 위치
 * @param {Boolean} bShow 포커스될 페이지를 보여줄 지 여부
 * @return 포커싱 성공여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.focus = function(poRow, psCol, pnfocusPagePos , bShow) {
  if(this.grid) return this.grid.Focus(poRow, psCol, pnfocusPagePos , bShow);
  else alert("focus call Error");
};
/**
 * 지정된 Cell을 편집상태로 만들어 주기 위한 메소드
 * @param {Object} poRow row object
 * @param {String} psCol column id
 * @param {Boolean} pbNoRunEvent onGridexFocus를 발생 안 시킬지 여부
 */
eXria.controls.xhtml.GridEx.prototype.startEdit = function(poRow, psCol, pbNoRunEvent) {
  //yjcho 2009.09.17 Add
  if(this.grid) {
    this.canvas.setFocusByControl(this);
    this.noFocusEvent = pbNoRunEvent;
    this.grid.Focus(poRow, psCol);
    this.noFocusEvent = false;
    this.grid.StartEdit(poRow, psCol);
  }
};
/////////////////////////////////////////////////////////////////
//Row 관련 메소드
/**
 * 전체 행 삭제
 * DataSet과 연결
 */
eXria.controls.xhtml.GridEx.prototype.deleteAll = function() {
  this.grid.Focus(null, null);
  if(this.datasetId != null){
    var voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
    if(voDataSet){
      var vnDataCount = voDataSet.getRowCnt();
      for(; vnDataCount > 0; vnDataCount--){
        voDataSet.deleteRow(vnDataCount);
      }
    }

  } else {
    var voData = this.data.getNodesetData2();
    var vnSize = voData.getLength();
    var voInstRow = null;
    var vsStatus = null;
    for(var i = 0; i < vnSize; i++) {
      voInstRow = voData.item(i);
      vsStatus = voInstRow.getUserAttribute("status");
      if(vsStatus == null) vsStatus = "";
      if(vsStatus.indexOf("I") != -1) voInstRow.getParentNode().removeChild(voInstRow);
      else if(vsStatus.indexOf("R") == -1) voInstRow.setUserAttribute("status", "R" + vsStatus);
    }
  }
  this.refreshData(null, null, true);
};
/**
 * 전체 행 개수 리턴
 * @param {Boolean} pbGrouped 그룹핑된 row를 포함시킬 지 여부
 * @return 전체 행 개수
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getRowCnt = function(pbGrouped) {
  var vnRowCount = 0;
//  var vnHeadCount = 0;
//  var vnFootCount = 0;
//  if(this.grid.Head.childNodes) vnHeadCount = this.grid.Head.childNodes.length;
//  if(this.grid.Foot.childNodes) vnFootCount = this.grid.Foot.childNodes.length;
//  vnRowCount = this.grid.RowCount - vnHeadCount - vnFootCount;

  if(this.grid.Body.childNodes && this.grid.Body.firstChild) vnRowCount = this.grid.Body.firstChild.childNodes.length;

  // 이조건을 안타면 Group등의 비어있는root한개만 있는경우도 row갯수를 반환한다
  if(vnRowCount === 0 && this.cfg.paging != "fast") return 0;
  if(pbGrouped && this.cfg.paging != "fast") return vnRowCount;
  // 페이지가 쓰이는 경우
//  if((this.cfg.paging == "fast" || this.cfg.paging == "auto") && this.grid.PageLength) {
//    for(var r=this.grid.XB.firstChild,vnRowCount=0;r;r=r.nextSibling) {
//      for(var v=r.firstChild;v;v=v.nextSibling,vnRowCount++) {
//      }
//    }
//  }
//  else {
    var vnIndex = 0;
    var vaDataRow = new Array();
    var voXB = this.grid.XB;
    function findLeafNode(poNode){
      var voNode = poNode;
      if(voNode.childNodes.length > 0){
        for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
          findLeafNode(r);
        }
      } else {
        if(voNode && voNode.nodeName && voNode.nodeName == "I") vaDataRow.push(voNode);
      }
    };
    if(voXB != undefined) findLeafNode(voXB);
    vnRowCount = vaDataRow.length;
//  }
  return vnRowCount;
};
/**
 * DataSource의 전체 행 개수 리턴
 * @return DataSource의 전체 행 개수
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getDataRowCnt = function(){
  var vnRowCount = 0;
  var voData = null;
  if(this.datasetId != null){
    try{
      voData = this.canvas.page.model.getDataSet(this.datasetId);
      if(voData) vnRowCount = voData.getRowCnt();
    } catch(e) {
      return voRowCount;
    }
  }else{
    try {
      voData = this.data.getNodesetData2();
      if(voData != null) {
        vnRowCount = voData.getLength();
        var vnSize = vnRowCount;
        var voNode = null;
        var vsStatus = null;
        for(var i = 0; i < vnSize; i++) {
          voNode = voData.item(i);
          vsStatus = voNode.getUserAttribute("status");
          if(vsStatus.indexOf("R") != -1) vnRowCount--;
        }
      }
    } catch(e) {
      return vnRowCount;
    }
  }
  return vnRowCount;
};
/**
 * 선택된 행들의 인덱스 배열을 반환하는 메소드
 * @return 선택된 행들의 인덱스 배열
 * @type Array(Number)
 */
eXria.controls.xhtml.GridEx.prototype.getSelectedIndexes = function() {
  var vaSelIndex = new Array(), vnIndex = 0, vnSelIndex = 0;

  for(var row=this.grid.GetFirstVisible();row;row=this.grid.GetNextVisible(row)) {
    if(row.Selected) {
      vaSelIndex[vnSelIndex++] = vnIndex;
    }
    vnIndex++;
  }

  if(vnSelIndex == 0) vaSelIndex = null;
  return vaSelIndex;
};
/**
 * 그리드의 첫 번째 row 오브젝트를 반환하는 메소드
 * @return 그리드의 첫 번째 row 오브젝트
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getFirst = function() {
  if(this.grid) return this.grid.GetFirst();
  else alert("getFirst call Error");
};
/**
 * 주어진 row의 다음 row 오브젝트를 반환하는 메소드
 * @param {Object} poRow row object
 * @return 주어진 row의 다음 row 오브젝트
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getNext = function(poRow) {
  if(this.grid) return this.grid.GetNext(poRow);
  else alert("getNext call Error");
};

/**
 * 주어진 row의 다음 row 오브젝트를 반환하는 메소드
 * @param {Object} poRow row object
 * @return 주어진 row의 이전 row 오브젝트
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getPrev = function(poRow) {
  if(this.grid) return this.grid.GetPrev(poRow);
  else alert("getPrev call Error");
};

/**
 * getRows
 * @param {Number} pnSection Cols위치를 구분하기 위한 정수(0 ? left, 1 ? variable, 2 - right).
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getRows = function(pnSection) {
  if(this.grid) return this.grid.GetRows(pnSection);
  else alert("getRows call Error");
};
/**
 * getRowIndex
 * @param {Number} pnIndex row index
 * @param {Boolean} pbGrouped 그룹핑된 row를 포함한 상태에서의 인덱스인지 여부
 * @return row object
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getRowIndex = function(pnIndex, pbGrouped) {
  if(pnIndex < 0) return null;
  // 페이지가 쓰이는 경우
//  if((this.cfg.paging == "fast" || this.cfg.paging == "auto") && this.grid.PageLength) {
  var voRow = null;
  if(this.cfg.paging == "fast" && this.grid.PageLength) {
    var voPageNum = 0;
    var voIndexInPage = 0;
    var voPage = null;
    var vnIncRowCnt = 0;

    voPage = this.grid.GetPage(voPageNum++);
    var vnPageRows = 0;
    while(voPage || pnIndex > vnIncRowCnt) {
      vnPageRows = voPage ? (voPage.childNodes.length ? voPage.childNodes.length : this.grid.PageLength) : this.grid.PageLength;
      vnIncRowCnt += vnPageRows;
      if(vnIncRowCnt >= pnIndex + 1) {
        voIndexInPage = pnIndex - (vnIncRowCnt - vnPageRows);
        break;
      }
      voPage = this.grid.GetPage(voPageNum++);
    }
    if(voPage) {
      for(voRow=voPage.firstChild,num=0;voIndexInPage!=num;voRow=voRow.nextSibling,num++){
        if(voRow == null) break;
      }
    }
    return voRow;
  }

  // 페이지가 쓰이는 않는 경우
  var vaDataRow = new Array();
  var voXB = this.grid.XB;
  var findLeafNode = null;
  var vnIdx = -1;
  var vbQuit = false;
  if(pbGrouped) {
    findLeafNode = function(poNode){
      var voNode = poNode;
      if(voNode && voNode.nodeName && voNode.nodeName == "I") {
          vnIdx++;
          if(vnIdx == pnIndex) {
            voRow = voNode;
            vbQuit = true;
            return;
          }
      }
      if(voNode.childNodes.length > 0) {
        for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
          findLeafNode(r);
          if(vbQuit) return;
        }
      }
    };
  } else {
    findLeafNode = function(poNode){
      var voNode = poNode;
      if(voNode.childNodes.length > 0 && voNode["InstIdx"] == null){
        for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
          findLeafNode(r);
          if(vbQuit) return;
        }
      }else{
        if(voNode && voNode.nodeName && voNode.nodeName == "I") vnIdx++;
        if(vnIdx == pnIndex) {
          voRow = voNode;
          vbQuit = true;
          return;
        }
      }
    };
  }
  if(voXB != undefined) findLeafNode(voXB);
  return voRow;
};

/**
 * getBodyRowByIndex
 * @param {Number} pnIndex row index
 * @return row object
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getBodyRowByIndex = function(pnIndex) {
  return this.getRowIndex(pnIndex);
};

/**
 * getHeaderRowByIndex
 * @param {Number} pnIndex header row index
 * @return header row
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getHeaderRowByIndex = function(pnIndex) {
  var vnIndex = 0;
  var vaFixedRows = this.grid.GetFixedRows();
  var voRetRow = null;

  if(vaFixedRows[pnIndex]){
    var vsSection = vaFixedRows[pnIndex].Fixed;

    if(vsSection == "Head") voRetRow = vaFixedRows[pnIndex];
  }

  return voRetRow;
};
/**
 * getFooterRowByIndex
 * @param {Number} pnIndex footer row index
 * @return footer row
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getFooterRowByIndex = function(pnIndex) {
  var vnIndex = 0;
  var vaFixedRows = this.grid.GetFixedRows();
  var vaFooterRows = new Array();
  var voRetRow = null;

  for(var i=0; i<vaFixedRows.length; i++){
    var vsSection = vaFixedRows[i].Fixed;
    if(vsSection == "Foot") vaFooterRows.push(vaFixedRows[i]);
  }

  if(vaFooterRows[pnIndex]) voRetRow = vaFooterRows[pnIndex];
  return voRetRow;
};
/**
 * row 타입을 반환하는 메소드
 * @return row 타입 구분 문자열
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getRowType = function(poRow) {
  var vsAttr = poRow.Fixed;

  if(vsAttr == "Head") return this.RowType.HeadRow;
  else if(vsAttr == "Foot") return this.RowType.FootRow;
  else return this.RowType.BodyRow;

  return vsAttr;
};
/**
 * 주어진 row의 index를 반환하는 메소드
 * @param {Object} poRow row object
 * @param {Boolean} pbGrouped 그룹핑된 row를 포함한 상태에서의 인덱스를 반환할 지 여부
 * @return 주어진 row의 index
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getIndexOfRow = function(poRow, pbGrouped) {
  var vnRowIndex = null;
  if(poRow != null && poRow["ChildIdx"] != null) poRow = poRow.parentNode;
  // 페이지가 쓰이는 경우
  if(this.cfg.paging == "fast" && this.grid) {
    var voPage = this.grid.GetRowPage(poRow);
    if(voPage) {
      var vnPageNum = this.grid.GetPageNum(voPage);
      if(vnPageNum != null) {
        vnRowIndex = 0;
        var voPage = null;
        for(var i = 0; i < vnPageNum; i++) {
          voPage = this.grid.GetPage(i);
          vnRowIndex += voPage ? (voPage.childNodes.length ? voPage.childNodes.length : this.grid.PageLength) : this.grid.PageLength;
        }
        vnRowIndex += this.grid.GetPos(poRow);
        return vnRowIndex;
      }
    }
  }

  // 페이지가 쓰이지 않는 경우
  var vnIndex = 0;
  var vaDataRow = new Array();
  var voXB = this.grid.XB;
  var findLeafNode = null;
  var vbQuit = false;
  if(pbGrouped) {
    findLeafNode = function(poNode) {
      var voNode = poNode;
      if(voNode == poRow) {
        vnRowIndex = vnIndex;
        vbQuit = true;
        return;
      }else{
        if(voNode && voNode.nodeName && voNode.nodeName == "I") vnIndex++;
      }
      if(voNode.childNodes.length > 0){
        for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
          findLeafNode(r);
          if(vbQuit) return;
        }
      }
    };
  } else {
    findLeafNode = function(poNode) {
      var voNode = poNode;
      if(voNode.childNodes.length > 0 && voNode["InstIdx"] == null){
        for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
          findLeafNode(r);
          if(vbQuit) return;
        }
      }else{
        if(voNode == poRow){
          vnRowIndex = vnIndex;
          vbQuit = true;
          return;
        }else{
          //vaDataRow.push(voNode);
          vnIndex++;
        }
      }
    };
  }
  findLeafNode(voXB);
  return vnRowIndex;
};
/**
 * 주어진 row index에 해당하는 instance row index를 반환하는 메소드
 * @param {Number} poRow 그리드 row index
 * @return 주어진 row의 index에 해당하는 instance row index
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getInstanceRowIndex = function(pnIndex) {
  var vnInstIdx = null;
  if(this.datasetId == null) {
    var voRow = this.getRowIndex(pnIndex);
    var vnInstIdx = voRow["InstIdx"];
    if(vnInstIdx == null) vnInstIdx = voRow.getAttribute("InstIdx");
    vnInstIdx = parseInt(vnInstIdx);
    vnInstIdx += 1;
  } else {
    var voDst = this.dataset;
    vnInstIdx = voDst.getInstanceRowIndex(pnIndex + 1);
  }
  return vnInstIdx;
};
/**
 * 주어진 header row의 index를 반환하는 메소드
 * @param {Object} poRow header row object
 * @return header row index
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getIndexOfHeadRow = function(poRow) {
  var vaRows = this.grid.GetFixedRows();
  for(var i=0; i<vaRows.length;i++){
    if(vaRows[i] == poRow && this.getRowType(poRow) == this.RowType.HeadRow) {
      if(poRow.Kind == "Data") return i - 1;
      return i;
    }
  }
  return null;
};
/**
 * 주어진 footer row의 index를 반환하는 메소드
 * @param {Object} poRow footer row object
 * @return footer row index
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getIndexOfFootRow = function(poRow) {
  var vaFixedRows = this.grid.GetFixedRows();
  var vaFooterRows = new Array();
  var voRetRow = null;
  var vnIndex = 0;

  for(var i=0; i<vaFixedRows.length; i++){
    var vsSection = vaFixedRows[i].Fixed;
    if(vsSection == "Foot") vaFooterRows.push(vaFixedRows[i]);
  }

  for(var i=0; i<vaFooterRows.length;i++){
    if(vaFooterRows[i] == poRow && this.getRowType(poRow) == this.RowType.FootRow) return vnIndex;
    vnIndex++;
  }
  return null;
};
/**
 * 주어진 row에 매핑된 instance row index를 반환하는 메소드.
 * 반드시 XHTML 모드에서만 사용해야함.
 * @param {Object} poRow row object
 * @return 주어진 row의 instance index
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getInstIndexOfRow = function(poRow) {
  var vnInstIdx = poRow["InstIdx"];
  if(vnInstIdx == null) vnInstIdx = poRow.getAttribute("InstIdx");
  vnInstIdx = parseInt(vnInstIdx) + 1;
  return vnInstIdx;
};
/**
 * 선택된 row object들을 배열형태를 반환하는 메소드
 * @return 선택된 row object들의 배열
 * @type Array(Object)
 */
eXria.controls.xhtml.GridEx.prototype.getSelRows = function() {
  var vaSelRows = null;
  if(this.grid) {
    vaSelRows = this.grid.GetSelRows();
    if(vaSelRows.length == 0) vaSelRows = null;
    return vaSelRows;
  }
  else new Error("getSelRows call Error");
};
//yhkim 2009.05.11 multiSelect 관련
/**
 * 설정된 multiSelect 값을 반환하는 메소드
 * @return 설정된 multiSelect 값
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.getMultiSelect = function() {
  return this.cfg.multiSelect;
};
/**
 * 포커스된 row object를 반환하는 메소드
 * @return 포커스된 row object
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getFocusRow = function() {
  if(this.grid) return this.grid.FRow;
  else alert("getFocusRow call Error");
};
/**
 * 포커스된 column의 Header ID를 반환하는 메소드
 * @return Header ID
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getFocusCol = function() {
  if(this.grid) return this.grid.FCol;
  else alert("getFocusCol call Error");
};
/**
 * 포커스된 row의 인데스를 반환하는 메소드
 * @param {Boolean} pbGrouped 그룹핑된 row를 포함한 상태에서의 인덱스를 반환할 지 여부
 * @return 포커스된 row의 인덱스
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getFocusRowIndex = function(pbGrouped) {
  var vnRowIndex = null;
  if(this.grid.FRow){
    vnRowIndex = this.getIndexOfRow(this.grid.FRow, pbGrouped);
  }
  return vnRowIndex;
};
/**
 * 특정 row에 포커스를 주기 위한 메소드
 * @param {Number} pnIndex row index
 * @return 포커싱 성공 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.setFocusRowIndex = function(pnIndex, pbNoRunEvent, pbGrouped) {
  if(this.canvas.focusedControl != this)
    this.canvas.setFocusByControl(this);

  var voRowCtrl = this.getRowIndex(pnIndex, pbGrouped);
  this.noFocusEvent = pbNoRunEvent;

  if(pnIndex < 0)   // exception
    return false;

  var colID = null; // default value
  var vbResult = false;
  // yhkim 2009.04.08 : initial focus column setting
  if( this.grid.FCol == undefined){
    var sections = this.grid.GetSections();
    if(sections.length != 0){
      var nSec = sections[0];
      colID = this.grid.GetFirstCol(nSec);
      if(colID == "Panel") colID = this.grid.GetNextCol(colID);
    }
  }
  //yhkim 2009.04.08 : reset scroll (in treegrid source)
  vbResult = this.grid.Focus(voRowCtrl, colID, null, true);
  this.noFocusEvent = false;
  //this.scrollIntoView(this.getRowIndex(this.getDataRowCnt()-1));
  return vbResult;
};
/**
 * 특정 row에 포커스를 주기 위한 메소드
 * @param {Object} poRow row 객체
 * @return 포커싱 성공 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.setFocusRow= function(poRow, pbNoRunEvent) {
  if(this.canvas.focusedControl != this)
    this.canvas.setFocusByControl(this);

  this.noFocusEvent = pbNoRunEvent;

  if(poRow == null)   // exception
    return false;

  var colID = null; // default value
  var vbResult = false;
  // yhkim 2009.04.08 : initial focus column setting
  if( this.grid.FCol == undefined){
    var sections = this.grid.GetSections();
    if(sections.length != 0){
      var nSec = sections[0];
      colID = this.grid.GetFirstCol(nSec);
    }
  }
  //yhkim 2009.04.08 : reset scroll (in treegrid source)
  vbResult = this.grid.Focus(poRow, colID, null, true);
  this.noFocusEvent = false;
  //this.scrollIntoView(this.getRowIndex(this.getDataRowCnt()-1));
  return vbResult;
};
/**
 * 커서가 위치한 row를 반환하는 메소드
 * @return 커서가 위치한 row
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.getActualRow = function() {
  if(this.grid) return this.grid.ARow;
  else alert("getActualRow call Error");
};
/**
 * 주어진 row를 선택 또는 해제하기 위한 메소드
 * @param {Object} poRow row object
 * @param {Number} pnSelect : null은 하나이상의 셀이 선택되어 있으면 해당 로우를 해제하고 아니면 선택, 1은 해당 로우를 선택, 0은 해당 로우를 해제
 */
eXria.controls.xhtml.GridEx.prototype.selectRow = function(poRow, pnSelect) {
  if(this.grid) return this.grid.SelectRow(poRow, pnSelect);
  else alert("selectRow call Error");
};
/**
 * 모든 row를 선택 또는 해제하기 위한 메소드
 * @param {Object} poRow row object
 * @param {Number} pnSelect : null은 선택된 로우가 있으면 모두 해제하고 선택된 로우가 없으면 모두 선택함, 1은 모든 로우 선택, 0은 모든 로우 해제, -1은 선택된 로우는 해제하고 해제된 로우는 선택
 */
eXria.controls.xhtml.GridEx.prototype.selectAllRows = function(pnSelect) {
  if(this.grid) this.grid.SelectAllRows(pnSelect);
  else alert("selectAllRows call Error");
};
/**
 * 특정 영역의 Cell들을 선택하기 위한 메소드
 * @param {Object} poRow1 영역 시작 부분의 row object
 * @param {String} psCol1 poRow1 영역 시작 부분의 column id
 * @param {Object} poRow2 영역 끝 부분의 row object
 * @param {String} psCol2 영역 끝 부분의 column id
 * @param {Number} pnSelect 0 ? unselects range, 1 ? selectes range, 2 ? unselects range if cell row1,col1 is selected, otherwise selects the range
 * @param {Number} pnType bit array, &1 ? selects only visible rows, &2 ? ignores children of collapsed rows.
 * @return 선택 성공 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.selectRange = function(poRow1, psCol1, poRow2, psCol2, pnSelect, pnType) {
  if(this.grid) this.grid.SelectRange(poRow1, psCol1, poRow2, psCol2, pnSelect, pnType);
  else alert("selectRange call Error");
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.getRowsByValue = function(psCol, poValue) {
  for(var voCol=this.grid.GetFirstCol();voCol;voCol=this.grid.GetNextCol(voCol)) {
    if(vnIndex == pnIndex) return voCol;
    vnIndex = vnIndex + 1;
  }
};
/**
 * 한 행을 추가
 * @param {Boolean} poParent parent row object(tree구조가 아닐경우 null로 표기)
 * @param {Object} poNext (이행의 바로 이전에 새행이 추가됨, null설정시 맨 마지막에 추가)
 * @param {Boolean} pbShow 화면 표시 여부(default값은  true)
 * @return 추가된 row object
 * @type Object
 */
eXria.controls.xhtml.GridEx.prototype.addRow = function(poParent, poNext, pbShow) {
  var voRow = null;
  var vnIndex = this.getIndexOfRow(poNext);

  if(vnIndex == null) vnIndex = this.getRowCnt();
  if(pbShow == null) pbShow = true;

  if(this.datasetId != null) {
    if(!this.dataset) this.dataset = this.canvas.page.model.getDataSet(this.datasetId);
    this.dataset.insertRow(vnIndex + 1, false);
  } else if(!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
    if(vnIndex < this.getRowCnt()) this.data.addData(null, null, vnIndex);
    else this.data.addData();
  }
  
  this.grid.LastId = this.lastId;
  if(this.grid) voRow = this.grid.AddRow(poParent, poNext, pbShow);
  this.lastId++;
  
  //rightButton 처리
  var voCollection = this.rgtBtnList;
  var vnSize = voCollection.size();
  if(vnSize > 0)
  {
    var voColumn;
    var vsValue;
    for(var i = 0; i < vnSize; i++){
     voColumn = voCollection.get(i);
     vsValue = voColumn.itemgroup.getItemValuesToString('|');
     if(!vsValue) vsValue = voColumn.rightButton.value;
     this.setRightButton(voRow, voColumn.colId, vsValue, voColumn.width);
    }
  }

  //enum Column style 처리
  voCollection = this.enumColList;
  vnSize = voCollection.size();
  if(vnSize > 0)
  {
    var voColumn;
    for(var i = 0; i < vnSize; i++){
     voColumn = voCollection.get(i);
     this.grid.SetAttribute(voRow, voColumn.colId, "IconAlign", "Right", false);
    }
  }

  //MaxHeigth 처리
  if(this.rowMaxHeight != null) {
    voRow.MaxHeight = this.rowMaxHeight;
    voRow.MaxEditHeight = this.rowMaxHeight;
  }
  this.refreshRow(voRow);

  // yhkim 2009.05.28
  this.scrollIntoView(voRow, null);
  if(this.datasetId == null) {
    if(!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
      var voNodeList = this.data.getNodesetData2();
      var vnIdx = voNodeList.getLength() - 1;
      voNodeList.item(vnIdx).setUserAttribute("status", "I");
      voRow["InstIdx"] = vnIdx;
    }
  }
  return voRow;
};
//yhkim 2009.05.28
/**
 * 스크롤될 Cell위치 지정
 * @param {Object} poRow row object
 * @param {String} psCol column id
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.scrollIntoView = function(poRow, psCol) {
  if(psCol == null){
    for(var i = 0; i < 3; i++){
      var vsColName = this.getColNames(i, 0);
      if(vsColName != "Panel"){
        psCol = vsColName;
        break;
      }
    }
  }
  if(this.cfg.paging == "fast"){
    this.grid.ScrollIntoView(poRow, psCol, this.cfg.pagePos);
  }else{
    this.grid.ScrollIntoView(poRow, psCol);
  }
};
/**
 * 한 행을 추가
 * @param {Number} pnIndex row Index
 * @param {Boolean} pbAfter 주어진 row 뒤에 행을 삽입할 지 여부
 */
eXria.controls.xhtml.GridEx.prototype.insertRow = function(pnIndex, pbAfter, poParent, pbShow) {
  var vbEmptyRow = false;
  var vaChildRows = this.childRows;
  if(this.getRowCnt() == 0) vbEmptyRow = true;

  if(pnIndex === null || pnIndex === undefined || this.rowMerged){
  pnIndex = 0;
  if(vbEmptyRow) pbAfter = true;
  else pbAfter = false;
  }

  if(this.datasetId != null) {
    if(!this.dataset) this.dataset = this.canvas.page.model.getDataSet(this.datasetId);
    if(vbEmptyRow) this.dataset.insertRow(pnIndex + 1, false);
    else this.dataset.insertRow(pnIndex + 1, pbAfter);
  } else if(!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
    this.data.addData();
  }


  if(this.cfg.groupMain && this.cfg.groupCols){
    if(poParent == null) poParent = this.getRowIndex(pnIndex).parentNode;
  }

  if(pbAfter) {
    voRow = this.getRowIndex(pnIndex+1);
  } else {
    voRow = this.getRowIndex(pnIndex);
  }

  var vbMove = false;

  if(this.cfg.groupMain && this.cfg.groupCols && !vaChildRows){
    if(voRow == null){
      vbMove = true;
      voRow = this.getRowIndex(pnIndex);
    }
    if(poParent == null) return;
  }
  
  this.grid.LastId = this.lastId;
  var voRetRow = null;
  if(this.grid) voRetRow = this.grid.AddRow(poParent, voRow, true);
  voRetRow.id = parseInt(this.grid.LastId);
  this.lastId++;
  
  if(vaChildRows) {
    var vnSize = vaChildRows.length;
    var voChild = null;
    for(var i = 0; i < vnSize; i++) {
      voChild = this.grid.AddRow(voRetRow, null, true, voRetRow.id + "_" + (i + 1));
      voChild["ChildIdx"] = i;
    }
  }

  if (this.cfg.groupMain && this.cfg.groupCols) {
    var vaGroupCols = this.cfg.groupCols.split(",");

    var ThisGrid = this.grid;
    var This = this;
    var vsGroupMain = this.cfg.groupMain;

    function setGroupValue(poElem){
      var vsGroupValue = ThisGrid.GetValue(poElem, vsGroupMain);
      var vsGroupCol = vaGroupCols[parseInt(poElem["Level"])];
      This.setGroupDefaultValue(voRetRow, vsGroupCol, vsGroupValue);
      if(poElem.parentNode.nodeName == "I") setGroupValue(poElem.parentNode);
    }

    if (voRetRow.parentNode != poParent || (pbAfter == true && vbMove)) {
      this.grid.MoveRow(voRetRow, poParent, null, true);
      this.grid.RenderBody();
    }
    setGroupValue(poParent);
  }

  //rightButton 처리
  var voCollection = this.rgtBtnList;
  var vnSize = voCollection.size();
  if(vnSize > 0)
  {
    var voColumn;
    var vsValue;
    for(var i = 0; i < vnSize; i++){
     voColumn = voCollection.get(i);
     vsValue = voColumn.itemgroup.getItemValuesToString('|');
     if(!vsValue) vsValue = voColumn.rightButton.value;
     this.setRightButton(voRetRow, voColumn.colId, vsValue, voColumn.width);
    }
  }

  //enum Column style 처리
  voCollection = this.enumColList;
  vnSize = voCollection.size();
  if(vnSize > 0)
  {
    var voColumn;
    for(var i = 0; i < vnSize; i++){
     voColumn = voCollection.get(i);
     this.grid.SetAttribute(voRetRow, voColumn.colId, "IconAlign", "Right", false);
    }
  }

  //MaxHeigth 처리
  if(this.rowMaxHeight != null) {
    voRetRow.MaxHeight = this.rowMaxHeight;
    voRetRow.MaxEditHeight = this.rowMaxHeight;
  }
  this.refreshRow(voRetRow);

  //yhkim 2009.05.28
  this.scrollIntoView(voRetRow, null);
  if(this.datasetId == null) {
    if(!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
      var voNodeList = this.data.getNodesetData2();
      var vnIdx = voNodeList.getLength() - 1;
      voNodeList.item(vnIdx).setUserAttribute("status", "I");
      voRetRow["InstIdx"] = vnIdx;
    }
  }
  return voRetRow;
};
eXria.controls.xhtml.GridEx.prototype.setGroupDefaultValue = function(poRow, psCol, psValue){
  if (this.grid) {
    this.grid.SetValue(poRow, psCol, psValue, true);
  }
  // DataSet과의 데이타 동기화
  var voDataSet, voColumn, vsDatasetCol = null;
  base = this;
  if(base.datasetId != null) {
    if(base.dataset) voDataSet = base.dataset;
    else voDataSet = base.canvas.page.model.getDataSet(base.datasetId);
    if(base.dataset) {
      voColumn = base.getBodyColumn(null, psCol);
      if(voColumn) {
        vsDatasetCol = voColumn.datasetCol;
        if(vsDatasetCol == null) {
          vsDatasetCol = voColumn.ref;
          if(vsDatasetCol != null) {
            var vaPath = vsDatasetCol.split("/");
            vsDatasetCol = vaPath[vaPath.length - 1];
          }
        }
        if(vsDatasetCol) {
          var voValue, vaEnumKeys = null;
          var vnRowIndex = base.getIndexOfRow(poRow);
          voValue = base.grid.GetValue(poRow, psCol);
          voValue = this.convertValueExria(poRow, psCol, voValue);
          if(voValue === null) voValue = "";
          var vbResult = true;
//          if(pbSimple) {
//            vbResult = base.dataset.simpleSet(vnRowIndex+1, vsDatasetCol, voValue);
//          } else {
            vbResult = base.dataset.set(vnRowIndex+1, vsDatasetCol, voValue);
//          }
          if(!vbResult) alert("data sync error");
        }
      }
    }
  }

};
/**
 * 해당 순번의 행 삭제
 * @param {Number} pnIndex 삭제될 row index
 */
eXria.controls.xhtml.GridEx.prototype.delRowByIndex = function(pnIndex) {
  var voRow = this.getRowIndex(pnIndex);
  this.delRow(voRow);
  /*
  var vnIndex = 0;
  for(var voRow=this.grid.GetFirst();voRow;voRow=this.grid.GetNext(voRow)) {
    if(vnIndex == pnIndex) this.grid.DelRow(voRow);
    vnIndex = vnIndex + 1;
    this.grid.RefreshRow(voRow);
  }
  */
};
/**
 * 해당 행 삭제
 * @param {Object} poRow 삭제될 row object
 */
eXria.controls.xhtml.GridEx.prototype.delRow = function(poRow) {
  var vnIndex = this.getIndexOfRow(poRow);

  if(this.datasetId == null) {
    if(!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
      var vnInstIdx = poRow["InstIdx"];
      if(vnInstIdx == null) vnInstIdx = poRow.getAttribute("InstIdx");
      vnInstIdx = parseInt(vnInstIdx);
      var voInstRow = this.data.getNodesetData2(vnInstIdx).node;
      var vsStatus = voInstRow.getUserAttribute("status");
      if(vsStatus == null) vsStatus = "";
      if(vsStatus.indexOf("I") != -1) voInstRow.getParentNode().removeChild(voInstRow);
      else if(vsStatus.indexOf("R") == -1) voInstRow.setUserAttribute("status", "R" + vsStatus);
    }
  } else {
    this.dataset.deleteRow(vnIndex + 1);
  }
  if(this.grid) this.grid.DelRow(poRow);
  else alert("delRow call Error");
  if(this.getRowCnt() == 0) {
    this.grid.LastId = "";
    this.grid.Focus(null, null);
  }
};
/**
 * 행에 대한 삭제를 marking
 * @param {Object} poRow row object
 * @param {Number} pnType type =  1 ? delete + confirm dialog, 2 ? delete, 3 ? undelete (delete는 child row까지 모두 삭제, undelete는 해당 로우만 삭제)
 */
eXria.controls.xhtml.GridEx.prototype.markDelRow = function(poRow, pnType) {

  if(pnType == null)
    return false;

  if(this.grid) {
    if(this.grid.DeleteRow(poRow, pnType) == false) {
      alert("cannot Mark Delete");
      return;
    }
  }
  else alert("deleteRow call Error");
};
/**
 * 해당 순번의 행에 대한 삭제를 marking
 * @param {Number} pnType [1 : delete + confirm dialog, 2 : delete, 3 : undelete (delete는 child row까지 모두 삭제, undelete는 해당 로우만 삭제)]
 */
eXria.controls.xhtml.GridEx.prototype.markDelRowByIndex = function(pnIndex, pnType) {
  var voRow = this.getRowIndex(pnIndex);
  this.markDelRow(voRow, pnType);

  /*
  var vnIndex = 0;
  for(var voRow=this.grid.GetFirst();voRow;voRow=this.grid.GetNext(voRow)) {
    if(vnIndex == pnIndex) this.grid.DeleteRow(voRow, pnType);
    vnIndex = vnIndex + 1;
    this.grid.RefreshRow(voRow);
  }
  */
};
/////////////////////////////////////////////////////////////////
// Column 관련 메소드
/**
 * addCol
 * @param {String} psColId column id
 * @param {Number} pnSec section of columns (0 ? left, 1 ? variable, 2 ? right)
 * @param {Number} pnPos column position in its section
 * @param {Number} pnWidth column width or null for automatic computing
 * @param {Boolean} pbShow column displayed in table
 * @param {String} psType column type
 * @param {String} psCaption caption
 * @param {String} psFormula column formula
 * @param {String} psEnum enum string
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addCol = function(psColId, pnSec, pnPos, pnWidth, pbShow, psType, psCaption, psFormula, psEnum) {
  if(this.grid) return this.grid.AddCol(psColId, pnSec, pnPos, pnWidth, pbShow, psType, psCaption, psFormula, psEnum);
  else alert("addCol call Error");
};
/**
 * 헤드 컬럼을 구함
 * @param {String} psHeadColId header column id
 * @return 칼럼에 설정된 Ref
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getHeadColumn = function(psHeadColId) {
  if(this.headColMap.get(psHeadColId)) return this.headColMap.get(psHeadColId);

  var voCols = new Array();
  var voHeader, voRow, vsRef = null;

  voHeader = this.header;
  voCols[0] = voHeader.cols["left"];
  voCols[1] = voHeader.cols["center"];
  voCols[2] = voHeader.cols["right"];

  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      voRow = voCols[i].rows[0];
      for(var j=0; j<voRow.columns.length; j++) {
        voColumn = voRow.columns[j];
        if(voColumn.id == psHeadColId) {
          return voColumn;
        }
      }
    }
  }
  return null;
};
/**
 * 헤드 컬럼을 제거
 * @param {String} psHeadColId header column id
 * @return 제거된 헤드 컬럼 객체
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.removeHeadColumn = function(psHeadColId) {
  var voCols = new Array();
  var voHeader, voRow, vsRef = null;

  voHeader = this.header;
  voCols[0] = voHeader.cols["left"];
  voCols[1] = voHeader.cols["center"];
  voCols[2] = voHeader.cols["right"];

  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      voRow = voCols[i].rows[0];
      for(var j=0; j<voRow.columns.length; j++) {
        voColumn = voRow.columns[j];
        if(voColumn.id == psHeadColId) {
          voColumn = voRow.columns.splice(j, 1);
          this.headColMap.remove(psHeadColId);
          return voColumn[0];
        }
      }
    }
  }
  return null;
};
/**
 * 주어진 Body Column을 반환하는 메소드.
 * @param {String} psColId column id(null)
 * @param {String} psHeadColId header column id
 * @return body Column
 * @type eXria.controls.xhtml.GridEx.BodyColumn
 */
eXria.controls.xhtml.GridEx.prototype.getBodyColumn = function(psColId, psHeadColId) {
  if(psColId && this.bodyColMap.get(psColId)) return this.bodyColMap.get(psColId);
  if(psHeadColId && this.bodyColHMap.get(psHeadColId)) return this.bodyColHMap.get(psHeadColId);

  var voBody = this.body;
  var voCols = new Array(3);
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  for(var i=0; i<voBody.cols.length; i++) {
    if(voCols[i]) {
      for(var j=0; j<voCols[i].rows.length; j++) {
        voColsRow = voCols[i].rows[j];
        for(var k=0; k<voColsRow.columns.length; k++) {
          voColumn = voColsRow.columns[k];
          if(voColumn.id == psColId) return voColumn;
          if(psColId == null && voColumn.colId == psHeadColId) return voColumn;
        }
      }
    }
  }
  return null;
/*
  var vnIndex = 0;
  if(!pnSection) pnSection = 1;
  for(var voCol=this.grid.GetFirstCol();voCol;voCol=this.grid.GetNextCol(voCol)) {
    if(vnIndex == pnIndex) return voCol;
    vnIndex = vnIndex + 1;
  }
*/
};
/**
 * Body Column을 제거해주는 메소드.
 * @param {String} psColId column id(null)
 * @param {String} psHeadColId header column id
 * @return 제거된 body Column 객체
 * @type eXria.controls.xhtml.GridEx.BodyColumn
 */
eXria.controls.xhtml.GridEx.prototype.removeBodyColumn = function(psColId, psHeadColId) {
  var voBody = this.body;
  var voCols = new Array(3);
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  for(var i=0; i<voBody.cols.length; i++) {
    if(voCols[i]) {
      for(var j=0; j<voCols[i].rows.length; j++) {
        voColsRow = voCols[i].rows[j];
        for(var k=0; k<voColsRow.columns.length; k++) {
          voColumn = voColsRow.columns[k];
          if(psColId && voColumn.id == psColId) {
            voColumn = voColsRow.columns.splice(k, 1);
            this.bodyColMap.remove(psColId);
            this.bodyColHMap.remove(voColumn.colId);
            return voColumn[0];
          }
          if(psColId == null && voColumn.colId == psHeadColId) {
            voColumn = voColsRow.columns.splice(k, 1);
            this.bodyColMap.remove(voColumn.id);
            this.bodyColHMap.remove(psHeadColId);
            return voColumn[0];
          }
        }
      }
    }
  }
  return null;
};
/**
 * 주어진 Function Column 을 반환하는 메소드.
 * @param {object} poRow header row object
 * @param {String} psColId Function column id
 * @param {String} psHeadColId header column id
 * @return Function Column
 * @type eXria.controls.xhtml.GridEx.FunctionColumn
 */
eXria.controls.xhtml.GridEx.prototype.getFunctionColumn = function(poRow, psColId, psHeadColId) {
  if(psColId && this.functionColMap.get(psColId)) return this.functionColMap.get(psColId);

  var vnIndex = this.getIndexOfHeadRow(poRow);
  var voCols = new Array();
  var voColumn = null;
  voCols[0] = this.header.cols["left"];
  voCols[1] = this.header.cols["center"];
  voCols[2] = this.header.cols["right"];

  for ( var i = 0; i < 3; i++) {
    if (voCols[i]) {
      var vaFunRows = new Array();
      for ( var j = 0; voCols[i].rows.length > j; j++) {
        var voRow = voCols[i].rows[j];
        voColumn = voRow.columns[0];
        if(voColumn instanceof eXria.controls.xhtml.GridEx.FunctionColumn
      || voColumn instanceof eXria.controls.xhtml.GridEx.HeadColumn){
          vaFunRows.push(voRow);
        }
      }
      var voFunRow = vaFunRows[vnIndex];
      for(var j=0; j<voFunRow.columns.length; j++){
        var voColumn = voFunRow.columns[j];
        if(voColumn.id == psColId) return voColumn;
        if(psColId == null && voColumn.colId == psHeadColId) return voColumn;
      }
    }
  }

  return null;
};
/**
 * Function Column을 제거해주는 메소드.
 * @param {object} poRow header row object
 * @param {String} psColId Function column id
 * @param {String} psHeadColId header column id
 * @return Function Column
 * @type eXria.controls.xhtml.GridEx.FunctionColumn
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.removeFunctionColumn = function(poRow, psColId, psHeadColId) {
  var vnIndex = this.getIndexOfHeadRow(poRow);
  var voCols = new Array();
  var voColumn = null;
  var voRow = null;
  voCols[0] = this.header.cols["left"];
  voCols[1] = this.header.cols["center"];
  voCols[2] = this.header.cols["right"];

  for ( var i = 0; i < 3; i++) {
    if (voCols[i]) {
      var vnFunRowIdx = -1;
      var vnSize = voCols[i].rows.length;
      for ( var j = 0; vnSize > j; j++) {
        voRow = voCols[i].rows[j];
        voColumn = voRow.columns[0];
        if(voColumn instanceof eXria.controls.xhtml.GridEx.FunctionColumn
      || voColumn instanceof eXria.controls.xhtml.GridEx.HeadColumn){
          vnFunRowIdx++;
          if(vnFunRowIdx == vnIndex) break;
        }
      }
      vnSize = voRow.columns.length;
      for(var j=0; j < vnSize; j++){
        var voColumn = voRow.columns[j];
        if(voColumn.id == psColId) {
          voColumn = voRow.columns.splice(j, 1);
          this.functionColMap.remove(voColumn[0].id);
          return voColumn[0];
        }
        if(psColId == null && voColumn.colId == psHeadColId) {
          voColumn = voRow.columns.splice(j, 1);
          return voColumn[0];
        }
      }
    }
  }

  return null;
};
/**
 * 주어진 footer Column 을 반환하는 메소드.
 * @param {object} poRow footer row object
 * @param {String} psColId footer column id
 * @param {String} psHeadColId header column id
 * @return footer Column
 * @type eXria.controls.xhtml.GridEx.FootColumn
 */
eXria.controls.xhtml.GridEx.prototype.getFootColumn = function(poRow, psColId, psHeadColId) {
  if(psColId && this.footColMap.get(psColId)) return this.footColMap.get(psColId);

  var voFooter = this.footer;
  var vnIndex = this.getIndexOfFootRow(poRow);
  var voFootRow = voFooter.rows[vnIndex];

  for(var vsColsSec in voFootRow.cols){
    var voCols = voFootRow.cols[vsColsSec];
    for(var i=0; i<voCols.columns.length; i++){
      var voColumn = voCols.columns[i];
      if(voColumn.id == psColId) return voColumn;
      if(psColId == null && voColumn.colId == psHeadColId) return voColumn;
    }
  }

  return null;
};
/**
 * Footer Column을 제거해주는 메소드.
 * @param {object} poRow footer row object
 * @param {String} psColId footer column id
 * @param {String} psHeadColId header column id
 * @return footer Column
 * @type eXria.controls.xhtml.GridEx.FootColumn
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.removeFootColumn = function(poRow, psColId, psHeadColId) {
  if(psColId && this.footColMap.get(psColId)) return this.footColMap.get(psColId);

  var voFooter = this.footer;
  var vnIndex = this.getIndexOfFootRow(poRow);
  var voFootRow = voFooter.rows[vnIndex];

  for(var vsColsSec in voFootRow.cols){
    var voCols = voFootRow.cols[vsColsSec];
    for(var i=0; i<voCols.columns.length; i++){
      var voColumn = voCols.columns[i];
      if(voColumn.id == psColId) {
        voColumn = voRow.columns.splice(i, 1);
        this.footColMap.remove(voColumn[0].id);
        return voColumn[0];
      }
      if(psColId == null && voColumn.colId == psHeadColId) {
        voColumn = voRow.columns.splice(i, 1);
        return voColumn[0];
      }
    }
  }

  return null;
};
/**
 * header column id에 해당하는 칼럼 이름(ID)를 구함
 * @param {String} psHeadColId header column id
 * @return header column id에 해당하는 칼럼 이름(ID)
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getBodyColid = function(psHeadColId) {
  var voBody = this.body;
  var voCols = new Array(3);
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  for(var i=0; i<voBody.cols.length; i++) {
    if(voCols[i]) {
      for(var j=0; j<voCols[i].rows.length; j++) {
        voColsRow = voCols[i].rows[j];
        for(var k=0; k<voColsRow.columns.length; k++) {
          voColumn = voColsRow.columns[k];
          if(voColumn.colId == psHeadColId) return voColumn.id;
        }
      }
    }
  }
  return null;
};
/**
 * 인덱스에 해당하는 칼럼 이름(ID)를 구함
 * @param {Number} pnSection
 * @param {Number} pnSection section of columns (0 ? left, 1 ? variable, 2 ? right)
 * @return 칼럼 이름(ID)
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getColNames = function(pnSection, pnIndex) {
  return this.grid.ColNames[pnSection][pnIndex];
};
/**
 * 인덱스에 해당하는 칼럼 ID를 구함
 * @param {Number} pnSection
 * @param {Number} pnSection section of columns (0 ? left, 1 ? variable, 2 ? right)
 * @return 칼럼 이름(ID)
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getColId = function(pnSection, pnIndex) {
  return this.grid.ColNames[pnSection][pnIndex];
};
/**
 * 칼럼에 설정된 Ref를 구함
 * @param {String} psHeadColId header column id
 * @return 칼럼에 설정된 Ref
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getColRef = function(psHeadColId) {
  var voCols = new Array();
  var voBody, voRow, vsRef = null;

  voBody = this.body;
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      voRow = voCols[i].rows[0];
      for(var j=0; j<voRow.columns.length; j++) {
        voColumn = voRow.columns[j];
        if(voColumn.colId == psHeadColId) {
          if(this.datasetId != null) {
            vsRef = voColumn.datasetCol;
            if(vsRef)
              return vsRef;
          }
          else {
            vsRef = voColumn.ref;
            if(vsRef) {
              vaPath = vsRef.split("/");
              vsRef = vaPath[vaPath.length - 1];
              return vsRef;
            }
          }
        }
      }
    }
  }
};
/**
 * 칼럼에 설정된 Ref 및 dataset정렬타입을 구함
 * @param {String} psHeadColId header column id
 * @return 칼럼에 설정된 Ref
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getColRefAndTextFlag = function(psHeadColId) {
  var voCols = new Array();
  var voBody, voRow, vsRef = null;
  var vnTextFlag = null;;

  voBody = this.body;
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];
  if(psHeadColId == this.cfg.idColumn) psHeadColId = "id";
  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      voRow = voCols[i].rows[0];
      for(var j=0; j<voRow.columns.length; j++) {
        voColumn = voRow.columns[j];
        vnTextFlag = 1;
        if(voColumn.type == "Int" || voColumn.type == "Float") vnTextFlag = 0;
        if(voColumn.colId == psHeadColId) {
          if(this.datasetId != null) {
            vsRef = voColumn.datasetCol;
            if(vsRef) return [vsRef, vnTextFlag];
            else return [voColumn.colId, vnTextFlag];
          }
          else {
            vsRef = voColumn.ref;
            if(vsRef) {
              vaPath = vsRef.split("/");
              vsRef = vaPath[vaPath.length - 1];
              return [vsRef, vnTextFlag];
            }
          }
        }
      }
    }
  }
};
/**
 * 주어진 칼럼의 다음 칼럼 id를 구한다.
 * @param {String} psCol column id
 * @return 주어진 칼럼의 다음 칼럼 id
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getNextCol = function(psCol) {
  if(this.grid) return this.grid.GetNextCol(psCol);
  else alert("getNextCol call Error");
};
/**
 * 주어진 칼럼의 이전 칼럼 id를 구한다.
 * @param {String} psCol column id
 * @return 주어진 칼럼의 다음 칼럼 id
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getPrevCol = function(psCol) {
  if(this.grid) return this.grid.GetPrevCol(psCol);
  else alert("getPrevCol call Error");
};
/**
 * 맨처음 칼럼 id를 구한다. (Section이 주어지면 주어진 Section에서 null 이면 전체에서)
 * @param {Number} pnSection section of columns (0 ? left, 1 ? variable, 2 ? right)
 * @return 맨처음 칼럼 id
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getFirstCol = function(pnSection) {
  if(this.grid) return this.grid.GetFirstCol(pnSection);
  else alert("getFirstCol call Error");
};
/**
 * 마지막 칼럼 id를 구한다. (Section이 주어지면 주어진 Section에서 null 이면 전체에서)
 * @param {Number} pnSection section of columns (0 ? left, 1 ? variable, 2 ? right)
 * @return 마지막 칼럼 id
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getLastCol = function(pnSection) {
  if(this.grid) return this.grid.GetLastCol(pnSection);
  else alert("getLastCol call Error");
};
/////////////////////////////////////////////////////////////////
// Html 관련 메소드
/**
 * 주어진 row를 새로고침 하는 메소드
 * @param {Object} poRow row object
 */
eXria.controls.xhtml.GridEx.prototype.refreshRow = function(poRow) {
  if(this.grid) this.grid.RefreshRow(poRow);
  else alert("refreshRow call Error");
};
/**
 * 주어진 Cell을 새로고침 하는 메소드
 * @param {Object} poRow row object
 * @param {String} psColId column id
 */
eXria.controls.xhtml.GridEx.prototype.refreshCell = function(poRow, psColId) {
  if(this.grid) this.grid.RefreshCell(poRow, psColId);
  else alert("refreshCell call Error");
};
/**
 * Cell의 HTML element를 반환하는 메소드
 * @param {Object} poRow row object
 * @param {String} psCol column id
 * @param {Number} pnType type==0 ? returns object of whole cell (main tag TD)
 * type==1 ? returns inner tag &lt;TD&gt; containing &lt;DIV&gt; with text (for MainCol and button) or inner tag &lt;DIV class="width..."&gt;
 * type==2 ? returns tag &lt;IMG&gt; or &lt;BUTTON&gt; for cell with button or null
 * @return Cell의 HTML element
 * @type HTMLElement
 */
eXria.controls.xhtml.GridEx.prototype.getCell = function(poRow, psCol, pnType) {
  if(this.grid) return this.grid.GetCell(poRow, psCol, pnType);
  else alert("getCell call Error");
};
/////////////////////////////////////////////////////////////////
//Page 관련 메소드
/**
 * 포커스된 페이지 위치를 반환하는 메소드
 * @param {Object} poRow row object
 * @return 포커스된 row의 page 위치
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getFocusPagePos = function(poRow) {
  if(this.grid) return this.grid.GetPagePos(poRow);
  else alert("getFocusPagePos call Error");
};

/**
 * 해당 row가 속한 페이지의 위치를 반환하는 메소드
 * @param {Object} poRow row object
 * @return row가 속한 page의 인덱스
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getPageNum = function(poRow) {
  if(this.grid) return this.grid.GetPageNum(poRow);
  else alert("getPageNum call Error");
};

/**
 * 전체 페이지 갯수를 반환하는 메소드
 * @return 전체 페이지 갯수
 * @type Number
 */
eXria.controls.xhtml.GridEx.prototype.getPageTotalNum = function(){
  if(this.grid) {
    var voTotalNum = 0;
    for(var r=this.grid.XB.firstChild;r;r=r.nextSibling) {
      if(r!=null) voTotalNum++;
      else break;
    }
    return voTotalNum;
  } else {
    alert("getPageTotalNum call Error");
  }
};

/////////////////////////////////////////////////////////////////
//Sort 관련 메소드
/**
 * 소트 실행
 * @param {Number} pnSortCount 화면 클릭에 의한 sort 여부를 구분 짓기 위한 정수
 * @param {Array(String)} paSortCols sort 컬럼 id 저장 배열
 * @param {Array} paSortTypes sort type
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.sort = function(pnSortCount, paSortCols, paSortTypes) {
  if(pnSortCount > 0) this.sortUser = true;
  this.sortColsUser = paSortCols;
  this.sortTyepsUser = paSortTypes;

//  if(this.cfg.idColumn != null) {
//    this.refresh(null, true, true, true);
//  } else {
    if(this.getRowCnt() > 0)  this.refreshData(null, null, true, true);
//  }
};
/**
 * 매개변수로 주어진 칼럼에 의해 GridEx를 sorting 한다.
 * @param {Array(String)} paSortCols sort 컬럼 id 저장 배열
 * @param {Array} paSortTypes sort type
 * @param {Boolean} bNosort 1이면 SortCols, SortTypes, sort icons을 변경하되 sorting을 수행하지 않는다. 0이면 sorting 까지 수행한다.
 */
eXria.controls.xhtml.GridEx.prototype.changeSort = function(paSortCols, paSortTypes, bNosort) {
  var cols = ""
  if(typeof(paSortTypes)=="object") {
    for(var i=0;i<paSortTypes.length;i++) if(paSortTypes[i]) paSortCols[i] = "-"+paSortCols[i];
    for(var i=0;i<paSortCols.length;i++) {
      if(cols == "") cols = cols + paSortCols[i];
      else cols = cols + "," + paSortCols[i];
    }
  }

  if(this.grid) this.grid.ChangeSort(cols, bNosort);
  else new Error("grid is null");
};

/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  this.setAttr(psAttrName, psAttrValue);
  var voCtrl = this.getCtrl(poDocument);

  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "className" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "left" :
  case "top" :
       this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    var vnOldWidth = this.innerWidth;
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.refresh();
    break;
  case "height" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    break;
  case "borderWidth" :
  case "borderLeftWidth" :
  case "borderRightWidth" :
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.refresh(poDocument);
    break;
  case "multiSelect" :
    this.cfg.multiSelect = psAttrValue;
    break;
  default :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.setAttrCtrl(psAttrName, psAttrValue, this.ctrl);
    break;
  }
};
/**
 * 그리드 헤더 생성.
 * @return 그리드헤더
 * @type eXria.controls.xhtml.GridEx.Header
 */
eXria.controls.xhtml.GridEx.prototype.createHeader = function() {
  var voHeader = new eXria.controls.xhtml.GridEx.Header(this);
  return voHeader;
};
/**
 * 그리드 바디 생성.
 * @return 그리드바디
 * @type eXria.controls.xhtml.GridEx.Body
 */
eXria.controls.xhtml.GridEx.prototype.createBody = function() {
  var voBody = new eXria.controls.xhtml.GridEx.Body(this);
  return voBody;

};
/**
 * 그리드 footer 생성.
 * @return 그리드 footer
 * @type eXria.controls.xhtml.GridEx.Footer
 */
eXria.controls.xhtml.GridEx.prototype.createFooter = function() {
  var voFooter = new eXria.controls.xhtml.GridEx.Footer(this);
  return voFooter;
};
/**
 * 그리드에 헤더 추가.
 * @param {eXria.controls.xhtml.GridEx.Header} poHeader 그리드헤더
 */
eXria.controls.xhtml.GridEx.prototype.addHeader = function(poHeader) {
//  poHeader.create();
  this.header = poHeader;
};
/**
 * 그리드에 바디 추가.
 * @param {eXria.controls.xhtml.GridEx.Body} poBody 그리드바디
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addBody = function(poBody) {
//  poBody.create();
  this.body = poBody;
};

/**
 * 그리드에 functionRow 추가.
 * @param {eXria.controls.xhtml.GridEx.FunctionRow} poFunctionRow 그리드 functionRow
 */
eXria.controls.xhtml.GridEx.prototype.addFunctionRow = function(poFunctionRow){
//  this.functionRow = poFunctionRow;
};

/**
 * 그리드에 footer 추가.
 * @param {eXria.controls.xhtml.GridEx.Footer} poFooter 그리드 footer
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addFooter = function(poFooter) {
  this.footer = poFooter;
};
/**
 * 주어진 row의 HTML element를 반환하는 메소드
 * @param {Object} poRow row object
 * @return 주어진 row의 HTML element
 * @type HTMLElement
 */
eXria.controls.xhtml.GridEx.prototype.getRow = function(poRow) {
  //(0 ? left, 1 ? variable, 2 - right)
  if(this.grid) return this.grid.GetRow(poRow, 1);
  else alert("getRow call Error");
};
/**
 * Row의 Color 설정
 * @param {String} psColor Color
 * @param {Object} poRow row object
 */
eXria.controls.xhtml.GridEx.prototype.setRowColor = function(psColor, poRow) {
  var vsColor = null;
  if(psColor.substring(0, 1) != "#"){
    vsColor = eXria.controls.xhtml.Util.getColor(psColor);
  }else{
    vsColor = psColor;
  }
  this.saveRowColor(poRow, psColor); // Color 저장

  var vnIdx = this.getIndexOfRow(poRow);
  var vsRGB = this.getRGBValue(vsColor);
  var vnVal = (vsRGB+"").split(",");
  //vnVal = (vnVal[0]<<16)+(vnVal[1]<<8)+(vnVal[2]-0);

  poRow["Color"] = vnVal;
  this.refreshRow(poRow);
};
/**
 * Row의 Index로 Row Color 설정
 * @param {String} psColor Color
 * @param {Number} pnIndex Row의 Index
 */
eXria.controls.xhtml.GridEx.prototype.setRowIndexColor = function(psColor, pnIndex/*, ...*/) {
  var vaArgv = arguments;
  var vnSize = vaArgv.length;
  for(var i=1; i<vnSize; i++){
    var voRow = this.getRowIndex(vaArgv[i]);
    this.setRowColor(psColor, voRow);
  }
};
/**
 * Cell의 Color 설정
 * @param {String} psColor Color
 * @param {Object} poRow row object
 * @param {String} psCol HeadColumn의 ID
 */
eXria.controls.xhtml.GridEx.prototype.setCellColor = function(psColor, poRow, psCol){
  var vsColor = null;
  if(psColor.substring(0, 1) != "#"){
    vsColor = eXria.controls.xhtml.Util.getColor(psColor);
  }else{
    vsColor = psColor;
  }
  this.saveCellColor(poRow, psCol, psColor);

  var vsRGB = this.getRGBValue(vsColor);
  var vnVal = (vsRGB+"").split(",");
  //vnVal = (vnVal[0]<<16)+(vnVal[1]<<8)+(vnVal[2]-0);
  var vsAttrName = psCol + "Color";
  poRow[vsAttrName] = vnVal;
  this.refreshRow(poRow); // TreeGrid RefreshRow에서 호출되는  GetRowHTML에서 Cell의 컬러를 설정
};
/**
 * Body Column들의 Color 설정
 * @param {String} psColor Color
 * @param {String} psCol HeadColumn의 ID
 */
eXria.controls.xhtml.GridEx.prototype.setBodyColumnColor = function(psColor, psCol){
  var vnLoop = this.getRowCnt();
  for(var i=0; i<vnLoop; i++){
    var voRow = this.getRowIndex(i);
    this.setCellColor(psColor, voRow, psCol);
  }
};
/**
 * Row의 Color 획득
 * @param {Object} poRow row object
 * @return Row의 Color 값
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getRowColor = function(poRow){
  //5.0에서 6.0 으로 변경 되면서 GetColor메소드가 제거 되었음

  if(!!this.grid && !!poRow){
  if(!!poRow.Color){
    var vsRGBArr = poRow.Color;
    return eXria.controls.xhtml.Util.getRGBToHex(Number(vsRGBArr[0]),Number(vsRGBArr[1]),Number(vsRGBArr[2]));
  }
  return poRow.Color;
  //if(this.grid) return this.grid.GetColor(poRow);
  }
  else alert("getRowColor call Error");
};

/**
 * Column의 Color 획득
 * @param {Object} poRow row object
 * @param {String} psCol HeadColumn의 ID
 * @return Column의 Color 값
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getCellColor = function(poRow, psCol){


  if(this.grid) return this.grid.GetColor(poRow, psCol);
  else alert("getColumnColor call Error");
};

/**
 * NodeSet value를 문자열 형태로 반환하는 메소드
 * @param {String} psCol 현재 컬럼명
 * @param {String} psValue xPath의 특정 컬럼
 * @param {String} psPath xPath로 지정된 곳
 * @param {String} psDelimeter 기본 컬럼에 설정된 Delimeter
 * @return NodeSet value 문자열
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.getNodeSetString = function(psInstance, psValue, psPath, psDelimeter){
  var voData = new eXria.controls.DataRefNodeset(this);
  var vsDelimeter = psDelimeter;

  if(vsDelimeter == null)
    vsDelimeter = "|";

  var vsInstanceID = psInstance;

  voData.setNodesetRef(vsInstanceID, psPath);
  var vsValueNode = "";
  var voCollectionNode = voData.getNodesetData2();

  if(voCollectionNode) {
    var vnLoop = voCollectionNode.getLength();
    var voMapNode = null;
    var voItem = null;
    var vsNodeVal = null;
    for(var i = 0; i < vnLoop; i++) {
      voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
      vsNodeVal = voMapNode.get(psValue);
      vsValueNode += vsDelimeter + (vsNodeVal ? vsNodeVal : "");
    }
  }
  return vsValueNode;
};
/**
 * GridEx에 연결된 Dataset을 Excel파일로 export한다.
 * @param {String} psPath export할 Excel 화일의 경로명
 * @param {Number} pnStartIdx export할 시작 Index
 * @param {Number} pnEndIdx export할 마지막 Index
 * @param {String} cell안에 데이터의 세로 정렬 [ex. "top", "middle", "bottom"]
 * @return Export의 성공여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.exportExcel = function(psPath, pnStartIdx, pnEndIdx, psVarticalAlign){
  if(psVarticalAlign == null) psVarticalAlign = "middle";
  if(!this.dataset) return false;
//  this.dataset.rebuild(false);
  var voModel = this.canvas.page.model;
  var voFSO = voModel.getFileSystemObject();
  var vsId = this.id;
  var vsFileName = this.userAttr;
  if(vsFileName == null || vsFileName == "") vsFileName = vsId;

  function checkFilePath(pbOver){
    if(!psPath || pbOver === false) psPath = voFSO.showFilePicker("Export Excel File", vsFileName + ".xls", "excel (*.xls)|*.xls|", 4);
    if(psPath != null && psPath != "" && voFSO.fileExists(psPath)){
      if(!window.confirm("The file '" + psPath + "' already exists.\nDo you want to replace the existing file?")) return checkFilePath(false);
    }
    return psPath;
  }

  psPath = checkFilePath();
  if(!psPath) return false;
  try{
  var vsConnId = this.datasetId + "conn";
    var conn = voModel.plugin.getConnection(vsConnId, voModel.plugin.ETBDATASETSOURCE, this.datasetId, voModel.plugin.ETBEXCELFILESOURCE, "", psPath);
    var comm = conn.getCommand(vsConnId);
    comm.changeTarget(voModel.plugin.ETBEXCELFILESOURCE,"",psPath);

  var vnVarticalAlign = comm.EXCEL_VERTICALALIGN_MIDDLE;
  psVarticalAlign = psVarticalAlign.toLowerCase();
  if (psVarticalAlign == "top")    vnVarticalAlign = comm.EXCEL_VERTICALALIGN_TOP;
  else if (psVarticalAlign == "bottom")vnVarticalAlign = comm.EXCEL_VERTICALALIGN_BOTTOM;
  comm.setVerticalAlign(vnVarticalAlign);

    if(pnStartIdx) comm.setMinRow(pnStartIdx);
    if(pnEndIdx) comm.setMaxRow(pnEndIdx);

    comm.executeQuery(comm.ETBDATAREPLACE | comm.ETBFIELDNAMENEW| comm.ETBFIRSTROWFIELD_TGT);
    conn.close();
  }catch(e){
    return false;
  }
  return true;
};
/**
 * @param {String} export 할 column id, 여러개일 경우 쉼표로 구분. [ex. "colId1,colId2,colId3"]
 * @param {Boolean} pbHeader Header 유무, false가 넘어올 경우에만 Header를 출력하지 않음
 * @param {String} psPath export할 Excel 화일의 경로명
 * @param {Number} pnStartIdx export할 시작 Index
 * @param {Number} pnEndIdx export할 마지막 Index
 * @param {String} cell안에 데이터의 세로 정렬 [ex. "top", "middle", "bottom"]
 * @type Boolean
 * @return Export 성공 유무
 * @author Choe, Hyeon jong.
 */
eXria.controls.xhtml.GridEx.prototype.exportExcelSelectedCols = function(psColIds, pbHeader, psPath, pnStartIdx, pnEndIdx, psVarticalAlign){
  return this.exportExcelMatchHeader(pbHeader, psPath, pnStartIdx, pnEndIdx, psColIds, null, psVarticalAlign);
};
/**
 * Grid의 헤더명을 Export될 Excel의 컬럼명으로 하여 GridEx에 연결된 Dataset을 Excel파일로 export 한다.
 * @param {Boolean} pbHeader Header 유무, false가 넘어올 경우에만 Header를 출력하지 않음
 * @param {String} psPath export할 Excel 화일의 경로명
 * @param {Number} pnStartIdx export할 시작 Index
 * @param {Number} pnEndIdx export할 마지막 Index
 * @param {String} export 할 column id, 여러개일 경우 쉼표로 구분. [ex. "colId1,colId2,colId3"]
 * @param {String} cell안에 데이터의 세로 정렬 [ex. "top", "middle", "bottom"]
 * @type Boolean
 * @return Export 성공 유무
 * @author Choe, Hyeon jong.
 */
eXria.controls.xhtml.GridEx.prototype.exportExcelMatchHeader = function(pbHeader, psPath, pnStartIdx, pnEndIdx, psColIds, pbVisibleOnly, psVarticalAlign){
  if(pbVisibleOnly == null) pbVisibleOnly = true;
  if(psVarticalAlign == null) psVarticalAlign = "middle";
  if(!this.dataset) {
    alert("dataset is null");
    return false;
  }


  // 파일 선택창에서 저장할 파일경로 및 파일명을 지정 부분
  var voModel = this.canvas.page.model;
  var voPlugin = voModel.plugin;
  var voFSO = voModel.getFileSystemObject();
  var vsId = this.id;
  var vsFileName = this.userAttr;
  if(vsFileName == null || vsFileName == "") vsFileName = vsId;

  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
  }
  if(voUserAttr && !!voUserAttr.excelFileName) {
    vsFileName = voUserAttr.excelFileName;
  }

  psPath = voFSO.showFilePicker("Export Excel File", vsFileName + ".xls", "excel (*.xls)|*.xls|", 4, psPath);
  if(!psPath) return false;

  // export 처리
  try {
    var vsConnId = (new Date().getTime()) + this.datasetId + "conn";
    var conn = voPlugin.getConnection(vsConnId, voPlugin.ETBDATASETSOURCE, this.datasetId, voPlugin.ETBEXCELFILESOURCE, "", psPath);
    var comm = conn.getCommand(vsConnId);

    comm.changeTarget(voPlugin.ETBEXCELFILESOURCE,"",psPath);

  var vnVarticalAlign = comm.EXCEL_VERTICALALIGN_MIDDLE;
  psVarticalAlign = psVarticalAlign.toLowerCase();
  if (psVarticalAlign == "top")    vnVarticalAlign = comm.EXCEL_VERTICALALIGN_TOP;
  else if (psVarticalAlign == "bottom")vnVarticalAlign = comm.EXCEL_VERTICALALIGN_BOTTOM;
  comm.setVerticalAlign(vnVarticalAlign);

    var vaColIds = new Array();
    var vaHeadColIds = this.getHeadColumnList();

    if(psColIds) vaColIds = psColIds.split(",");
    else {
      var voColumn = null;
      for(var vnIndex = 0; vnIndex < vaHeadColIds.length; vnIndex++) {
        voColumn = this.getBodyColumn(null, vaHeadColIds[vnIndex]);
        if(voColumn.visible == false && pbVisibleOnly) continue;
//        vaColIds.push(this.getColRef(vaHeadColIds[vnIndex]));
        if(voColumn.datasetCol) vaColIds.push(voColumn.datasetCol);
      }
    }

    var vaHeadColIds = this.getHeadColumnList();
    var vaTmpColRef = [];
    var vsColRef = null;
    var voBodyCol = null;
    var voReg = null;
    var voMap = null;
    var vaValue = null, vaLabel = null;

    var voFuncReplaceColId = function(psColRef) {
      var vsOriColRef = psColRef;
      psColRef = "__" + psColRef;
      var vnSize = vaColIds.length;

      for(var k = 0; k < vaColIds.length; k++) {
        if(vaColIds[k] == vsOriColRef) {
          vaColIds[k] = psColRef;
          break;
        }
      }

      return psColRef;
    };

    // Enum type일 경우 value가 아닌 label로 출력하기 위한 부분
    var vbSkip = false;
    for(var i = 0, vnLen = vaHeadColIds.length ; i < vnLen ; i++) {
      voBodyCol = this.getBodyColumn(null, vaHeadColIds[i]);
      if(pbVisibleOnly && voBodyCol.visible == false) vbSkip = true;
      else vbSkip = false;
      if(psColIds == null && vbSkip) { continue; }
//      vsColRef = this.getColRef(vaHeadColIds[i]);
      vsColRef = voBodyCol.datasetCol;
      if(vsColRef == null) continue;
      switch(voBodyCol.type) {
        case "Enum" :
          voMap = {};
          vaValue = voBodyCol.itemgroup.getItemValuesToArray();
          vaLabel = voBodyCol.itemgroup.getItemLabelsToArray();
          var vnSize = vaValue.length;
          for(var j = 0; j < vnSize; j++) {
            voMap[vaValue[j]] = vaLabel[j];
          }
          this.addLabelColumn(vsColRef, vaTmpColRef, voMap);
          vsColRef = voFuncReplaceColId(vsColRef);
          break;
        case "Date" :
          this.addDateFormatColumn(vsColRef, vaTmpColRef, voBodyCol);
          vsColRef = voFuncReplaceColId(vsColRef);
          break;
        case "Text" :
        case "Lines" :
          if(!!voBodyCol.regFormat) {
            this.addTextFormatColumn(vsColRef, vaTmpColRef, voBodyCol);
            vsColRef = voFuncReplaceColId(vsColRef);
          }
          break;
      }
      // 헤더를 화면에 보이는 텍스트로 설정
      comm.setFieldMatch(vsColRef, this.getTitleText(vaHeadColIds[i]));
    }

    vsColIds = vaColIds.join(",");
    comm.setColSeq(vsColIds);
    if(pnStartIdx) comm.setMinRow(pnStartIdx);
    if(pnEndIdx) comm.setMaxRow(pnEndIdx);

    // 헤더 출력인 경우의 처리
    var vnExecConst = comm.ETBFIELDNAMENEW | comm.ETBDATAREPLACE;
    if(pbHeader != false) {
      vnExecConst = vnExecConst | comm.ETBFIRSTROWFIELD_TGT;
    }

    comm.executeQuery(vnExecConst);
    comm.setColSeq("");
    conn.close();
    var voDst = this.dataset;
    var vnSize = vaTmpColRef.length;
    var vsTmpCol = null;
    for(var i = 0; i < vnSize; i++) {
      vsTmpCol = vaTmpColRef[i];
      voDst.removeColumn(vsTmpCol);
    }
  }catch(e){
    var voDst = this.dataset;
    var vnSize = vaTmpColRef.length;
    var vsTmpCol = null;
    for(var i = 0; i < vnSize; i++) {
      vsTmpCol = vaTmpColRef[i];
      voDst.removeColumn(vsTmpCol);
    }
    alert(e.description);
    return false;
  }
  return true;
};
/**
 * Enum 등의 List타입 컬럼의 cell값을 excel export시 화면에 보여지는 값으로 내보내기 위해 사용
 * @param {String} psColRef dataset 필드명
 * @param {Array(String)} paTmpColRef 임시적으로 추가되는 Label컬럼 명세를 저장하기 위한 배열
 * @param {Object} poMap dataset 필드에 매핑되는 label값을 얻어오기 위한 Map 객체
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addLabelColumn = function(psColRef, paTmpColRef, poMap) {
  var voDst = this.dataset;
  var vsTmpColRef = "__" + psColRef;
  paTmpColRef.push(vsTmpColRef);
  voDst.addColumn(-1, vsTmpColRef);

  var vnSize = voDst.getRowCnt();
  var vsValue = null;
  var vsLabel = null;
  for(var i = 1; i <= vnSize; i++) {
    vsValue = voDst.get(i, psColRef);
    vsLabel = poMap[vsValue];
    if(vsLabel == null || vsLabel == "&nbsp") vsLabel = "";
    voDst.simpleSet(i, vsTmpColRef, vsLabel);
  }
};
/**
 * Date 타입 컬럼의 cell값을 excel export시 화면에 보여지는 값으로 내보내기 위해 사용
 * @param {String} psColRef dataset 필드명
 * @param {Array(String)} paTmpColRef 임시적으로 추가되는 Label컬럼 명세를 저장하기 위한 배열
 * @param {eXria.controls.xhtml.GridEx.BodyColumn} poBodyCol DateFormat 정보를 저장하고 있는 BodyColumn 객체
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addDateFormatColumn = function(psColRef, paTmpColRef, poBodyCol) {
  var voDst = this.dataset;
  var vsTmpColRef = "__" + psColRef;
  paTmpColRef.push(vsTmpColRef);
  voDst.addColumn(-1, vsTmpColRef);

  var vnSize = voDst.getRowCnt();
  var vsValue = null;
  var vsLabel = null;
  for(var i = 1; i <= vnSize; i++) {
    vsValue = voDst.get(i, psColRef);
    vsValue = this.convertValueTGrid(poBodyCol, vsValue, null, poBodyCol.colId);
    vsLabel = TGP.GetString(vsValue, "date", poBodyCol.regFormat);
    if(vsLabel == null || vsLabel == "&nbsp") vsLabel = "";
    voDst.simpleSet(i, vsTmpColRef, vsLabel);
  }
};
/**
 * Text나 Lines타입 컬럼의 cell값을 excel export시 화면에 보여지는 값으로 내보내기 위해 사용
 * @param {String} psColRef dataset 필드명
 * @param {Array(String)} paTmpColRef 임시적으로 추가되는 Label컬럼 명세를 저장하기 위한 배열
 * @param {eXria.controls.xhtml.GridEx.BodyColumn} poBodyCol format 정보를 저장하고 있는 BodyColumn 객체
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addTextFormatColumn = function(psColRef, paTmpColRef, poBodyCol) {
  var voDst = this.dataset;
  var vsTmpColRef = "__" + psColRef;
  paTmpColRef.push(vsTmpColRef);
  voDst.addColumn(-1, vsTmpColRef);

  var vnSize = voDst.getRowCnt();
  var vsValue = null;
  var vsLabel = null;
  for(var i = 1; i <= vnSize; i++) {
    vsValue = voDst.get(i, psColRef);
    vsLabel = TGP.GetString(vsValue, "string", poBodyCol.regFormat);
    if(vsLabel == null || vsLabel == "&nbsp") vsLabel = "";
    voDst.simpleSet(i, vsTmpColRef, vsLabel);
  }
};
//yhkim 2009.04.22
/**
 * enum list를 설정한다
 * @param {Object} poRow 현재 row
 * @param {String} psCol 현재 column
 * @param {String} psEnum 설정하려는 enum값
 * @param {String} psEnumKeys 설정하려는 enumkey값
 * @param {String} psValue 인덱스설정
 */
eXria.controls.xhtml.GridEx.prototype.setEnumList = function(poRow, psCol, psEnum, psEnumKeys, psValue){
  var vsColumnEnum = psCol + "Enum";
  var vsColumnEnumKey = psCol + "EnumKeys";
  poRow[vsColumnEnum] = psEnum;
  poRow[vsColumnEnumKey] = psEnumKeys;
  this.setValue(poRow, psCol, psValue, true);
};
/**
 * select list를 설정한다
 * @param {Object} poRow 현재 row
 * @param {String} psCol 현재 column
 * @param {String} psSelect 설정하려는 selectString 값
 * @param {String} psDefault 설정하려는 인덱스 설정, Default index는 0
 * @param {String} psDefault 설정하려는 Select의 index를 찾기위한 Delimeter, 기본값은 "|"
 * @ignore
 */
/*
eXria.controls.xhtml.GridEx.prototype.setSelectList = function(poRow, psCol, psSelect, piDefaultIndex, psDelimeter){
  var vsColumnSelect = psCol + "Defaults";
  if(poRow.setAttribute) poRow.setAttribute(vsColumnSelect, psSelect);
  else poRow[vsColumnSelect] = psSelect;

  var vsDelimeter = psDelimeter;
  if(vsDelimeter == null)
    vsDelimeter = "|";

  var vsArray = null;
  if(piDefaultIndex > 0){
    vsArray = psSelect.split('|', piDefaultIndex+2);
    if(vsArray.length > 1)
      psDefault = vsArray[piDefaultIndex+1];
  }

  this.setValue(poRow, psCol, psDefault);
  this.refreshCell(poRow,psCol);
};
*/
/**
 * 정해진 문자형 마스크 포맷으로 값을 변환.
 * @param {String} psValue 컨트롤 disabled설정
 * @return 문자형 마스크 포맷 적용 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.toStringFormatValue = function(psValue, psFormat){
  if(psValue == "") return "";
  var vsMaskPrompt = String.fromCharCode(255);
  var vsFormat = psFormat.replace(/[x#*]/gi,vsMaskPrompt);
  var vsReg = new RegExp('['+vsMaskPrompt+']','gi');
  var vsValue = psValue.replace(vsReg,"0");
  var vsRegValue = vsFormat;
  var vsRegFormat = new RegExp('['+vsMaskPrompt+']','i');
  for(var i=0;i < vsValue.length;i++) {
    vsRegValue = vsRegValue.replace(vsRegFormat, vsValue.charAt(i));
  }
  vsRegValue = vsRegValue.replace(/[x#*]/gi, vsMaskPrompt);
  return vsRegValue;
};
/**
 * 마스크 프롬프트를 공백문자롤 치환하는 메소드
 * @param {String} psValue 컨트롤 disabled설정
 * @return 문자형 마스크 포맷 적용 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.maskPromptToBlank = function(psValue){
  var vsMaskPrompt = String.fromCharCode(255);
  var vsReg = new RegExp('['+vsMaskPrompt+']','gi');
  psValue = psValue.replace(vsReg, "");
  return psValue;
};
/**
 * 주어진 data형 value에 따라 column type을 설정하기 위한 메소드.
 * @param {String} psColId column id
 * @param {String} psValue value
 * @private;
 */
eXria.controls.xhtml.GridEx.prototype.setDateValueType = function(psColId, psValue){
  var voColumn = this.getBodyColumn(null, psColId);
  psValue = String(psValue);
  psValue = psValue.replace(/\D/g, "");
  if(psValue.length == 14){ // datetime
    voColumn.dateType = "DateTime";
  }else if(psValue.length == 8){ // date
    voColumn.dateType = "Date";
  }else if(psValue.length == 6){ // time
    voColumn.dateType = "Time";
  }
};
/**
 * 주어진 column에 해당하는 format으로 value를 변환시켜 반환하는 메소드.
 * @param {String} psValue value
 * @param {String} psColId column id
 * @return 주어진 column에 해당하는 format으로 value를 변환시킨 값
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getFormattedValue = function(psValue, psColId){
  var voColumn = this.getBodyColumn(null, psColId);
  if(voColumn.formatMask){
    psValue = voColumn.formatMask.toStringFormatValue(psValue, voColumn.format, psColId);
    psValue = voColumn.formatMask.maskPromptToBlank(psValue, psColId);
  }
  return psValue;
};
/**
 * 값을 지정된 Mask에 맞게 변환하여 반환
 * @param {String} psData Data
 * @param {String} psColId Column Id
 * @return 값을 지정된 Mask에 맞게 변환한 문자열
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getMaskedValue = function(poInput, poRow, psColId){
  var voColumn = this.getBodyColumn(null, psColId);

  if(voColumn.formatMask){
    return voColumn.formatMask.getMaskedValue(poInput, poRow, psColId);
  }
  return poInput.value;
};
/**
 * Mask가 적용된 Value를 Mask를 없앤 후 반환
 * @param {String} psData Data
 * @param {String} psColId Column Id
 * @return value에서 Mask가 제거된 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getUnMaskedValue = function(psData, psColId){
  var voColumn = this.getBodyColumn(null, psColId);
  if(voColumn.formatMask){
   psData = voColumn.formatMask.getUnMaskedValue(psData, psColId);
  }
  return psData;
};
/**
 * 현재 텍스트가 전체 select 되어있는지 여부를 확인
 * @param {HTMLEvent} e 윈도우 이벤트
 * @param {HTMLInput} poInput html inputbox
 * @param {String} psColId column id
 */
eXria.controls.xhtml.GridEx.prototype.checkSelect = function(e, poInput, psColId){
  var voColumn = this.getBodyColumn(null, psColId);

  if(voColumn.formatMask){
    voColumn.formatMask.checkSelect(e, poInput, psColId);
  }
};
/**
 * 입력키에 유효성을 체크하고 마스크 타입에 맞게 문자열 변환 메소드.
 * @param {HTMLEvent} e 윈도우이벤트
 * @param {HTMLInput} poInput html inputbox
 * @param {String} psColId column id
 * @return 작업수행의 성공 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.checkKey = function(e, poInput, psColId){
  var voColumn = this.getBodyColumn(null, psColId);

  if(voColumn.formatMask){
    return voColumn.formatMask.checkKey(e, poInput, psColId);
  }
};
/**
 * KeyDown value 설정
 * @param {String} psValue value
 * @param {Object} poRow row object
 * @param {String} psColId
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setKeyDownValue = function(psValue, poRow, psColId){
  var voColumn = this.getBodyColumn(null, psColId);

  if(voColumn.formatMask){
    voColumn.formatMask.setKeyDownValue(psValue, poRow, psColId);
  }
};
/**
 * 값을 yyyymmdd형태의 문자열 값으로 반환.
 * @param psData 값
 * @param psColId Column Id
 * @return yyyymmdd형태의 문자열 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getDateString = function(psData, psColId){
  var voDate = this.getDate(psData, psColId);
  var vaStrBuf = [];
  vaStrBuf.push(voDate.getFullYear());
  var vnMonth = voDate.getMonth() + 1;
  if(vnMonth < 10) vnMonth = "0" + vnMonth;
  vaStrBuf.push(vnMonth);
  var vnDate = voDate.getDate();
  if(vnDate < 10) vnDate = "0" + vnDate;
  vaStrBuf.push(vnDate);

  return vaStrBuf.join("");
};
/**
 * 값을 Date형태로 반환.
 * @param psData 값
 * @param psColId Column Id
 * @return Date형으로 변환된 컨트롤 설정 값
 * @type Date
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getDate = function(psData, psColId){
  var voColumn = this.getBodyColumn(null, psColId);
  var voDate = new Date();
  var vsValue = psData;
  var vsMask = voColumn.mask;
  var vsFormat = vsMask.replace(/[^YMD]/gi,"");
  vsValue = vsValue.replace(/[^0-9]/gi,"");
  var vnIndex = vsValue.length;
  //year
  var temp = vsFormat.indexOf("YYYY",0);
  var vnYear = vsValue.substring(temp,temp+4);
  if(vnYear.length == 4) voDate.setFullYear(vnYear);
  //month
  var temp = vsFormat.indexOf("MM",0);
  var vnMonth = vsValue.substring(temp,temp+2);
  if(vnMonth.length == 2) voDate.setMonth(vnMonth-1);
  //date
  var temp = vsFormat.indexOf("DD",0);
  var vnDate = vsValue.substring(temp,temp+2);
  if(vnDate.length == 2) voDate.setDate(vnDate);

  return voDate;
};
/**
 * addSeparator
 * @param {String} psValue value
 * @param {Number} pnType 데이타형 value의 format을 구분 짓기 위한 정수 값.
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @return Separator가 추가된 value 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.addSeparator = function(psValue, pnType, poRow, psColId){
  if(!pnType) pnType = 1;
  var vsDateSep = "-";
  if(pnType == 2) vsDateSep = "/";
  psValue = String(psValue);

  var voColumn = this.getBodyColumn(null, psColId);

  function addDateSeparator(psDate){
    return psDate.substring(0, 4) + vsDateSep + psDate.substring(4, 6) + vsDateSep + psDate.substring(6, 8);
  }
  function addTimeSeparator(psTime){
    return psTime.substring(0, 2) + ":" + psTime.substring(2, 4) + ":" + psTime.substring(4, 6);
  }
  var vnlen = psValue.length;
  if(psValue.length == 14){ // datetime
    if(voColumn) {
      if(voColumn.dateType == null) {
        voColumn.dateType = "DateTime";
        voColumn.maxLength = 14;
      }
    }
    var vsDate = psValue.substring(0, 8);
    var vsTime = psValue.substring(8, 14);
    vsDate = addDateSeparator(vsDate);
    vsTime = addTimeSeparator(vsTime);
    psValue = vsDate + " " + vsTime;
  }else if(psValue.length == 8){ // date
    if(voColumn) {
      if(voColumn.dateType == null) {
        voColumn.dateType = "Date";
        voColumn.maxLength = 8;
      }
    }
    psValue = addDateSeparator(psValue);
  }else if(psValue.length == 6){ // time
    if(voColumn) {
      if(voColumn.dateType == null) {
        voColumn.dateType = "Time";
        voColumn.maxLength = 6;
      }
    }
    psValue = addTimeSeparator(psValue);
  }
  return psValue;
};
/**
 * Title의 Text를 획득
 * @param {String} psCol headColumn의 ID
 * @return Title의 Text
 * @type String
 */
eXria.controls.xhtml.GridEx.prototype.getTitleText = function(psCol){
  var voCols = [],
      voHeader = this.header,
      i,j,k,voRow, vnLength, vnLength2,
      voArray=[], voColumn, vsTitle;

  voCols[0] = voHeader.cols["left"];
  voCols[1] = voHeader.cols["center"];
  voCols[2] = voHeader.cols["right"];

  pastureLoop:
  for(var i = 0; i < 3; i++) {
    if(voCols[i]) {
      vnLength = voCols[i].rows.length;
      for(var j=0; j < vnLength; j++){
        if(voHeader.mainRow != j) continue;
        voRow = voCols[i].rows[j];
        for ( var k = 0; voRow.columns.length > k; k++) {
          voColumn = voRow.columns[k];
          if(voColumn.id == psCol) {
            vsTitle = voColumn.value;
            break pastureLoop;
          }
        }
      }
    }
  }

  return vsTitle;

  /*
  var vsTitle = null;
  if(this.grid.XHeader.getAttribute) vsTitle = this.grid.XHeader.getAttribute(psCol);
  else vsTitle = this.grid.XHeader[psCol];
  return vsTitle;
  */

};
/**
 * Title의 Text를 설정
 * @param {String} psCol headColumn의 ID
 * @param {String} psValue 설정될 Text
 */
eXria.controls.xhtml.GridEx.prototype.setTitleText = function(psCol, psValue, poRow){
  var voCols = [],
  voHeader = this.header,
  i,j,k,voRow, voTRow, vnLength, vnLength2,
  voArray=[], voColumn;

  voCols[0] = voHeader.cols["left"];
  voCols[1] = voHeader.cols["center"];
  voCols[2] = voHeader.cols["right"];
  
  pastureLoop:
  for(var i = 0; i < 3; i++) {
    if(voCols[i]) {
      vnLength = voCols[i].rows.length;
      for(var j=0; j < vnLength; j++){
        if(voHeader.mainRow != j) continue;
        voRow = voCols[i].rows[j];
        for ( var k = 0; voRow.columns.length > k; k++) {
          voColumn = voRow.columns[k];
          if(voColumn.id == psCol) {
            voColumn.value = psValue;
            if(poRow) {
             this.grid.SetValue(poRow, psCol, psValue, true); 
            } else {
              voTRow = this.getHeaderRowByIndex(j);
              this.grid.SetValue(voTRow, psCol, psValue, true); 
            }
            break pastureLoop;
          }
        }
      }
    }
  }
};
/**
 * Column을 숨김
 * @param {String} psCol 적용시킬 headColumn의 ID
 */
eXria.controls.xhtml.GridEx.prototype.hideColumn = function(psCol){
  this.hideColMap.put(psCol, "");
  this.grid.HideCol(psCol);
};
/**
 * Column을 보임
 * @param {String} psCol 적용시킬 headColumn의 ID
 */
eXria.controls.xhtml.GridEx.prototype.showColumn = function(psCol){
  this.hideColMap.remove(psCol);
  this.grid.ShowCol(psCol);
};
/**
 * Row를 숨김
 * @param {Object} poRow 적용시킬 Row
 */
eXria.controls.xhtml.GridEx.prototype.hideRow = function(poRow){
  this.grid.HideRow(poRow);
};
/**
 * Row를 보임
 * @param {Object} poRow 적용시킬 Row
 */
eXria.controls.xhtml.GridEx.prototype.showRow = function(poRow){
  this.grid.ShowRow(poRow);
};
/**
 * CanEdit를 설정
 * @param {Object} poRow 설정될 Row
 * @param {String} psCol 설정될 Column의 headColumn의 ID, null일경우 Row에 설정
 * @param {Boolean} pbEdit 설정될 값
 */
eXria.controls.xhtml.GridEx.prototype.setCanEdit = function(poRow, psCol, pbEdit){
  var vsAttrName = null;
  if(psCol) vsAttrName = psCol + "CanEdit";
  else vsAttrName = "CanEdit";

  if(poRow) {
    poRow[vsAttrName] = pbEdit;
    var voBodyCol = this.getBodyColumn(null, psCol);

    //2010.09.02 voBodyCol이 null이 될경우
    //에 대한 처리 코드 추가
    if((!!voBodyCol) && voBodyCol.type == "Date") {
      if (!pbEdit) {
        poRow["Button"] = "None";
      } else if(voBodyCol.calendarEnable) {
        poRow["Button"] = "Date";
      }
    }
    this.refreshRow(poRow);
  }
};
/**
 * CanFocus를 설정
 * @param {Object} poRow 설정될 Row
 * @param {String} psCol 설정될 Column의 headColumn의 ID, null일경우 Row에 설정
 * @param {Boolean} pbFocus 설정될 값
 */
eXria.controls.xhtml.GridEx.prototype.setCanFocus = function(poRow, psCol, pbFocus){
  var vsAttrName = null;
  if(psCol) vsAttrName = psCol + "CanFocus";
  else vsAttrName = "CanFocus";

  poRow[vsAttrName] = pbFocus;

  this.refreshRow(poRow);
};
/**
 * CanDrag를 설정
 * @param {Object} poRow 설정될 Row
 * @param {String} psCol 설정될 Column의 headColumn의 ID, null일경우 Row에 설정
 * @param {Boolean} pbDrag 설정될 값
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setCanDrag = function(poRow, pbDrag){
  poRow["CanDrag"] = pbDrag;

  this.refreshRow(poRow);
};
/**
 * 주어진 row object가 자식 row를 가지고 있는지 여부를 알려주는 메소드
 * @param {Object} poRow row object
 * @return 주어진 row object가 자식 row를 가지고 있는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.hasChildren = function(poRow){
  if(this.grid.HasChildren(poRow)) return true;
  else return false;
};
/**
 * 새로운 창으로 GridEx를 프린트
 * @return 프린트의 성공여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.print = function(){
  return this.grid.ActionPrint();
};
/**
 * Cell의 InnerStyle을 적용
 * @return 스타일 적용여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.setCellInnerStyle = function(poRow, psCol, psStyleAttr, psStyleValue){
  var voCtrl = this.grid.GetCell(poRow, psCol);
  if(voCtrl == null) return false;
  if(voCtrl.style == null) return false;
  var voStyle = voCtrl.style;
  voStyle[psStyleAttr] = psStyleValue;
  return true;
};
/**
 * Cell의 OuterStyle을 적용
 * @return 스타일 적용여부
 * @type Boolean
 */
eXria.controls.xhtml.GridEx.prototype.setCellOuterStyle = function(poRow, psCol, psStyleAttr, psStyleValue){
  var voCtrl = this.grid.GetCell(poRow, psCol);
  if(voCtrl){
    var voStyle = voCtrl.style;
    voStyle[psStyleAttr] = psStyleValue;
    return true;
  }
  return false;
};

/**
 * HeadColumn의 ID 리스트를 얻어오기
 * pnSection : 0(LeftCols), 1(Cols), 2(RightCols), null(all)
 * @return HeadColumn의 ID리스트
 * @type Array(String)
 */
eXria.controls.xhtml.GridEx.prototype.getHeadColumnList = function(pnSection) {

  var voCols = new Array();
  var voColumn = null;

  if(pnSection == 0)
    voCols[0] = this.body.cols["left"];
  else if(pnSection == 1)
    voCols[0] = this.body.cols["center"];
  else if(pnSection == 2) {
    voCols[0] = this.body.cols["right"];
  }
  else if(pnSection == null) {
    voCols[0] = this.body.cols["left"];
    voCols[1] = this.body.cols["center"];
    voCols[2] = this.body.cols["right"];
  }
  else
    return voCols;

  var vsCols = new Array();

  for(var i=0; i<voCols.length; i++) {
    if(voCols[i]) {
      for(var j=0; j<voCols[i].rows.length; j++) {
        voColsRow = voCols[i].rows[j];
        for(var k=0; k<voColsRow.columns.length; k++) {
            voColumn = voColsRow.columns[k];
            vsCols.push(voColumn.colId);
        }
      }
    }
  }
  return vsCols;
};

/**
 * @class Concreate xhtml GridEx.Header<br>
 * GridEx 컨트롤의 헤더부분 구성정보 담당 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx} poParent 상위 그리드 객체
 * @return 새로운 eXria.controls.xhtml.GridEx.Header 객체
 * @type eXria.controls.xhtml.GridEx.Header
 * @constructor
 */
eXria.controls.xhtml.GridEx.Header = function(poParent) {
  /**
   * 상위 객체 지정.
   * @type eXria.controls.xhtml.GridEx
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent;
  /**
   * left, center, right 컬럼그룹 저장 배열.
   * @type Array
   */
  this.cols = new Array(3);
  /**
   * 헤더의 컬럼 타이틀을 구성하는 메인 row index.
   * @type Number
   */
  this.mainRow = null;
  /**
   * 헤더의 표시 여부
   * @type Boolean
   */
  this.visible = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 배경색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 텍스트 가로 정렬 방식.(left | center | right)
   * @type String
   */
  this.textAlign = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 텍스트 밑줄 적용 방식.(underline | overline | line-through | blink)
   * @type String
   */
  this.textDecoration = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 보더 색상.
   * @type Number
   */
  this.borderColor = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 헤더 컬럼 셀의 공통적으로 적용될 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 스타일의 속성의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {};
};

/**
 * 컬럼그룹 생성.
 * @return 컬럼그룹
 * @type eXria.controls.xhtml.Columns
 */
eXria.controls.xhtml.GridEx.Header.prototype.createCols = function() {
  return new eXria.controls.xhtml.GridEx.Cols(this);
};
/**
 * 컬럼그룹 추가.
 * @param {eXria.controls.xhtml.GridEx.Columns} poCols 추가될 컬럼 그룹
 * @param {String} psType 컬럼 위치 정보('left' | 'center' | 'right')
 */
eXria.controls.xhtml.GridEx.Header.prototype.addCols = function(poCols, psType) {
  poCols.type = psType;
  if(psType == "left") this.cols[psType] = poCols;
  else if(psType == null || psType == "center") this.cols[psType] = poCols;
  else if(psType == "right") this.cols[psType] = poCols;
};


/**
 * @class Concreate xhtml GridEx.Body.<br>
 * Grid 컨트롤의 컨텐츠 구성정보 당담 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx} poParent 상위 그리드 객체
 * @return 새로운 eXria.controls.xhtml.GridEx.Body 객체
 * @type eXria.controls.xhtml.GridEx.Body
 * @constructor
 */
eXria.controls.xhtml.GridEx.Body = function(poParent) {
  /**
   * 상위 객체 지정.
   * @type eXria.controls.xhtml.GridEx
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent;
  /**
   * left, center, right 컬럼그룹 저장 배열.
   * @type Array
   */
  this.cols = new Array(3);
  /**
   * 스타일 속성의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * height.
   * @type Number
   */
  this.height = null;
};
/**
 * 컬럼그룹 생성.
 * @return 컬럼그룹
 * @type eXria.controls.xhtml.Columns
 */
eXria.controls.xhtml.GridEx.Body.prototype.createCols = function() {
  return new eXria.controls.xhtml.GridEx.Cols(this);
};
/**
 * 컬럼그룹 추가.
 * @param {eXria.controls.xhtml.GridEx.Columns} 추가될 컬럼 그룹
 * @param {String} psType 컬럼 위치 정보('left' | 'center' | 'right')
 */
eXria.controls.xhtml.GridEx.Body.prototype.addCols = function(poCols, psType) {
  poCols.type = psType;
  if(psType == "left") this.cols[psType] = poCols;
  else if(psType == null || psType == "center") this.cols[psType] = poCols;
  else if(psType == "right") this.cols[psType] = poCols;
};


/**
 * @class Concreate xhtml GridEx.FunctionRow.<br>
 * Grid 컨트롤의 컨텐츠 구성정보 당담 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx} poParent 상위 그리드 객체
 * @return 새로운 eXria.controls.xhtml.GridEx.FunctionRow 객체
 * @type eXria.controls.xhtml.GridEx.FunctionRow
 * @constructor
 */
eXria.controls.xhtml.GridEx.FunctionRow = function(poParent) {
  /**
   * 상위 객체 지정.
   * @type eXria.controls.xhtml.GridEx
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent;
  /**
   * 스타일 속성의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * height.
   * @type Number
   */
  this.height = null;
  /**
   * row object들을 저장하는 배열.
   * @type Array(Object)
   */
  this.rows = new Array();
};


/**
 * @class Concreate xhtml GridEx.Footer.<br>
 * Grid 컨트롤의 footer 컨텐츠 구성정보 당담 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx} poParent 상위 그리드 객체
 * @return 새로운 eXria.controls.xhtml.GridEx.Footer 객체
 * @type eXria.controls.xhtml.GridEx.Footer
 * @constructor
 */
eXria.controls.xhtml.GridEx.Footer = function(poParent) {
  /**
   * 상위 객체 지정.
   * @type eXria.controls.xhtml.GridEx
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent;
  /**
   * 스타일 속성의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * height.
   * @type Number
   */
  this.height = null;
  /**
   * row object들을 저장하는 배열.
   * @type Array(Object)
   */
  this.rows = new Array();
};
/**
 * row object 생성 메소드
 * @return 새로 생성된 row object
 * @type eXria.controls.xhtml.GridEx.FootRow
 */
eXria.controls.xhtml.GridEx.Footer.prototype.createRow = function(){
  return new eXria.controls.xhtml.GridEx.FootRow(this);
};
/**
 * rows에 row object를 추가하기 위한 메소드
 * @param {Object} poRow row object
 */
eXria.controls.xhtml.GridEx.Footer.prototype.addRow = function(poRow){
  this.rows.push(poRow);
};


/**
 * @class Concreate xhtml Columns.<br>
 * 컬럼그룹 구성을 구성하기 위한 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridHeader|eXria.controls.xhtml.GridBody} poParent 상위 객체
 * @return 새로운 eXria.controls.xhtml.Columns 객체
 * @type eXria.controls.xhtml.Columns
 * @constructor
 */
eXria.controls.xhtml.GridEx.Cols = function(poParent) {
  /**
   * 상위 객체 지정.
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 컬럼구룹 타입('left' | 'center' | 'right').
   * @type String
   */
  this.type = null;
  /**
   * 스크롤 바 표시 여부.
   * @type Boolean
   */
  this.noscroll = true;
  /**
   * 행 저장 배열.
   * @type Array
   */
  this.rows = new Array();
};
/**
 * ColumnsRow 생성 메소드.
 * @return 새로운 ColumnsRow 객체
 * @type eXria.controls.xhtml.GridEx.ColumnsRow
 */
eXria.controls.xhtml.GridEx.Cols.prototype.createColsRow = function() {
  var voColsRow = new eXria.controls.xhtml.GridEx.ColsRow(this);
  return voColsRow;
};
/**
 * ColumnsRow 추가 메소드.
 * @param {eXria.controls.xhtml.GridEx.ColumnsRow} poColsRow 추가할 ColumnsRow객체
 */
eXria.controls.xhtml.GridEx.Cols.prototype.addColsRow = function(poColsRow) {
  this.rows.push(poColsRow);
};


/**
 * @class Concreate xhtml FootCols.<br>
 * 컬럼그룹 구성을 구성하기 위한 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridHeader|eXria.controls.xhtml.FootRow} poParent 상위 객체
 * @return 새로운 eXria.controls.xhtml.FootCols 객체
 * @type eXria.controls.xhtml.FootCols
 * @constructor
 */
eXria.controls.xhtml.GridEx.FootCols = function(poParent) {
  /**
   * 상위 객체 지정.
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 컬럼구룹 타입('left' | 'center' | 'right').
   * @type String
   */
  this.type = null;
  /**
   * 스크롤 바 표시 여부.
   * @type Boolean
   */
  this.noscroll = true;
  /**
   * 컬럼 저장 배열. // FootRow용
   * @type Array
   */
  this.columns = new Array();
};
/**
 * 새로운 풋 컬럼을 생성하여 반환
 * @param {String} psId 컬럼식별자
 * @param {String} psType 테이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 풋 컬럼 객체
 * @type eXria.controls.xhtml.FootColumn
 */
eXria.controls.xhtml.GridEx.FootCols.prototype.createFootColumn = function(psId, psHeadColId, psType, psInstanceid, psRef) {
  var voColumn = new eXria.controls.xhtml.GridEx.FootColumn(this, psId, psHeadColId, psType, psInstanceid, psRef);
  return voColumn;
};
/**
 * 컬럼 추가
 * @param {eXria.controls.xhtml.FootColumn} poColumn 추가될 컬럼
 */
eXria.controls.xhtml.GridEx.FootCols.prototype.addColumn = function(poColumn) {
  this.columns.push(poColumn);
  var vcGrx = this.control;
  vcGrx.footColMap.put(poColumn.id, poColumn);
};

/**
 * @class Concreate xhtml GridEx.ColumnsRow.<br>
 * 컬럼그룹 Row를 구성하기 위한 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx.Columns} poParent 상위 객체
 * @return 새로운 eXria.controls.xhtml.GridEx.ColumnsRow 객체
 * @type eXria.controls.xhtml.GridEx.ColumnsRow
 * @constructor
 */
eXria.controls.xhtml.GridEx.ColsRow = function(poParent) {
  /**
   * 상위 객체 지정.
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 객체 식별자
   * @type String
   */
  this.id = null;
  /**
   * 컬럼 저장 배열.
   * @type Array
   */
  this.columns = new Array();

  this.height = null;
};
/**
 * 새로운 헤드 컬럼을 생성하여 반환.
 * @param {String} psId 컬럼식별자
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 헤드 컬럼
 * @type eXria.controls.xhtml.GridEx.HeadColumn
 */
eXria.controls.xhtml.GridEx.ColsRow.prototype.createHeadColumn = function(psId, psInstanceid, psRef) {
  var voColumn = new eXria.controls.xhtml.GridEx.HeadColumn(this.parent, psId, psInstanceid, psRef);
  return voColumn;
};
/**
 * 새로운 바디 컬럼을 생성하여 반환
 * @param {String} psId 컬럼식별자
 * @param {String} psType 테이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 바디 컬럼
 * @type eXria.controls.xhtml.GridEx.BodyColumn
 */
eXria.controls.xhtml.GridEx.ColsRow.prototype.createBodyColumn = function(psId, psHeadColId, psType, psInstanceid, psRef) {
  var voColumn = new eXria.controls.xhtml.GridEx.BodyColumn(this, psId, psHeadColId, psType, psInstanceid, psRef);
  return voColumn;
};
//yhkim 2009.05.19 head 컬럼
/**
 * 새로운 Fuction Column을 생성하여 반환하는 메소드
 * @param {String} psId 새로운 Fuction Column의 id
 * @param {String} psInstanceid 참조 instance id
 * @param {String} psRef 참조 ref 정보
 */
eXria.controls.xhtml.GridEx.ColsRow.prototype.createFunctionColumn = function(
    psId, psInstanceid, psRef) {
  var voColumn = new eXria.controls.xhtml.GridEx.FunctionColumn(this.parent,
      psId, psInstanceid, psRef);
  return voColumn;
};
/**
 * 컬럼 추가
 * @param {eXria.controls.xhtml.GridEx.HeadColumn|eXria.controls.xhtml.GridEx.BodyColumn} poColumn 추가될 컬럼
 */
eXria.controls.xhtml.GridEx.ColsRow.prototype.addColumn = function(poColumn) {
  this.columns.push(poColumn);
  var vcGrx = this.control;
  if(poColumn.ganttId) {
    vcGrx.cfg.ganttIdColumn = poColumn.ganttId;
    vcGrx.cfg.idColumn = poColumn.ganttId;
  }
  if(poColumn instanceof eXria.controls.xhtml.GridEx.HeadColumn) {
    vcGrx.headColMap.put(poColumn.id, poColumn);
  } else if(poColumn instanceof eXria.controls.xhtml.GridEx.BodyColumn) {
    vcGrx.bodyColMap.put(poColumn.id, poColumn);
    vcGrx.bodyColHMap.put(poColumn.colId, poColumn);
    if(poColumn.userAttr) {
      if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(poColumn.userAttr)) poColumn.userAttrObj = eval(poColumn.userAttr);
    }
  } else if(poColumn instanceof eXria.controls.xhtml.GridEx.FunctionColumn) {
    vcGrx.functionColMap.put(poColumn.id, poColumn);
  }
};

/**
 * @class Concreate xhtml GridEx.FootRow.<br>
 * FootRow를 구성하기 위한 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx.Columns} poParent 상위 객체
 * @return 새로운 eXria.controls.xhtml.GridEx.FootRow 객체
 * @type eXria.controls.xhtml.GridEx.FootRow
 * @constructor
 */
eXria.controls.xhtml.GridEx.FootRow = function(poParent) {
  /**
   * 상위 객체 지정.
   * @private
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 객체 식별자
   * @type String
   */
  this.id = null;
  /**
   * left, center, right 컬럼그룹 저장 배열.
   * @type Array
   */
  this.cols = new Array(3);
  /**
   * 스타일 속성의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * height.
   * @type Number
   */
  this.height = null;
};
/**
 * 새로운 컬럼그룹 생성.
 * @return 새로운 컬럼그룹
 * @type eXria.controls.xhtml.Columns
 */
eXria.controls.xhtml.GridEx.FootRow.prototype.createCols = function() {
  return new eXria.controls.xhtml.GridEx.FootCols(this);
};
/**
 * 컬럼그룹 추가.
 * @param {eXria.controls.xhtml.GridEx.Columns} poCols 추가될 컬럼 그룹
 * @param {String} psType 컬럼 위치 정보('left' | 'center' | 'right')
 */
eXria.controls.xhtml.GridEx.FootRow.prototype.addCols = function(poCols, psType) {
  poCols.type = psType;
  if(psType == "left") this.cols[psType] = poCols;
  else if(psType == null || psType == "center") this.cols[psType] = poCols;
  else if(psType == "right") this.cols[psType] = poCols;
};


/**
 * @class Concreate xhtml HeadColumn.<br>
 * GridHeader에 추가될 컬럼을 구성하기 위한 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.ColumnsRow} poParent 상위 객체
 * @param {String} psId 해당 컬럼과 매핑되고 해드컬럼의 ID
 * @param {String} psType 데이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Intance Path
 * @return 새로운 eXria.controls.xhtml.GridEx.HeadColumn 객체
 * @type eXria.controls.xhtml.GridEx.HeadColumn
 * @constructor
 */
eXria.controls.xhtml.GridEx.HeadColumn = function(poParent, psId, psInstanceId, psRef) {
  /**
   * 상위 객체 지정
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 컬럼 식별자.
   * @type String
   */
  this.id = psId;
  /**
   * instanceId
   * @type String
   */
  this.instanceId = psInstanceId;
  /**
   * ref
   * @type String
   */
  this.ref = psRef;
  /**
   * 인스턴스 데이타 접근 객체.
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this.control);
  /**
   * datasetCol
   * @type String
   */
  this.datasetCol = null;
  /**
   * 컬럼 표시 문자열.
   * @type String
   */
  this.value = null;
  /**
   * 컬럼 셀의 배경색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 컬럼 셀의 폰트색상.
   * @type String
   */
  this.color = null;
  /**
   * 컬럼의 적용될 CSS Class
   * @type String
   */
  this.className = null;
  /**
   * 컬럼의 마우스 오버 시에 적용될 CSS Class
   * @type String
   */
  this.hoverClassName = null;
  /**
   * 텍스트 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 컬럼 가로 길이.
   * @type Number
   */
  this.width = null;
  /**
   * @ignore
   */
  this.field = null;
  /**
   * rowSpan.
   * @type Number
   */
  this.rowspan = null;
  /**
   * colSpan.
   * @type Number
   */
  this.colspan = null;
  /**
   * dojo type object.
   * It will be created when ColumnsRow's addColumn method called.
   * @type Object
   * @ignore
   */
  this.cell = null;
  /**
   * 컬럼을 보여줄지 여부.
   * @type Boolean
   */
  this.visible = null;
  /**
   * 첫번째 헤더 라인의 날짜 영역 (들어올수 있는 값은 ganttUnits와 동일)
   * @type String
   */
  this.ganttHeader1 = null;
  /**
   * 두번째 헤더 라인의 날짜 영역 (들어올수 있는 값은 ganttUnits와 동일)
   * @type String
   */
  this.ganttHeader2 = null;
  /**
   * 세번째 헤더 라인의 날짜 영역 (들어올수 있는 값은 ganttUnits와 동일)
   * @type String
   */
  this.ganttHeader3 = null;
  /**
   * 네번째 헤더 라인의 날짜 영역 (들어올수 있는 값은 ganttUnits와 동일)
   * @type String
   */
  this.ganttHeader4 = null;
  /**
   * 다섯번째 헤더 라인의 날짜 영역 (들어올수 있는 값은 ganttUnits와 동일)
   * @type String
   */
  this.ganttHeader5 = null;
  /**
   * 첫번째 헤더 라인의 날짜 표시 format
   * @type String
   */
  this.ganttFormat1 = null;
  /**
   * 두번째 헤더 라인의 날짜 표시 format
   * @type String
   */
  this.ganttFormat2 = null;
  /**
   * 세번째 헤더 라인의 날짜 표시 format
   * @type String
   */
  this.ganttFormat3 = null;
  /**
   * 네번째 헤더 라인의 날짜 표시 format
   * @type String
   */
  this.ganttFormat4 = null;
  /**
   * 다섯번째 헤더 라인의 날짜 표시 format
   * @type String
   */
  this.ganttFormat5 = null;
};


/**
 * @class Concreate xhtml GridEx.BodyColumn.<br>
 * Body에 추가될 컬럼을 구성하기 위한 클래스.
 * @author 김경태
 * @version 1.0
 * @param {eXria.controls.xhtml.ColsRow} poParent 상위 객체
 * @param {String} psId ID
 * @param {String} psHeadColId 헤드 컬럼 ID.
 * @param {String} psType 데이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 eXria.controls.xhtml.GridEx.BodyColumn 객체
 * @type eXria.controls.xhtml.GridEx.BodyColumn
 * @constructor
 */
eXria.controls.xhtml.GridEx.BodyColumn = function(poParent, psId, psHeadColId, psType, psInstanceId, psRef) {
  /**
   * 상위 객체 지정.
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * id.
   * @type String
   */
  this.id = psId;
  /**
   * 헤드 컬럼 id.
   * @type Number
   */
  this.colId = psHeadColId;
  /**
   * itemgroup 오브젝트
   * @type eXria.controls.xhtml.GridEx.itemgroup
   */
  this.itemgroup = new eXria.controls.xhtml.GridEx.itemgroup();
  /**
   * instanceId
   * @type String
   */
  this.instanceId = psInstanceId;
  /**
   * ref
   * @type String
   */
  this.ref = psRef;
  /**
   * 인스턴스 데이타 접근 객체.
   * @type eXria.controls.DataRefNode
   */
  this.data = null;
  /**
   * 컬럼을 보여줄지 여부.
   * @type Boolean
   */
  this.visible = null;
  /**
   * 컬럼 데이타 타입.
   * @type String
   */
  this.type = psType || "Text";
  /**
   * 컬럼의 에디트 가능 여부
   *  uneditable - 0, 컬럼의 css 가 disable 처리 되며 수정 되지않음
   *  editable   - 1, 컬럼 수정가능
   *  preview    - 2, 컬럼의 css 가 disable 처리 도지 않으며 수정 되지 않음
   * @type Int
   */
  this.canEdit = null;
  /**
   * 컬럼의 소트 가능 여부.
   * @type Boolean
   */
  this.canSort = null;
  /**
   * 컬럼 데이타 타입별로 보여지는 형태를 지정
   * @type String
   */
  this.format = null;
  /**
   * @type String
   */
  this.regFormat = null;
  /**
   * 문자열 표현 마스크.
   * @type String
   */
  this.mask = null;
  /**
   * @type String
   */
  this.regMask = null;
  /**
   * 마스크 프롬프트 문자.
   * @type String
   */
  this.maskPrompt = "_";
  /**
   * 입력 가능한 문자열의 최대 길이.
   * @type Number
   */
  this.maxLength = null;
  /**
   * 입력 가능한 문자열의 최소 길이.(Body)
   * @type Number
   */
  this.minLength = null;
  /**
   * itemSeparator
   * @type String
   * @private
   */
  this.itemSeparator = "|";
  /**
   * 컬럼 셀의 배경색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 컬럼 셀의 폰트색상.
   * @type String
   */
  this.color = null;
  /**
   * 컬럼의 안쪽에 적용될 CSS Class
   * @type String
   */
  this.className = null;
  /**
   * 컬럼의 바깥쪽에 적용될 CSS Class
   * @type String
   */
  this.outerClassName = null;
  /**
   * 텍스트 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 인스턴스 데이타 접근 라벨 태그명.
   * @type String
   */
  this.labelTagName = psId + "_name";
  /**
   * 인스턴스 데이타 접근 value 태그명.
   * @type String
   */
  this.valueTagName = psId + "_value";
  /**
   * 셀 편집 형태가 select일 경우 select의 value 배열값
   * @type Array
   */
  this.values = null;
  /**
   * 오른쪽 버튼
   * @type eXria.controls.xhtml.GridEx.rightButton
   */
  this.rightButton = null;
  /**
   * 데이타 연산식
   * @type String
   */
  this.formula = null;
  /**
   * Group Formula
   * @type String
   */
  this.groupFormula = null;
  /**
   * Group FormulaFormat
   * @type String
   */
  this.groupFormat = null;
  /**
   * imageItem 속성을 저장하기 위한 오브젝트.
   * imageItem 속성 항목 :<br>
   * width {String} width에 대한 참조 값<br>
   * height {String} height에 대한 참조 값<br>
   * left {String} left에 대한 참조 값<br>
   * top {String} top에 대한 참조 값<br>
   * href {String} href에 대한 참조 값<br>
   * target {String} target에 대한 참조 값<br>
   * @type Object
   */
  this.imageItem = {
    width : null,           // width에 대한 ref를 의미
    height : null,          // height에 대한 ref를 의미
    left : null,            // left에 대한 ref를 의미
    top : null,             // top에 대한 ref를 의미
    href : null,            // href에 대한 ref를 의미
    target : null           // target에 대한 ref를 의미
  };
  /**
   * buttonItem 속성을 저장하기 위한 오브젝트.
   * buttonItem 속성 항목 :<br>
   * icon {String} icon에 대한 참조 값<br>
   * iconChecked {String} iconChecked에 대한 참조 값<br>
   * tooltip {String} tooltip에 대한 참조 값<br>
   * tooltipChecked {String} tooltipChecked에 대한 참조 값<br>
   * height {String} height에 대한 참조 값<br>
   * action {String} action에 대한 참조 값<br>
   * @type Object
   */
  this.buttonItem = {
    icon : null,            // icon에 대한 ref를 의미
    iconChecked : null,     // iconChecked에 대한 ref를 의미
    tooltip : null,         // icon에 대한 ref를 의미
    tooltipChecked : null,  // icon에 대한 ref를 의미
    width : null,           // icon에 대한 ref를 의미
    height : null,          // icon에 대한 ref를 의미
    action : null           // icon에 대한 ref를 의미
  };
  /**
   * Radio/CheckBox Type 시 Item들의 정렬
   * @type String
   */
  this.displayMode = null; // multilines(def) || horizontal || vertical
  /**
   * Radio/CheckBox Type 시 Label의 정렬
   * @type String
   */
  this.labelPos = null; // right(def) || left
  /**
   * calendar 아이콘의 활성화 여부.
   * @type Boolean
   */
  this.calendarEnable = true;
  /**
   * 스타일의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {
    backgroundColor : null,
    color : null,
    textAlign : null,
    readOnly : null,
    fontFamily : null,
    fontSize : null,
    fontStyle : null,
    fontWeight : null,
    borderColor : null,
    borderStyle : null,
    borderWidth : null
  };
  /**
   * date type 구분 문자열 상수 값
   * @type String
   */
  this.dateType = "Date"; // DateTime || Date || Time

  this.enumType = null;

  /**
   * 사용자 정의 nullable 속성(Body Column)
   * @type Boolean
   */
  this.nullable = true;
  /**
   * 사용자정의 Max Byte 길이
   * @type Number
   */
  this.maxByteLenth = null;
  /**
   * 사용자정의 Min Byte 길이
   * @type Number
   */
  this.minByteLenth = null;

  /**
   * 컬럼 타입이 Text
   * @member eXria.controls.xhtml.GridEx.BodyColumn
   * @type ?
   * @author tomato at 10. 3. 15 오후 1:29
   */
  this.imeMode = null;

  /**
   * Gantt chart에서 사용하게 되는 idColumn (Task를 나타내는 유일한 id 값들을 갖는 칼럼의 헤더 id)
   * 기존에 지정된 idColumn이 있다면 무시되고 여기서 지정된 column이 idColumn으로 동작함
   * @type String
   */
  this.ganttId = null;
  /**
   * Gantt chart에서 main bar의 시작 날짜의 값을 갖는 칼럼의 헤더 id를 지정
   * @type String
   */
  this.ganttStart = null;
  /**
   * Gantt chart에서 main bar의 종료 날짜의 값을 갖는 칼럼의 헤더 id를 지정
   * 이 값이 비어있으면 main bar 대신에 milestone이 표시됨
   * @type String
   */
  this.ganttEnd = null;
  /**
   * task의 완료율을 지정하는 값을 갖는 칼럼의 헤더 id
   * @type String
   */
  this.ganttComplete = null;
  /**
   * main bar 또는 milestone 위에 마우스가 위치할 때 표시할 tooltip의 내용을 갖는 칼럼의 헤더 id
   * @type String
   */
  this.ganttTooltipText = null;
  /**
   * 의존하는 task(다음으로 오는 task)의 id 값(세미콜른으로 구분하여 여러 개의 값이 올수 있음)을 갖는 칼럼의 헤더 id
   * @type String
   */
  this.ganttDependencies = null;
  /**
   * ganttDependencies에서 지정된 task별로 의존 형태를 나타내는 값을 갖는 칼럼의 헤더 id
   * 이때 해당 칼럼에서 지정 가능한 값은 SF(start->start), SF(start->end) FS(end->start), FF(end -> end)의 네가지 이며
   * FS가 디폴트이고 하나의 task에 여러 개의 연결 정보가 존재시 세미콜른으로 구분하여 지정
   * @type String
   */
  this.ganttDependencyTypes = null;
  /**
   * Gantt Chart를 표시할때 기본이 되는 날짜(시간) 단위
   * ‘m’ - minutes,’m5’ ? 5 minutes, ’m10’ ? 10 minutes, ’m15’ ? quarters of hour, ’m30’ halves of hour,
   * ’h’ - hours, ’h2’ ? 2 hours, ’h3’ ? 3 hours, ’h6’ ? quarters of day, ’h8’ ? thirds of day, ’h12’ - halves of day,
   * ’d’ - days, ’w’ ? weeks (starting by Sunday), ’w1’ ? weeks (starting by Monday),
   * ’M’ - months, ’M3’ ? quarters of year, ’M6’ ? halves of year, ’y’ ? years
   * @type String
   */
  this.ganttUnits = null;
  /**
   * 영역의 맨처음과 맨나중에 남는 영역을 짜를때의 단위
   * 지정될 수 있는 값은 ganttUnits와 같음
   * @type String
   */
  this.ganttTrimUnits = null;
  /**
   * 사용자에 의해 Main bars 와 milestones 이 created, deleted and modified 될 수 있음
   * @type String
   */
  this.ganttEditMain = null;
   /**
   * 사용자에 의해 Dependency lines 이 created and deleted 될 수 있음
   * @type String
   */
  this.ganttEditDependency = null;
  /**
   * 사용자에 의해 Resources 가 assigned or entered 될 수 있음
   * @type String
   */
  this.ganttEditResources = null;
  /**
   * 백그라운드로 표시가 되는 Date Range로 특정 구간이 반복된다는 것을 나타내기 위해 사용
   * @type String
   */
  this.ganttBackground = null;
  /**
   * 백그라운드가 반복되는 interval로 가능한 값은 ganttUnits의 값과 같음(생략되면 ganttUnits에 설정된 값과 같음)
   * @type String
   */
  this.ganttBackgroundRepeat = null;
  /**
   * 메인 바 또는 마일스톤에 표시될 문자열을 가지고 있는 칼럼의 헤더 id
   * @type String
   */
  this.ganttResources = null;
  /**
   * ganttUnits 로 지정된 기본 unit 하나의 넓이(픽셀)
   * @type String
   */
  this.ganttUnitWidth = null;
  /**
   * gantt의 스타일을 css로 지정
   * GanttG, GanttAqua, GanttBlack, GanttBlue, GanttFuchsia, GanttGray, GanttGreen, GanttLime,
   * GanttMaroon, GanttNavy, GanttOlive, GanttOrange, GanttPurple, GanttRed, GanttSilver, GanttTeal, GanttWhite,
   * GanttYellow 중에 하나를 지정
   * @type String
   */
  this.ganttClass = null;
}
/**
 * 오른쪽 버튼을 생성하여 반환
 * @param {String} psType 테이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 오른쪽 버튼
 * @type eXria.controls.xhtml.GridEx.rightButton
 */
eXria.controls.xhtml.GridEx.BodyColumn.prototype.createRightButton = function(psType, psInstanceId, psRef) {
  var voRightButton = new eXria.controls.xhtml.GridEx.rightButton(this, psType, psInstanceId, psRef);
  return voRightButton;
};
/**
 * 주어진 오른쪽 버튼 오브젝트를 컬럼에 추가하는 메소드
 * @param {eXria.controls.xhtml.GridEx.rightButton} poRightButton 오른쪽 버튼 오브젝트
 */
eXria.controls.xhtml.GridEx.BodyColumn.prototype.addRightButton = function(poRightButton) {
  this.rightButton = poRightButton;
};
/**
 * Body칼럼의 nodeset을 설정하는 메소드
 * @param {String} psNodesetInstanceId Page에서 Unique한 InstanceId
 * @param {String} psNodesetPath 해당 Instance에서의 XPath
 */
eXria.controls.xhtml.GridEx.BodyColumn.prototype.setNodesetRef = function(psNodesetInstanceId, psNodesetPath) {
  if(this.itemgroup && this.itemgroup.data) this.itemgroup.data.setNodesetRef(psNodesetInstanceId, psNodesetPath);
};
/**
 * 사용자 정의 속성 추가
 * @param {String} psUserAttr 사용자 정의 속성 문자열 값
 */
eXria.controls.xhtml.GridEx.BodyColumn.prototype.setUserAttr = function(psUserAttr) {
  this.userAttr = psUserAttr;
  if(psUserAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(psUserAttr)) this.userAttrObj = eval(psUserAttr);
  }
};
/**
 * @class Concreate xhtml GridEx.FootColumn.<br>
 * Footer에 추가될 컬럼을 구성하기 위한 클래스.
 * @author 김경태
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx.ColsRow} poParent 상위 객체
 * @param {String} psId ID
 * @param {String} psHeadColId 헤드 컬럼 ID.
 * @param {String} psType 데이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 eXria.controls.xhtml.GridEx.FootColumn 객체
 * @type eXria.controls.xhtml.GridEx.FootColumn
 * @constructor
 */
eXria.controls.xhtml.GridEx.FootColumn = function(poParent, psId, psHeadColId, psType, psInstanceId, psRef) {
  /**
   * 상위 객체 지정.
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * id.
   * @type String
   */
  this.id = psId;
  /**
   * 헤드 컬럼 id.
   * @type Number
   */
  this.colId = psHeadColId;
  /**
   * itemgroup 오브젝트
   * @type eXria.controls.xhtml.GridEx.itemgroup
   */
  this.itemgroup = new eXria.controls.xhtml.GridEx.itemgroup();
  /**
   * instanceId
   * @type String
   */
  this.instanceId = psInstanceId;
  /**
   * 인스턴스 데이타 참조 xpath 경로
   * @type String
   */
  this.ref = psRef;
  /**
   * 인스턴스 데이타 접근 객체.
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this.control);
  /**
   * 컬럼을 보여줄지 여부.
   * @type Boolean
   */
  this.visible = null;
  /**
   * 컬럼 데이타 타입.
   * @type String
   */
  this.type = psType || "Text";
  /**
   * 컬럼의 에디트 가능 여부
   * @type Boolean
   */
  this.canEdit = null;
  /**
   * 컬럼의 소트 가능 여부.
   * @type Boolean
   */
  this.canSort = null;
  /**
   * 컬럼 데이타 타입별로 보여지는 형태를 지정
   * @type String
   */
  this.format = null;
  /**
   * @type String
   */
  this.regFormat = null;
  /**
   * 문자열 표현 마스크.
   * @type String
   */
  this.mask = null;
  /**
   * @type String
   */
  this.regMask = null;
  /**
   * 마스크 프롬프트 문자.
   * @type String
   */
  this.maskPrompt = "_";
  /**
   * cursor 위치
   * @type Number
   * @private
   */
  this.cursorPosition = -1;
  /**
   * 컬럼에 적용된 FormatMask 객체 참조
   * @type String
   */
  this.formatMask = null;
  /**
   * date type 구분 문자열 상수 값
   * @type String
   */
  this.dateType = "DateTime"; // DateTime || Date || Time
  /**
   * 입력 가능한 문자열의 최대 길이.
   * @type Number
   */
  this.maxLength = null;
  /**
   * 입력 가능한 문자열의 최소 길이.(Foot)
   * @type Number
   */
  this.minLength = null;
  /**
   * itemSeparator
   * @type String
   * @private
   */
  this.itemSeparator = "|";
  /**
   * 컬럼 셀의 배경색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 컬럼 셀의 폰트색상.
   * @type String
   */
  this.color = null;
  /**
   * 컬럼의 안쪽에 적용될 CSS Class
   * @type String
   */
  this.className = null;
  /**
   * 컬럼의 바깥쪽에 적용될 CSS Class
   * @type String
   */
  this.outerClassName = null;
  /**
   * 텍스트 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 인스턴스 데이타 접근 라벨 태그명.
   * @type String
   */
  this.labelTagName = psId + "_name";
  /**
   * 인스턴스 데이타 접근 value 태그명.
   * @type String
   */
  this.valueTagName = psId + "_value";
  /**
   * 셀 편집 형태가 select일 경우 select의 value 배열값
   * @type Array
   */
  this.values = null;
  /**
   * 오른쪽 버튼
   */
  this.rightButton = null;
  /**
   * 데이타 연산식
   */
  this.formula = null;
  /**
   * imageItem 속성을 저장하기 위한 오브젝트.
   * imageItem 속성 항목 :<br>
   * width {String} width에 대한 참조 값<br>
   * height {String} height에 대한 참조 값<br>
   * left {String} left에 대한 참조 값<br>
   * top {String} top에 대한 참조 값<br>
   * href {String} href에 대한 참조 값<br>
   * target {String} target에 대한 참조 값<br>
   */
  this.imageItem = {
    width : null,           // width에 대한 ref를 의미
    height : null,          // height에 대한 ref를 의미
    left : null,            // left에 대한 ref를 의미
    top : null,             // top에 대한 ref를 의미
    href : null,            // href에 대한 ref를 의미
    target : null           // target에 대한 ref를 의미
  };
  /**
   * buttonItem 속성을 저장하기 위한 오브젝트.
   * buttonItem 속성 항목 :<br>
   * icon {String} icon에 대한 참조 값<br>
   * iconChecked {String} iconChecked에 대한 참조 값<br>
   * tooltip {String} tooltip에 대한 참조 값<br>
   * tooltipChecked {String} tooltipChecked에 대한 참조 값<br>
   * height {String} height에 대한 참조 값<br>
   * action {String} action에 대한 참조 값<br>
   */
  this.buttonItem = {
    icon : null,            // icon에 대한 ref를 의미
    iconChecked : null,     // iconChecked에 대한 ref를 의미
    tooltip : null,         // icon에 대한 ref를 의미
    tooltipChecked : null,  // icon에 대한 ref를 의미
    width : null,           // icon에 대한 ref를 의미
    height : null,          // icon에 대한 ref를 의미
    action : null           // icon에 대한 ref를 의미
  };
  /**
   * Radio/CheckBox Type 시 Item들의 정렬
   * @type String
   */
  this.displayMode = null; // multilines(def) || horizontal || vertical
  /**
   * Radio/CheckBox Type 시 Label의 정렬
   * @type String
   */
  this.labelPos = null; // right(def) || left
  /**
   * calendar 아이콘의 활성화 여부.
   * @type Boolean
   */
  this.calendarEnable = true;
  /**
   * 스타일의 디폴트 값 저장 Object
   * @type Object
   * @private
   */
  this.df = {
    backgroundColor : null,
    color : null,
    textAlign : null,
    readOnly : null,
    fontFamily : null,
    fontSize : null,
    fontStyle : null,
    fontWeight : null,
    borderColor : null,
    borderStyle : null,
    borderWidth : null
  };

  this.enumType = null;

  /**
   * 사용자 정의 nullable 속성(Foot Column)
   * @type Boolean
   */
  this.nullable = true;
  /**
   * 사용자정의 Max Byte 길이
   * @type Number
   */
  this.maxByteLenth = null;
  /**
   * 사용자정의 Min Byte 길이
   * @type Number
   */
  this.minByteLenth = null;

  /**
   * 컬럼 타입이 Text
   * @member eXria.controls.xhtml.GridEx.FootColumn
   * @type ?
   * @author tomato at 10. 3. 15 오후 1:29
   */
  this.imeMode = null;
};
/**
 * 오른쪽 버튼을 생성하여 반환
 * @param {String} psType 데이터 타입
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 오른쪽 버튼
 * @type eXria.controls.xhtml.GridEx.rightButton
 */
eXria.controls.xhtml.GridEx.FootColumn.prototype.createRightButton = function(psType, psInstanceId, psRef) {
  var voRightButton = new eXria.controls.xhtml.GridEx.rightButton(this, psType, psInstanceId, psRef);
  return voRightButton;
};
/**
 * 주어진 오른쪽 버튼 오브젝트를 컬럼에 추가하는 메소드
 * @param {eXria.controls.xhtml.GridEx.rightButton} poRightButton 오른쪽 버튼 오브젝트
 */
eXria.controls.xhtml.GridEx.FootColumn.prototype.addRightButton = function(poRightButton) {
  this.rightButton = poRightButton;
};


/**
 * @class GridEx.rightButton<br>
 * rightButton 클래스.
 * @author 김경태
 * @version 1.0
 * @param {eXria.controls.xhtml.GridEx.BodyColumn} poParent 상위 BodyColumn 객체
 * @param {String} psType 버튼 type
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 eXria.controls.xhtml.GridEx.rightButton 객체
 * @type eXria.controls.xhtml.GridEx.rightButton
 * @constructor
 */
eXria.controls.xhtml.GridEx.rightButton = function(poParent, psType, psInstanceId, psRef) {
  /**
   * 상위 객체 지정.
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 오른쪽 버튼의 형태
   * 일반적인 버튼 : Normal, 이미지 : Image
   */
  this.type = psType;
  /**
   * instanceId
   * @type String
   */
  this.instanceId = psInstanceId;
  /**
   * 인스턴스 데이타 참조 xpath 경로
   * @type String
   */
  this.ref = psRef;
  /**
   * 버튼 가로 길이.
   * @type Number
   */
  this.width = null;
  /**
   * 버튼 value.
   * @type String
   */
  this.value = null;
  /**
   * 버튼 enableMode
   * @type String
   */
  this.enableMode = null;
};


/**
 * @class GridEx.itemgroup<br>
 * itemgroup 클래스.
 * BodyColumn에 두개 이상의 데이타를 표시해야 되는 경우(Enum, Select 등) 사용됨
 * @author 김경태
 * @version 1.0
 * @return 새로운 eXria.controls.xhtml.GridEx.itemgroup 객체
 * @type eXria.controls.xhtml.GridEx.itemgroup
 * @constructor
 */
eXria.controls.xhtml.GridEx.itemgroup = function() {
  /**
   * 아이템 label 태그 명
   * @type String
   */
  this.labelTagName = null;
  /**
   * 아이템 value 태그 명
   * @type Number
   */
  this.valueTagName = null;
  /**
   * 데이타 접근 정보 저장 오브젝트.
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset();
  /**
   * 인스턴스로 부터 가져올 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.itemset = new eXria.data.ArrayMap();
  /**
   * 앞쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.frontItems = new eXria.data.ArrayMap();
  /**
   * 뒤쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.backItems = new eXria.data.ArrayMap();
};
/**
 * itemset에 아이템 추가 메소드.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.addToItemset = function() {
  this.itemset.clear();
  var voData = this.data;
  var vsInstanceId = voData.nodesetInstanceId;
  var vsRef = voData.nodesetInstancePath;

  if(vsInstanceId == null || vsRef == null) return;
  var voCollectionNode = voData.getNodesetData2();
  var vsLabelTagName = this.labelTagName;
  var vsValueTagName = this.valueTagName;
  if(voCollectionNode) {
    var vnLoop = voCollectionNode.getLength();
    var voMapNode = null;
    var vsLabelNode = null;
    var vsValueNode = null;
    var voItem = null;
    for(var i = 0; i < vnLoop; i++) {
      voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
      if(vsLabelTagName) vsLabelNode = voMapNode.get(vsLabelTagName);
      else vsLabelNode = i;
      vsValueNode = voMapNode.get(vsValueTagName);
      if(vsLabelNode == null) vsLabelNode = "";
      if(vsValueNode == null) vsValueNode = "";
    voItem = this.itemset.put(vsValueNode, vsLabelNode);
    }
  }
};
/**
 * frontItems혹은 backItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psType 아이템 타입
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.addItem = function(psType, psOption, psValue, pnIndex, poDocument) {
  if(psType == "front") voItems = this.frontItems;
  else voItems = this.backItems;

  if(pnIndex == null) {
      if(psValue == null) psValue = psOption;
      voItems.put(psValue, psOption);
  } else {
    var voNewItems = new eXria.data.ArrayMap();
    var vnIndex = 0;
    var voIterator = voItems.getKeyCollection().iterator();
    var vsKey = null;
    while(voIterator.hasNext()) {
      if(vnIndex == pnIndex){
        if(psValue == null) psValue = psOption;
        voItems.put(psValue, psOption);
      }
      vsKey = voIterator.next();
      voNewItems.put(vsKey, voItems.get(vsKey));
      vnIndex++;
    }
    if(psType == "front") this.frontItems = voNewItems;
    else this.backItems = voNewItems;
  }
};
/**
 * frontItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psOption 아이템 라벨 명
 * @param {String} psValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.addItemFront = function(psOption, psValue, pnIndex, poDocument) {
  this.addItem("front", psOption, psValue, pnIndex, poDocument);
};
/**
 * backItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psOption 아이템 라벨 명
 * @param {String} psValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.addItemBack = function(psOption, psValue, pnIndex, poDocument) {
  this.addItem("back", psOption, psValue, pnIndex, poDocument);
};
/**
 * 리스트 아이템 제거.
 * @param {String} psName 아이템 라벨 명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.removeItem = function(psName, poDocument) {
  this.frontItems.remove(psName);
  this.itemset.remove(psName);
  this.backItems.remove(psName);
};
/**
 * 모든 리스트 아이템 제거.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.removeAll = function(poDocument) {
  this.frontItems.clear();
  this.itemset.clear();
  this.backItems.clear();
};
/**
 * item label들을 문자열 배열에 담아 반환하는 메소드
 * @return item label들을 담은 문자열 배열
 * @type Array(String)
 * @private
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.getItemLabelsToArray = function() {
  var vaLabels = new Array();

  var vnIndex = 0;
  var vsKey = null;

  var voItems = this.frontItems;
  var voIterator = voItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    vsKey = voIterator.next();
    var vsTemp  = vsKey.search(/\S/gi);
    if(vsTemp === -1) vsKey = "&nbsp";
    vaLabels[vnIndex] = vsKey;
    vnIndex++;
  }

  voItems = this.itemset;
  voIterator = voItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    vsKey = voIterator.next();
    var vsTemp  = vsKey.search(/\S/gi);
    if(vsTemp === -1) vsKey = "&nbsp";
    vaLabels[vnIndex] = vsKey;
    vnIndex++;
  }

  voItems = this.backItems;
  voIterator = voItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    vsKey = voIterator.next();
    var vsTemp  = vsKey.search(/\S/gi);
    if(vsTemp === -1) vsKey = "&nbsp";
    vaLabels[vnIndex] = vsKey;
    vnIndex++;
  }

  return vaLabels;
};
/**
 * item value들을 문자열 배열에 담아 반환하는 메소드
 * @return item value들을 담은 문자열 배열
 * @type Array(String)
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.getItemValuesToArray = function() {
  var vaValues = new Array();

  var voItems = this.frontItems;
  var voIterator = voItems.getKeyCollection().iterator();
  var vsKey = null;
  var vsValue = null;
  var vnIndex = 0;
  while(voIterator.hasNext()) {
    vsValue = voIterator.next();
    vaValues[vnIndex] = vsValue;
    vnIndex++;
  }

  voItems = this.itemset;
  voIterator = voItems.getKeyCollection().iterator();
  while(voIterator.hasNext()) {
    vsValue = voIterator.next();
    vaValues[vnIndex] = vsValue;
    vnIndex++;
  }

  voItems = this.backItems;
  voIterator = voItems.getKeyCollection().iterator();
  while(voIterator.hasNext()) {
    vsValue = voIterator.next();
    vaValues[vnIndex] = vsValue;
    vnIndex++;
  }

  return vaValues;
};
/**
 * item label들을 sparator를 이용하여 하나의 문자열로 반환하는 메소드
 * @return 한 문자열로 표현된 item들의 label 값
 * @type String
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.getItemLabelsToString = function(psSeparator) {
  var vsLabels = '', vsLabel = '';
  var vbSeparator = false;
  if(psSeparator) vbSeparator = true;

  var voItems = this.frontItems;
  var voIterator = voItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    vsLabel = voIterator.next();
    vsLabel += "";
    vsLabel = vsLabel.replace(/\'/g, "&apos;")
    var vsTemp  = vsLabel.search(/\S/gi);
    if(vsTemp === -1) vsLabel = "&nbsp";
    if(vbSeparator) vsLabels = vsLabels + psSeparator + vsLabel;
    else vsLabels = vsLabels + vsLabel;
  }

  voItems = this.itemset;
  voIterator = voItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    vsLabel = voIterator.next();
    vsLabel += "";
    vsLabel = vsLabel.replace(/\'/g, "&apos;")
    var vsTemp  = vsLabel.search(/\S/gi);
    if(vsTemp === -1) vsLabel = "&nbsp";
    if(vbSeparator) vsLabels = vsLabels + psSeparator + vsLabel;
    else vsLabels = vsLabels + vsLabel;
  }

  voItems = this.backItems;
  voIterator = voItems.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    vsLabel = voIterator.next();
    vsLabel += "";
    vsLabel = vsLabel.replace(/\'/g, "&apos;")
    var vsTemp  = vsLabel.search(/\S/gi);
    if(vsTemp === -1) vsLabel = "&nbsp";
    if(vbSeparator) vsLabels = vsLabels + psSeparator + vsLabel;
    else vsLabels = vsLabels + vsLabel;
  }

  return vsLabels;
};
/**
 * item value들을 sparator를 이용하여 하나의 문자열로 반환하는 메소드
 * @return 한 문자열로 표현된 item들의 value 값
 * @type String
 */
eXria.controls.xhtml.GridEx.itemgroup.prototype.getItemValuesToString = function(psSeparator) {
  var vsValues = '', vsValue = '';
  var vbSeparator = false;
  if(psSeparator) vbSeparator = true;

  var voItems = this.frontItems;
  var voIterator = voItems.getKeyCollection().iterator();

  while(voIterator.hasNext()) {
    vsValue = voIterator.next();
    vsValue += "";
    vsValue = vsValue.replace(/\'/g, "&apos;");
    if(vbSeparator) vsValues = vsValues + psSeparator + vsValue;
    else vsValues = vsValues + vsValue;
  }

  voItems = this.itemset;
  voIterator = voItems.getKeyCollection().iterator();
  while(voIterator.hasNext()) {
    vsValue = voIterator.next();
    vsValue += "";
    vsValue = vsValue.replace(/\'/g, "&apos;");
    if(vbSeparator) vsValues = vsValues + psSeparator + vsValue;
    else vsValues = vsValues + vsValue;
  }

  voItems = this.backItems;
  voIterator = voItems.getKeyCollection().iterator();
  while(voIterator.hasNext()) {
    vsValue = voIterator.next();
    vsValue += "";
    vsValue = vsValue.replace(/\'/g, "&apos;");
    if(vbSeparator) vsValues = vsValues + psSeparator + vsValue;
    else vsValues = vsValues + vsValue;
  }

  return vsValues;
};

//yhkim 2009.05.18 Paging Data 관련
/**
 * 그리드의 paging 구조 정의 문자열을 반환하는 메소드
 * @param {Number} rowPos page 위치 정보
 * @return 그리드의 paging 구조 정의 문자열
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getPagingData = function(rowPos) {
  if (this.cfg.paging != "fast")
    return;
  // 렌더링 할 페이지 카운트
  if(this.pageCountWithFastMode === 0) this.pageCountWithFastMode++;

  this.cfg.pagePos = rowPos;
  var vnId = this.cfg.pageLength * rowPos;
  var vnPos = 0;
  var voPage = null;
  for(var i = 0; i < rowPos; i++) {
    voPage = this.grid.GetPage(i);
    vnPos += voPage ? (voPage.childNodes.length ? voPage.childNodes.length : this.grid.PageLength) : this.grid.PageLength;
  }

  var vsXml = "";
  if (this.datasetId == null) {
    if (this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null)
      return;
    var voCollectionNode = null;
    if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
      voCollectionNode = this.data.getNodesetStr();
      if(voCollectionNode) {
        voCollectionNode = eval(voCollectionNode);
      }
    } else {
      voCollectionNode = this.data.getNodesetData();
    }
    // instance는 0부터
    vsXml = this.makeRowData(voCollectionNode, vnPos, vnPos + this.cfg.pageLength, vnId);
  } else {
    var voDataSet = null;
    if(this.dataset)
      voDataSet = this.dataset;
    else
      voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
    // dataset은 1부터
    vsXml = this.makeRowData(voDataSet, vnPos + 1, vnPos + this.cfg.pageLength, vnId + 1);
  }

  var vsReturn = '<Grid><Body><B Pos=' + '"' + rowPos + '"' + '>';
  vsReturn = vsReturn + vsXml;
  vsReturn = vsReturn + '</B></Body></Grid>';
  if(this.grid.RowCount < 1) this.grid.RowCount = 1;
  return vsReturn;
};
//yhkim 2009.05.18 Paging Data
/**
 * makeRowData
 * @param {eXria.data.xhtml.CollectionNode | eXria.data.DataSetCmd} poCollectionNode data collection node or dataset
 * @param {Number} pnFirst 읽어 올 시작 page 위치
 * @param {Number} pnLoop 읽어 올 row count
 * @param {Number} pnId 그리드 row 객체에 부여될 id 시작 번호
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.makeRowData = function(poCollectionNode, pnFirst, pnLoop, pnId) {
  if(poCollectionNode) {
    var vnDataCount;
    if(this.datasetId) {
      vnDataCount = poCollectionNode.getRowCnt();
    } else if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
      vnDataCount = poCollectionNode.length;
    } else {
      vnDataCount = poCollectionNode.size();
    }
    if(pnFirst > vnDataCount) return "";
    if(pnLoop > vnDataCount) pnLoop = vnDataCount;
  } else {
     return "";
  }
  var voFuncDataSize;
  var voAddStatusMap = {};
  var voUptStatusMap = {};
  var voDelStatusMap = {};
  var vaStatus, vsStatus, vnSize, voDst;
  
  this.funcRef = function(poColumn) {
    return poColumn.ref;
  };
  this.funcRowId = function(poMapNode, pnId) {
    return pnId + 1;
  };
  this.funcGet = function(poMapNode, psRef) {
    return poMapNode[psRef]
  };
  this.funcRefVal = function(psRef, poMapNode, pnIdx, psInstId) {
    return this.getRefValueFromMap(psRef, poMapNode);
  };
  
  if(this.datasetId) {
    pnLoop += 1;
    voDst = poCollectionNode;
    vaStatus = voDst.getStatusIndex(eXria.data.CrudType.ADDEDFLAG);
    vaStatus = vaStatus.split(",");
    vnSize = vaStatus.length;
    for(var i = 0; i < vnSize; i++) {
      vsStatus = vaStatus[i];
      if(vsStatus != "") {
        voAddStatusMap[vsStatus] = "";
      }
    }
    vaStatus = voDst.getStatusIndex(eXria.data.CrudType.MODIFIEDFLAG);
    vaStatus = vaStatus.split(",");
    vnSize = vaStatus.length;
    for(var i = 0; i < vnSize; i++) {
      vsStatus = vaStatus[i];
      if(vsStatus != "") {
        voUptStatusMap[vsStatus] = "";
      }
    }
    vaStatus = voDst.getStatusIndex(eXria.data.CrudType.DELETEDFLAG);
    vaStatus = vaStatus.split(",");
    vnSize = vaStatus.length;
    for(var i = 0; i < vnSize; i++) {
      vsStatus = vaStatus[i];
      if(vsStatus != "") {
        voDelStatusMap[vsStatus] = "";
      }
    }
    
    poCollectionNode = eval(voDst.dataSet.getRowDataStrContainFrontIndex(pnFirst, pnLoop));
    this.funcMapNode = function(poCollectionNode, pnIdx) {
      return poCollectionNode[pnIdx - pnFirst];
    };
    this.funcStatus = function(poMapNode, pnIdx) {
      var vsStatus = "";
      if(voAddStatusMap[pnIdx] != null) vsStatus += "I";
      else if(voUptStatusMap[pnIdx] != null) vsStatus += "U";
      else if(voDelStatusMap[pnIdx] != null) vsStatus += "D";
      return vsStatus;
    };
    this.funcRef = function(poColumn) {
      return poColumn.datasetCol;
    };
    this.funcRowId = function(poMapNode, pnId) {
      return poMapNode["@frontIndex"];
    };
    
  } else if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    this.funcMapNode = function(poCollectionNode, pnIdx) {
      return poCollectionNode[pnIdx];
    };
    this.funcStatus = function(poMapNode, pnIdx) {
      return this.data.getNodesetData2(pnIdx).node.getUserAttribute("status");
    };
    
  } else {
    this.funcMapNode = function(poCollectionNode, pnIdx) {
      return new eXria.data.xhtml.MapNode(poCollectionNode.get(pnIdx));
    };
    this.funcStatus = function(poMapNode, pnIdx) {
      return poMapNode.node.getUserAttribute("status");
    };
    this.funcGet = function(poMapNode, psRef) {
      return poMapNode.get(psRef);
    };
    this.funcRefVal = function(psRef, poMapNode, pnIdx, psInstId) {
      return this.getRefValue(psRef, poMapNode, pnIdx, psInstId);
    };
    
  }
  if(pnId == null) pnId = pnFirst;
  var voMapNode = null;
  var voBody, voRow, voColumn, voValue = null;
  var vsBody = "", vsRow;
  var vsRef, vaPath, vsRButtonRef, vsRButtonValue = "";
  var voCols = new Array();
  
  voBody = this.body;
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  var vsDsColId;
  var voCfg = this.cfg;
  
  this.setColsRowSpan(pnFirst, pnLoop, poCollectionNode);
  var voMergeRowColsMap = this.mergeRowColsMap;
  var vaChildRows = this.childRows;
  var vnSize;

  for( var i = pnFirst, ii = pnId; i < pnLoop; i++, ii++) {
    vsRow = this.getTRowStr(i, ii, poCollectionNode, voCols, voCfg, voMergeRowColsMap);
    if(vaChildRows) {
      vnSize = vaChildRows.length;
      vsRow += ">";
      for(var j = 0; j < vnSize; j++) {
        vsRow += this.getTRowStr(i, ii, poCollectionNode, voCols, voCfg, voMergeRowColsMap, vaChildRows[j], j) + "/>";
      }
      vsRow += "</I>";
    } else if(vsRow != ""){
      vsRow +=  "/>";
    } else {
      ii--;
    }

    vsBody = vsBody + vsRow;
  }
  this.rowCount = pnLoop;
  return vsBody;
};
/**
 * 데이타 로딩 시점에서 데이타 메타 정보를 응용단에서 편집 가능하도록 하는 이벤트 발생 메소드
 * @param {Number} pnRowIdx row 인덱스
 * @param {String} psRow 해당 row 메타 데이타
 * @param {Array(Object)|eXria.data.ArrayCollection} paRowData 전체 row 데이타
 * @return 응용단에서 편집된 row 메타 데이타
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setRowMetaExtAttrs = function(pnRowIdx, psRow, paRowData) {
  var vsVal = psRow;
  var voPage = this.canvas.page;
  if(voPage.onGridexSetRowMetaExtAttrs) vsVal = voPage.onGridexSetRowMetaExtAttrs(this, pnRowIdx, psRow, paRowData);
  if(vsVal == null) vsVal = psRow;
  return vsVal;
};

/**
 * MarkDelRow가 된 로우와 Dataset  Sync
 * @param {Object} poRow markdel상태가 변한 row
 * @param {Boolean} pbDel 
 */
eXria.controls.xhtml.GridEx.prototype.SetMarkDelStatus = function(poRow, pbDel) {
  if(this.datasetId) {
    if(!this.dataset) this.dataset = this.canvas.page.model.getDataSet(this.datasetId);
    if(this.dataset == null) return;

    var vnIdx = this.getIndexOfRow(poRow)

    if(pbDel == true) {
        if(poRow["Added"] == "1") this.dataset.setStatus(vnIdx + 1, eXria.data.CrudType.UNCHANGEDFLAG);
        else this.dataset.setStatus(vnIdx + 1, eXria.data.CrudType.DELETEDFLAG);
    } else {
      if(poRow["Added"] == "1") {
        if(poRow["Changed"] == "1") this.dataset.setStatus(vnIdx + 1, eXria.data.CrudType.ADDEDFLAG);
        else this.dataset.setStatus(vnIdx + 1, eXria.data.CrudType.EMPTYEDFLAG);
      } else if(poRow["Changed"] == "1") {
        this.dataset.setStatus(vnIdx + 1, eXria.data.CrudType.MODIFIEDFLAG);
      } else {
        this.dataset.setStatus(vnIdx + 1, eXria.data.CrudType.UNCHANGEDFLAG);
      }
    }
//    if(pbDel == true )
//      this.dataset.setStatus(vnIndex + 1, this.dataset.dataSet.ETBDELETEDFLAG);
//    else
//      this.dataset.setStatus(vnIndex + 1, this.dataset.dataSet.ETBUNCHANGEDFLAG);
  } else if(!!this.data.nodesetInstanceId && !!this.data.nodesetInstancePath) {
    var vnInstIdx = poRow["InstIdx"];
    if(vnInstIdx == null) vnInstIdx = poRow.getAttribute("InstIdx");
    vnInstIdx = parseInt(vnInstIdx);
    var voInstRow = this.data.getNodesetData2(vnInstIdx).node;
    var vsStatus = null;
    if(pbDel) {
      vsStatus = voInstRow.getUserAttribute("status");
      if(vsStatus == null) vsStatus = "";
      if(vsStatus.indexOf("D") == -1) voInstRow.setUserAttribute("status", "D" + vsStatus);
    } else {
      vsStatus = voInstRow.getUserAttribute("status");
      if(vsStatus != null) {
        voInstRow.setUserAttribute("status", vsStatus.replace("D", ""));
      }
    }
  }
};

/**
 * NodeSet Ref 이외의 경로가 참조 가능한 ref(image 등)에 대하여 value 값을 구해 리턴
 * @param {String} psRef XPath
 * @param {eXria.data.xhtml.MapNode || DataSet} poNodeSet NodeSet 형태의 값들을 가지고 있는 객체
 * @param {Number} pnIndex
 * @param {String} psInstanceId instance의 Id로 현재는 사용 안함
 * @return 해당 instance의 ref에 있는 value
 * @type {String}
 */
eXria.controls.xhtml.GridEx.prototype.getRefValue = function(psRef, poNodeSet, pnIndex, psInstanceId) {
  var voValue = "";
  if(!psInstanceId) psInstanceId = this.data.nodesetInstanceId;
  if(psRef) {
    if(psRef.indexOf("/") == 0) {                     // XPath가 절대경로로 지정된 경우
      this.data.setRef(psInstanceId, psRef);
      voValue = this.data.getNodeData().getValue();
    } else if(poNodeSet) {                            // XPath가 상대경로로 지정된 경우
      vaPath = psRef.split("/");
      if(this.dataset) voValue = poNodeSet[vaPath];
      else voValue = poNodeSet.get(vaPath[vaPath.length - 1]);
    }
    if(!voValue) voValue = "";
  }
  return voValue;
};
/**
 * NodeSet Ref 이외의 경로가 참조 가능한 ref(image 등)에 대하여 value 값을 구해 리턴
 * @param {String} psRef XPath
 * @param {Object} poRowData row 데이타 저장 맵 객체
 * @return 해당 row 데이타의 ref에 있는 value
 * @type {String}
 */
eXria.controls.xhtml.GridEx.prototype.getRefValueFromMap = function(psRef, poRowData) {
  if(psRef == null || poRowData == null) return null;
  var voValue = "";
  if(psRef.indexOf("/") == 0) {
    var voData = this.data;
    voData.setRef(voData.nodesetInstanceId, psRef);
    voValue = voData.getNodeData().getValue();
  } else {
    var vaPath = psRef.split("/");
    voValue = poRowData[vaPath[vaPath.length - 1]];
  }
  if(!voValue) voValue = "";
  return voValue;
};
//yhkim 2009.05.19 head 컬럼
/**
 * @class Fuction Column 클래스
 * @param {eXria.controls.xhtml.GridEx.BodyColumn} poParent 상위 객체
 * @param {String} psId ID
 * @param {String} psInstanceId Instance ID
 * @param {String} psRef Instance Path
 * @return 새로운 eXria.controls.xhtml.GridEx.FunctionColumn 객체
 * @type eXria.controls.xhtml.GridEx.FunctionColumn
 * @constructor
 */
eXria.controls.xhtml.GridEx.FunctionColumn = function(poParent, psId, psInstanceId, psRef) {
  /**
   * 상위 객체 지정
   * @type eXria.controls.xhtml.GridEx.Body|eXria.controls.xhtml.GridEx.Header
   */
  this.parent = poParent;
  /**
   * 자신이 속한 GridEx 컨트롤 참조
   *
   * @type eXria.controls.xhtml.GridEx
   */
  this.control = poParent.control;
  /**
   * 헤드 컬럼 식별자.
   * @type String
   */
  this.colId = null;
  /**
   * 컬럼 식별자
   */
  this.id = psId;
  /**
   * instanceId
   * @type String
   */
  this.instanceId = psInstanceId;
  /**
   * ref
   * @type String
   */
  this.ref = psRef;
  /**
   * 인스턴스 데이타 접근 객체.
   *
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this.control);
  /**
   * datasetCol
   * @type String
   */
  this.datasetCol = null;
  /**
   * 컬럼 표시 문자열.
   * @type String
   */
  this.value = null;
  /**
   * 입력 가능한 문자열의 최대 길이.
   * @type Number
   */
  this.maxLength = null;
  /**
   * 입력 가능한 문자열의 최소 길이.(Function)
   * @type Number
   */
  this.minLength = null;
  /**
   * 컬럼 셀의 배경색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 컬럼 셀의 폰트색상.
   * @type String
   */
  this.color = null;
  /**
   * 컬럼의 안쪽에 적용될 CSS Class
   * @type String
   */
  this.className = null;
  /**
   * 컬럼의 바깥쪽에 적용될 CSS Class
   * @type String
   */
  this.outerClassName = null;
  /**
   * 텍스트 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 컬럼 가로 길이.
   * @type Number
   */
  this.width = null;
  /**
   * @ignore
   */
  this.field = null;
  /**
   * rowSpan.
   * @type Number
   */
  this.rowspan = null;
  /**
   * colSpan.
   * @type Number
   */
  this.colspan = null;
  /**
   * dojo type object. It will be created when ColumnsRow's addColumn method
   * called.
   * @type Object
   * @ignore
   */
  this.cell = null;
  /**
   * 컬럼을 보여줄지 여부.
   * @type Boolean
   */
  this.visible = null;
  // yhkim 2009.05.19 head 컬럼
  /**
   * 드래그 가능 여부.
   * @type Boolean
   * @private
   */
  this.canDrag = null;
  /**
   * 편집 가능 여부.
   * @type Boolean
   */
  this.canEdit = null;
  /**
   * 포커싱 가능 여부.
   * @type Boolean
   */
  this.canFocus = null;
  /**
   * 데이타 연산식
   * @type String
   */
  this.formula = null;
  /**
   * 컬럼 타입 구분 문자열
   * @type String
   */
  this.type = "Text";
  /**
   * item separator
   * @type String
   * @private
   */
  this.itemSeparator = "|";
  /**
   * itemgroup 객체 참조 변수
   * @type eXria.controls.xhtml.GridEx.itemgroup
   */
  this.itemgroup = new eXria.controls.xhtml.GridEx.itemgroup();
  /**
   * rightButton 객체 참조 변수
   * @type eXria.controls.xhtml.GridEx.rightButton
   */
  this.rightButton = null;
  /**
   * imageItem 속성을 저장하기 위한 오브젝트.
   * imageItem 속성 항목 :<br>
   * width {String} width에 대한 참조 값<br>
   * height {String} height에 대한 참조 값<br>
   * left {String} left에 대한 참조 값<br>
   * top {String} top에 대한 참조 값<br>
   * href {String} href에 대한 참조 값<br>
   * target {String} target에 대한 참조 값<br>
   */
  this.imageItem = {
    width : null,           // width에 대한 ref를 의미
    height : null,          // height에 대한 ref를 의미
    left : null,            // left에 대한 ref를 의미
    top : null,             // top에 대한 ref를 의미
    href : null,            // href에 대한 ref를 의미
    target : null           // target에 대한 ref를 의미
  };
  /**
   * buttonItem 속성을 저장하기 위한 오브젝트.
   * buttonItem 속성 항목 :<br>
   * icon {String} icon에 대한 참조 값<br>
   * iconChecked {String} iconChecked에 대한 참조 값<br>
   * tooltip {String} tooltip에 대한 참조 값<br>
   * tooltipChecked {String} tooltipChecked에 대한 참조 값<br>
   * height {String} height에 대한 참조 값<br>
   * action {String} action에 대한 참조 값<br>
   */
  this.buttonItem = {
    icon : null,            // icon에 대한 ref를 의미
    iconChecked : null,     // iconChecked에 대한 ref를 의미
    tooltip : null,         // icon에 대한 ref를 의미
    tooltipChecked : null,  // icon에 대한 ref를 의미
    width : null,           // icon에 대한 ref를 의미
    height : null,          // icon에 대한 ref를 의미
    action : null           // icon에 대한 ref를 의미
  };

  this.calendarEnable = true;

  this.enumType = null;

  /**
   * 사용자 정의 nullable 속성(Function Column)
   * @type Boolean
   */
  this.nullable = true;
  /**
   * 사용자정의 Max Byte 길이
   * @type Number
   */
  this.maxByteLenth = null;
  /**
   * 사용자정의 Min Byte 길이
   * @type Number
   */
  this.minByteLenth = null;

  /**
   * 컬럼 타입이 Text
   * @member eXria.controls.xhtml.GridEx.FunctionColumn
   * @type ?
   * @author tomato at 10. 3. 15 오후 1:29
   */
  this.imeMode = null;
};
/**
 * 새로운 rightButton을 생성하여 반환하는 메소드
 * @param {String} psType 버튼 타입 구분 문자열
 * @param {String} psInstanceid 참조 instance id
 * @param {String} psRef 참조 instance path 정보
 * @return 새로운 rightButton 객체
 * @type eXria.controls.xhtml.GridEx.FunctionColumn.prototype.createRightButton
 */
eXria.controls.xhtml.GridEx.FunctionColumn.prototype.createRightButton = function(psType, psInstanceId, psRef) {
  var voRightButton = new eXria.controls.xhtml.GridEx.rightButton(this, psType, psInstanceId, psRef);
  return voRightButton;
};
/**
 * 주어진 오른쪽 버튼 오브젝트를 컬럼에 추가하는 메소드
 * @param {eXria.controls.xhtml.GridEx.rightButton} poRightButton 오른쪽 버튼 오브젝트
 */
eXria.controls.xhtml.GridEx.FunctionColumn.prototype.addRightButton = function(poRightButton) {
  this.rightButton = poRightButton;
};


/**
 * @class FormatMask 오브젝트 생성 클래스
 * @param {Object} poColumn 부모 컬럼 객체
 * @param {eXria.controls.xhtml.GridEx} poGrid GridEx 객체
 * @return eXria.controls.xhtml.GridEx.FormatMask 객체
 * @type eXria.controls.xhtml.GridEx.FormatMask
 * @constructor
 */
eXria.controls.xhtml.GridEx.FormatMask = function(poColumn, poGrid){
  /**
   * GridEx 객체 참조 변수
   * @type eXria.controls.xhtml.GridEx
   */
  this.grid = poGrid;
  /**
   * 컬럼 객체 참조 변수
   * @type Object
   */
  this.column = poColumn;
  /**
   * format 문자열 참조 변수
   * @type String
   */
  this.format = poColumn.format;
  /**
   * @type String
   */
  this.regFormat = poColumn.regFormat;
  /**
   * mask 문자열 참조 변수
   * @type String
   */
  this.mask = poColumn.mask;
  /**
   * @type String
   */
  this.regMask = poColumn.regMask;
  /**
   * maskPrompt 문자열 참조 변수
   * @type String
   */
  this.maskPrompt = poColumn.maskPrompt;
  /**
   * 텍스트가 전체 select 되었는지 여부
   * @type Boolean
   */
  this.vbSelectAll = false;
  /**
   * mask character 설정 값을 참조하기 위한 Object
   * @type Object
   */
  this.stringMaskChar = {
    "9" : "0-9",
    "0" : "0-9",
    "#" : "0-9",
    "*" : "0-9a-zA-Z",
    "x" : "0-9a-zA-Z",
    "X" : "0-9a-zA-Z",
    "a" : "0-9a-zA-Z",
    "A" : "0-9a-zA-Z",
    "w" : "a-zA-Z",
    "W" : "a-zA-Z",
    "!" : "0-9a-zA-Z",
    "^" : "0-9a-zA-Z"
  };
  /**
   * 숫자형 mask character 설정 값을 참조하기 위한 Object
   * @type Object
   */
  this.numberMaskChar = {
    "9" : "0-9",
    "0" : "0-9",
    "#" : "0-9",
    "." : "."
  };
  /**
   * date형 character 설정 값을 참조하기 위한 Object
   * @type Object
   */
  this.dateMaskChar = {
    "Y" : "0-9",
    "y" : "0-9",
    "M" : "0-9",
    "D" : "0-9",
    "d" : "0-9",
    "H" : "0-9",
    "h" : "0-9",
    "m" : "0-9",
    "s" : "0-9"
  };
  /**
   * 이벤트 키값 상수 정의 오브젝트.
   * @type Object
   */
  this.constKey = {
    SHIFT: 16,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    ENTER: 13,
    TAB: 9,
    BACKSPACE: 8,
    DEL: 46,
    HAN_ENG: 21,
    UP : 38,
    DOWN : 40
  };
  /**
   * YYMMDD의 정규식 표현.
   * @type RegExp
   * @private
   */
  this.regDateMask = /[yMdHhms]/g;
  /**
   * 숫자가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noDigits = /[^\d]/gi;
  /**
   * 커서 위치 저장 변수
   * @type Number
   * @private
   */
  this.cursorPosition = -1;
};
/**
 * TreeGrid의 Format, Mask 관련 속성의 문자열 반환
 * @param {Object} psFormat Format
 * @return String
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.createFormatAndMask = function(poColumn){
  var vsFormat = poColumn.regFormat;
  var vsMask = poColumn.regMask;
  var vsType = poColumn.type;
  var vsEditFormat = "", vsEditMask = "", vsResultMask = "", vsRet = "";
  if(!vsFormat && vsMask) vsFormat = vsMask;
  if(!vsFormat && vsType=="Date") vsFormat = "yyyy-MM-dd";
  if(!vsMask && vsType=="Date") vsMask = "yyyyMMdd";
  switch(vsType){
    case "Int" :
    case "Float" :
      if(vsMask){
        if(vsMask.lastIndexOf(".")) vsMask = vsMask.replace(vsMask.charAt(vsMask.lastIndexOf(".")-1), "0");
        vsEditMask = "^[0-9]*\\.*[0-9]*$";
        vsResultMask = "^[0-9]*\\.*[0-9]*$";
      }
      break;
    case "Text" :
    case "Lines" :
      if(vsMask){
        var vsMaskReg = "";
        var voMaskChar = this.stringMaskChar;
        for(var vsMaskChar in this.stringMaskChar){
          if(/\W/.test(vsMaskChar)) vsMaskChar = "\\" + vsMaskChar;
          vsMaskReg += vsMaskChar;
        }
        var vrMaskReg = new RegExp("[^" + vsMaskReg + "]", "g");

        var vsNoFormat = vsMask.replace(vrMaskReg, "");

        vsEditMask = "^";

        //문자가 일치하는 마지막 index를 리턴
        var getLastIndex = function(pnIndex){
          if(pnIndex > vsNoFormat.length) return vsNoFormat.length;
          if(vsNoFormat.charAt(pnIndex) == vsNoFormat.charAt(pnIndex + 1)) pnIndex = getLastIndex(pnIndex + 1);
          return pnIndex;
        }

        //editmask 생성
        var getEditMask = function(pnIndex){
          if(!pnIndex) pnIndex = 0;
          var vnStartIdx = pnIndex;
          var vnLastIdx = getLastIndex(pnIndex);
          var vnCnt = vnLastIdx + 1 - vnStartIdx;

          vsEditMask = vsEditMask + "[" + voMaskChar[vsNoFormat.charAt(pnIndex)] + "]{" + 0 + "," + vnCnt + "}";
          if(vsNoFormat.charAt(vnLastIdx + 1)) vsEditMask = getEditMask(vnLastIdx + 1);
          return vsEditMask;
        }

        //resultmask 생성
        var getResultMask = function(pnIndex){
          if(!pnIndex) pnIndex = 0;
          var vnStartIdx = pnIndex;
          var vnLastIdx = getLastIndex(pnIndex);
          var vnCnt = vnLastIdx + 1 - vnStartIdx;

          vsResultMask = vsResultMask + "[" + voMaskChar[vsNoFormat.charAt(pnIndex)] + "]{" + vnCnt + "}";
          if(vsNoFormat.charAt(vnLastIdx + 1)) vsResultMask = getResultMask(vnLastIdx + 1);
          return vsResultMask;
        }

        vsEditMask = getEditMask() + "$";
        vsResultMask = getResultMask() + "$";
      }
      break;
    case "Date" :
      vsFormat = this.convertDateFormat(vsFormat);
      if(vsMask){
        vsMask = this.convertDateFormat(vsMask);
        var vsNoFormat = vsMask.replace(/[^ymdhs]/gi, "");
        vsEditMask = "^";
        vsEditMask = vsEditMask + "[0-9]{0," + vsNoFormat.length + "}$";
        vsResultMask = vsResultMask + "[0-9]{" + vsNoFormat.length + "}$";
//        if(vsMask.length <= 8 && /ss/.test(vsMask)) poColumn.dateType = "Time";
//        else if(vsMask.length < 14) poColumn.dateType = "Date";
//        else poColumn.dateType = "DateTime";
      }
      break;
    case "Radio" :
    case "CheckBox" :
      var pnFormat = 1;
      if(poColumn.displayMode){
        if(poColumn.displayMode == "horizontal") pnFormat -= 1;
        else if(poColumn.displayMode == "vertical") pnFormat += 1;
      }
      if(poColumn.labelPos == "left") pnFormat += 4;
      if(poColumn.type == "CheckBox") pnFormat = pnFormat + 8 + 16 + 32;

      vsFormat = "|" + pnFormat + "|||||";
      return vsFormat;
      break;
  }
  var vsRet = "";
  var vsId = poColumn.colId;
  if(vsId == poColumn.control.cfg.idColumn) vsId = "id";
  if(vsFormat) vsRet = vsRet + " " + vsId + "Format='" + vsFormat + "'";
//  if(vsMask) vsRet = vsRet + " " + vsId + "EditFormat='" + vsMask + "' " + vsId + "EditMask='" + vsEditMask + "' " + vsId + "ResultMask='" + vsResultMask + "'";
  if(vsMask) vsRet = vsRet + " " + vsId + "EditFormat='" + vsMask + "' ";
  return  vsRet;
};
/**
 * 주어진 format 문자열을 내부적으로 사용될 표준 format 문자열로 변환하는 메소드
 * @param {String} psFormat format 문자열
 * @return 내부적으로 사용될 표준 format 문자열로 변환된 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.convertDateFormat = function(psFormat){
  // DateMask 추가코드
  /*
  psFormat = psFormat.toUpperCase();
  psFormat = psFormat.split("Y").join("y");
  psFormat = psFormat.split("D").join("d");
  if(psFormat.search("HH24") != -1) psFormat = psFormat.split("HH24").join("HH");
  else if(psFormat.search("HH12") != -1) psFormat = psFormat.split("HH12").join("hh");
  else if(psFormat.search("HH") != -1) psFormat = psFormat.split("HH").join("hh");

  psFormat = psFormat.split("MI").join("mm");
  psFormat = psFormat.split("SS").join("ss");
  */
  return psFormat;
};
/**
 * 정해진 문자형 마스크 포맷으로 값을 변환.
 * @param {String} psValue 컨트롤 disabled설정
 * @return 문자형 마스크 포맷 적용 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.toStringFormatValue = function(psValue, psFormat, psColId){
//  if(psValue == "") return "";
  var voColumn = this.column;

  var vsMaskReg = "";
  var vsMaskPrompt = String.fromCharCode(255);
  for(var vsMaskChar in this.stringMaskChar){
    if(/\W/.test(vsMaskChar)) vsMaskChar = "\\" + vsMaskChar;
    vsMaskReg += vsMaskChar;
  }
  var vrMaskReg = new RegExp("[" + vsMaskReg + "]", "g");
  var vrPrompt = new RegExp("["+vsMaskPrompt+"]", "i");
  var vsFormat = psFormat.replace(vrMaskReg, vsMaskPrompt);
  var vnValIdx = 0;
  for(var i=0; i<vsFormat.length; i++){
    if(vrPrompt.test(vsFormat.charAt(i))){
      var vsFormatChar = psFormat.charAt(i);
      var vsValueChar = psValue.charAt(vnValIdx);
      switch(vsFormatChar){
        case "0" :
          break;
        case "9" :
        case "#" :
        case "*" :
        case "x" :
        case "X" :
          break;
        case "a" :
        case "w" :
        case "^" :
          vsValueChar = vsValueChar.toLowerCase();
          break;
        case "A" :
        case "W" :
        case "!" :
          vsValueChar = vsValueChar.toUpperCase();
          break;
      }
      if(vsValueChar != "") vsFormat = vsFormat.replace(vsFormat.charAt(i), vsValueChar);
      vnValIdx++;
    }
  }
  vrPrompt = new RegExp("["+vsMaskPrompt+"]", "gi");
  if(voColumn) vsFormat = vsFormat.replace(vrPrompt, voColumn.maskPrompt);
  else vsFormat = vsFormat.replace(vrPrompt, "");
  return vsFormat;
};
/**
 * 주어진 값에 정규식 표현을 적용하여 반환하는 메소드
 * @param {String} psValue value
 * @param {String} psMask 정규식 문자 포함 마스크
 * @return 정규식 표현을 적용한 value 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.toMaskedChar = function(psValue, psMask){
  switch(psMask){
    case "0" :
      break;
    case "9" :
    case "#" :
    case "*" :
    case "x" :
    case "X" :
      break;
    case "a" :
    case "w" :
    case "^" :
      psValue = psValue.toLowerCase();
      break;
    case "A" :
    case "W" :
    case "!" :
      psValue = psValue.toUpperCase();
      break;
  }
  return psValue;
};
/**
 * 마스크 프롬프트를 공백문자롤 치환하는 함수
 * @param {String} psValue 컨트롤 disabled설정
 * @return 문자형 마스크 포맷 적용 값
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.maskPromptToBlank = function(psValue, psColId){
  if(!psColId) return psValue;
  var voColumn = this.column;
  var vsMaskPrompt = voColumn.maskPrompt;
  var vsReg = new RegExp('['+vsMaskPrompt+']','gi');
  psValue = psValue.replace(vsReg, "");
  return psValue;
};
/**
 * 값을 지정된 Mask에 맞게 변환하여 반환
 * @param {String} psData Data
 * @param {String} psColId Column Id
 * @return String
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.getMaskedValue = function(poInput, poRow, psColId){
  var voColumn = this.column;
  var vsData = this.grid.getValue(poRow, psColId);
  var voEditMaskObj = this.editMaskObj = new eXria.controls.xhtml.EditMask();
  voEditMaskObj.df.mask = voColumn.mask;
  if(!voColumn.mask) return poInput.value;
  voEditMaskObj.df.maskPrompt = voColumn.maskPrompt;
  voEditMaskObj.subElement.input = poInput;
  voEditMaskObj.document = this.document;
  if(voEditMaskObj.cursorPosition < 0) voEditMaskObj.cursorPosition = 0;

  switch(voColumn.type) {
    case "Int":
    case "Float":
      vsData = String(vsData);
      vsData = this.setNumber(vsData);
      break;
    case "Date":
//      vsData = this.toDateFormatValue(vsData);
      vsData = poInput.value;
      if(vsData == "") vsData = this.toDateFormatValue(vsData);
      break;
    case "Text":
    case "Lines":
      vsData = this.setGeneric(vsData, psColId);
      break;
  }
  if(vsData == null) vsData = "&nbsp;"
  return vsData;
}
/**
 * 정해진 날짜형 마스크 포맷으로 값을 변환.
 * @param {String} psValue 컨트롤 disabled설정
 * @return 날짜형 마스크 포맷 적용 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.toDateFormatValue = function(psValue){
  psValue = psValue.replace(/[^\d]/g, "");
  var vsMask = this.convertDateFormat(this.column.mask);
  var vsPrompt = this.column.maskPrompt;
  var vsFormat = vsMask.replace(this.regDateMask,vsPrompt);
  // 개체의 값 얻어오기
  var vsReg = new RegExp('['+vsPrompt+']','gi');
  //var vsValue = psValue.replace(vsReg,"a");
  var vsRegValue = vsFormat;
  var vsRegFormat = new RegExp('['+vsPrompt+']','i');
  for(var i=0;i < psValue.length;i++) {
    vsRegValue = vsRegValue.replace(vsRegFormat, psValue.charAt(i));
  }
  vsRegValue = vsRegValue.replace(/[YMDhms]/g,vsPrompt);
  return vsRegValue;
};
/**
 * 숫자형 마스크 포맷으로 값을 변환.
 * @param {String} psValue 입력값
 * @return 숫자형 마스크 포맷 적용 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.setNumber = function(psValue) {
  var vsValue = this.getUnMaskedValue(psValue);
  var vsMask = this.column.mask;
  vsValue = NumberToString(psValue, vsMask);
  return vsValue;
};
/**
 * 문자형 마스크 포맷으로 값을 변환.
 * @param {String} psValue 입력값
 * @return 문자형 마스크 포맷 적용 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.setGeneric = function (psValue, psColId){
  var voColumn = this.column;
  var vsValue = this.getUnMaskedValue(psValue, psColId);
  vsValue = this.toStringFormatValue(vsValue, voColumn.mask, psColId);
  var vnPos = vsValue.indexOf(voColumn.maskPrompt);
  this.cursorPosition = vnPos;
  return vsValue;
};
/**
 * setKeyDownValue
 * @param {String} psValue 입력값
 * @param {Object} poRow row object
 * @param {String} psColId column id
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.setKeyDownValue = function(psValue, poRow, psColId){
  this.tempValue = psValue;
}
/**
 * 입력키에 유효성을 체크하고 마스크 타입에 맞게 문자열 변환 메소드.
 * @param {HTMLEvent} e 윈도우이벤트
 * @return 작업수행의 성공 여부
 * @type Boolean
 * @ignore
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.checkKey = function(e, poInput, psColId){
  var voColumn = this.column;
  var vnKeyCode = e.keyCode;
  var vsValue = poInput.value;
  var vnPos = this.cursorPosition = this.getCursorPosition(poInput);
  if(vnKeyCode == 229 && e.type != "keyup") { // 한글 입력 상태에서 마우스 클릭시 keyup 이벤트가 발생하여 이를 제외하여 체크
    alert("한글 입력은 허용이 되지 않습니다.");
  } else if(vnKeyCode == 229 && e.type == "keyup") {
    return;
  }

  var voConstKey = this.constKey;
  switch(vnKeyCode) {
    case voConstKey["ENTER"] :
    case voConstKey["TAB"] :
    case voConstKey["SHIFT"] :
    case voConstKey["LEFT"] :
    case voConstKey["RIGHT"] :
    case voConstKey["UP"] :
    case voConstKey["DOWN"] :
      return true;
  }
  var voStringMaskChar = this.stringMaskChar;
  var voNumberMaskChar = this.numberMaskChar;
  var voDateMaskChar = this.dateMaskChar;

  var voMaskCharSet = null;
  var vsType = voColumn.type;
  if(vsType == "Text" || vsType == "Lines") voMaskCharSet = voStringMaskChar;
  else if(vsType == "Int" || vsType == "Float") voMaskCharSet = voNumberMaskChar;
  else if(vsType == "Date") voMaskCharSet = voDateMaskChar;

  var vsMaskReg = "";
  for(var vsMaskChar in voMaskCharSet){
    if(/\W/.test(vsMaskChar)) vsMaskChar = "\\" + vsMaskChar;
    vsMaskReg += vsMaskChar;
  }
  var vrMaskReg = new RegExp("[" + vsMaskReg + "]", "g");
  var vsColMask = voColumn.mask;
  if(voColumn.type == "Date") voColumn.mask = this.convertDateFormat(voColumn.mask);
  var vsMask = voColumn.mask.replace(vrMaskReg, voColumn.maskPrompt);
  var vsTempValue = this.tempValue;

  function checkPosChar(pnPos){
    var vsMChar = voColumn.mask.charAt(pnPos-1);
    for(var vsMaskChar in voMaskCharSet){
      if(voMaskCharSet[vsMChar]) return voMaskCharSet[vsMChar];
    }
    return false;
  }

  function getValuePosition(pos, pnType){
    if(pos < 0 || pos > voColumn.mask.length) return pos;
    var retPos = pos;
    if(checkPosChar(pos)){
    }else{
      if(pnType == 0) pos--;
      else if(pnType == 1) pos++;
      retPos = getValuePosition(pos, pnType);
    }
    return retPos;
  }

  function setInputChar(pnPos, psChar){
    var vaTempValue = vsTempValue.split("");
    vaTempValue[pnPos-1] = psChar;
    return vaTempValue.join("");
  }
  function deleteInputChar(pnPos1, pnPos2){
    var vaTempValue = vsTempValue.split("");
    if(voColumn.type == "Text" || voColumn.type == "Lines") vaTempValue[pnPos1] = vsMask.charAt(pnPos1);
    if(voColumn.type == "Int" || voColumn.type == "Float") vaTempValue[pnPos1] = "";
    return vaTempValue.join("");
  }
  function returnInputValue(){
    return vsTempValue;
  }

  function checkInputCharValidation(pnPos, psChar){
    var vbRet = new RegExp("[" + voMaskCharSet[voColumn.mask.charAt(pnPos)] + "]").test(psChar);
    return vbRet;
  }

  vnKeyCode = this.matchNumberPad(vnKeyCode);
  var vsKeyCharacter = String.fromCharCode(vnKeyCode);
  switch(voColumn.type){
    case "Text" :
    case "Lines" :
    case "Date" :
      if(this.vbSelectAll){
        vnPos = vsMask.indexOf(voColumn.maskPrompt);
        if(new RegExp("[" + voMaskCharSet[voColumn.mask.charAt(vnPos)] + "]", "g").test(vsValue)){
          vsKeyCharacter = vsValue.charAt(vnTempPos-1);
          vsValue = this.toMaskedChar(vsKeyCharacter, voColumn.mask.charAt(vnPos));
          vsValue = vsMask.replace(voColumn.maskPrompt, vsValue);
        }else{
          vsValue = vsMask;
        }
        vnPos = vsValue.indexOf(voColumn.maskPrompt);
      }else if(vnKeyCode == 8 || vnKeyCode == 46){
        var vnTempPos = getValuePosition(vnPos, 0);
        vsValue = deleteInputChar(vnPos, vnTempPos);
      }else{
        var vnTempPos = getValuePosition(vnPos, 1);
        vsKeyCharacter = vsValue.charAt(vnTempPos-1);

        if(checkInputCharValidation(vnTempPos-1, vsKeyCharacter)){
          vsKeyCharacter = this.toMaskedChar(vsKeyCharacter, voColumn.mask.charAt(vnTempPos-1));
          vsValue = setInputChar(vnTempPos, vsKeyCharacter);

          // 2009.07.01 다음키가  key값 또는 maskPrompt도 아닌경우( - << 와 같은 캐릭터 일경우)
          // TODO: -- 두개일경우를 고려하여 for루프가 필요할수 있다
          if(vsValue.charAt(vnTempPos)) {
            var vsNextKey = vsValue.charAt(vnTempPos);
            if(voColumn.maskPrompt != vsNextKey) {
              if(checkInputCharValidation(vnTempPos, vsNextKey) == false)
                vnTempPos++;
            }
          }

          vnPos = vnTempPos;
        }else{
          vsValue = returnInputValue();
          vnPos--;
        }
      }
      break;
    case "Int" :
    case "Float" :
      if(vnKeyCode == 8 || vnKeyCode == 46){
        var vnTempPos = getValuePosition(vnPos, 0);
        vsValue = deleteInputChar(vnPos, vnTempPos);
        vsValue = vsValue.replace(/[^0-9\.]/gi, "");
        vsValue = NumberToString(vsValue, voColumn.mask);
        vnPos++;
      }else{
        vsValue = vsValue.replace(/[^0-9\.]/gi, "");
        var vnTempPos = getValuePosition(vnPos, 1);
        if(vnKeyCode == 190) vsKeyCharacter = ".";
        if(checkInputCharValidation(vnTempPos-1, vsKeyCharacter)){
          vsKeyCharacter = this.toMaskedChar(vsKeyCharacter, voColumn.mask.charAt(vnTempPos));
          vsValue = setInputChar(vnTempPos, vsKeyCharacter);
          var vnTempLen = vsValue.length;
          if(vsKeyCharacter != "."){
            vsValue = vsValue.replace(/[^0-9\.]/gi, "");
            vsValue = NumberToString(vsValue, voColumn.mask);
          }
          vnPos = vnTempPos;
          if(vnTempLen != vsValue.length) vnPos++;
        }else{
          vsValue = returnInputValue();
          vnPos--;
        }
      }
      break;
  }
  poInput.value = vsValue;
  if(vnPos >= 0) this.setCursorPosition(vnPos, poInput);
};
/**
 * 날짜 validiate 검사.
 * @param (String) psValue 컨트롤 disabled설정
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.checkDate = function(psValue){
  var voDf = this.df;
  psValue = psValue.replace(this.noDigits, "");
  var vsFormat = this.column.mask;
  vsFormat = vsFormat.replace(/[^YyMDdhms]/g, "");

  var vnYearPos = vsFormat.search(/yyyy/i);
  var vnMonthPos = vsFormat.search(/mm/i);
  var vnDatePos = vsFormat.search(/dd/i);
  var vnYear = psValue.substr(vnYearPos, 4);
  if(vnYear != "") vnYear = parseInt(vnYear);
  var vnMonth = psValue.substr(vnMonthPos, 2);
  if(vnMonth.length == 1) vnMonth += "0";
  if(vnMonth != "") vnMonth = parseInt(vnMonth) - 1;
  var vnDate = psValue.substr(vnDatePos, 2);
  if(vnDate.length == 1) vnDate += "0";
  if(vnDate != "") vnDate = parseInt(vnDate);

  var voDate = new Date();
  if(vnYear == "" || vnYear == 0) vnYear = voDate.getFullYear();
  if(vnMonth == "" || vnMonth == -1) vnMonth = voDate.getMonth();
  if(vnDate == "" || vnDate == 0) vnDate = voDate.getDate();

  voDate.setFullYear(vnYear);
  voDate.setMonth(vnMonth);
  voDate.setDate(vnDate);

  if( voDate.getFullYear() != vnYear
      || voDate.getMonth() != vnMonth
      || voDate.getDate() != vnDate) {
    return false;
  }
  return true;
};
/**
 * 사용자가 정의한 마스크를 제외하고 삭제
 * @param poEvent
 * @return 삭제하고 난 후의 값
 * @type Array(String)
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.chkBackSpace = function(poEvent, psColId, poInput){
  var voColumn = this.column;
  var voDf = this.df;
  var vnKeyCode = poEvent.keyCode;
  var vnPos = this.getCursorPosition(poInput);
  var vsValue = null;
  var vnCutPos = 0;
  var vsMaskReg = "";
  var vsMaskPrompt = String.fromCharCode(255);
  for(var vsMaskChar in this.stringMaskChar){
    if(/\W/.test(vsMaskChar)) vsMaskChar = "\\" + vsMaskChar;
    vsMaskReg += vsMaskChar;
  }
  var voStringReg = new RegExp("[^" + vsMaskReg + "]","g");
  var voDateReg = new RegExp("[^YMDhms]","g");
  var voReg = null;
  var voRegI = null;
  var voValues = new Array;
  voColumn.vbSelectAll = false; // temp code
  if(voColumn.vbSelectAll) return "";
  if(voColumn.type == "Text" || voColumn.type == "Lines") {
    voReg = voStringReg;
    voRegI = new RegExp("[" + vsMaskReg + "]","g");
  }
  else if(voColumn.type == "Date") {
    voReg = voDateReg;
    voRegI = /[YMDhms]/g;
  }
  vsValue = poInput.value;
  if(vnKeyCode == 8){
    var vsVal1 = vsValue.substring(0, vnPos);
    var vsVal2 = vsValue.substring(vnPos, vsValue.length);
    vsValue = vsVal1 + voColumn.maskPrompt + vsVal2;
    vnPos++;
  }else if(vnKeyCode == 46){
    var vsVal1 = vsValue.substring(0, vnPos);
    var vsVal2 = vsValue.substring(vnPos, vsValue.length);
    vsValue = vsVal1 + voColumn.maskPrompt + vsVal2;
  }
  voValues[0] = vsValue;
  voValues[1] = vnPos;

  return voValues;
};
/**
 * inputbox에서의 커서 위치 설정
 * @param {Number} pnPos 커서 위치 값
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.setCursorPosition = function(pnPos, poInput) {
  if(poInput.selectionEnd) {
    poInput.selectionStart = pnPos;
    poInput.selectionEnd = pnPos;
  } else if (poInput.createTextRange) {
    var voRange = poInput.createTextRange();
    voRange.collapse(true);
    voRange.moveEnd('character', pnPos);
    voRange.moveStart('character', pnPos);
    voRange.select();
  }
};
/**
 * 현재에서의 커서 위치 반환
 * @return 커서의 위치
 * @type Number
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.getCursorPosition = function(poInput) {
  var voDocument = this.grid.document;
  var vnCursorPosition = -1;
  if(poInput == null) return vnCursorPosition;
  if (poInput.selectionEnd) {
    vnCursorPosition = poInput.selectionEnd;
  } else if(voDocument.selection && voDocument.selection.createRange) {
    var voRange = voDocument.selection.createRange().duplicate();
    voRange.moveStart('textedit', -1);
    vnCursorPosition = voRange.text.length;
  }
  return vnCursorPosition;
};
/**
 * 넘버패드의 keycode를 기본 숫자 keycode로 변환
 * @param (Number)
 * @return 변환된 keyCOde
 * @type Number
 * @private
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.matchNumberPad = function(vnKeyCode){
  if(vnKeyCode > 95 && vnKeyCode < 106) return vnKeyCode -= 48;
  else if(vnKeyCode == 110) return 190;
  else return vnKeyCode;
}
/**
 * 현재 텍스트가 전체 select 되어있는지 여부를 확인
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.checkSelect = function(e, poInput, psColId){
  var voDocument = this.grid.document;
  var voCanvas = this.grid.canvas;
  var vnTextLen = poInput.value.length;
  this.vbSelectAll = false;
  if(voCanvas.page.metadata.browser.ie){
    var voTextRange = voDocument.selection.createRange();
    var vnLen = voTextRange.text.length;
    if(vnLen == vnTextLen) this.vbSelectAll = true;
  }else{
    if(poInput.selectionEnd - poInput.selectionStart == vnTextLen) this.vbSelectAll = true;
  }
};
/**
 * Mask가 적용된 Value를 Mask를 없앤 후 반환
 * @param {String} psData Data
 * @param {String} psColId Column Id
 * @return String
 * @type String
 * @private
 */
eXria.controls.xhtml.GridEx.FormatMask.prototype.getUnMaskedValue = function(psData, psColId){
  var voColumn = this.column;
  var vsMask = voColumn.mask;
  var vsNotMask = "";
  var vsMaskReg = null;

  if(!vsMask) return psData;
  if(voColumn.type == "Text" || voColumn.type == "Lines"){
    vsNotMask = eXria.util.StringUtil.trim((voColumn.mask.replace(/[#*x]/gi,"")));
    if(vsNotMask.length != 0){
      if(vsNotMask.match(/\W/g)){
        var vaMatch = String(vsNotMask.match(/\W/g)).split(",");
        for(var i=0; i<vaMatch.length; i++) vaMatch[i] = "\\" + vaMatch[i];
        vsNotMask = vaMatch.join("");
      }
      vsNotMask = "[" + vsNotMask + "]";
      vsMaskReg = new RegExp(vsNotMask,'gi');
    }
  }
  var vsData = eXria.controls.xhtml.Util.parseLang(psData);
  var vsFormat = voColumn.mask.replace(this.regDateMask, voColumn.maskPrompt);
  // 개체의 값 얻어오기
  var vsReg = new RegExp('['+voColumn.maskPrompt+']','gi');
  //var vsValue = psValue.replace(vsReg,"a");
  var vsRegValue = vsFormat;
  var vsRegFormat = new RegExp('['+voColumn.maskPrompt+']','gi');
  switch(voColumn.type){
    case "Text":
    case "Lines":
      psData = String(psData);
      psData = psData.replace(vsMaskReg, "");
      psData = psData.replace(vsRegFormat, "");
      vsData = psData;
      break;
    case "Int":
    case "Float":
      psData = String(psData);
      vsData = Number(psData.replace(/[^0-9\.\-\+]/gi, ""));
      break;
    case "Date":
      vsFormat = vsMask.replace(this.regDateMask, voColumn.maskPrompt);
      vsData = this.toDateFormatValue(vsData);
      var vsNotMask = voColumn.mask.replace(/[ymdhs]/gi, "");
      vsNotMask = vsNotMask.split(" ").join("");
      if(vsNotMask.length != 0){
        if(vsNotMask.match(/\W/g)){
          var vaMatch = String(vsNotMask.match(/\W/g)).split(",");
          for(var i=0; i<vaMatch.length; i++) vaMatch[i] = "\\" + vaMatch[i];
          vsNotMask = vaMatch.join("");
        }
        vsNotMask = "[" + vsNotMask + "]";
        vsMaskReg = new RegExp(vsNotMask,'gi');
      }
      vsData = vsData.replace(vsMaskReg, "");

      vsData = vsData.replace(new RegExp("[\\" + voColumn.maskPrompt + "]", "gi"), "");
      vsData = vsData.split(" ").join("");
      break;
  }
  return vsData;
};


/**
 * @class GridEx의 Color정보 저장 객체 정의 클래스
 * @return 새로운 eXria.controls.xhtml.GridEx.ColorData 객체
 * @type eXria.controls.xhtml.GridEx.ColorData
 * @constructor
 * @private
 */
eXria.controls.xhtml.GridEx.ColorData = function() {
  /**
   * row 식별자 저장 배열
   * @type Arryay
   * @private
   */
  this.primaryKeys = new Array();
  /**
   * header row color 정보 저장 배열
   * @type Array
   * @private
   */
  this.headColorData = new Array();
  /**
   * body row color 정보 저장 배열
   * @type Array
   * @private
   */
  this.bodyColorData = new Array();
  /**
   * footer row color 정보 저장 배열
   * @type Array
   * @private
   */
  this.footColorData = new Array();
  /**
   * header row color 정보를 반환하는 메소드
   * @return header row color 정보
   * @type Array
   * @private
   */
  this.getHeaderRowData = function(psColId){
    for(var i=0,il=this.headColorData.length; i<il; i++){
      if(this.headColorData[i].columnId == psColId) return this.headColorData[i];
    }
    return null;
  };
  /**
   * footer row color 정보를 반환하는 메소드
   * @return footer row color 정보
   * @type Array
   * @private
   */
  this.getFooterRowData = function(psColId){
    for(var i=0,il=this.footColorData.length; i<il; i++){
      if(this.footColorData[i].columnId == psColId) return this.footColorData[i];
    }
    return null;
  }
};

/**
 * @class GridEx row의 Color정보 저장 객체 정의 클래스
 * @return 새로운 eXria.controls.xhtml.GridEx.ColorData.RowData 객체
 * @type eXria.controls.xhtml.GridEx.ColorData.RowData
 * @constructor
 * @private
 */
eXria.controls.xhtml.GridEx.ColorData.RowData = function(){
  /**
   * column 식별자 저장 ArrayMap 객체
   * @type Array
   * @private
   */
  this.primaryKeyValues = new eXria.data.ArrayMap();
  /**
   * row color 값 참조 변수
   * @type String
   * @private
   */
  this.rowColor = null;
  /**
   * 컬럼 색상 정보 ArrayMap 객체
   * @type Array
   * @private
   */
  this.columnsColor = new eXria.data.ArrayMap();
  /**
   * 컬럼 id 참조 변수
   * @type Array
   * @private
   */
  this.columnId = null;
};

/**
 * @class GridEx Page(Fast) 옵션일 경우 Select 처리 위한 함수
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setPageSelection = function() {
   // paging 관련 추가코드 (rowcount갯수가 변함)
//  var vnCount = this.getRowCnt();
//  for(var i = 0; i < vnCount; i++) {
//   var voRow = this.getRowIndex(i);
//    if(voRow) {
//      if(this.pageSelectAllChecked == true) {
//        if(voRow.Selected == null || voRow.Selected == false) {
//          this.selectRow(voRow);
//        }
//      }
//      else if(this.pageSelectAllChecked == false) {
//        if(voRow.Selected == true) {
//          this.selectRow(voRow);
//        }
//      }
//    }
//  }
//
//  // 마지막에 안보이는 사례 보임
//  var voRow = this.grid.GetLastVisible(null, null);
//  if(voRow) {
//    if(this.pageSelectAllChecked == true) {
//      if(voRow.Selected == null || voRow.Selected == false) {
//        this.selectRow(voRow);
//      }
//    }
//    else if(this.pageSelectAllChecked == false) {
//      if(voRow.Selected == true) {
//        this.selectRow(voRow);
//      }
//    }
//  }
   var vaRow = this.getPagingRows();
   var vnSize = vaRow.length;
   var voRow = null;
   for(var i = 0; i < vnSize; i++) {
     voRow = vaRow[i];
     if(this.pageSelectAllChecked == true) {
       if(voRow.Selected == null || voRow.Selected == false) {
         this.selectRow(voRow);
       }
     } else if(this.pageSelectAllChecked == false) {
       if(voRow.Selected == true) {
         this.selectRow(voRow);
       }
     }
   }
};

/**
 * @member eXria.controls.xhtml.GridEx
 * @type void
 * @author yhkim at 10. 1. 5 오전 11:29
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setColumnDiffWidth = function(pnOldWidth, pnAttrValue) {
  var voCols = new Array();
  voBody = this.body;
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  var nColLen = 0;
  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      voRow = voCols[i].rows[0];
    for(var j=0; j<voRow.columns.length; j++) {
        voColumn = voRow.columns[j];
    if(voColumn.visible !== false)
        nColLen++;
    }
    }
  }
  var nDiff = pnAttrValue - pnOldWidth;
  nDiff = nDiff / nColLen;

  for(var i=0; i<3; i++) {
    if(voCols[i]) {
      voRow = voCols[i].rows[0];
      for(var j=0; j<voRow.columns.length; j++) {
        voColumn = voRow.columns[j];
    if(voColumn.visible !== false)
          voColumn.width = voColumn.width + nDiff;
      }
    }
  }
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
};

/**
 * @member eXria.controls.xhtml.GridEx
 * @type void
 * @author yhkim at 10. 1. 12 오후 19:07
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getOrgValueFromMask = function(psData, psMask) {
  if(psData == null || psData == "") return psData;
  if(psMask == null || psMask == "") return psData;
  var voRegMap = {"x": "[A-Za-z0-9]", "X": "[A-Za-z0-9]", "#": "[0-9]", "*": ".", "S" : "[a-zA-Z0-9\\xC0-\\xD6\\xD8-\\xF6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD]"};
  psMask = psMask.replace(/[^#Xx*S]/g, "");
  var vsRegValue = "";
  var vnIndex = 0;
  var vnSize = psMask.length;
  var vsMaskChar = null;
  var vsChar = null;
  var vnValLen = psData.length;
  var vsRegStr = null;
  for(var i=0; i < vnSize; i++) {
    vsMaskChar = psMask.charAt(i);    // xx:
    vsChar = psData.charAt(vnIndex++);  // 123
    vsRegStr = voRegMap[vsMaskChar];  //
    if(vsRegStr && (new RegExp(vsRegStr)).test(vsChar)) vsRegValue += vsChar;
  else i--;
    if(vnIndex >= vnValLen) break;
  }

  return vsRegValue;
};

/**
 * treegrid소스내에서 동적으로 locale정보를 얻기위해 제공해주는 함수(gridEx에서는 사용안됨)
 * @member eXria.controls.xhtml.GridEx
 * @type void
 * @author yhkim at 10. 1. 282 오후 19:07
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getLocale = function() {
  var vsLocale = "kor";
  if(this.locale == null) {
    if(this.canvas.page.metadata.useMultilingual != null && this.canvas.page.metadata.language != null) {
      if(this.canvas.page.metadata.useMultilingual == true) {
        var vsDefaultLocale = this.canvas.page.metadata.eXriaLocale.toUpperCase();
        if(vsDefaultLocale == "KO_KR") vsLocale = "kor";
        else if(vsDefaultLocale == "JA_JP") vsLocale = "jpn";
        else if(vsDefaultLocale.search(/ZH/) != -1) vsLocale = "chn";
        else vsLocale = "eng";
      }
      else {
        if(this.canvas.page.metadata.language.toUpperCase() == "KO") vsLocale = "kor";
        else vsLocale = "eng";
      }
    }
  }
  else vsLocale = this.locale;
  return vsLocale;
};

/**
 * Re-calculates grid after given cell changes
 * @member eXria.controls.xhtml.GridEx
 * @type void
 * @author tomato at 10. 2. 24 오후 3:06
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.recalculate = function(poRow, psCol, pbShow) {
  this.grid.Recalculate(poRow, psCol, pbShow);
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.clearDataSetRowKeyValue = function(psKeyName) {
  var voDataSet = null;
  if (this.dataset) voDataSet = this.dataset;
    else {
    if(this.datasetId)
      voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
  }
  if(voDataSet) {
    if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE)
      voDataSet.setRowsAttr(psKeyName, null);
//    else if(this.canvas.page.metadata.modelType == eXria.form.ModelType.PLUGIN) {
    else {
      var vnRowCnt = voDataSet.getRowCnt();
      for(var i = 0; i < vnRowCnt; i++) {
        // plugin 한번에 날리는 로직을 구현해준다고 함
        voDataSet.setRowAttr(i+1, psKeyName, "");
      }
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.setDataSetRowKeyValue = function(psKeyName, psValue) {
   if(psValue == null) psValue = "";
   var voDataSet = null;
  if (this.dataset) voDataSet = this.dataset;
    else {
    if(this.datasetId)
      voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
  }

  if(voDataSet === null) return;

  if(voDataSet) {
    var vaIndexes = [];
    if(psKeyName === "focus__RowIndex") {
      if(this.focusRow !== null)
        vaIndexes.push(this.getIndexOfRow(this.focusRow));
    }
    else if(psKeyName === "selected__RowIndex") {
          if(this.selectedIndexes !== null)
        vaIndexes = this.selectedIndexes;
    }

    for(var j = 0; j < vaIndexes.length; j++) {
      voDataSet.setRowAttr(vaIndexes[j]+1, psKeyName, psValue);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.runWithDataSetColumnType = function(psType) {
  var voDataSet = null;
  if (this.dataset) voDataSet = this.dataset;
  else {
    if(this.datasetId)
      voDataSet = this.canvas.page.model.getDataSet(this.datasetId);
  }

  if(voDataSet === null) return;

  var voRow = null;
  var vsValue = null;

  if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    var vaList = null;
    vaList = voDataSet.getRowsAttr(psType);
    if(vaList == null || !(vaList instanceof Array)) vaList = [];
    for(var i = 0; i < vaList.length; i++) {
    var vnIndex = vaList[i].get(0);
    vsValue = voDataSet.getRowAttr(vnIndex, psType);
    voRow = this.getRowIndex(vnIndex-1);
    }
  }
//  else if(this.canvas.page.metadata.modelType == eXria.form.ModelType.PLUGIN) {
  else {
    var vnDSCnt = voDataSet.getRowCnt();
    for(var i = 1; i < vnDSCnt+1; i++) {
      vsValue = voDataSet.getRowAttr(i, psType);
      if(!!vsValue) {
        voRow = this.getRowIndex(i-1);
        break;
      }
    }
  }

  if(voRow) {
    if(vsValue) {
      if("focus__RowIndex" === psType) {
        if(vsValue == "") vsValue = null;
        this.grid.Focus(voRow, vsValue, null, true);
      }
      if("selected__RowIndex" === psType) {
        if(voRow.Selected != true)
          this.grid.SelectRow(voRow);
      }
    }
    else {
      if("selected__RowIndex" === psType && voRow.Selected === true)
        this.grid.SelectRow(voRow);
    }
  }
};

/**
 *
 * @member eXria.controls.xhtml.GridEx
 * @type ?
 * @author tomato at 10. 3. 9 오후 1:22
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.Initialize = function() {
  this.pageSelectAllChecked = null;
};

/**
 * @member eXria.controls.xhtml.GridEx
 * @author tomato at 10. 3. 11 오전 9:40
 * @ignore
 */
eXria.controls.xhtml.GridEx.prototype.getIMEInfo = function(poRow, psCol) {
  var voCol = null;
  if(voCol == null) voCol = this.getBodyColumn(null, psCol);
  if(voCol == null) voCol = this.getFunctionColumn(poRow, null , psCol);
  if(voCol == null) voCol = this.getFootColumn(poRow, null , psCol);
  if(voCol && voCol.imeMode) return voCol.imeMode;
};

/**
 * 그리드 컬럼 정보 반환
 * @member eXria.controls.xhtml.GridEx
 * @type ?
 * @author tomato at 10. 4. 8 오후 4:20
 */
eXria.controls.xhtml.GridEx.prototype.getColumnObj = function(psCol) {
  var voColumn = null;
  var voCols = new Array();
  voBody = this.body;
  voCols[0] = voBody.cols["left"];
  voCols[1] = voBody.cols["center"];
  voCols[2] = voBody.cols["right"];

  var voArray = new Array();
  for(var i = 0; i < voCols.length; i++)
    if(voCols[i] && voCols[i].rows)
      voArray = voArray.concat(voCols[i].rows[0].columns);

  for(var j=0; j < voArray.length; j++) {
    voColumn = voArray[j];
    if(voColumn.colId == psCol) {
      break;
    }
  }
  return voColumn;
};

/**
 * instance 또는 dataset의 컬럼 name 으로 그리드 rowIndex 의 value값 가져오기
 * @member eXria.controls.xhtml.GridEx
 * @type ?
 * @author tomato at 10. 4. 8 오후 4:20
 * @public
 */
eXria.controls.xhtml.GridEx.prototype.getValueByIndex = function(pnRow, psCol) {
  var value = null;

  if(this.dataset)
    return this.dataset.get(pnRow, psCol);
  else {
    var voColumn = this.getColumnObj(psCol);
    if(voColumn == null) return;
    var poCollectionNode = this.data.getNodesetData();
    if(poCollectionNode == null) return;
    var voMapMode = new eXria.data.xhtml.MapNode(poCollectionNode.get(pnRow));
    value = voMapMode.get(voColumn.ref);
    return value;
  }
};

/**
 * instance 또는 dataset의 row의 String값 가져오기
 * @member eXria.controls.xhtml.GridEx
 * @type ?
 * @author tomato at 10. 4. 8 오후 4:20
 * @public
 */
eXria.controls.xhtml.GridEx.prototype.getStringByIndex = function(pnRow, psCol) {
  var vsValue = this.getValueByIndex(pnRow, psCol);
  var voColumn = this.getColumnObj(psCol);
  if(voColumn == null) return;
  // Treegrid값 형태로 변환
  switch(voColumn.type){
    case "Date" :
      var vnTime = "";
      if (vsValue != "" && vsValue != null) {
        var tempDate = new Date(this.addSeparator(vsValue, 2, null, psCol));
        var ut = new Date(tempDate);
        var voDate = new Date(Date.UTC(ut.getFullYear(), ut.getMonth(), ut.getDate(), ut.getHours(), ut.getMinutes(), ut.getSeconds()));
        vnTime = voDate.getTime();
      }
      vsValue = vnTime;
      break;
    case "Bool" :
      if(vsValue != null && vsValue != "") vsValue = eval(vsValue);
      break;
    case "Radio" :
    case "CheckBox" :
      if(vsValue == null) return null; // 2009.12.01 yhkim(bug6398) 이 조건문 자체는 맨위로 가야할듯 하나 Date가 ""리턴하는 side-effect 문제로 이조건문에만 넣음 > 향후고려 필요
      var vaValues = voColumn.itemgroup.getItemValuesToArray();
      var getMatchValueIdx = function(psVal) {
        for(var i=0; i<vaValues.length; i++) {
          if(vaValues[i] == psVal) return i;
        }
        return false;
      }
      if(typeof(vsValue) == "string") vsValue = vsValue.split(",");
      if(voColumn.type == "CheckBox") {
        var vaAllValues = voColumn.itemgroup.getItemValuesToArray();
        var vaAllLabels = voColumn.itemgroup.getItemLabelsToArray();
        var vaSelectedValues = vsValue;
        var vaSelectedLabels = [];
        for(var p=0; p< vaAllValues.length; p++) {
          for(var q=0; q<vaSelectedValues.length; q++)
          if(vaAllValues[p] == vaSelectedValues[q])
            vaSelectedLabels.push(vaAllLabels[p]);
        }
        vsValue = vaSelectedLabels.join(";");
      }else {
        vsValue = getMatchValueIdx(vsValue[vsValue.length-1]);
      }
      break;
    case "Enum" :
      var vsValues = voColumn.itemgroup.getItemValuesToString(voColumn.itemSeparator);
      var vsLabels = voColumn.itemgroup.getItemLabelsToString(voColumn.itemSeparator);

      var vaEnumKeys = vsValues.split('|');
      var vaEnum = vsLabels.split('|');
      for(var i=0, il=vaEnumKeys.length; i<il; i++){
        if(vaEnumKeys[i] == vsValue){
          vsRetValue = i;
          break;
        }
      }
      vsValue = vaEnum[i];
    default :
      break;
  }
  // Tree그리드 변환 형태 따름
  return this.grid.GetStringExt(voColumn.type, voColumn.regFormat, vsValue);

};

/**
 * GridEx의 칼럼과 이벤트 정보를 다른 GridEx에서 가져와 확장한다.
 * @param {Object} eXria.controls.xhtml.GridEx
 * @public
 */
eXria.controls.xhtml.GridEx.prototype.extendCols = function(poGrid) {
  var voTrgDst = this.dataset;
  var voTrgHColsRow = this.header.cols["center"].rows[0];
  var voTrgBColsRow = this.body.cols["center"].rows[0];
  var voCol = null;

  var voSrcDst = poGrid.dataset;
  var voSrcHColsRow = poGrid.header.cols["center"].rows[0];
  var vaSrcHColumns = voSrcHColsRow.columns;
  var voSrcHCol = null;
  var voSrcBCol = null;
  var vnSize = vaSrcHColumns.length;
  for(var i = 0; i < vnSize; i++) {
    voSrcHCol = vaSrcHColumns[i];
    voSrcBCol = poGrid.getBodyColumn(null, voSrcHCol.id)

    voCol = voTrgHColsRow.createHeadColumn(voSrcHCol.id, null, null);
    voCol.colspan = voSrcHCol.colspan;
    voCol.value = voSrcHCol.value;
    voCol.className = voSrcHCol.className;
    voCol.hoverClassName = voSrcHCol.hoverClassName;
    voTrgHColsRow.addColumn(voCol);

    voCol = voTrgBColsRow.createBodyColumn(voSrcBCol.id, voSrcHCol.id, voSrcBCol.type, voSrcBCol.instanceId, voSrcBCol.ref);
    voCol.width = voSrcBCol.width;
    voCol.datasetCol = voSrcBCol.datasetCol;

    voCol.className = voSrcBCol.className;
    voCol.hoverClassName = voSrcBCol.hoverClassName;
    voCol.enumType = voSrcBCol.enumType;
    voCol.formula = voSrcBCol.formula;
    voCol.itemSeparator = voSrcBCol.itemSeparator;

    voCol.minLength = voSrcBCol.minLength;
    voCol.maxLength = voSrcBCol.maxLength;
    voCol.minByteLength = voSrcBCol.minByteLength;
    voCol.maxByteLength = voSrcBCol.maxByteLength;
    voCol.nullable = voSrcBCol.nullable;
    voCol.inputMode = voSrcBCol.inputMode;

    voCol.groupFormula = voSrcBCol.groupFormula;
    voCol.groupFormat = voSrcBCol.groupFormat;
    voCol.groupClassName = voSrcBCol.groupClassName;

    if(voCol.type == "Int" || voCol.type == "Float" || voCol.type == "Date" || voCol.type == "Text") {
      voCol.format = voSrcBCol.format;
      voCol.mask = voSrcBCol.mask;
      voCol.regMask = voSrcBCol.regMask;
      voCol.regFormat = voSrcBCol.regFormat;
    }

    if(voSrcBCol.rightButton) {
        var voRightButton = voCol.createRightButton(voSrcBCol.rightButton.type, voSrcBCol.instanceId, voSrcBCol.ref);
        voRightButton.width = voSrcBCol.rightButton.width;
        voRightButton.value = voSrcBCol.rightButton.value;
        voRightButton.enableMode = voSrcBCol.rightButton.enableMode;
        voCol.addRightButton(voRightButton);
    }

    voCol.canEdit = voSrcBCol.canEdit;
    voCol.canFocus = voSrcBCol.canFocus;
    voCol.canSort = voSrcBCol.canSort;
    voCol.visible = voSrcBCol.visible;

    var voItemGroup = null;
    switch(voCol.type) {
      case "CheckBox" :
      case "Radio" :
        voCol.displayMode = voSrcBCol.displayMode;
      case "Enum" :
        var voData = voSrcBCol.itemgroup.data;
        voItemGroup = voCol.itemgroup;
        if(voData.nodesetInstanceId && voData.nodesetInstancePath) {
          voItemGroup = voCol.itemgroup;
          voItemGroup.data.setNodesetRef(voData.nodesetInstanceId, voData.nodesetInstancePath);
          voItemGroup.labelTagName = voSrcBCol.itemgroup.labelTagName;
          voItemGroup.valueTagName = voSrcBCol.itemgroup.valueTagName;
        }

        var voItems = voSrcBCol.itemgroup.frontItems;
        var vnItemCnt = voItems.size();
        var voItemKeys = voItems.getKeyCollection();
        var voItemValues = voItems.getValueCollection();
        var vsItemKey = null;
        var vsItemValue = null;
        for(var j = 0; j < vnItemCnt; j++) {
          vsItemKey = voItemKeys.get(j);
          vsItemValue = voItemValues.get(j);
          voItemGroup.addItemFront(vsItemValue, vsItemKey);
        }
        voItems = voSrcBCol.itemgroup.backItems;
        vnItemCnt = voItems.size();
        voItemKeys = voItems.getKeyCollection();
        voItemValues = voItems.getValueCollection();
        for(var j = 0; j < vnItemCnt; j++) {
          vsItemKey = voItemKeys.get(j);
          vsItemValue = voItemValues.get(j);
          voItemGroup.addItemBack(vsItemValue, vsItemKey);
        }
        break;
      case "Button" :
        voCol.buttonItem.width = voSrcBCol.buttonItem.width;
        voCol.buttonItem.height = voSrcBCol.buttonItem.height;
        voCol.buttonItem.icon = voSrcBCol.buttonItem.icon;
        voCol.buttonItem.iconChecked = voSrcBCol.buttonItem.iconChecked;
        voCol.buttonItem.tooltip = voSrcBCol.buttonItem.tooltip;
        voCol.buttonItem.tooltipChecked = voSrcBCol.buttonItem.tooltipChecked;
        break;
      case "Image" :
        voCol.imageItem.width = voSrcBCol.imageItem.width;
        voCol.imageItem.height = voSrcBCol.imageItem.height;
        voCol.imageItem.left = voSrcBCol.imageItem.left;
        voCol.imageItem.top = voSrcBCol.imageItem.top;
        voCol.imageItem.href = voSrcBCol.imageItem.href;
        voCol.imageItem.target = voSrcBCol.imageItem.target;
        break;
    }

    voTrgBColsRow.addColumn(voCol);
    voTrgDst.addColumn(-1, voCol.datasetCol);
  }

  var vaTableName = voSrcDst.getCRUDTableNames().split(",");
  var vnTblCnt = vaTableName.length;
  var vsTableNm = null;
  var vnColCnt = null;
  var vaColName = null;
  var vsColNm = null;
  var vaCol = null;
  var vsPrefix = null;
  for(var i = 0; i < vnTblCnt; i++) {
    vsTableNm = vaTableName[i];
    if(vsTableNm == "") {
      break;
    }
    vsPrefix = voSrcDst.getPrefix(vsTableNm);
    voTrgDst.addCRUDTable(vsTableNm);
    voTrgDst.setPrefix(vsTableNm, vsPrefix);
    vaColName = voSrcDst.getPrimaryKeys(vsTableNm).split(",");
    vnColCnt = vaColName.length;
    for(var j = 0; j < vnColCnt; j++) {
      vsColNm = vaColName[j];
      if(vsColNm == "") break;
      vaCol = vsColNm.split(":");
      vsColNm = voTrgDst.addPrimaryKey(vsTableNm, vaCol[0], vaCol[1]);
    }

    vaColName = voSrcDst.getUpdateCols(vsTableNm).split(",");
    vnColCnt = vaColName.length;
    for(var j = 0; j < vnColCnt; j++) {
      vsColNm = vaColName[j];
      if(vsColNm == "") break;
      vaCol = vsColNm.split(":");
      vsColNm = voTrgDst.addUpdateColumn(vsTableNm, vaCol[0], vaCol[1]);
    }
  }
  this.orgEventList = {};
  for(var attr in poGrid) {
    if(attr.indexOf("onGridex") == 0) {
      var vsPageFunc = poGrid[attr].toString();
      if(this[attr] == null) {
        var vnStIdx = vsPageFunc.indexOf(".") + 1;
        var vnEdIdx = vsPageFunc.lastIndexOf("(");
        vsPageFunc = vsPageFunc.substring(vnStIdx, vnEdIdx);

        var vsFunc = poGrid.canvas.page[vsPageFunc].toString();
        var vnStIdx = vsFunc.indexOf("{") + 1;
        var vnEdIdx = vsFunc.lastIndexOf("}");
        vsFunc = vsFunc.substring(vnStIdx, vnEdIdx);
        eval("this.canvas.page[vsTrgFuncSource] = function(e) {" + vsFunc + "};");
        eval("this[attr] = this.canvas.page[vsTrgFuncSource];");
        this.orgEventList[attr] = null;
      } else {
        var vsTrgFuncSource = this[attr].toString();
        var vnStIdx = vsTrgFuncSource.indexOf(".") + 1;
        var vnEdIdx = vsTrgFuncSource.lastIndexOf("(");
        vsTrgFuncSource = vsTrgFuncSource.substring(vnStIdx, vnEdIdx);

        var vsTrgPageFunc = this.canvas.page[vsTrgFuncSource].toString();
        var vnStIdx = vsTrgPageFunc.indexOf("{") + 1;
        var vnEdIdx = vsTrgPageFunc.lastIndexOf("}");
        var vsTrgFunc = vsTrgPageFunc.substring(vnStIdx, vnEdIdx);

        var vnStIdx = vsPageFunc.indexOf(".") + 1;
        var vnEdIdx = vsPageFunc.lastIndexOf("(");
        vsPageFunc = vsPageFunc.substring(vnStIdx, vnEdIdx);

        var vsFunc = poGrid.canvas.page[vsPageFunc].toString();
        var vnStIdx = vsFunc.indexOf("{") + 1;
        var vnEdIdx = vsFunc.lastIndexOf("}");
        vsFunc = vsFunc.substring(vnStIdx, vnEdIdx);
        this.orgEventList[attr] = "this.canvas.page[\"" + vsTrgFuncSource + "\"] = function(e) {" + vsTrgFunc + "};";
        eval("this.canvas.page[vsTrgFuncSource] = function(e) {" + vsTrgFunc + vsFunc + "};");
      }
    }
  }

  this.refresh();
};

/**
 * GridEx에 대한 확장 이전의 상태를 저장한다.
 * @public
 */
eXria.controls.xhtml.GridEx.prototype.extendInit = function() {
  this.extendTableMap = {};
  this.extendHeadColMap = {};
  this.extendRestoreObj = {};
  var voDst = this.dataset;
  var vaCol = this.getHeadColumnList(1);
  var vsCol = null;
  var vnSize = vaCol.length;
  for(var j = 0; j < vnSize; j++) {
    vsCol = vaCol[j];
    this.extendHeadColMap[vsCol] = "";
  }

  var vaTbl = voDst.getCRUDTableNames().split(",");
  vnSize = vaTbl.length;
  var vsTbl = null;
  for(var j = 0; j < vnSize; j++) {
    vsTbl = vaTbl[j];
    if(vsTbl == "") break;
    this.extendTableMap[vsTbl] = "";
  }
};

/**
 * GridEx의 상태를 초기 extendInit 시점으로 되돌린다.
 * @public
 */
eXria.controls.xhtml.GridEx.prototype.extendReset = function() {
  var voDst = this.dataset;
  var vaCol = this.getHeadColumnList(1);
  var vsCol = null;
  var voCol = null;
  var vnSize = vaCol.length;
  for(var j = 0; j < vnSize; j++) {
    vsCol = vaCol[j];
    if(this.extendHeadColMap[vsCol] == null) {
      this.removeHeadColumn(vsCol);
      voCol = this.removeBodyColumn(null, vsCol);
      voDst.removeColumn(voCol.datasetCol);
    }
  }

  var vaTbl = voDst.getCRUDTableNames().split(",");
  vnSize = vaTbl.length;
  var vsTbl = null;
  for(var j = 0; j < vnSize; j++) {
    vsTbl = vaTbl[j];
    if(this.extendTableMap[vsTbl] == null) {
      voDst.removeCRUDTable(vsTbl);
    }
  }
  var voOrgEventList = this.orgEventList;
  for(var vsAttr in voOrgEventList) {
    if(voOrgEventList[vsAttr] == null) {
      this[vsAttr] = null;
    } else {
      eval(voOrgEventList[vsAttr]);
    }
  }
  this.refresh();
};

/**
 * 일반적으로 그리드와 연결된 데이타셋의 CUD내역을 submission객체를 통해 서버로 전달할 때 기본 테이블의 내용과 확장 테이블에 내용이 같이 보내지게됨.
 * 기본테이블의 CUD내역만을 submission을 통해 서버로 전달할 경우 setDstReqMode(true)를 호출 후 submission send를 호출하면됨.
 * 다시 기본테이블과 확장테이블의 CUD내역을 모두 보내고자 할 경우에는 setDstReqMode(false)를 호출하여 setDstReqMode(true) 상태를 해지시킴.
 * @param {Boolean} pbStandard true이면 원래 가지고 있던 영역에 대한 것만 보내는 모드로 변경하고 이 모드를 해제하는 경우에만 false로 지정
 * @public
 */
eXria.controls.xhtml.GridEx.prototype.extendSetReqMode = function(pbStandard) {
  var voDst = this.dataset;
  var voRestore = null;
  var vsTbl = null;
  var voObj = null;
  var vaCols = null;
  var vnSize = null;
  if(pbStandard == true) {
    voRestore = this.extendRestoreObj;
    var vaTbl = voDst.getCRUDTableNames();
    vaTbl = vaTbl.replace(/\,$/, "");
    vaTbl = vaTbl.split(",");
    vnSize = vaTbl.length;
    for(var i = 0; i < vnSize; i++) {
      vsTbl = vaTbl[i];
      if(this.extendTableMap[vsTbl] == null) {
        voObj = {};
        voObj.prefix = voDst.getPrefix(vsTbl);
        vaCols = voDst.getPrimaryKeys(vsTbl);
        vaCols = vaCols.replace(/\,$/, "");
        if(vaCols == "") vaCols = [];
        else vaCols = vaCols.split(",");
        voObj.primaryKeys = vaCols;

        vaCols = voDst.getUpdateCols(vsTbl);
        vaCols = vaCols.replace(/\,$/, "");
        if(vaCols == "") vaCols = [];
        else vaCols = vaCols.split(",");
        voObj.updateCols = vaCols;

        voRestore[vsTbl] = voObj;
        voDst.removeCRUDTable(vsTbl);
      }
    }
  } else {
    if(this.extendRestoreObj == null) return;
    voRestore = this.extendRestoreObj;
    for(vsTbl in voRestore) {
      voObj = voRestore[vsTbl];
      voDst.addCRUDTable(vsTbl);
      voDst.setPrefix(vsTbl, voObj.prefix);
      var vaPrimaryKeys = voObj.primaryKeys;
      vnSize = vaPrimaryKeys.length;
      for(var i = 0; i < vnSize; i++) {
        vaCols = vaPrimaryKeys[i].split(":");
        voDst.addPrimaryKey(vsTbl, vaCols[0], vaCols[1]);
      }
      var vaUpdateCols = voObj.updateCols;
      vnSize = vaUpdateCols.length;
      for(var i = 0; i < vnSize; i++) {
        vaCols = vaUpdateCols[i].split(":");
        voDst.addUpdateColumn(vsTbl, vaCols[0], vaCols[1]);
      }
    }
    delete this.extendRestoreObj;
  }
};
/**
 * Gantt chart 뷰 영역을 오늘 일자 기준으로 이동시켜주는 메소드.
 * @param {String} psIcon 오늘 일자 기준선 표시에 사용되는 이미지 경로(디폴트 값 : null)
 *
 */
eXria.controls.xhtml.GridEx.prototype.moveToToday = function(psIcon) {
  var vbRefresh = false;
  if(psIcon) {
    if(this.userAttr == null) this.userAttr = {};
//    if(this.userAttr.todayIcon == null) {
//      vbRefresh = true;
//    }
    this.userAttr.todayIcon = psIcon;
    vbRefresh = true;
  }

  if(vbRefresh) {
    this.refresh(null, true);
  } else {
    var voRow = this.getRowIndex(0);
    var vnLeftOffset = 0;
    var voCols = this.body.cols["left"];
    var vsGanttCol = null;
    if(voCols) {
      var voColumns = voCols.rows[0].columns;
      var vnSize = voColumns.length;
      var voColumn = null;
      for(var i = 0; i < vnSize; i++) {
        voColumn = voColumns[i];
        if(voColumn.visible != false) vnLeftOffset += voColumn.width;
      }
    }
    var vnLeftOffset2 = 0;
    voCols = this.body.cols["center"];
    if(voCols) {
      var voColumns = voCols.rows[0].columns;
      var vnSize = voColumns.length;
      var voColumn = null;
      for(var i = 0; i < vnSize; i++) {
        voColumn = voColumns[i];
        if(voColumn.type == "Gantt") {
          vsGanttCol = voColumn.colId;
          break;
        }
        if(voColumn.visible != false) vnLeftOffset2 += voColumns[i].width;
      }
    }
    var vnWidth = this.width;
    var vnScrollAreaHalfWidth = (vnWidth - vnLeftOffset) / 2;
    var voGanttCell = this.grid.GetCell(voRow, vsGanttCol);
    if(voGanttCell) {
      vaDiv = voGanttCell.getElementsByTagName("DIV");
      if(vaDiv.length == 0) {
        return;
      }
      var vnX = parseInt(vaDiv[vaDiv.length - 1].style.marginLeft) + vnLeftOffset2;
      this.grid.SetScrollLeft(vnX - vnScrollAreaHalfWidth);
    }
  }
};

/**
 * paging된 grid row 객체들을 배열에 담아 반환하는 메소드
 * @return paging된 row 저장 배열
 * @type Array(Object)
 */
eXria.controls.xhtml.GridEx.prototype.getPagingRows = function() {
  if(this.cfg.paging != "fast") return null;

  var vaDataRow = [];
  var vnIndex = 0;
  var vaDataRow = new Array();
  var voXB = this.grid.XB;
  function findLeafNode(poNode){
    var voNode = poNode;
    if(voNode.childNodes.length > 0){
      for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
        findLeafNode(r);
      }
    } else {
      if(voNode && voNode.nodeName && voNode.nodeName == "I") vaDataRow.push(voNode);
    }
  };
  if(voXB != undefined) findLeafNode(voXB);
  else return null;
  return vaDataRow;
};

/**
 * 현재 그리드 데이터의 정렬된 상태를 기준으로 instance row 데이타를 배열에 담아 반환하는 메소드
 * @return instance row가 그리드 row의 정렬 상태에 따라 순서대로 저장되는 배열
 * @type Array(eXria.data.xhtml.Node);
 */
eXria.controls.xhtml.GridEx.prototype.getSortedInstRows = function() {
  if(this.cfg.paging == "fast") return null;

  var vaDataRow = [];
  var vnIndex = 0;
  var voXB = this.grid.XB;
  function findLeafNode(poNode){
    var voNode = poNode;
    if(voNode.childNodes.length > 0){
      for(var r=poNode.firstChild,num=0;r;r=r.nextSibling,num++){
        findLeafNode(r);
      }
    } else {
      if(voNode && voNode.nodeName && voNode.nodeName == "I") vaDataRow.push(parseInt(voNode["InstIdx"]));
    }
  };
  if(voXB != undefined) findLeafNode(voXB);
  else return null;
  var voNodeList = this.data.getNodesetData2();
  var vnSize = vaDataRow.length;
  for(var i = 0; i < vnSize; i++) {
    vaDataRow[i] = voNodeList.item(vaDataRow[i]);
  }
  return vaDataRow;
};
/**
 * 사용자 이벤트 핸들러에 전달될 이벤트 객체 하위 속성 초기화 메소드
 * @member eXria.controls.xhtml.GridEx
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.resetEvent = function() {
    var voEvent = this.event;
    voEvent.object = null;
    voEvent.type = null;
    voEvent.row = null;
    voEvent.beforeRow = null;
    voEvent.colId = null;
    voEvent.beforeColId = null;
    voEvent.pagePos  = null;
    voEvent.x = null;
    voEvent.y = null;
    voEvent.key = null;
    voEvent.value = null;
    voEvent.e = null;
    voEvent.startcol = null;
    voEvent.pastedtext = null;
    voEvent.copiedRows = null;
};
/**
 * 데이타 세로 셀 병합 수행 메소드
 * @param {Number} pnFirst 셀 병합 시작 행 인덱스 번호
 * @param {pnLoop} pnLoop 셀 병합 종료 행 인덱스 번호(셀 병합에 포함되지 않음)
 * @param {eXria.data.xhtml.CollectionNode} poCollectionNode data collection node
 * @member eXria.controls.xhtml.GridEx
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setColsRowSpan = function(pnFirst, pnLoop, poCollectionNode) {
  this.mergeRowColsMap = {};
  this.rowMerged = false;
  var vaMergeRowCols = this.mergeRowCols;
  if(vaMergeRowCols && vaMergeRowCols.length > 0) {
    var voMergeRowColsMap = this.mergeRowColsMap;
    var vnSize = vaMergeRowCols.length;
    for(var i = 0; i < vnSize; i++) {
      voMergeRowColsMap[vaMergeRowCols[i]] = {};
    }
    this.setColRowSpan(pnFirst, pnLoop, poCollectionNode, vaMergeRowCols, 0);
  }
};
/**
 * 컬럼별 데이타 세로 셀 병합 수행 메소드.
 * 다중 컬럼 셀 병합을 위해 내부적으로 다음 컬럼을 대상으로 메소드 재귀호출.
 * @param {Number} pnFirst 셀 병합 시작 행 인덱스 번호
 * @param {pnLoop} pnLoop 셀 병합 종료 행 인덱스 번호(셀 병합에 포함되지 않음)
 * @param {eXria.data.xhtml.CollectionNode} poCollectionNode data collection node
 * @param {Array(String)} paMergeRowCols 셀 병합 컴럼 명세 저장 배열
 * @param {Array(String)} paMergeRowCols 셀 병합 수행 컬럼의 셀 병합 컬럼 명세 배열 내의 인덱스
 * @member eXria.controls.xhtml.GridEx
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.setColRowSpan = function(pnFirst, pnLoop, poCollectionNode, paMergeRowCols, pnColIdx) {
  var voMergeRowColsMap = this.mergeRowColsMap;
  var voColumn = this.getBodyColumn(null, paMergeRowCols[pnColIdx]);
  var voMergeRowColIdxMap = voMergeRowColsMap[voColumn.colId];
  var voValue, voPrevVal, vnRowSpan, j;
    
  for( var i = pnFirst; i < pnLoop; i++) {
    voMapNode = this.funcMapNode(poCollectionNode, i);
    voMergeRowColIdxMap = voMergeRowColsMap[voColumn.colId]
    vsRef = voColumn.ref;
    if (vsRef) {
      vaPath = vsRef.split("/");
      vsRef = vaPath[vaPath.length - 1];
    }
    if (vsRef != null)  voValue = this.funcGet(voMapNode, vsRef);
    voPrevVal = voMergeRowColIdxMap[(i - 1) + "_val"];
    voMergeRowColIdxMap[i + "_val"] = voValue;
    if(i != pnFirst && voPrevVal != voValue) {
      j = i - 1;
      vnRowSpan = 1;
      while(j > pnFirst) {
        if(voMergeRowColIdxMap[j + "_val"] == voMergeRowColIdxMap[(j - 1) + "_val"]) {
          vnRowSpan++;
          voMergeRowColIdxMap[j + ""] = 0;
          this.rowMerged = true;
        }
        j--;
      }
      voMergeRowColIdxMap[j + ""] = this.mergeRowCols ? vnRowSpan + 0.5 : vnRowSpan ;
      if(pnColIdx < paMergeRowCols.length - 1) this.setColRowSpan(j, j + vnRowSpan, poCollectionNode, paMergeRowCols, pnColIdx + 1);
      pnFirst = j + vnRowSpan;
    }
    if(i == pnLoop - 1) {
      j = i;
      vnRowSpan = 1;
      while(j > pnFirst) {
        if(voMergeRowColIdxMap[j + "_val"] == voMergeRowColIdxMap[(j - 1) + "_val"]) {
          vnRowSpan++;
          voMergeRowColIdxMap[j + ""] = 0;
          this.rowMerged = true;
        }
        j--;
      }
      voMergeRowColIdxMap[j + ""] = this.mergeRowCols ? vnRowSpan + 0.5 : vnRowSpan;
      if(pnColIdx < paMergeRowCols.length - 1) this.setColRowSpan(j, j + vnRowSpan, poCollectionNode, paMergeRowCols, pnColIdx + 1);
    }
  }
};
/**
 * 트리그리드 데이타 행 생성 메소드
 * @param {Number} pnIdx 데이타 리스트 내에 데이타 인덱스 번호
 * @param {Number} pnId id 컬럼에 설정될 순번
 * @param {eXria.data.xhtml.CollectionNode} poCollectionNode 생성하고자 하는 문자열의 데이타 행을 포함하는 데이타 리스트
 * @param {eXria.controls.xhtml.Columns} poCols 헤더 컬럼 추출을 위한 컬럼 그룹 객체
 * @param {eXria.controls.xhtml.GridEx.Cfg} poCfg 그리드 Cfg 참조 객체
 * @param {Object} poMergeRowColsMap row merge를 수행할 컬럼 명세 저장 json 객체
 * @param {Object} poChildRef Child Data Row의 컬럼별 data ref 저장 json 객체
 * @param {Number} pnChildIdx Child Data Rows 내에서의 row 인덱스
 * @member eXria.controls.xhtml.GridEx
 * @private
 */
eXria.controls.xhtml.GridEx.prototype.getTRowStr = function(pnIdx, pnId, poCollectionNode, poCols, poCfg, poMergeRowColsMap, poChildRef, pnChildIdx) {
    var vsRow = "<I";
    var vsBg = null;
    var voDataSet = this.dataset;
    var voDataSetHeader = (voDataSet) ? voDataSet.getHeader() : null; 
    var vsTmpColRef = null;
    if(this.oddRowBg || this.evenRowBg) {
      if(pnIdx % 2 == 1) vsBg = this.evenRowBg;
      else vsBg = this.oddRowBg;
      if(vsBg) vsRow += "  Color=\"" + vsBg + "\"";
    }
    if(!poChildRef)  vsRow += " InstIdx='" + pnIdx + "'";
    else vsRow += " ChildIdx='" + pnChildIdx + "'";
    var voMapNode = this.funcMapNode(poCollectionNode, pnIdx);
    var vsStatus = this.funcStatus(voMapNode, pnIdx);
    var voRow, voValue, voColumn, vsColumn, vsRef, vsSpan, vaPath, voMergeRowColIdxMap, vsExtAttrs;
    if(vsStatus == null) vsStatus = "";
    vsRow += " InstStatus='" + vsStatus + "'";
    if(vsStatus.indexOf("R") != -1) return "";
    if(poCfg.editing != null) vsRow = vsRow + " CanEdit='" + poCfg.editing + "'";
    if(vsStatus.indexOf("I") != -1) vsRow += " Added='1'";
    if(vsStatus.indexOf("U") != -1) vsRow += " Changed='1'";
    if(vsStatus.indexOf("D") != -1) vsRow += " Deleted='1'";
    for ( var i = 0; i < 3; i++) {
      if (poCols[i]) {
        if (poCols[i].rows.length > 0) {
          voRow = poCols[i].rows[0];
          if (i == 1) {
            if (voRow.id != null) vsRow = vsRow + " id='" + voRow.id + "'";
          }
          for ( var k = 0; k < voRow.columns.length; k++) {
            voColumn = voRow.columns[k];
            voMergeRowColIdxMap = poMergeRowColsMap[voColumn.colId]
            if(voColumn.colId == "id") { // id 칼럼에 대한 처리
              if(poCfg.ganttIdColumn) {  // id 칼럼이 Gantt에서 지정된 칼럼일 경우
                vsRef = this.funcRef(voColumn);
                if (vsRef != null) voValue = this.funcGet(voMapNode, vsRef);
                voValue = this.getXml(voValue, 2);
                vsRow = vsRow + " id=" + voValue;
              } else { // id 칼럼이 일반적인 형태로 지정된 경우
                if(poChildRef) vsRow = vsRow + " id='" + poCfg.idPrefix + this.funcRowId(voMapNode, pnId) + poCfg.idPostfix + "_" + (pnChildIdx + 1) + "'";
                else vsRow = vsRow + " id='" + poCfg.idPrefix + this.funcRowId(voMapNode, pnId) + poCfg.idPostfix + "'";
                
                if(!!voDataSet && poCfg.paging === "none" && !vsStatus){
                  vsTmpColRef = "__id" + poCfg.idPrefix + poCfg.idPostfix;
                  if(!voDataSetHeader.contains(vsTmpColRef)) voDataSet.appendColumn(vsTmpColRef);
                  voDataSet.simpleSet(pnIdx, vsTmpColRef, this.funcRowId(voMapNode, pnId));
                  voColumn.datasetCol = vsTmpColRef;
                }
              }
            } else {
              vsRef =  this.funcRef(voColumn);
              if(poChildRef) {
                vsRef = poChildRef[voColumn.colId];
              }
              if (vsRef) {
                vsRef = vsRef.split(",");
                vsSpan = vsRef[1];
                vaPath = vsRef[0].split("/");
                vsRef = vaPath[vaPath.length - 1];
              }
              if (vsRef != null)  voValue = this.funcGet(voMapNode, vsRef);

              if (voValue != null && voValue != "") {
                switch (voColumn.type) {
                case "Enum":
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "=" + voValue;
                  vsColumn = vsColumn + " " + voColumn.colId + "IconAlign='Right'";
                  break;
                case "Bool":
                case "Number":
                case "Int":
                case "Float":
                  voValue = eval(voValue);
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "=" + voValue;
                  break;
                case "CheckBox":
                case "Radio":
                  voValue = this.convertValueTGrid(voColumn, voValue);
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "=" + voValue;
                  break;
                case "Select":
                  if (voColumn.selectionDataType == "Numeric") voValue = eval(voValue);
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "=" + voValue;
                  break;
                case "Pass":
                case "Text":
                case "Lines":
                case "Html":
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "=" + voValue;
                  break;
                // DateMask 추가코드
                case "Date":
                  voValue = this.addSeparator(voValue, 2, null, voColumn.colId)
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "=" + voValue;
                  break;
                case "Button":
                  voValue = this.getXml(voValue, 2);
                  vsColumn = " " + voColumn.colId + "Caption=" + voValue;
                  vsRef = voColumn.buttonItem.width;
                  if (vsRef) {
                    if (isNaN(vsRef)) {
                      vaPath = vsRef.split("/");
                      vsRef = vaPath[vaPath.length - 1];
                      voValue = this.funcGet(voMapNode, vsRef);
                      voValue = this.getXml(voValue, 2);
                    } else {
                      voValue = this.getXml(vsRef, 2);
                    }
                    if (!voValue) voValue = "";
                    vsColumn = vsColumn + " " + voColumn.colId + "Width=" + voValue;
                  } else {
                    var vnButtonWidth = voColumn.width;
                    if(vnButtonWidth > 2) vnButtonWidth = vnButtonWidth - 2;
                    voValue = this.getXml(vnButtonWidth, 2);
                    vsColumn = vsColumn + " " + voColumn.colId + "Width=" + voValue;
                  }
                  vsRef = voColumn.buttonItem.height;
                  if (vsRef) {
                    if (isNaN(vsRef)) {
                      vaPath = vsRef.split("/");
                      vsRef = vaPath[vaPath.length - 1];
                      voValue = this.funcGet(voMapNode, vsRef);
                      voValue = this.getXml(voValue, 2);
                    } else {
                      voValue = this.getXml(vsRef, 2);
                    }
                    if (!voValue) voValue = "";
                    vsColumn = vsColumn + " " + voColumn.colId + "Height=" + voValue;
                  }
                  vsRef = voColumn.buttonItem.icon;
                  if (vsRef) {
                    if (isNaN(vsRef)) {
                      vaPath = vsRef.split("/");
                      vsRef = vaPath[vaPath.length - 1];
                      voValue = this.funcGet(voMapNode, vsRef);
                      voValue = this.getXml(voValue, 2);
                    } else {
                      voValue = this.getXml(vsRef, 2);
                    }
                    if (!voValue) voValue = "";
                    vsColumn = vsColumn + " " + voColumn.colId + "Icon=" + voValue;
                  }
                  vsRef = voColumn.buttonItem.iconChecked;
                  if (vsRef) {
                    if (isNaN(vsRef)) {
                      vaPath = vsRef.split("/");
                      vsRef = vaPath[vaPath.length - 1];
                      voValue = this.funcGet(voMapNode, vsRef);
                      voValue = this.getXml(voValue, 2);
                    } else {
                      voValue = this.getXml(vsRef, 2);
                    }
                    if (!voValue) voValue = "";
                    vsColumn = vsColumn + " " + voColumn.colId + "IconChecked=" + voValue;
                  }
                  vsRef = voColumn.buttonItem.tooltip;
                  if (vsRef) {
                    if(isNaN(vsRef)) {
                      vaPath = vsRef.split("/");
                      vsRef = vaPath[vaPath.length - 1];
                      voValue = this.funcGet(voMapNode, vsRef);
                      voValue = this.getXml(voValue, 2);
                    } else {
                      voValue = this.getXml(vsRef, 2);
                    }
                    if (!voValue) voValue = "";
                      vsColumn = vsColumn + " " + voColumn.colId + "ToolTip=" + voValue;
                  }
                  vsRef = voColumn.buttonItem.tooltipChecked;
                  if (vsRef) {
                    if(isNaN(vsRef)) {
                      vaPath = vsRef.split("/");
                      vsRef = vaPath[vaPath.length - 1];
                      voValue = this.funcGet(voMapNode, vsRef);
                      voValue = this.getXml(voValue, 2);
                    } else {
                      voValue = this.getXml(vsRef, 2);
                    }
                    if (!voValue) voValue = "";
                    vsColumn = vsColumn + " " + voColumn.colId + "ToolTipChecked=" + voValue;
                  }
                  break;
                case "Image":
                  voHrefValue = this.getRefValue(voColumn.imageItem.href, voMapNode, pnIdx);
                  voTargetValue = this.getRefValue(voColumn.imageItem.target, voMapNode, pnIdx);
                  voWidthValue = this.getRefValue(voColumn.imageItem.width, voMapNode, pnIdx);
                  //voHeightValue = this.getRefValue(voColumn.imageItem.height, voMapNode, pnIdx);
                  if(voColumn.imageItem.height == "" || voColumn.imageItem.height === null) {
                    if(this.body.cols && this.body.cols["center"] && this.body.cols["center"].rows)
                      voHeightValue = this.body.cols["center"].rows[0].height;
                  }
                  else
                    voHeightValue = this.getRefValue(voColumn.imageItem.height, voMapNode, pnIdx);

                  voLeftValue = this.getRefValue(voColumn.imageItem.left, voMapNode, pnIdx);
                  voTopValue = this.getRefValue(voColumn.imageItem.top, voMapNode, pnIdx);
                  if(voValue != null) {
                    var vaStrBuf = [];
                    vaStrBuf.push(" ");
                    vaStrBuf.push(voColumn.colId);
                    vaStrBuf.push("=\"|");
                    vaStrBuf.push(voHrefValue);
                    vaStrBuf.push("|");
                    vaStrBuf.push(voWidthValue);
                    vaStrBuf.push("|");
                    vaStrBuf.push(voHeightValue);
                    vaStrBuf.push("|");
                    vaStrBuf.push(voLeftValue);
                    vaStrBuf.push("|");
                    vaStrBuf.push(voTopValue);
                    vaStrBuf.push("|");
                    vaStrBuf.push(voTargetValue);
                    vaStrBuf.push("\"");
                    vsColumn = vaStrBuf.join("");
                  }
                  break;
                }
                voValue = null;
              } else {
                vsColumn = " " + voColumn.colId + "=\"\"";
                if(voColumn.type == "Gantt" && voColumn.ganttFlags && i == pnIdx) {
                  vsColumn += " " + voColumn.colId + "GanttFlags='" + voColumn.ganttFlags + "'";
                  vsColumn += " " + voColumn.colId + "GanttFlagTexts='" + voColumn.ganttFlagTexts + "'";
                  vsColumn += " " + voColumn.colId + "GanttFlagIcons='" + voColumn.ganttFlagIcons + "'";
                } else if(voColumn.type == "Enum") {
                  vsColumn = vsColumn + " " + voColumn.colId + "IconAlign='Right'";
                }
              }

              if(voColumn.rightButton) {
                var vsRButtonType = voColumn.rightButton.type;
                if(voColumn.rightButton.ref) {  // ref가 있는 경우 그 경로에 해당하는 값으로 설정
                  if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE && i == 0) {
                    var vaDataList = this.data.getNodesetStr(voColumn.rightButton.instanceId, voColumn.rightButton.ref);
                    if(vaDataList) vaDataList = eval(vaDataList);
                    voColumn.rightButton.dataList = vaDataList;
                  }
                  vsRButtonValue = this.funcRefVal(voColumn.rightButton.ref, voMapNode, pnIdx, voColumn.rightButton.instanceId);
                  if(vsRButtonType == "Image") {
                    if(vsRButtonValue) vsColumn = vsColumn + " " + voColumn.colId + "Button='" + vsRButtonValue + "'";
                  } else if(vsRButtonType == "Normal") {
                    if(vsRButtonValue) vsColumn = vsColumn + " " + voColumn.colId + "Button='Button' " + voColumn.colId + "ButtonText='" + vsRButtonValue + "'";
                  }
                } else {                        // ref가 없는 경우 value 값으로 설정
                  if(vsRButtonType == "Image") {
                    vsRButtonValue = eXria.controls.xhtml.Util.getImagePath(voColumn.rightButton.value, this.window);
                    if(vsRButtonValue) vsColumn = vsColumn + " " + voColumn.colId + "Button='" + vsRButtonValue + "'";
                  } else if(vsRButtonType == "Normal") {
                    vsRButtonValue = voColumn.rightButton.value;
                    if(vsRButtonValue) vsColumn = vsColumn + " " + voColumn.colId + "Button='Button' " + voColumn.colId + "ButtonText='" + vsRButtonValue + "'";
                  }
                }
              }
              if(voMergeRowColIdxMap && voMergeRowColIdxMap[pnIdx] > 1) {
                vsColumn = vsColumn + " " + voColumn.colId + "RowSpan=\"" + voMergeRowColIdxMap[pnIdx] + "\"";
              }
              if(!!vsSpan) vsColumn = vsColumn + " " + voColumn.colId + "Span=\"" + vsSpan + "\"";
              vsRow = vsRow + vsColumn;
            }
          }
        }
      }
    }
    if (voRow.height != null) {
      vsRow = vsRow + " Height='" + voRow.height + "'";
      if(this.rowMaxHeight == null) this.rowMaxHeight = voRow.height;
    }
    if(this.rowMaxHeight != null) {
      vsRow = vsRow + " MaxHeight='" + this.rowMaxHeight + "'";
      vsRow = vsRow + " MaxEditHeight='" + this.rowMaxHeight + "'";
    }
    var vnRowIdx = pnIdx;
    if(this.datasetId != null) vnRowIdx--;
    if(!!this.showTooltip) {
      var vaShowTooltip = this.showTooltip;
      for(var z=0, vnRowCnt = vaShowTooltip.length; z < vnRowCnt; z++){
        vsDsColId = vaShowTooltip[z]['dsColId'];
        vsRow = vsRow + " " + vaShowTooltip[z]['colId'] + "ShowHint='0' " + vaShowTooltip[z]['colId'] + "Tip='" + this.funcGet(this.funcMapNode(poCollectionNode, vnRowIdx), vsDsColId).simpleReplace('\n','<br/>') + "'";
      }
    }
    if(this.datasetId && this.makeRowColorData(pnIdx) != null) vsRow = vsRow + this.makeRowColorData(pnIdx);
    //로우별 스타일 정보 반영
    vsExtAttrs = this.setRowMetaExtAttrs(vnRowIdx, vsRow, poCollectionNode);
    
    return vsExtAttrs;
};