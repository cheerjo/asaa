/** 캔버스나 컨트롤에 덮어씌워져 window이벤트를 대신 처리하기 위한 오브젝트 클래스.<br>
 * @version 1.0
 * @param {eXria.form.xhtml.Canvas|eXria.controls.xhtml.UIControl} poParent GlassPane적용 대상
 * @return 새로운 eXria.controls.xhtml.GlassPane 객체
 * @type eXria.controls.xhtml.GlassPane
 * @constructor
 */
eXria.controls.xhtml.GlassPane = function(poParent) {
  /**
   * GlassPane이 덧씌워질 Canvas혹은 컨트롤
   * @type eXria.controls.xhtml.Canvas|eXria.controls.xhtml.UIControl
   */
  this.parent = poParent;
  /**
   * 실체화 객체 생성에 사용되는 document객체 저장
   * @type HTMLDocument
   */
  this.document = null;
  /**
   * 실체화 객체의 배경색 설정 값
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 실체화 객체의 배경 투명도 설정 값
   * @type Number
   */
  this.opacity = null;
  /**
   * 컨트롤의 실체화 객체에 반영될 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};
/**
 * Ctrl(실체화 컨트롤)을 생성한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치할 Doucment에 대한 참조
 * @return 실체화 컨트롤에 대한 참조
 * @type object
 */
eXria.controls.xhtml.GlassPane.prototype.create = function(poDocument) {
  var voCtrl = this.createCtrl(poDocument);
  this.setDefaults(voCtrl, poDocument);
  this.setAttrs(voCtrl, poDocument);
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * Main Ctrl 생성.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return Div 객체
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.GlassPane.prototype.createCtrl = function(poDocument) {
  var voParent = this.parent;
  if(poDocument == null) poDocument = voParent.document;
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * 속성값 설정.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.GlassPane.prototype.setDefaults = function(poCtrl, poDocument) {
  if(this.backgroundColor == null) this.backgroundColor = "#FFFFFF";
  if(this.opacity == null) this.opacity = 0;
};
/**
 * 속성값을 실체화 컨트롤에 반영
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.GlassPane.prototype.setAttrs = function(poCtrl, poDocument) {
  var voParent = this.parent;
  var voDf = this.df;
  var voPage = voParent.page || voParent.window.page;

  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;position:absolute;border-style:none;background-color:" + this.backgroundColor + ";");
  vaCssStrBuf.push("position:absolute;");
//  var vnZIndex = voParent.zIndex;
//  if(vnZIndex == null || vnZIndex == "") vnZIndex = 0;
//  vnZIndex++;
  var vnZIndex = 1000000;
  vaCssStrBuf.push("z-index:");
  vaCssStrBuf.push(vnZIndex + ";");
  vaCssStrBuf.push("left:");
  vaCssStrBuf.push(voParent.left + "px;");
  vaCssStrBuf.push("top:");
  vaCssStrBuf.push(voParent.top + "px;");
  vaCssStrBuf.push("width:");
  vaCssStrBuf.push(voParent.width + "px;");
  vaCssStrBuf.push("height:");
  vaCssStrBuf.push(voParent.height + "px;");
  if(voPage.metadata.browser.ie > 0) {
    vaCssStrBuf.push("filter:alpha(opacity=" + this.opacity + ");");
  } else {
    vaCssStrBuf.push("opacity:" + (this.opacity / 100) + ";");
  }
  poCtrl.style.cssText = vaCssStrBuf.join("");
  vaCssStrBuf = null;
};
/**
 * GlassPane에 발생된 이벤트로 이벤트가 전달될 컨트롤을 찾는 메소드
 * @param {eXria.event.Event} poEvent 컨트롤을 검색하기 위한 eXria 이벤트 객체
 * @return 이벤트가 전달될 컨트롤
 * @type eXria.form.xhtml.Canvas|eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.GlassPane.prototype.getControlByEvent = function(poEvent) {
  var voParent = this.parent;
  var voRet = null;
  var voControl = null;
  var voCollection = null;
  if(voParent.controls) {
    if(voParent.controls.getValueCollection) voCollection = voParent.controls.getValueCollection();
    else voCollection = voParent.controls;
  } else {
    voCollection = new eXria.data.ArrayCollection();
    voCollection.add(voParent);
  }
  var vnSize = voCollection.size();
  var vnX = poEvent.clientX;
  var vnY = poEvent.clientY;
  var voPage = null;
  for(var i = 0; i < vnSize; i++) {
    voControl = voCollection.get(i);
    if((vnX >= voControl.left && vnX <= voControl.left + voControl.width) &&
       (vnY >= voControl.top && vnY <= voControl.top + voControl.height)) {
      voRet = voControl;
      if(voControl.toString() == "SubPage" && (voPage = voControl.getPage(this.document))) {
        vnX -= voControl.left;
        vnY -= voControl.top;
        poEvent.clientX = vnX;
        poEvent.clientY = vnY;
        voRet = this.getControlByPos(vnX, vnY, voPage.canvas, poEvent);
      } else if(voControl.controls) {
        vnX -= voControl.left;
        vnY -= voControl.top;
        poEvent.clientX = vnX;
        poEvent.clientY = vnY;
        voRet = this.getControlByPos(vnX, vnY, voControl, poEvent);
      } else if(voControl.toString() == "Tab" || voControl.toString() == "SlideTab") {
        vnX -= voControl.left;
        vnY -= voControl.top;
        var voTagPage = voControl.getPage(voControl.selectedIndex);
        if(voTagPage && (vnX >= voTagPage.left && vnX <= voTagPage.left + voTagPage.width) &&
           (vnY >= voTagPage.top && vnY <= voTagPage.top + voTagPage.height)) {
          vnX -= voTagPage.left;
          vnY -= voTagPage.top;
          poEvent.clientX = vnX;
          poEvent.clientY = vnY;
          voRet = this.getControlByPos(vnX, vnY, voTagPage, poEvent);
        }
      }
      break;
    }
  }
  if(voRet == null) voRet = voParent;
  return voRet;
};
/**
 * x,y좌표값을 이용하여 컨트롤을 찾는 메소드
 * @param {Number} pnX 컨트롤 검색에 이용될 x좌표
 * @param {Number} pnY 컨트롤 검색에 이용될 y좌표
 * @param {eXria.event.Event} poEvent 컨트롤을 검색하기 위한 eXria 이벤트 객체
 * @return 검색된 컨트롤
 * @type eXria.form.xhtml.Canvas|eXria.controls.xhtml.UIControl
 * @private
 */
eXria.controls.xhtml.GlassPane.prototype.getControlByPos = function(pnX, pnY, poContainer, poEvent) {
  var voRet = null;
  var voControl = null;
  var voCollection = poContainer.controls;
  if(voCollection.getValueCollection) voCollection = voCollection.getValueCollection();

  var vnSize = voCollection.size();
  for(var i = 0; i < vnSize; i++) {
    voControl = voCollection.get(i);
    if((pnX >= voControl.left && pnX <= voControl.left + voControl.width) &&
       (pnY >= voControl.top && pnY <= voControl.top + voControl.height)) {
      voRet = voControl;
      if(voControl.toString() == "SubPage" && (voPage = voControl.getPage(this.document))) {
        pnX -= voControl.left;
        pnY -= voControl.top;
        poEvent.clientX = pnX;
        poEvent.clientY = pnY;
        voRet = this.getControlByPos(pnX, pnY, voPage.canvas, poEvent);
      } else if(voControl.controls) {
        pnX -= voControl.left;
        pnY -= voControl.top;
        poEvent.clientX = pnX;
        poEvent.clientY = pnY;
        voRet = this.getControlByPos(pnX, pnY, voControl, poEvent);
      } else if(voControl.toString() == "Tab" || voControl.toString() == "SlideTab") {
        pnX -= voControl.left;
        pnY -= voControl.top;
        var voTagPage = voControl.getPage(voControl.selectedIndex);
        if(voTagPage && (pnX >= voTagPage.left && pnX <= voTagPage.left + voTagPage.width) &&
           (pnY >= voTagPage.top && pnY <= voTagPage.top + voTagPage.height)) {
          pnX -= voTagPage.left;
          pnY -= voTagPage.top;
          poEvent.clientX = pnX;
          poEvent.clientY = pnY;
          voRet = this.getControlByPos(pnX, pnY, voTagPage, poEvent);
        }
      }
      break;
    }
  }
  if(voRet == null) voRet = poContainer;
  return voRet;
};
/**
 * GlassPane 실체화 객체를 제거하기 위한 메소드.
 */
eXria.controls.xhtml.GlassPane.prototype.removeCtrl = function() {
  var voParentNode = this.ctrl.parentNode;
  this.ctrl.style.display = "none";
  if(voParentNode) voParentNode.removeChild(this.ctrl);
};