/**
 * @fileoverview
 * Concreate xhtml EditMask(XHTML EditMask 컨트롤)
 * @author 조영진 , 이종녕
 */

/**
 * @class maskType에 알맞은 입력값을 정의된 maskFormat으로 변경해 주는 입력필드입니다.<br />
 * XHTML EditMask Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.EditMask 객체
 * @type eXria.controls.xhtml.EditMask
 * @constructor
 * @base eXria.controls.xhtml.InputCommon
 */
eXria.controls.xhtml.EditMask = function(psId, pnLeft, pnTop, pnWidth, pnHeight){

  pnLeft =  pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  eXria.controls.xhtml.InputCommon.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /////////////////////////////////////////////////////////////////////////////
  ////속성
  /**
   * 읽기 전용 여부.
   * @type String
   */
  this.readOnly = null;
  /**
   * 컨트롤에 적용될 마스크 종류 구분 문자열("string" | "date" | "number")
   * @type String
   */
  this.maskType = null;
  /**
   * 문자열 표현 마스크.
   * @type String
   */
  this.mask = null;
  /**
   *문자열 표현 마스크를 제외한 값
   *@type Object
   *@private
   */
  this.nonMask = []; //d
  /**
   * 딜리트 상태인지의 여부.
   * @type boolean
   * @ignore
   */
  this.vbCheck = false;
  /**
   * 마스크 프롬프트 문자.
   * @type String
   */
  this.maskPrompt = null;
  /**
   * 스핀 컨트롤 영역의 가로 길이(px).
   * @type Number
   */
  this.spinWidth = 20;
  /**
   * 이미지가 위치한 영역의 가로 길이.
   * @private
   * @type Number
   */
  this.imgAreaWidth = 20;
  /**
   * calendar를 실행시키는 이미지의 url.
   * @type String
   */
  this.calendarImageUrl = null;
  /**
   * 하위 컨트롤인 calendar에 대한 참조.
   * @type eXria.controls.xhtml.Calendar
   */
  //this.calendar = new eXria.controls.xhtml.Calendar(psId+"calendar",pnWidth,pnHeight,200,200);
  this.calendar = null;
  /**
   * calendar 컨트롤의 활성화 여부.
   * @type Boolean
   */
  this.calendarEnable = null;
  /**
   * 스핀 버튼을 클릭시의 증가치.
   * @type Number
   */
  this.spinNum = null;
  /**
   * 스핀 버튼의 사용 여부.
   * @type String
   */
  this.useSpin = null;
  /**
   * @type Number
   * @private
   */
  this.selectionSize = 0;
  /**
   * #,x 가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noMaskVal = /[^\#Xx*Aa!^Ww90]/gi;
  /**
   * 숫자가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noDigits = /[^\d]/gi;
  /**
   * 문자가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noString = /[^A-Za-z]/gi;
  /**
   * 문자, 숫자가 아닌 정규식 표현.
   * @type RegExp
   * @private
   */
  this.noGeneric = /[^A-Za-z0-9]/gi;
  /**
   * 공백 문자 정규식 표현.
   * @type RegExp
   * @private
   */
  this.blank = /\s/g;
  /**
   * YYMMDD의 정규식 표현.
   * @type RegExp
   * @private
   */
  this.regDateMask = /[YMDhmis]/g;
  /**
   * 버튼의 커서 모양.
   * @type String
   */
  this.btnCursor = null;
  /**
   * 커서 위치 저장 변수
   * @type Number
   * @private
   */
  this.cursorPosition = -1;
  /**
   * 이벤트 키값 상수 정의 오브젝트.
   * @type Object
   * @private
   */
  this.constKey = {
    SHIFT: 16,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    ENTER: 13,
    TAB: 9,
    BACKSPACE: 8,
    DEL: 46,
    HAN_ENG: 21,
    UP : 38,
    DOWN : 40
  };
  /**
   * 유효값 체크유무
   * @type string
   * @private
   */
  this.vbValidation = "nonChecked";
  /**
   * 텍스트가 전체 select 되었는지 여부
   * @type Boolean
   * @private
   */
  this.vbSelectAll = false;

  /**
   * 사용자정의 Max Byte 길이
   * @type Number
   */
  this.maxByteLenth = null;
  /**
   * 사용자정의 Min Byte 길이
   * @type Number
   */
  this.minByteLenth = null;

  /**
   *  readOnly와 Calendar의 동기화
   */
  this.readOnlyWithCalendar = null;

  /**
   * 시분초 입력영역 hide 처리
   * @type Boolean
   * @private
   */
  this.noUseHMS = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.InputCommon, eXria.controls.xhtml.EditMask);

//////////////////////////////////////////////////////////////////
//// 메소드
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.createSubCtrl = function(poCtrl,poDocument) {
  this.spinWidth = this.getAttrValue("spinWidth", this.spinWidth);
  if(this.calendar == null) this.calendar = new eXria.controls.xhtml.Calendar(this.id + "calendar", this.width, this.height, 180, 180, true);
//  this.calendar = new eXria.controls.xhtml.Calendar(this.id + "calendar", this.width, this.height, 200, 200);
  var voCalendar = this.calendar;
  voCalendar.canvas = this.canvas;
  voCalendar.window = this.window;
  voCalendar.document = this.document;
};

eXria.controls.xhtml.EditMask.prototype.setTemplate = function(poCtrl,poDocument) {

  this.calendar.defaultFileName = this.getAttrValue("defaultFileName", this.defaultFileName);
  this.calendar.textFileName = this.getAttrValue("textFileName", this.textFileName);
  this.calendar.loadDefaultSpce();

  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
//  vaTemplate.push("<table cellPadding='0px' cellSpacing='0px' style='position:absolute; overflow:hidden; left:0px; top:0px'><tbody><tr>");
//  vaTemplate.push("<td ");
//  vaTemplate.push("@attStrBuf"); // 2 - td attribute
//  vaTemplate.push(" style='");
//  vaTemplate.push("@cssStrBuf"); // 4 - td style
//  vaTemplate.push("'>");
  vaTemplate.push("<input id='" + this.id + "_text' type='text' class='" + vsClass + "' ");
  vaTemplate.push("@attStrBuf"); // 0 - input attribute
  vaTemplate.push(" style=\"");
  vaTemplate.push("@cssStrBuf"); // 1 - input style
  vaTemplate.push("\"/>");
//  vaTemplate.push("</td></tr></tbody></table>");

  vaTemplate.push("<div style=\"");
  vaTemplate.push("@cssStrBuf"); // 2 - spin div style
  vaTemplate.push("\">");
  vaTemplate.push("<input id='" + this.id + "_btn_up' type='button' value='▲' style=\"");
  vaTemplate.push("@cssStrBuf"); // 3
  vaTemplate.push("\" onclick=\"");
  vaTemplate.push(this.getEHandler(this.id, "increaseNum"));
  vaTemplate.push("\">");
  vaTemplate.push("<input id='" + this.id + "_btn_down' type='button' value='▼' style=\"");
  vaTemplate.push("@cssStrBuf"); // 4
  vaTemplate.push("\" onclick=\"");
  vaTemplate.push(this.getEHandler(this.id, "decreaseNum"));
  vaTemplate.push("\">");
  vaTemplate.push("</div>");

  vaTemplate.push("<div style=\"");
  vaTemplate.push("@cssStrBuf"); // 5 - img div style
  vaTemplate.push("\">");
  vaTemplate.push("<table style='width:100%;height:100%' cellspacing='0'><tbody><tr><td style=\"text-align:center;vertical-align:middle;\">");
  vaTemplate.push("<img id='" + this.id + "_icon' ");
  vaTemplate.push("@attStrBuf"); // 6 - img attribute
  vaTemplate.push("style=\"border-color:red;border-style:none;border-width:1px;width:16px;height:16px;\"/>");
  vaTemplate.push("</td></tr></tbody></table></div>");

  vaTemplate.push("<span class='" + vsClass + "'" + " style=\"");
  vaTemplate.push("@cssStrBuf"); //7
  vaTemplate.push("\"/>");

  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};

eXria.controls.xhtml.EditMask.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;


  this.noUseHMS = this.getAttrValue("noUseHMS", this.noUseHMS);
  this.verticalAlign = this.getAttrValue("verticalAlign", this.verticalAlign);
  this.value = this.getAttrValue("value", this.value);
  this.readOnly = this.getAttrValue("readonly", this.readOnly);
  this.formatType = this.getAttrValue("formatType", this.formatType);
  this.format = this.getAttrValue("format", this.format);
  this.mask = this.getAttrValue("mask", this.mask);
  if(this.formatType == "date") {
    if(this.mask == null || this.mask  == "") this.mask = "yyyyMMdd";
    if(this.regFormat == null || this.regFormat == "") this.regFormat = "yyyy-MM-dd";
    if(this.regMask == null || this.regMask == "") this.regMask = "yyyyMMdd";
    this.maskLen = this.mask.length;
    if(this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
    else this.dataLen = 8;
  }

  //this.stringPromptMask = this.mask.replace(/[#Xx*Aa!^Ww90]/g,this.maskPrompt);
  this.spinWidth = this.getAttrValue("spinWidth", this.spinWidth);
  this.spinNum = this.getAttrValue("spinNum", this.spinNum);
  this.useSpin = this.getAttrValue("useSpin", this.useSpin);
  this.maxLength = this.getAttrValue("maxLength", this.maxLength);
  this.minLength = this.getAttrValue("minLength", this.minLength);
  this.calendarImageUrl = this.getAttrValue("calendarImageUrl", this.calendarImageUrl);

  this.btnCursor = this.getAttrValue("btnCursor", this.btnCursor);
  if(this.formatType == "date"){
    this.calendarEnable = this.getAttrValue("calendarEnable", this.calendarEnable);
    this.readOnlyWithCalendar = this.getAttrValue("readOnlyWithCalendar", this.readOnlyWithCalendar);
  }else
    this.calendarEnable = false;
  this.vbSelectAll = this.vbSelectAll;
};

eXria.controls.xhtml.EditMask.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  // /////////////////////////////////////////////////////////////////////////////////
  // 블럭 A
  // 이 블럭의 코드는 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  // /////////////////////////////////////////////////////////////////////////////
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  // 반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  // 단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;

  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.userAttrObj = voUserAttr;
    if(voUserAttr.regFormat) this.regFormat = voUserAttr.regFormat;
  }

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  //if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);

  poCtrl.style.cssText = vaCssStrBuf.join("");
  // ////////////////////////////////////////////////////////////////////////////////////////
  // 블럭 A 끝
  // ////////////////////////////////////////////////////////////////////////////////////////

  vaAttStrBuf = [];
  if(this.readOnly) vfcSetAttStrBuf(vaAttStrBuf, "readOnly", this.readOnly);
  if(this.maskLen) vfcSetAttStrBuf(vaAttStrBuf, "maxLength", this.maskLen);
  else vfcSetAttStrBuf(vaAttStrBuf, "maxLength", this.maxLength);
  vfcSetAttStrBuf(vaAttStrBuf, "minLength", this.minLength);
  vaTemplate[voIndexMap.get(0)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;top:0px;left:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-direction", this.dir);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vaTemplate[voIndexMap.get(1)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;border-style:none;top:0px;width:" + this.spinWidth + "px;height:" + this.height + "px;");
  if(!this.useSpin) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
  vfcSetCssStrBuf(vaCssStrBuf, "left", (this.innerWidth - this.spinWidth), "px");
  vaTemplate[voIndexMap.get(2)] = vaCssStrBuf.join("");

  var vnFontSize = Math.round(this.fontSize / 2);
  if(vnFontSize < 2) vnFontSize = 2;
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;left:0px;top:0px;width:" + this.spinWidth + "px;height:" + (this.height / 2) + "px;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vnFontSize, "pt");
  vaTemplate[voIndexMap.get(3)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;left:0px;top:" + ((this.height / 2) - 1) + "px;width:" + this.spinWidth + "px;height:" + ((this.height - (this.height / 2))-1) + "px;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vnFontSize, "pt");
  vaTemplate[voIndexMap.get(4)] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute; top:0px; width:" + this.imgAreaWidth + "px;");
  vfcSetCssStrBuf(vaCssStrBuf, "left", (this.innerWidth - this.imgAreaWidth), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.btnCursor);
  if (this.readOnlyWithCalendar === "auto") {
    if (this.readOnly === true) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "block");

    if (! this.calendarEnable) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
  }
  else {
    if (! this.calendarEnable) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "block");
  }
  vaTemplate[voIndexMap.get(5)] = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "src", this.calendarImageUrl);
  vaTemplate[voIndexMap.get(6)] = vaAttStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(7)] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");
  voIndexMap.clear();

  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  this.template = null;
  this.templateIndexMap = null;
  this.setSubElement(poDocument);
  var a = this.subElement.divSpin;
  var b = this.subElement.divDate;
  a.style.zindex = -1;
  b.style.zindex = -1;
  this.showSpin(this.useSpin, this.spinNum);
  var voInputCtrl = this.subElement.input;
  var vsValue = this.value;
  if(vsValue != null && vsValue != ""){
    switch(this.formatType) {
    case "number":
      break;
    case "date":
      vsValue = this.getDate(vsValue).getTime();
      break;
    case "string":
      break;
    }
    vsValue = TGP.GetString(vsValue, this.formatType, this.regFormat);
  } else {
    vsValue = "";
  }
  voInputCtrl.value = vsValue;
  var voDateinput_icon = poCtrl.getElementsByTagName("img")[0]; // 수정필요
  this.calendar.canvas = this.canvas;
  //voCalendar.style.visibility = "hidden";
  voDateinput_icon.control = this;
  voDateinput_icon.onclick = function(e) {
   var voControl = this.control;
   var voCanvas = voControl.canvas;

   var getPositionLeft = function(poControl){
     var vnLeft = poControl.left;
     if(poControl.parent) vnLeft = vnLeft + getPositionLeft(poControl.parent);
     return vnLeft;
   }

   var getPositionTop = function(poControl){
     var vnTop = poControl.top;
     if(poControl.parent) vnTop = vnTop + getPositionTop(poControl.parent);
     return vnTop;
   }

   if(voCanvas.collapseControl && voCanvas.collapseControl.id != voControl.id) {
     voCanvas.doCollapseControl(voCanvas);
   }
   var voCalendar = voControl.calendar;
   var voCalendarCtrl = voCalendar.getCtrl(poDocument);
   if(voCalendarCtrl) {
     voCalendar.hide();
     this.calendarShowed = false;
     voCanvas.collapseControl = null;
     return;
   }

   //voCalendar.style.visibility = "visible";
   var e = e || window.event;
   if(voControl.calendarEnable) {
     var voCtrl = voControl.getCtrl();
     voCalendar.setDate(voControl.getDate(voControl.value));
     voCalendar.type = "Dateinput";
     voCalendar.fontSize = 10;
     voCalendar.setTarget(voControl);


     //전체화면의 크기
     var vnCanvasWidth = voControl.canvas.width;
     var vnCanvasHeight= voControl.canvas.height;

     //컨트롤(DateInput)의 포지션
     var vnLeft = getPositionLeft(voControl);
     var vnTop = getPositionTop(voControl);

     //컨트롤(DateInput)의 크기
     var vnWidth = voControl.width;
     var vnHeight = voControl.height;

     var vsCSSStyle = {
          "GB": {
             "W":169,
             "H":161
          },
          "GL": {
             "W":196,
             "H":150
          },
          "GM": {
             "W":169,
             "H":161
          },
          "GO": {
             "W":169,
             "H":161
          },
          "GP": {
             "W":169,
             "H":161
          },
          "GR": {
             "W":169,
             "H":161
          },
          "GS": {
             "W":169,
             "H":161
          }
      }[voCalendar.CSS];


     //컨트롤(Calendar)의 크기
     var vnCalendarWidth  =  vsCSSStyle["W"];//voCalendar.width;
     var vnCalendarHeight =  vsCSSStyle["H"];//voCalendar.height;

     //컨트롤(Calendar)의 포지션
     var vnCalendarLeft;
     var vnCalendarTop;


     if( (vnLeft+vnWidth) >= vnCalendarWidth ){
        vnCalendarLeft = vnLeft;
        if( (vnCalendarLeft+vnCalendarWidth) >= vnCanvasWidth ){
          vnCalendarLeft = (vnLeft+vnWidth) - vnCalendarWidth;
        }
     }else{
        vnCalendarLeft = (vnLeft+vnWidth) - vnCalendarWidth;
        if(vnCalendarLeft < 0)
          vnCalendarLeft = vnLeft;
     }

     if( vnCanvasHeight-(vnTop+vnHeight) >= vnCalendarHeight){
        vnCalendarTop = vnTop+vnHeight;
     }else{
        vnCalendarTop = (vnTop+vnHeight) -  vnCalendarHeight;
     }

     voCalendar.left = vnCalendarLeft;
     voCalendar.top = vnCalendarTop;
     voCalendar.position = "absolute";
     voCalendar.zIndex = 10000;
     voCalendar.show();


     //window.useHMS 속성은 이대프로젝트에 의존된 속성임.
     //template_xhtml.xml에 적용됨
     if(voControl.mask.length > 14 && !voControl.noUseHMS) {
        var vnTmp = voControl.getDate(voControl.value).getTime();
        voCalendar._showTimesInfo(TGP.GetString(vnTmp, voControl.formatType, 'HH:mm:ss'));
     }

     voControl.calendarShowed = true;
     voCanvas.collapseControl = voControl;
   }
  }
};

eXria.controls.xhtml.EditMask.prototype.setSpecificEvents = function(poCtrl){
  var voInput = this.subElement.input;
  //@data  TODO: 테스트 필요...
  voInput.control = this;
  //this.eventManager.addListener(voInput, "onchange", this.mediateEvent);
  this.eventManager.addListener(voInput, "onfocus", this.mediateEvent);
  this.eventManager.addListener(voInput, "onblur", this.mediateEvent);
  this.eventManager.addListener(voInput, "onselect", this.mediateEvent);

  var add = "";
  if(this.formatType == "number") voInput.onkeypress = function(ev){ TestKey(ev?ev:event,this,TestKeyFloat,add); }
  else if(this.formatType == "date") {
    var tt = this.regFormat && this.regFormat.indexOf('t')>=0 && this.regFormat.indexOf('h')>=0;
    if(tt) add+=Formats.AMDesignator.toUpperCase()+Formats.PMDesignator.toUpperCase();
    voInput.onkeypress = function(ev){ TestKey(ev?ev:event,this,TestKeyDate,add); }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.setSubElement = function(poDocument) {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement;
  voSubElement.input = this.getSubCtrl("input", voCtrl, poDocument);
  voSubElement.divSpin = voCtrl.childNodes[1];
  voSubElement.btnUp = this.getSubCtrl("input", voCtrl, poDocument, 1);
  voSubElement.btnDown = this.getSubCtrl("input", voCtrl, poDocument, 2);
  voSubElement.img = this.getSubCtrl("img", voCtrl, poDocument);
  voSubElement.divDate = voCtrl.childNodes[2];
  voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  var voInput = this.subElement.input;
  var voDivSpin = this.subElement.divSpin;
  var voDivDate = this.subElement.divDate;
  var voSpan = this.subElement.span;
  switch(psAttrName) {
    case "width" :
      this.setInputWidth();
      this.calendar.left = this.width;
//    this.calendar.refresh();
      break;
    case "height" :
      this.setAttrCtrl("height", this.innerHeight, voDivDate);
      this.calendar.top = this.height;
//      this.setVerticalAlign(voInput, poCtrl, voDf.verticalAlign);
//        this.calendar.refresh();
      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.dofocus = function() {
  if(this.calendarShowed) return;
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  setTimeout(function(){ try { voInput.focus(); }catch(err) {} },10); //ff에서 제대로 작동하지 않아서 setTimeout 사용
  //voInput.focus();
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.atfocus = function(e) {
  var voInput = this.subElement.input;
  var vsValue = this.value;
  if(vsValue != null && vsValue !== "") {
    switch(this.formatType) {
    case "number":
      break;
    case "date":
      vsValue = this.getDate(vsValue).getTime();
      break;
    case "string":
      vsValue = this.getMaskedValue(vsValue, this.mask);
      break;
    }
    vsValue = TGP.GetString(vsValue, this.formatType, this.regMask);
  } else {
    vsValue = "";
  }
  voInput.value = vsValue;
  if(this.focused != true) {
    if(this.calendarEnable) {
      var voCalendar = this.calendar;
      var voCalendarCtrl = voCalendar.getCtrl();
      if(voCalendarCtrl) {
        voCalendar.hide();
        this.calendarShowed = false;
        this.canvas.collapseControl = null;
      }
    }
    this.selectText();
  }
  this.vbValidation = "nonChecked";
  this.focused = true;
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.atkeydown = function(e){
//  this.checkSelect();
  if(e.keyCode == 13) {
    this.isEnter = true;
    var voInput = this.subElement.input;
    //atkeydown 다음 메소드 콜스택 때 onchange, onblur가 순차적으로 발생되며 그 뒤에 onkeydown이 호출됨.
    voInput.blur();
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.atkeyup = null;
//eXria.controls.xhtml.EditMask.prototype.atkeyup = function(e) {
//  e = new eXria.event.Event(e, this.window);
//  //if(this.df.maskType == "string" && e.keyCode == 8) this.chkBackSpace(e);
//  this.checkKey(e);
//};

/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.atblur = function(e) {
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  this.setInputHeight(voCtrl);
  this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
  this.focused = false;

  if(!this.mask && !!this.inputMode)
    voInput.value = eXria.controls.xhtml.Util.getValueFromInputMode(String(voInput.value), this.inputMode);

  // var vsValue = voInput.value;
  if(this.formatType != "string") this.tempValue = voInput.value;
  var vsValue = voInput.value;
  if(this.formatType == "string") vsValue = this.getMaskedValue(vsValue, this.mask);
  else if(this.formatType == "number") {
    if(vsValue !== "") vsValue = TGP.GetValueInput(vsValue, this.formatType, this.regMask);
  } else if(this.formatType == "date" && vsValue) {
    vsValue = this.filterDateInput(vsValue);
    vsValue = TGP.GetValueInput(vsValue, this.formatType, this.regMask);
    var voDate = new Date();
    voDate.setTime(vsValue);
    vsValue = this.getDateString(voDate);
  } else {
    vsValue = TGP.GetValueInput(vsValue, this.formatType, this.regMask);
  }

  if((this.formatType === "date" || this.formatType == "number" ) && isNaN(vsValue)) vsValue = "";

  this.setValueWithNotify(vsValue);
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;
  var voInputCtrl = this.subElement.input;
  var voDivSpinCtrl = this.subElement.divSpin;
  var voBtnUpCtrl = this.subElement.btnUp;
  var voBtnDownCtrl = this.subElement.btnDown;
  var voDivDateCtrl = this.subElement.divDate;
  var voImgCtrl = this.subElement.img;
  var voSpanCtrl = this.subElement.span
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  //if(this.disabled) poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  //else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  var vsValue = this.value;
  if(vsValue != null && vsValue != "") {
    switch(this.formatType) {
    case "number":
     break;
    case "date":
     vsValue = this.getDate(vsValue).getTime();
     break;
    case "string":
     break;
    }
    vsValue = TGP.GetString(vsValue, this.formatType, this.regFormat);
  } else {
    vsValue = "";
  }
  voInputCtrl.value = vsValue;

  if(this.readOnly != null) voInputCtrl ["readOnly"] = this.readOnly;
  if(this.maskLen != null) voInputCtrl["maxLength"] = this.maskLen;
  else if(this.maxLength != null) voInputCtrl["maxLength"] = this.maxLength;
  if(this.minLength != null) voInputCtrl["minLength"] = this.minLength;

  if(this.className != null) voInputCtrl.className = this.getCSSClass(this, 1);

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;border-style:none;border-width:0px;top:0px;left:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", 0, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "text-direction", this.dir);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  var vnWidth = this.innerWidth;
  if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
  if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "width", (this.innerWidth - this.imgAreaWidth - voDf.paddingLeft - voDf.paddingRight), "px");
  voInputCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;border-style:none;top:0px;width:" + this.spinWidth + "px;height:" + this.height + "px;");
  if(!this.useSpin) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
  vfcSetCssStrBuf(vaCssStrBuf, "left", (this.innerWidth - this.spinWidth), "px");
  voDivSpinCtrl.style.cssText = vaCssStrBuf.join("");

  var vnFontSize = Math.round(this.fontSize / 2);
  if(vnFontSize < 2) vnFontSize = 2;
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;left:0px;top:0px;width:" + this.spinWidth + "px;height:" + (this.height / 2) + "px;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vnFontSize, "pt");
  voBtnUpCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;left:0px;top:" + ((this.height / 2) - 1) + "px;width:" + this.spinWidth + "px;height:" + ((this.height - (this.height / 2))-1) + "px;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vnFontSize, "pt");
  voBtnDownCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute; top:0px; width:" + this.imgAreaWidth + "px;");
  vfcSetCssStrBuf(vaCssStrBuf, "left", (this.innerWidth - this.imgAreaWidth), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.btnCursor);
  //if(voDf.formatType == "date" && voDf.calendarEnable == false) vfcSetCssStrBuf(vaCssStrBuf, "visibility", "hidden");
  if (this.readOnlyWithCalendar === "auto") {
    if (this.readOnly === true) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "block");

    if (! this.calendarEnable) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
  }
  else {
    if (! this.calendarEnable) vfcSetCssStrBuf(vaCssStrBuf, "display", "none");
    else vfcSetCssStrBuf(vaCssStrBuf, "display", "block");
  }
  voDivDateCtrl.style.cssText = vaCssStrBuf.join("");

  voImgCtrl["src"] = this.calendarImageUrl;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  voSpanCtrl.style.cssText = vaCssStrBuf.join("");

  this.showSpin(this.useSpin, this.spinNum);
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voDivSpin = this.subElement.divSpin;
  var voDivDate = this.subElement.divDate;
  var voInput = this.subElement.input;
  var voImgCtrl = this.subElement.img;
  var voDf = this.df;

  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName){
    case "visible" :
      this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
      this.setInputHeight(voCtrl);
      this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
      break;
    case "disabled" :
      if(psAttrValue == true) this.doblur();
      this.setDisable(voCtrl, psAttrValue);
      break;
    case "textAlign" :
      this.setAttrCtrl(psAttrName, psAttrValue, voInput);
      this.setInputWidth();
      break;
    case "readOnly":
    this.setAttrCtrl(psAttrName, psAttrValue, voInput);
    // this.readOnlyWithCalendar상황에서는 this.calendarEnable는 don't care
    if (this.readOnlyWithCalendar === "auto") {
      if (this.readOnly === true) this.setAttrCtrl("visible", false, voImgCtrl);
      else this.setAttrCtrl("visible", true, voImgCtrl);
    }

    break;
  case "readOnlyWithCalendar" :
    if (this.readOnlyWithCalendar === "auto") {
      if (this.readOnly === true) this.setAttrCtrl("visible", false, voImgCtrl);
      else this.setAttrCtrl("visible", true, voImgCtrl);
    }
    else {
      if (! this.calendarEnable) this.setAttrCtrl("visible", false, voImgCtrl);
    }
    break;
    case "maxLength":
    case "minLength":
    case "value":
      this.setAttrCtrl(psAttrName, psAttrValue, voInput);
      break;
    case "verticalAlign":
      this.setInputHeight(voCtrl);
      this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
      break;
    case "color" :
    case "fontFamily" :
    case "fontSize" :
    case "fontStyle" :
    case "fontWeight" :
    case "textDecoration":
    case "textTransform":
      this.setAttrCtrl(psAttrName, psAttrValue, voInput);
      this.setInputHeight(voCtrl);
      this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
      break;
    case "outerClassName":
    case "className":
      this.refresh(poDocument);
      break;
    case "width" :
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setInputWidth();
      this.calendar.left = this.width;
      //this.calendar.refresh(poDocument);
      this.refresh(poDocument);
      break;
    case "height" :
      this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setAttrCtrl("height", this.innerHeight, voDivDate);
      this.calendar.top = this.height;
      //this.calendar.refresh(poDocument);
      this.refresh(poDocument);
      break;
    case "borderWidth" :
      this.borderLeftWidth = this.borderWidth;
      this.borderRightWidth = this.borderWidth;
      this.borderTopWidth = this.borderWidth;
      this.borderBottomWidth = this.borderWidth;
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
      this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
      this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
      this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setInputWidth();
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setVerticalAlign(voInput, voCtrl, "middle");

      break;
    case "borderLeftWidth" :
    case "borderRightWidth" :
      this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setInputWidth();
      break;
    case "borderTopWidth" :
    case "borderBottomWidth" :
      this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
      this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setVerticalAlign(voInput, voCtrl, "middle");
      break;
    case "padding" :
      this.paddingTop = this.padding;
      this.paddingRight = this.padding;
      this.paddingBottom = this.padding;
      this.paddingLeft = this.padding;
      this.setAttrCtrl("paddingTop", this.paddingTop + "px", voInput);
      this.setAttrCtrl("paddingRight", this.paddingRight + "px", voInput);
      this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voInput);
      this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voInput);
      this.setInputWidth();
      this.setVerticalAlign(voInput, voCtrl, "middle");
      break;
    case "paddingTop" :
    case "paddingBottom" :
      this.setAttrCtrl(psAttrName, psAttrValue + "px", voInput);
      this.setInputWidth();
      this.setVerticalAlign(voInput, voCtrl, "middle");
      break;
    case "paddingLeft" :
    case "paddingRight" :
      this.setAttrCtrl(psAttrName, psAttrValue + "px", voInput);
      this.setInputWidth();
      break;
    case "formatType" :
      break;
    case "format" :
      if(this.formatType == "date") {
        if(this.format == null || this.format == "") this.format = "yyyy-MM-dd";
      }
      if(this.formatType == "string") this.regFormat = null;
      else this.regFormat = this.format;
      this.setValue(this.value);
      break;
    case "regFormat" :
      if(this.formatType == "date") {
        if(this.regFormat == null || this.regFormat == "") this.regFormat = "yyyy-MM-dd";
      }
      if(this.formatType == "string") this.format = null;
      else this.format = this.regFormat;
      this.setValue(this.value);
      return;
    case "mask" :
      if(this.formatType == "date") {
        if(this.mask == null || this.mask == "") this.mask = "yyyyMMdd";
        this.maskLen = this.mask.length;
        if(this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
        else this.dataLen = 8;
        voInput.maxLength = this.maskLen;
      }
      if(this.formatType == "string") this.regMask = null;
      else this.regMask = this.mask;
      break;
    case "regMask" :
      if(this.formatType == "date") {
        if(this.regMask == null || this.regMask == "") this.regMask = "yyyyMMdd";
        this.mask = this.regMask;
        this.maskLen = this.mask.length;
        if(this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
        else this.dataLen = 8;
        voInput.maxLength = this.maskLen;
      }
      if(this.formatType == "string") this.mask = null;
      else this.mask = this.regMask;
      break;
    default:
      this.refresh(poDocument);
      break;
  }
};
/**
 * 스핀 버튼의 표시 여부를 설정합니다(maskType이 number이고 readOnly가 true일때만).
 * @param {Boolean} pbShow 스핀 버튼 표시여부
 * @param {Number} pnNum 스핀 버튼에 의한 수치 증가치(생략시 디폴트값)
 */
eXria.controls.xhtml.EditMask.prototype.showSpin = function(pbShow, pnNum) {
  var voDf = this.df;
  if(this.formatType != "number" || !this.readOnly) return;

  if(pnNum != null) {
    this.spinNum = pnNum;
//    voDf.spinNum = pnNum;
  }
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  var voDiv = this.subElement.divSpin;
  if(pbShow) {
    var voInput = this.subElement.input;
    var vnWidth = this.innerWidth;
    if(this.imgAreaWidth !== null) vnWidth = vnWidth - this.imgAreaWidth;
    if(this.paddingLeft !== null) vnWidth = vnWidth - this.paddingLeft;
    if(this.paddingRight !== null) vnWidth = vnWidth - this.paddingRight;
    voInput.style.width = vnWidth;
    this.useSpin = true;
//    voDf.useSpin = true;
    this.setAttrCtrl("display", "inline", voDiv);
    //this.setAttrCtrl("width", (this.width - 2 * this.subBorderWidth - this.spinWidth), voInput);
  } else {
    this.useSpin = false;
//    voDf.useSpin = false;
    this.setAttrCtrl("display", "none", voDiv);
   // this.setAttrCtrl("width", (this.width - 2 * this.subBorderWidth), voInput);
  }
};
/**
 * 텍스트 박스에 표시된 수치를 증가시켜 줍니다.
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.increaseNum = function() {
  var voDf = this.df;
  var voInput = this.subElement.input;
  var vsTempValue = voInput.value;
  this.onchangeInitValue = vsTempValue;

  if(vsTempValue == "") vsTempValue = "0";
//  voDf.value = vsTempValue;
  var vsValue = vsTempValue;
  var vaValue = vsTempValue.split(".");
  var vsInteger = vaValue[0];
  var vsDecimal = vaValue[1];
  if(vsDecimal == null) vsDecimal = "";
  var vnInteger = Number(vsInteger);
  vnInteger += this.spinNum;
  if(vsDecimal == "") vsValue = vnInteger;
  else vsValue = vnInteger + "." + vsDecimal;
//  voDf.value = vsValue;
  this.value = vsValue;
  voInput.value = vsValue;

  if(!!this.data.instanceId)this.data.setData(vsValue);
  this.setValueWithNotify(vsValue);
};
/**
 * 텍스트 박스에 표시된 수치를 감소시켜 줍니다.
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.decreaseNum = function() {
  var voDf = this.df;
  var voInput = this.subElement.input;
  var vsTempValue = voInput.value;
  this.onchangeInitValue = vsTempValue;


  if(vsTempValue == "") vsTempValue = "0";
//  voDf.value = vsTempValue;
  var vsValue = vsTempValue;
  var vaValue = vsTempValue.split(".");
  var vsInteger = vaValue[0];
  var vsDecimal = vaValue[1];
  if(vsDecimal == null) vsDecimal = "";
  var vnInteger = Number(vsInteger);
  vnInteger -= this.spinNum;
  if(vsDecimal == "") vsValue = vnInteger;
  else vsValue = vnInteger + "." + vsDecimal;
//  voDf.value = vsValue;
  this.value = vsValue;
  voInput.value = vsValue;

  if(!!this.data.instanceId)this.data.setData(vsValue);
  this.setValueWithNotify(vsValue);
};
/**
 * 현재에서의 커서 위치를 반환합니다.
 * @return 커서의 위치
 * @type Number
 */
eXria.controls.xhtml.EditMask.prototype.getCursorPosition = function() {
  var voDocument = this.document;
  var voInput = this.subElement.input;
  var vnCursorPosition = -1;
  if(voInput == null) return vnCursorPosition;
  if (voInput.selectionEnd) {
    vnCursorPosition = voInput.selectionEnd;
  } else if(voDocument.selection && voDocument.selection.createRange) {
    var voRange = voDocument.selection.createRange().duplicate();
    voRange.moveStart('textedit', -1);
    vnCursorPosition = voRange.text.length;
  }
  return vnCursorPosition;
};
/**
 * 입력키에 유효성을 체크하고 마스크 타입에 맞게 문자열을 변환합니다.
 * @param {HTMLEvent} e 윈도우이벤트
 * @return 작업수행의 성공 여부
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.checkKey = function(e){
  var voDf = this.df;
  var vnKeyCode = e.e.keyCode;
  var voInputCtrl = this.subElement.input;
  var vsValue = voInputCtrl.value;
  this.cursorPosition = this.getCursorPosition();
  var vnPos = this.cursorPosition;
  var tempValue = null;
  var vbBackOrDel = false;
//    var vnKeyCode = e.e.which||e.e.which==0?e.e.which:e.e.keyCode;
//    if(vnKeyCode == 229) e.stopEvent();
  if(vnKeyCode == 229 && e.type != "keyup") { // 한글 입력 상태에서 마우스 클릭시 keyup 이벤트가 발생하여 이를 제외하여 체크
    alert("한글 입력은 허용이 되지 않습니다.");
  } else if(vnKeyCode == 229 && e.type == "keyup") {
    return;
  }
  var voConstKey = this.constKey;
  switch(vnKeyCode) {
  case voConstKey["ENTER"] :
  case voConstKey["TAB"] :
  //case voConstKey["BACKSPACE"] :
  //case voConstKey["DEL"] :
  case voConstKey["SHIFT"] :
  case voConstKey["LEFT"] :
  case voConstKey["RIGHT"] :
  case voConstKey["UP"] :
  case voConstKey["DOWN"] :
    return true;
  }
  if(vnKeyCode == 27) {
    vbValidation = "nonChecked";
    vsValue = this.mask.replace(/[#Xx*Aa!^Ww9]/g, this.maskPrompt);
  }
  if(vnPos == 0 && vsValue.length == this.mask.length && vnConstKey == "BACKSPACE") return true;
  if(this.maskType == "number" && (vnKeyCode == 8 || vnKeyCode == 46)) return true;
  vnKeyCode = this.matchNumberPad(vnKeyCode);
  var vsKeyCharacter = String.fromCharCode(vnKeyCode);

  switch(this.maskType) {
    case "number":
      // vnKeyCode = 190 -> "."
      if((vsKeyCharacter == "-" || vsKeyCharacter == "+") && vsValue == vsKeyCharacter) return;
      if(/[0-9]/.test(vsKeyCharacter) == false && vnKeyCode != 190) {
        vnPos--;
        vsValue = vsValue.substring(0, vnPos) + vsValue.substring(vnPos + 1);
      } else if(vnKeyCode == 190) {
        var vaMatch = vsValue.match(/\./g);
        if(vaMatch && vaMatch.length > 1) {
          vnPos--;
          vsValue = vsValue.substring(0, vnPos) + vsValue.substring(vnPos + 1);
        }
      }
      var vsPreValue = vsValue;
      vsValue = this.setNumber(vsValue);
      if(!/[0-9]/.test(vsValue.charAt(vnPos))) vnPos++;
      if(vsPreValue.length < vsValue.length) vnPos = vsValue.length;
      voInputCtrl.value = vsValue;
      break;
    case "date":
      if(vnKeyCode == 8 || vnKeyCode == 46){
        var voValues = this.chkBackSpace(e);
        if(voValues[0] != null){
          vsValue = voValues[0];
          if(voValues[1]) vnPos = voValues[1];
        }
      }else if(/[0-9]/.test(vsValue) == false) {
        vnPos--;
        vsValue = vsValue.substring(0, vnPos) + vsValue.substring(vnPos + 1);
      }else if(this.checkDate(vsValue) == false) {
        vnPos--;
        vsValue = vsValue.substring(0, vnPos) + vsValue.substring(vnPos + 1);
      }
      vsValue = vsValue.replace(this.noDigits, "");
      this.tempValue = vsValue;
      vsValue = this.toDateFormatValue(vsValue);
      voInputCtrl.value = vsValue;
      var vsChar = null;
      if(vsValue != null) {
        while(vsValue.charAt(vnPos)) {
          vsChar = vsValue.charAt(vnPos);
          if(/[0-9]/.test(vsChar) == false && this.maskPrompt != vsChar) {
            vnPos++;
          } else {
            break;
          }
        }
      }
      break;
    case "string":
      if(vnKeyCode == 8 || vnKeyCode == 46){
        this.vbCheck = true;
        vsValue = this.setGeneric(vsValue);
        voInputCtrl.value = vsValue;
        vbBackOrDel = true;
      }else{
        vsValue = this.setGeneric(vsValue);
        var vcTest = this.mask.charAt(vnPos);
        if(this.noMaskVal.test(this.mask.charAt(vnPos))) vcTest = this.mask.charAt(vnPos + 1);
        if(/[0]/g.test(vcTest)){
          if(!/[#Xx*Aa!^Ww90]/.test(this.mask.charAt(0)) && (vnPos == 1 || vnPos == 0)) vnPos++;
          vnPos = this.stringPromptMask.indexOf(this.maskPrompt, this.vsInput == "fail" ? vnPos - 1 : vnPos);
        }else vnPos = vsValue.indexOf(this.maskPrompt);
        voInputCtrl.value = vsValue;
      }
      break;
  }
  if(vbBackOrDel){
    if(this.stringPromptMask.charAt(vnPos) != this.maskPrompt) vnPos--;
  }
  if(vnPos >= 0) this.setCursorPosition(vnPos);
  this.skipBlur = true;
  return true;
};
/**
 * 넘버패드의 keycode를 기본 숫자 keycode로 변환합니다.
 * @param {Number} 넘버패드의 keycode
 * @return 변환된 keyCOde
 * @type Number
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.matchNumberPad = function(vnKeyCode){
  if(vnKeyCode > 95 && vnKeyCode < 106) return vnKeyCode -= 48;
  else return vnKeyCode;
}
/**
 * 입력된 날짜에 대해서 유효성 체크를 합니다.
 * @param {String} psValue 입력된 날짜
 * @return 성공여부
 * @type Boolean
 */
eXria.controls.xhtml.EditMask.prototype.checkDate = function(psValue){
  var voDf = this.df;
  psValue = psValue.replace(this.noDigits, "");
  var vsFormat = this.vsMask;
  vsFormat = vsFormat.replace(/[^YyMDdhmis]/g, "");
  var voDate = new Date();
  var vnYearPos = vsFormat.search(/yyyy/i);
  var vnMonthPos = vsFormat.search(/mm/i);
  var vnDatePos = vsFormat.search(/dd/i);
  var vnHour = "";
  var vnMinute = "";
  var vnSecond = "";
  var vnYear = psValue.substr(vnYearPos, 4);
  if(vnYearPos < 0) {
    vnYearPos = vsFormat.search(/yy/i);
    vnYear = psValue.substr(vnYearPos, 2);
    vnYear = String(voDate.getFullYear()).substring(0, 2) + vnYear;
  }
  if(vnYear != "") vnYear = parseInt(vnYear);
  var vnMonth = psValue.substr(vnMonthPos, 2);
  if(vnMonth.length == 1) vnMonth += "0";
  if(vnMonth != "") vnMonth = parseInt(vnMonth) - 1;
  var vnDate = psValue.substr(vnDatePos, 2);
  if(vnDate.length == 1) vnDate += "0";
  if(vnDate != "") vnDate = parseInt(vnDate);
  var vnHourPos = vsFormat.search(/hh/i);
  var vnMinutePos = vsFormat.search(/mi/i);
  var vnSecondPos = vsFormat.search(/ss/i);
  if(vnHourPos > -1){
    vnHour = psValue.substr(vnHourPos, 2);
    if(vnHour.length == 1) vnHour += "0";
    if(/hh12/.test(this.mask) && vnHour > 12) {
      return false;
    }
  }
  if(vnHour != "") vnHour = parseInt(vnHour);
  if(vnMinutePos > -1){
    vnMinute = psValue.substr(vnMinutePos, 2);
    if(vnMinute.length == 1) vnMinute += "0";
  }
  if(vnMinute != "") vnMinute = parseInt(vnMinute);
  if(vnSecondPos > -1){
    vnSecond = psValue.substr(vnSecondPos, 2);
    if(vnSecond.length == 1) vnSecond += "0";
  }
  if(vnSecond != "") vnSecond = parseInt(vnSecond);
  if(vnYear == "" || vnYear == 0) vnYear = voDate.getFullYear();
  if(vnMonth == "" || vnMonth == -1) vnMonth = voDate.getMonth();
  if(vnDate == "" || vnDate == 0) vnDate = voDate.getDate();
  if(vnHour == "" || vnHour == 0) vnHour = voDate.getHours();
  if(vnMinute == "" || vnMinute == 0) vnMinute = voDate.getMinutes();
  if(vnSecond == "" || vnSecond == 0) vnSecond = voDate.getSeconds();

  voDate.setFullYear(vnYear);
  voDate.setMonth(vnMonth);
  voDate.setDate(vnDate);
  voDate.setHours(vnHour);
  voDate.setMinutes(vnMinute);
  voDate.setSeconds(vnSecond);

  if( voDate.getFullYear() != vnYear
      || voDate.getMonth() != vnMonth
      || voDate.getDate() != vnDate
      || voDate.getHours() != vnHour
      || voDate.getMinutes() != vnMinute
      || voDate.getSeconds() != vnSecond) {
    return false;
  }
  return true;
};
/**
 * 마스크 프롬프트를 공백문자로 치환합니다.
 * @param {String} 치환할 마스크 프롬프트값
 * @return 마스크프롬프트가 공백으로 치환된 값
 * @type String
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.maskPromptToBlank = function(psValue){
  var vsReg = new RegExp('['+this.maskPrompt+']','gi');
  psValue = psValue.replace(vsReg, " ");
  return psValue;
};
/**
 * 설정된 숫자형 마스크 포맷으로 값을 변환합니다.
 * @param {String} 변환할 값
 * @return 숫자형 마스크 포맷 적용 값
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.toNumberFormatValue = function(psValue){
  var vsFormat = this.mask.replace(/[#0]/gi,this.maskPrompt);
  // 개체의 값 얻어오기
  var vsReg = new RegExp('['+this.maskPrompt+']','gi');
  var vsValue = psValue.replace(vsReg,"a");
  var vsRegValue = vsFormat;
  var vsRegFormat = new RegExp('['+this.maskPrompt+'0]','i');
  for(var i=0;i < vsValue.length;i++) {
    vsRegValue = vsRegValue.replace(vsRegFormat, vsValue.charAt(i));
  }
  vsRegValue = vsRegValue.replace(/[#]/g,this.maskPrompt);
  return vsRegValue;
};
/**
 * 설정된 날짜형 마스크 포맷으로 값을 변환합니다.
 * @param {String} 변환할 값
 * @param {Boolean} 데이타에서 넘어왔는지의 여부
 * @return 마스크 포멧이 적용된 값
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.toDateFormatValue = function(psValue, pbData){
  var voDf = this.df;
  var vbData = pbData;
  if(vbData == null) vbData = false;
  psValue = psValue.replace(/[^\d]/g, "");
  var vsMask = this.mask.replace(/[124]/g, "");
  var vsRegValue = "";
  var voDate = new Date();
  if(!vbData){
    var vsFormat = vsMask.replace(this.regDateMask,this.maskPrompt);
    // 개체의 값 얻어오기
    var vsReg = new RegExp('['+this.maskPrompt+']','gi');
    //var vsValue = psValue.replace(vsReg,"a");
    vsRegValue = vsFormat;
    var vsRegFormat = new RegExp('['+this.maskPrompt+']','i');
    for(var i=0;i < psValue.length;i++) {
      vsRegValue = vsRegValue.replace(vsRegFormat, psValue.charAt(i));
    }
    vsRegValue = vsRegValue.replace(/[YMDhms]/g,this.maskPrompt);
  }else{
    var vnLen = psValue.length;
    var voDates = {"year" : "____", "month" : "__", "day" : "__",
        "hour" : "__", "minute" : "__", "second" : "__"};
    vsRegValue = vsMask;
    vsMask = vsMask.replace(/[^YMDhmis]/g, "");
    if(vnLen >= 8){
      voDates.year = psValue.substring(0, 4);
      voDates.month = psValue.substring(4, 6);
      voDates.day = psValue.substring(6, 8);
      if(vnLen == 14){
        voDates.hour = psValue.substring(8, 10);
        voDates.minute = psValue.substring(10, 12);
        voDates.second = psValue.substring(12);
      }
    }else if(vnLen == 6){
      voDates.hour = psValue.substring(0, 2);
      voDates.minute = psValue.substring(2, 4);
      voDates.second = psValue.substring(4);
    }
    vsRegValue = vsRegValue.replace(/yyyy/ig, voDates.year);
    vsRegValue = vsRegValue.replace(/mm/ig, voDates.month);
    vsRegValue = vsRegValue.replace(/dd/ig, voDates.day);
    vsRegValue = vsRegValue.replace(/hh/ig, voDates.hour);
    vsRegValue = vsRegValue.replace(/mi/ig, voDates.minute);
    vsRegValue = vsRegValue.replace(/ss/ig, voDates.second);
    vsRegValue = vsRegValue.replace(/[YMDhmis]/g,this.maskPrompt);
  }
  return vsRegValue;
};

eXria.controls.xhtml.EditMask.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null || this.data.isRelativeRef()) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voDf = this.df;
  if(this.data.instanceId == null) return;
  var voCtrl = this.ctrl;
  var vsRefData = this.data.getData();
  if (vsRefData != null && typeof vsRefData != this.formatType) {
    switch (this.formatType) {
      case "number" :
        if(vsRefData != "") vsRefData = Number(vsRefData);
        break;
      case "date" :
        if (vsRefData != null && vsRefData != "") {
          this.dataLen = vsRefData.length;
        } else if (this.dataLen == null) {
          if (this.mask && /(H{1,2}|h{1,2}|m{1,2}|s{1,2})/.test(this.mask)) this.dataLen = 14;
          else this.dataLen = 8;
        }
        break;
      case "string" :
        vsRefData = String(vsRefData);
        break;
    }
  }
  this.setValue(vsRefData);
};
/**
 * 정해진 마스크 타입에 따라 컨트에 값을 설정합니다.
 * @param {String} psData 설정할 값
 */
eXria.controls.xhtml.EditMask.prototype.setValue = function(psData) {
  var voInput = this.subElement.input;
  if(this.formatType == "date") {
    if(this.mask && /^\d*$/g.test(psData) == false) {
      var vsRegMask = this.mask
      vsRegMask = vsRegMask.replace("yyyy", "\\d{4}");
      vsRegMask = vsRegMask.replace("MM", "\\d{2}");
      vsRegMask = vsRegMask.replace("dd", "\\d{2}");
      if(new RegExp(vsRegMask).test(psData)) {
        psData = TGP.GetValueInput(psData, "date", this.mask);
        var voDate = new Date();
        voDate.setTime(psData);
        psData = this.getDateString(voDate);
      }
    }
  }
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue !== psData) {
    vbChanged = true;
  }
  this.onchangeInitValue = psData;
  this.value = psData;
  if(vbChanged) this.data.setData(this.value);
  if(psData != null && psData !== "") {
    switch(this.formatType) {
    case "number":
			psData = TGP.GetString(psData, this.formatType, this.regFormat);
      break;
    case "date":
      psData = this.getDate(psData).getTime();
			psData = TGP.GetString(psData, this.formatType, this.regFormat);
      break;
    case "string":
			psData = this.getFormatedValue(psData, this.format);
      psData = TGP.GetString(psData, this.formatType, this.regFormat);
      break;
    }		
  } else {
    psData = "";
  }
  voInput.value = psData;
};
/**
 * 컨트롤에 값을 설정하며 값의 변경이 있으면 onchange 이벤트를 발생시킵니다.
 * @param {String} psData 설정 값
 */
eXria.controls.xhtml.EditMask.prototype.setValueWithNotify = function(psData) {
  var voInput = this.subElement.input;
  if(this.formatType == "date") {
    if(this.mask && /^\d*$/g.test(psData) == false) {
      var vsRegMask = this.mask
      vsRegMask = vsRegMask.replace("yyyy", "\\d{4}");
      vsRegMask = vsRegMask.replace("MM", "\\d{2}");
      vsRegMask = vsRegMask.replace("dd", "\\d{2}");
      if(new RegExp(vsRegMask).test(psData)) {
        psData = TGP.GetValueInput(psData, "date", this.mask);
        var voDate = new Date();
        voDate.setTime(psData);
        psData = this.getDateString(voDate);
      }
    }
  }
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue !== psData) {
    vbChanged = true;
  }
  this.onchangeInitValue = psData;
  this.value = psData;
  if(psData != null && psData !== "") {
    switch(this.formatType) {
    case "number":
      break;
    case "date":
      psData = this.getDate(psData).getTime();
      break;
    case "string":
      psData = this.getFormatedValue(psData, this.format);
      break;
    }
    psData = TGP.GetString(psData, this.formatType, this.regFormat);
  } else {
    psData = "";
  }
  voInput.value = psData;
  if(vbChanged) {
    this.data.setData(this.value)
    var voEvent = new eXria.event.Event(null);
    voEvent.object = this;
    if(this.onchange) this.onchange(voEvent);
    if(this.changeEventCallback) this.changeEventCallback(voEvent);
  }
};
/**
 * 주어진 마스크에 의해 데이타를 필터링하는 메소드
 * @param {String} psData 데이타
 * @param {String} psMask 마스크 문자열
 * @return 주어진 마스크에 의해 필터링된 데이타 값
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.getMaskedValue = function(psData, psMask) {
  if(psData == null || psData == "") return psData;
  if(psMask == null || psMask == "") return psData;
  var voRegMap = {"x": "[A-Za-z0-9]", "X": "[A-Za-z0-9]", "#": "[0-9]", "*": ".", "S" : "[a-zA-Z0-9\\xC0-\\xD6\\xD8-\\xF6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD]"};
  psMask = psMask.replace(/[^#Xx\*S]/g, "");
  var vsRegValue = "";
  var vnIndex = 0;
  var vnSize = psMask.length;
  var vsMaskChar = null;
  var vsChar = null;
  var vnValLen = psData.length;
  var vsRegStr = null;
  for(var i=0; i < vnSize; i++) {
    vsMaskChar = psMask.charAt(i);
    vsChar = psData.charAt(vnIndex++);
    vsRegStr = voRegMap[vsMaskChar];
    if(vsRegStr && (new RegExp(vsRegStr)).test(vsChar)) vsRegValue += vsChar;
    else i--;
    if(vnIndex >= vnValLen) break;
  }
  return vsRegValue;
};
/**
 * 컨트롤에 설정된 값을 Date형태로 반환합니다.
 * @return Date형으로 변환된 컨트롤 설정 값
 * @type Date
 */
eXria.controls.xhtml.EditMask.prototype.getDate = function(psDate){
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voDateinputCtrl = this.subElement.input;
  var voDate = new Date();
  if(psDate) {

   //psDate 가 숫자로만 들어온다는 가정하에 구현된 코드 이므로
   //숫자만 남기는 코드 추가
   //2010-03-10
   var vsRegType = /[^0-9]/gi;
   psDate = psDate + "";
   psDate = psDate.replace(vsRegType, '');

   var vsTime = psDate.substring(0, 4) + "/" + psDate.substring(4, 6) + "/" + psDate.substring(6, 8);
   if(psDate.length > 8) {
     var _HH = (psDate.substring(8, 10)*1 >= 24)? 23 :psDate.substring(8, 10);
     var _mm = (psDate.substring(10, 12)*1>= 60)? 59 :psDate.substring(10, 12);
     var _ss = (psDate.substring(12, 14)*1>= 60)? 59 :psDate.substring(12, 14);

     vsTime += " " + _HH + ":" + _mm + ":" + _ss;
   }

   var vnTime = Date.parse(vsTime);
   if(isNaN(vnTime)) vnTime = new Date();

   voDate.setTime(vnTime);
   return voDate;
  }
  var vsValue = voDateinputCtrl.value;
  var vsFormat = this.regFormat;
  if(vsFormat == null) vsFormat = "";
  vsFormat = vsFormat.replace(/[^YMDhmis]/gi,"");
  vsValue = vsValue.replace(/[^0-9]/gi,"");
  var vnIndex = vsValue.length;
  //year
  var temp = vsFormat.indexOf("YYYY",0);
  var vnYear = vsValue.substring(temp,temp+4);
  if(temp < 0){
   temp = vsFormat.search(/yy/i);
   vnYear = vsValue.substring(temp, temp + 2);
   vnYear = String(voDate.getFullYear()).substring(0, 2) + vnYear;
  }
  if(vnYear.length == 4) voDate.setFullYear(vnYear);
  //month
  var temp = vsFormat.indexOf("MM",0);
  var vnMonth = vsValue.substring(temp,temp+2);
  if(vnMonth.length == 2) voDate.setMonth(vnMonth-1);
  //date
  var temp = vsFormat.indexOf("DD",0);
  var vnDate = vsValue.substring(temp,temp+2);
  var vnHour = "00";
  var vnMinute = "00";
  var vnSecond = "00";
  if(vnDate.length == 2) voDate.setDate(vnDate);
  //initialize time
  voDate.setHours(0);
  voDate.setMinutes(0);
  voDate.setSeconds(0);
  voDate.setMilliseconds(0);
  //hour
  temp = vsFormat.indexOf("hh",0);
  if(temp != -1) {
   vnHour = vsValue.substring(temp,temp+2);
   if(vnHour.length == 2) voDate.setHours(vnHour);
  }
  //minute
  temp = vsFormat.indexOf("mi",0);
  if(temp != -1) {
   vnMinute = vsValue.substring(temp,temp+2);
   if(vnMinute.length == 2) voDate.setMinutes(vnMinute);
  }
  //second
  temp = vsFormat.indexOf("ss",0);
  if(temp != -1) {
   vnSecond = vsValue.substring(temp,temp+2);
   if(vnSecond.length == 2) voDate.setSeconds(vnSecond);
  }
  return voDate;
};
/**
 * 컨트롤에 설정된 값을 yyyymmdd형태의 문자열 값으로 반환합니다.
 * @parame {Date} 문자열 형태로 변환될 Date 값
 * @return yyyymmdd형태의 문자열 값
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.getDateString = function(poDate){
  var voDf = this.df;
  var voDate = poDate;
  if(voDate == null) voDate = this.getDate();
  var vaStrBuf = [];
  vaStrBuf.push(voDate.getFullYear());
  var vnMonth = voDate.getMonth() + 1;
  if(vnMonth < 10) vnMonth = "0" + vnMonth;
  vaStrBuf.push(vnMonth);
  var vnDate = voDate.getDate();
  if(vnDate < 10) vnDate = "0" + vnDate;
  vaStrBuf.push(vnDate);
  if(this.dataLen >= 14) {
    var vnHour = voDate.getHours();
    if(vnHour < 10) vnHour = "0" + vnHour;
    var vnMinute = voDate.getMinutes();
    if(vnMinute < 10) vnMinute = "0" + vnMinute;
    var vnSecond = voDate.getSeconds();
    if(vnSecond < 10) vnSecond = "0" + vnSecond;
    vaStrBuf.push(vnHour + "" + vnMinute + vnSecond);
  }
  return vaStrBuf.join("");
};
/**
 * 입력된 date형 데이타를 컨트롤 값으로 설정해주는 메소드.
 * @param {Date} poDate 컨트롤 값으로 설정할 date형 데이타
 */
eXria.controls.xhtml.EditMask.prototype.setDate = function(poDate){
  var voDateinputCtrl = this.subElement.input;
  var vnYear = new String(poDate.getFullYear());
  var vnMonth = new String(poDate.getMonth()+1);
  if(vnMonth.length == 1) vnMonth = "0" + vnMonth;
  var vnDate = new String(poDate.getDate());
  if(vnDate.length == 1) vnDate = "0" + vnDate;
  var vnHours = new String(poDate.getHours());
  if(vnHours.length == 1) vnHours = "0" + vnHours;
  var vnMinutes = new String(poDate.getMinutes());
  if(vnMinutes.length == 1) vnMinutes = "0" + vnMinutes;
  var vnSeconds = new String(poDate.getSeconds());
  if(vnSeconds.length == 1) vnSeconds = "0" + vnSeconds;
//  var vsValue = this.mask.replace(/[^YMDhmis]/g,"");
  var vsValue = "YYYYMMDDhhmmss";
  vsValue = vsValue.replace(/YYYY/g,vnYear);
  vsValue = vsValue.replace(/MM/g,vnMonth);
  vsValue = vsValue.replace(/DD/g,vnDate);
  vsValue = vsValue.replace(/hh/g,vnHours);
  vsValue = vsValue.replace(/mm/g,vnMinutes);
  vsValue = vsValue.replace(/ss/g,vnSeconds);
  if(this.dataLen < 14) vsValue = vsValue.substring(0, 8);
  this.setValue(vsValue);
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.EditMask[psAttrName];
  if( vsDefaultValue === undefined) {
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 마스크포멧이 적용된값에서 사용자가 입력한값만을 추출하는 메소드입니다.
 * @param psValue
 * @return 사용자가 입력한값
 * @type String
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.evalValue = function (psValue){
  var voDf = this.df;
  var vsValue = psValue;
  var vsRegValue = "";
  var vsMask = this.stringPromptMask;
  for(var i = 0; i < vsMask.length; i++ ){
    if(vsMask.charAt(i) == this.maskPrompt) vsRegValue += vsValue.charAt(i)
  }
  return vsRegValue;
}
/**
 * 문자형 마스크 포맷으로 값을 변환합니다.
 * @param {String} psValue 입력값
 * @return 문자형 마스크 포맷 적용 값
 * @type String
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.setGeneric = function (psValue){
  var voDf = this.df;
  var vsValue = String(psValue);
  var vsTempValue = vsValue;
  var vsMaskChar = "Xx#A*a!^Ww90";
  var vsMaskChange = this.stringPromptMask;
  var vsMaskChangeZero = this.mask.replace(/[Xx#A*a!^Ww9]/g, this.maskPrompt);
  var vaReg = [];
  var vsRetVal = "";
  var vbMask;
  var vsChar;
  var vbFail = false;
  var vaIsMaskChar = [];
  var vnIndex = -1;
  var vaRegExp = {"x": "A-Za-z0-9", "X": "A-Za-z0-9", "#": "0-9", "*": " A-Za-z0-9", "A" : "A-Z0-9",
      "a" : "0-9a-z", "!" : "A-Z0-9", "^" : "0-9a-z", "W" : "A-Z", "w" : "a-z", "9" : "0-9" , "0" : "0-9"};
  //var vnPos = this.cursorPosition;
  var vnPos = this.getCursorPosition();
  var vsMask = this.mask;
  var vnLen = vsMask.length
  var vaIsMaskForChar = [];
  for(var i = 0; i < vnLen; i++) {
    // grab the current character
    vsChar = vsMask.charAt(i);
    // check to see if current character is a mask, escape commands are not a mask character
    vbMask = (vsMaskChar.indexOf(vsChar) > -1);
    // build a regex to test against
    //if(vbMask && (vaReg.length < vsValue.length)) vaReg[vaReg.length] = "[" + vaRegExp[vsChar] + "]";
    if(vbMask) vaReg[vaReg.length] = "[" + vaRegExp[vsChar] + "]";
    else vaReg[vaReg.length] = vsChar;
    // build mask definition table
    vaIsMaskForChar[vaIsMaskForChar.length] = { "char": vsChar, "mask": vbMask };
  }
  //////////////////
  if(this.vbCheck && this.vbSelectAll) {
    this.tempValue = "";
    return vsMaskChangeZero;
  }
  if(this.vbCheck && vaIsMaskForChar[vnPos]["mask"]){
    if(vnPos == 0 && vsValue.length > this.mask.length) return vsValue;
    var vsDelString = "";
    var vnLastSize = vnPos + this.selectionSize;
    for(var i = vnPos; i < vnLastSize; i++){
      if(vaIsMaskForChar[i]["mask"]) vsDelString += vaIsMaskForChar[i]["char"] == 0 ? 0 : this.maskPrompt;
      else vsDelString += vaIsMaskForChar[i]["char"];
    }
    vsValue = vsValue.substring(0, vnPos) + vsDelString + vsValue.substring(vnPos);
    this.vbCheck = false;
    this.tempValue = this.evalValue(vsValue);
    return vsValue;
  }else if(this.vbCheck && !vaIsMaskForChar[vnPos]["mask"]){
    vnCutPos = this.stringPromptMask.substring(0, vnPos).lastIndexOf(this.maskPrompt);
    if(vnCutPos < 0) {
      vnCutPos = 0;
      vsValue = vsMaskChange.substring(0, this.selectionSize) + vsMaskChange.substring(vnCutPos + 1, vnPos + 1) + vsValue.substring(vnPos);
    }else{
      var vsDelString = "";
      var vnLastSize = vnPos + this.selectionSize;
      for(var i = vnPos; i < vnLastSize; i++){
        if(vaIsMaskForChar[i]["mask"]) vsDelString += vaIsMaskForChar[i]["char"] == 0 ? 0 : this.maskPrompt;
        else vsDelString += vaIsMaskForChar[i]["char"];
      }
      vsValue = vsValue.substring(0, vnCutPos) + (vaIsMaskForChar[vnPos - 1]["char"] == 0 ? "0" : this.maskPrompt) + vsDelString + vsValue.substring(vnCutPos + 1);
    }
    this.cutPos = vnCutPos;
    this.tempValue = this.evalValue(vsValue);
    this.vbCheck = false;
    return vsValue;
  }
  /////////////////
  if(!this.vbSelectAll){
    this.vsInput = "";
    var vsData = "";
    for(var i = 0; i < vnPos; i++) {
      if(vaIsMaskForChar[i]){
        vnIndex++;
        if(vaIsMaskForChar[i]["mask"]) {
          var vcValue = vsTempValue.charAt(vnIndex).split(" ").join("");
          switch(vaIsMaskForChar[i]["char"]){
          case "A" :
          case "W" :
          case "!" : vcValue = vcValue.toUpperCase();
            break;
          case "^" :
          case "w" :
          case "a" : vcValue = vcValue.toLowerCase();
            break;
          }
          if(new RegExp(vaReg[i]).test(vcValue) && vcValue.length != 0) {
            if(vcValue != this.maskPrompt)vsData += vcValue;
          }else if(vcValue != this.maskPrompt){
            this.vsInput = "fail";
            vbFail = true;
            vsTempValue = vsTempValue.substring(0, vnIndex) + vsTempValue.substring(vnIndex + 1);
            vnPos--;
            vnIndex--;
          }else{
            vsData += vcValue;
          }
        }
      }
    }
    var vnLength = vsValue.length;
    vnLength = vnLength < this.mask.length ? this.mask.length : vnLength - (vnPos + 1);
    //var vnStartIndex = vaIsMaskForChar.length - vnLength - 1;
    var vnStartIndex = vbFail == true ? vnPos : vnPos + 1;
    var vnEndIndex = vaIsMaskForChar.length - 1;
    var vaRevertData = [];
    var vsChar = null;
    var vnIndex = 0;
    for(var i = vnEndIndex; i >= vnPos; i--) {
      vnIndex++;
      if(vaIsMaskForChar[i]["mask"]) {
        var vnToIndex = this.mask.length + 1 - vnIndex;
        vsChar = vsValue.substring(vnToIndex, vnToIndex + 1);
        if(vsChar != this.maskPrompt){
          if(new RegExp(vaReg[i]).test(vsChar)) vaRevertData.push(vsChar);
        }else vaRevertData.push(vsChar);
      }
    }
    //if(vbFail) vsData += vsTempValue.substring(vnPos);
    //else vsData += vsTempValue.substring(vnPos + 1);
    vsData = vsData + vaRevertData.reverse().join("");
    var vsPlusData = "";
    //vnPos = this.getCursorPosition();
    if(vnLen < vnPos){
      var vnIndex = 0;
      vsValue = psValue.substring(vnLen);
      for(var i = 0; vsValue.charAt(vnIndex).length != 0; i++){
        var vnPromptIndex = vsTempValue.indexOf(this.maskPrompt);
        if( vnPromptIndex > 0 && vaIsMaskForChar[vnPromptIndex]["mask"]) {
          var vcValue = vsValue.charAt(vnIndex++);
          switch(vaIsMaskForChar[vnPromptIndex]["char"]){
          case "A" :
          case "W" :
          case "!" : vcValue = vcValue.toUpperCase();
            break;
          case "^" :
          case "w" :
          case "a" : vcValue = vcValue.toLowerCase();
            break;
          }
          if(new RegExp(vaReg[vnPromptIndex]).test(vcValue)) {
            if(vcValue != this.maskPrompt)vsPlusData += vcValue;
          }
        }else vnIndex++;
      }
    }
    vsData += vsPlusData;
  }else{
    var vnIndex = 0;
    var vnValueIndex = 0;
    var vsData = "";
    for(var i = 0; i < vaIsMaskForChar.length; i++){
      if(vaIsMaskForChar[i]["mask"]) {
        var vcValue = vsValue.charAt(vnValueIndex++);
        switch(vaIsMaskForChar[i]["char"]){
          case "A" :
          case "W" :
          case "!" : vcValue = vcValue.toUpperCase();
            break;
          case "^" :
          case "w" :
          case "a" : vcValue = vcValue.toLowerCase();
            break;
         }
        if(new RegExp(vaReg[i]).test(vcValue)) {
          if(vcValue != this.maskPrompt)vsData += vcValue;
        }
      }
    }
  }

  this.tempValue = vsData;
  vsRetVal = this.toStringFormatValue(vsData);
  this.tempValue = this.evalValue(vsRetVal);

  var vsChar = null;
  if(vsRetVal != null) {
    var voIsMaskForChar = null;
    if(vaIsMaskForChar[vnPos]) voIsMaskForChar = vaIsMaskForChar[vnPos];
    while(voIsMaskForChar && voIsMaskForChar["mask"] == false) {
      vnPos++;
      if(vaIsMaskForChar[vnPos]) voIsMaskForChar = vaIsMaskForChar[vnPos];
      else voIsMaskForChar = null;
    }
  }
  if(vnPos == vnLen - 1) vnPos++;
  this.cursorPosition = vnPos;
  this.vbSelectAll = false;
  return vsRetVal;
};
/**
 * 설정한 문자형 포맷으로 값을 변환합니다.
 * @param (String) psValue value 값
 * @return 스트링 포맷이 적용된 문자열 값
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.toStringFormatValue = function(psValue) {
  var voDf = this.df;
  var vrMask = /[#Xx*Aa!^Ww90]/g;
  var vsFormat = this.mask.replace(vrMask, this.maskPrompt);
  var vrMaskPrompt = new RegExp('['+this.maskPrompt+']','i');
  var vsRegValue = "";
  var vnIndex = 0;
  for(var i=0;i < vsFormat.length;i++) {
    var vcFormat = vsFormat.charAt(i);
    if(vcFormat == this.maskPrompt){
      var vcValue = psValue.charAt(vnIndex++);
      if(vcValue.length == 0) vsRegValue += this.mask.charAt(i) == 0 ? 0 : this.maskPrompt;
      else vsRegValue += vcValue;
    }else vsRegValue += vcFormat;
  }
//  for(var i = 0; i < psValue.length; i++){
//    vsRegValue = vsRegValue.replace(vrMaskPrompt, psValue.charAt(i));
//  }
  return vsRegValue;
};
//************************ NUMBERS *********************** //
/**
 * 숫자형 마스크 포맷으로 값을 변환합니다.
 * @param {String} psValue 입력값
 * @param {Boolean} pbData data값인지의 여부
 * @return 숫자형 마스크 포맷 적용 값
 * @type String
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.setNumber = function(psValue, pbData) {
  var voDf = this.df;
  var vnPos =  this.cursorPosition;
  //var vsMask = voDf.mask;
  if(pbData == null) pbData = false;
  var vsMask = this.mask.replace(/[0]/g, "#");
  var vsValue = psValue;
  //if(vsValue.length > vsMask.length){
    //vsValue = psValue.substring(0, vnPos) + (psValue.charAt(vnPos) == "." ? "" : psValue.substring(vnPos + 1));
  //}
  if(psValue.charAt(vnPos) != "." && !pbData) vsValue = psValue.substring(0, vnPos) +
  (psValue.charAt(vnPos) == "." ? "" : psValue.substring(vnPos + 1));
  var vnLen = null;
  var vbMaskHasDecimal = false;
  if(vsMask.indexOf(".") > -1) vbMaskHasDecimal = true;

  vsValue = String(vsValue).replace(/[^\d.-]*/gi, "");
  // make sure there's only one decimal point
  vsValue = vsValue.replace(/\./, "d").replace(/\./g, "").replace(/d/, ".");

  // check to see if an invalid mask operation has been entered
  if(!/^[+-]?((([0#]{1,3},)?([0#]{3},)*([0#]{3}))|([0#]{1,3})+)(\.[0#]*)?$/.test(vsMask.replace(/[^0#.\,\-\+]/gi, ""))) {
    alert("An invalid mask was specified for the \nMask constructor.");
    return psValue;
  }
  if(vsValue.length == 0) vsValue = NaN;
  if(vsValue == "." && vbMaskHasDecimal) vsValue = "0.";
  var vnValue = Number(vsValue);
  if(isNaN(vnValue)) {
    //alert("The value entered was not a number.");
    return "";
  }

  // if no mask, stop processing
  if(vsMask.length == 0) return vsValue;

  // get the value before the decimal point
  var vsInteger = String(Math.abs((vsValue.indexOf(".") > -1) ? vsValue.split(".")[0] : vsValue));
  // get the value after the decimal point
  var vbDecimal = false;
  if(vsValue.indexOf(".") > -1 && vbMaskHasDecimal) vbDecimal = true;
  var vsDecimal = (vbDecimal) ? vsValue.split(".")[1] : "";
  var vbNegative = ((Math.abs(vnValue)*-1 == vnValue) && (Math.abs(vnValue) != 0));

  // check for masking operations
  var vaIsShow = {
    "+" : ((vsMask.indexOf("+") != -1) && !vbNegative),
    "-" : vbNegative,
    "￥" : (vsMask.indexOf("￥") != -1), // Japanese yen
    "￡" : (vsMask.indexOf("￡") != -1), // English Pound
    "€" : (vsMask.indexOf("€") != -1), // /^[€]/.test(m), // Euro
    "$" : (vsMask.indexOf("$") != -1), // /^[\$]/.test(m), // Dollar
    "%" : (vsMask.indexOf("%") != -1), // Percentage
    "(" : (vbNegative && (vsMask.indexOf("(") > -1))
  };

  vaIsShow["-"] = (vbNegative && (!vaIsShow["("] || (vsMask.indexOf("-") != -1)));
  // if mask contain more than one symbol ￥ € $ and %, select just one
  if (vaIsShow["￥"] && ( vaIsShow["￡"] || vaIsShow["€"] || vaIsShow["$"] || vaIsShow["%"] )) vaIsShow["￥"] = false;
  if (vaIsShow["￡"] && ( vaIsShow["€"] || vaIsShow["$"] || vaIsShow["%"] )) vaIsShow["￡"] = false;
  if (vaIsShow["€"] && ( vaIsShow["$"] || show["%"] )) vaIsShow["€"] = false;
  if (vaIsShow["$"] && vaIsShow["%"]) vaIsShow["$"] = false;

  // replace all non-place holders from the mask
  //var vsMask = vsMask.replace(/[^#0._,]*/gi, "");


  var vaMask = vsMask.split(".");

  //pad the int with any necessary zeros

  // get number of digits before decimal point in mask
  var vsIntegerMask = (vaMask[0]) ? vaMask[0] : vsMask;
  vsIntegerMask = vsIntegerMask.replace(/[^0#]+/gi, "");
  // find the first zero, which indicates the minimum length
  // that the value must be padded w/zeros
  vnLen = vsValue.split(".")[0].length;
  if(vnLen > vsIntegerMask.length) {
    vnPos--;
  }
  if(vsInteger.length > vsIntegerMask.length) {
//    vsInteger = vsInteger.substring(0, vsIntegerMask.length);
    vsInteger = vsInteger.substring(vsInteger.length - vsIntegerMask.length);
  }
  var vnFirstZeroMask = vsIntegerMask.indexOf("0") + 1;
  // if there is a zero found, make sure it's padded
  //var vnFillZeroMask = -1;
  if(vnFirstZeroMask > 0) {
    vnFillZeroMask = vsIntegerMask.length - vnFirstZeroMask + 1;

    while(vsInteger.length < vnFillZeroMask) vsInteger = "0" + vsInteger;
  }


  //make sure there are the correct number of decimal places
  // get number of digits after decimal point in mask
  var vsDecimalMask = (vaMask[1]) ? vaMask[1] : "";
  if(vsDecimalMask.length == 0) {
    vsDecimal = "";
  } else {
    // find the last zero, which indicates the minimum number
    // of decimal places to show
    //vsDecimalMask = vsDecimalMask.replace(/[#0]/g, "0");
    //var vsTempDMask = vsDecimalMask.replace(/[#]/g, "%");
    //vsDecimalMask = vsDecimalMask.replace(/[#0]/g, "0");
    var vnLastZeroMask = vsDecimalMask.lastIndexOf("0") + 1;
    while(vsDecimal.length < vnLastZeroMask) vsDecimal += "0";
    //vsDecimalMask = vsTempDMask.replace(/[%]/g, "#");
  }
//  if(vsDecimal.length >= vsDecimalMask.length) {
//    vsDecimal = vsDecimal.substring(0, vsDecimalMask.length);
//  }
  //소수점 마지막위치에서 입력할때의 처리부분
  var vnDeMaskL = vsDecimalMask.length;
  if(vsDecimal.length > vnDeMaskL) {
    var vbZero = false;
    //var vsRealDecimalMask = voDf.mask.split(".")[1];
    var vsDecimalOverVal = vsDecimal.substring(vnDeMaskL);
    vsDecimal = vsDecimal.substring(0, vnDeMaskL);
    var vnNotZero = vsDecimal.indexOf("0");
    if(vsDecimalOverVal.length > vnDeMaskL) {
      vsDecimalOverVal = vsDecimalOverVal.substring(0, vnDeMaskL);
    }
    if(vnNotZero != -1){
      for(var i = vnNotZero; i <= vsDecimal.length; i++){
        if(vsDecimal.charAt(vnNotZero + i) == 0) vbZero = true;
        else {
          vbZero = false;
          i = vsDecimal.length + 1;
        }
      }
    }
    if(vbZero) {
      vsDecimal = vsDecimal.substring(0, vnNotZero) + vsDecimalOverVal +
      vsDecimal.substring(vsDecimalOverVal.length + vnNotZero);
    }
  }
  //check to see if we need commas in the thousands place holder
  //OLD: if( /[#0]+,[#0]{3}/.test(m) ){
  if( /[#0]+,[#0]{3}/.test(vsMask) ){
    // add the commas (or a space) as the place holder
    //added by Sylvain Machefert: we can define _ symbol to replace comma with space (French notation)
    //so mask = #,###.00 => 1,234,567.89
    //   mask = #_###.00 => 1 234 567.89
    var vaIntegerByComma = [];
    var i = 0;
    var vnNum = Number(vsInteger);
    while( vnNum > 999 ){
      vaIntegerByComma[i] = "00" + String(vnNum % 1000);
      vaIntegerByComma[i] = vaIntegerByComma[i].substring(vaIntegerByComma[i].length - 3);
      vnNum = Math.floor(vnNum / 1000);
      i++;
    }
    vaIntegerByComma[i] = String(vnNum % 1000);
    vsInteger = vaIntegerByComma.reverse().join(",");
  }


  //combine the new value together

  //if((vsDecimalMask.length > 0) && this.allowPartial && (vsValue.indexOf(".") > -1)) {
  //if(vsDecimalMask.length > 0 && vsDecimal.length) {
  if(vsDecimalMask.length > 0 && vsDecimal.length) {
    vsValue = vsInteger + "." + vsDecimal;
  } else {
    vsValue = vsInteger;
    if(vbDecimal) vsValue += ".";
  }

  //this.tempValue = vsValue;
  // 포멧이 0인곳에 0을 표시하는부분..
  var vsRegValue = "";
  var vbIsZero = false;
  var vsIntgerValue = vsValue.split(".")[0];
  var vsDecimalValue = vsValue.split(".")[1];
  var vsIntegerMask = this.mask.split(".")[0];
  var vsDecimalMask = this.mask.split(".")[1];
  vsDecimalValue = vsDecimalValue == undefined ? "" : vsDecimalValue;
  for(var i = 0; i < vsIntegerMask.length - vsIntgerValue.length; i++){
    var vcMask = this.mask.charAt(i);
    if(vcMask == 0) vbIsZero = true;
    if(vsRegValue.length != 0 && vcMask == "#") {
      vsRegValue = "";
      vbIsZero = false;
    }else if(vbIsZero) vsRegValue += vcMask;
  }
  vsValue = vsRegValue + vsValue;
  //소수점부분에서 포멧이 0인부분 처리
  if(vsValue.indexOf(".") > -1 && vsDecimalMask.replace(/0/g, "").length == 0
      && vsDecimalValue.length < vsDecimalMask.length && Number(vsDecimalValue) <= 0){
    vsDecimalValue = vsDecimalMask.substring(0, vsDecimalMask.length - vsDecimalValue.length) + vsDecimalValue;
  }else vsDecimalValue = "";
  vsValue += vsDecimalValue;

  vnLen = psValue.split(".")[0].length;
  if(vaIsShow["+"]) vsValue = "+" + vsValue;
  if(vaIsShow["-"]) vsValue = "-" + vsValue;
  if(vaIsShow["￥"]) vsValue = vsValue + "￥";
  if(vaIsShow["￡"]) vsValue = "￡" + vsValue;
  if(vaIsShow["€"]) vsValue = "€ " + vsValue; // this.mask.replace(/(^[€])(.+)/gi, "€ ") + v;
  if(vaIsShow["$"]) vsValue = "$" + vsValue; // this.mask.replace(/(^[\$])(.+)/gi, "$ ") + v;
  if(vaIsShow["%"]) vsValue = vsValue + " %";
  if(vaIsShow["("]) vsValue = "(" + vsValue + ")";
//  var vnLen2 = vsValue.split(".")[0].length;
//  if(vnLen2 - vnLen > 0) {
//    vnPos = vnPos + (vnLen2 - vnLen);
//  }
//  this.cursorPosition = vnPos;
  this.tempValue = vsValue;
  return vsValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "EditMask"
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.toString = function() {
  return "EditMask";
};
/**
 * 현재 텍스트가 전체 select 되어있는지 여부를 확인합니다.
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.checkSelect = function() {
  var voDf = this.df;
  var voDocument = this.document;
  var voCanvas = this.canvas;
  var voInput = this.subElement.input;
  var vnTextLen = this.mask.length;
  this.vbSelectAll = false;
  if(voCanvas.page.metadata.browser.ie){
    var voTextRange = voDocument.selection.createRange();
    var vnLen = voTextRange.text.length;
    this.selectionSize = vnLen == 0 ? 1 : vnLen;
    if(vnLen == vnTextLen) this.vbSelectAll = true;
  }else{
    if(voInput.selectionEnd - voInput.selectionStart == vnTextLen) this.vbSelectAll = true;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.atselect = function(poEvent){
//  this.checkSelect();
};
/**
 * @ignore
 */
eXria.controls.xhtml.EditMask.prototype.atclick = function(poEvent){
//  this.checkSelect();
};
/**
 * 텍스트값을 삭제시 사용자가 정의한 마스크를 제외한값을 삭제합니다.
 * @param poEvent
 * @return 삭제하고 난 후의 값
 * @private
 */
eXria.controls.xhtml.EditMask.prototype.chkBackSpace = function(poEvent){
  var voDf = this.df;
  var vnKeyCode = poEvent.keyCode;
  var vnPos = this.getCursorPosition();
  var vsValue = null;
  var vnCutPos = 0;
  //var voStringReg = new RegExp("[^#*XxAa!Ww9^]","g");
  var voDateReg = new RegExp("[^YMDhms]","g");
  var voValues = new Array;
  if(this.vbSelectAll) return "";
  this.vbCheck = true;
  var voReg = voDateReg;
  var voRegI = /[YMDhms]/g;
  if(voReg.test(this.mask.charAt(vnPos))){
      vsValue = this.tempValue;
      if(vsValue == null || vsValue == undefined || vsValue.legnth == 0) vsValue = "";
      else vsValue = this.toDateFormatValue(vsValue);
      if(vnKeyCode == 8){
        vnCutPos = this.mask.replace(voRegI, this.maskPrompt).substring(0, vnPos).lastIndexOf(this.maskPrompt);
        if(vnCutPos < 0) vnCutPos = 0;
        vsValue = vsValue.substring(0, vnCutPos) + this.maskPrompt + vsValue.substring(vnCutPos + 1);
        voValues[1] = vnCutPos;
      }else{
        vnCutPos = this.mask.replace(voRegI, this.maskPrompt).substring(vnPos).indexOf(this.maskPrompt);
        vnCutPos += vnPos;
        vsValue = vsValue.substring(0, vnCutPos) + this.maskPrompt + vsValue.substring(vnCutPos + 1);
      }
      voValues[0] = vsValue;
  }
  return voValues;
};

/**
 * 주어진 포맷에 의해 데이타를 필터링하는 메소드
 * @param {String} psData 데이타
 * @param {String} psFormat 포맷 문자열
 * @return 주어진 포맷에 의해 필터링된 데이타 값
 * @type String
 */
eXria.controls.xhtml.EditMask.prototype.getFormatedValue = function(psData, psFormat) {
  if(psData == null || psData == "") return psData;
  if(psFormat == null || psFormat == "") return psData;
  var voRegMap = {"x": "[A-Za-z0-9]", "X": "[A-Za-z0-9]", "#": "[0-9]", "*": ".", "S" : "[a-zA-Z0-9\\xC0-\\xD6\\xD8-\\xF6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD]"};
  var vsRegValue = "";
  var vnIndex = 0;
  var vnSize = psFormat.length;
  var vsFormatChar = null;
  var vsChar = null;
  var vnValLen = psData.length;
  var vsRegStr = null;
  for(var i=0; i <= vnSize; i++) {
    vsFormatChar = psFormat.charAt(i);
    vsChar = psData.charAt(vnIndex);
    vsRegStr = voRegMap[vsFormatChar];
    if(vsRegStr && (new RegExp(vsRegStr)).test(vsChar)) {
			vsRegValue += vsChar;
			vnIndex++;
		} else {
			vsRegValue += vsFormatChar;
		}
    if(vnIndex >= vnValLen) break;
  }
  return vsRegValue;
};