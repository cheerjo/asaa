/**
 * @fileoverview
 * Concreate xhtml FreeForm(XHTML FreeForm 컨트롤)
 * @author : 조영진
 */

/**
 * @class Concreate xhtml FreeForm.<br>
 * XHTML FreeForm 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.FreeForm 객체
 * @type eXria.controls.xhtml.FreeForm
 * @constructor
 * @base eXria.controls.xhtml.Group
 */
eXria.controls.xhtml.FreeForm = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pbTableLayout) {
  if(pbTableLayout != true && page.tableLayoutMap && page.tableLayoutMap[psId] != null) {
    this.inheritTableLayout(psId, pnLeft, pnTop, pnWidth, pnHeight);
    return;
  }
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight = pnHeight == null ? 300 : pnHeight;

  eXria.controls.xhtml.Group.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight, true);  // UIControl을 상속받는다.
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 프린트 작업 담당 오브젝트.
   * @type eXria.controls.xhtml.Print
   */
  this.printObject = null;
  /**
   * 화면에 표시될 인스턴스 데이타의 row index(base 0)
   * @type Number
   */
  this.rowIndex = 0;
  /**
   * 그리도 연동 데이타 셋 참조 변수
   * @type eXria.data.plugin.DataSetCmd
   */
  this.dataset = null;

  this.cursor = null;
	
	this.recursiveCnt = 0;
	this.recursiveMap = new eXria.data.ArrayMap();
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Group, eXria.controls.xhtml.FreeForm);
//////////////////////////////////////////////////////////////////
// 메소드

eXria.controls.xhtml.FreeForm.prototype.loadData = function(poDocument, pbKeepStatus) {
  if(this.datasetId == null || this.datasetId == "") {
    this.loadDataFromInstance(poDocument);
  } else {
    this.loadDataFromDataSet(poDocument, pbKeepStatus);
  };
};
/**
 * loadDataFromInstance.
 * 인스턴스 데이타 연동 메소드.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.FreeForm.prototype.loadDataFromInstance = function(poDocument) {
  var voData = this.data;
  var vsInstanceId = voData.nodesetInstanceId;
  var vsInstancePath = voData.nodesetInstancePath;
  if(vsInstanceId == null || vsInstancePath == null) return;
  var voCtrl = this.getCtrl(poDocument);
  //this.removeChildren();

  var voCollectionNode = voData.getNodesetData2();
  if(voCollectionNode == null) return;
  var vnLoop = voCollectionNode.getLength();
  var voMapNode = null;
  var vsValue = null;
  var voChildData = null;
  var vnRowIndex = this.rowIndex;
  for(var i = 0; i < vnLoop; i++) {
    if(vnRowIndex != i) continue;
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
    var voChild = null;
    var voIterator = this.controls.iterator();
    var vsId = null;
    var vsPath = null;
    var vsType = null;
    var vsValue = null;
    var vbJsonPath = page.metadata.useJsonInstance && (page.metadata.useDomPath != true);
		
		var voMap = null;
		var vnMapLength = null;
		
    while(voIterator.hasNext()) {
      voChild = voIterator.next();

			if(voChild.controls != null) {
				this.recursiveControl(voChild);
				voMap = this.recursiveMap;
			}

			if(voMap == null) vnMapLength = 1;
			else vnMapLength = voMap.size();
			
			for(var i = 0; i < vnMapLength; i++) {
				if(voMap != null) voChild = voMap.get(i);
				voChildData = voChild.data;
				
	      if(voChildData != null) {
	        var vbNotAttached = false;
	        if(voChild.canvas == null) {
	          voChild.canvas = this.canvas;
	          vbNotAttached = true;
	        }
	        vsId = voChildData.instancePath;
	        if(vsId) {
	          vsId = vsId.split("/");
	          vsId = vsId[vsId.length - 1];
	          vsPath = vsInstancePath + "[" + (vbJsonPath ? vnRowIndex : (vnRowIndex + 1)) + "]/" + vsId;
	          voChildData.setRef(vsInstanceId, vsPath);
	          voChildData.markUpdateAbove = true;
	          vsType = voChild.toString();
	          if(vsType == "DateInput" || vsType == "EditMask") {
	            vsValue = voChildData.getData();
	            if(vsValue != null && vsValue != "") {
	              if(voChild.maxLength == null) voChild.maxLength = vsValue.length;
	            }
	          }
	//         vsValue = voMapNode.get(vsId);
	//         if(vsValue == null) vsValue = "";
	//         voChildCtrl = voChild.getCtrl(poDocument);
	//         if(voChildCtrl) {
	//          if(voChild.setValue) voChild.setValue(vsValue, null, poDocument);
	//         } else {
	//          voChild.value = vsValue;
	//         }
	        }
	        if(vbNotAttached) voChild.canvas = null;
	      }
			}
			this.recursiveCnt = 0;
			this.recursiveMap.clear();
			voMap = null;
			vnMapLength = null;
    }
    break;
//    if(this.printMode == false) break;
  }
};
eXria.controls.xhtml.FreeForm.prototype.recursiveControl = function(poSubChild) {
	var voSubChild = null;
	if(poSubChild != null && poSubChild.controls != null) {
		var voSubIterator = poSubChild.controls;
		
		for(var i = 0; i < voSubIterator.size(); i++) {
			voSubChild = voSubIterator.get(i);
			
			if(voSubChild.controls != null) {
				this.recursiveControl(voSubChild);
			} else {
				this.recursiveMap.put(this.recursiveCnt, voSubChild);
				this.recursiveCnt += 1;
			}
		}
	}
};
/**
 * loadDataFromDataset.
 * dataset을 통한 데이타 연동 메소드.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.FreeForm.prototype.loadDataFromDataSet = function(poDocument, pbKeepStatus) {
  var vsDataSetId = this.datasetId;
  if(this.dataset == null) this.dataset = this.canvas.page.model.getDataSet(vsDataSetId);
  var voDataSet = this.dataset;
  if(voDataSet == null) return;
//  voDataSet.setDataSync(true);
  if(!pbKeepStatus) voDataSet.rebuild(false);

  var voCtrl = this.ctrl;

  var vnLoop = voDataSet.getRowCnt();
  var voMapNode = null;
  var vsValue = null;
  var voChildData = null;
  for(var i = 0; i < vnLoop; i++) {
    if(this.rowIndex != i) continue;
    var voChild = null;
    var voIterator = this.controls.iterator();
    var vsId = null;
    var vsPath = null;
    var vsType = null;
    var vsValue = null;
    var voMap = null;
    var vnMapLength = null;
    
    while(voIterator.hasNext()) {
      voChild = voIterator.next();
      
      if(voChild.controls != null) {
        this.recursiveControl(voChild);
        voMap = this.recursiveMap;
      }

      if(voMap == null) vnMapLength = 1;
      else vnMapLength = voMap.size();
      
      for(var j = 0; j < vnMapLength; j++) {
        
        if(voMap != null) voChild = voMap.get(j);
        voChildData = voChild.data;
        
        if(voChildData != null) {
          vsDatasetCol = null;
          if(voChild.datasetCol) vsDatasetCol = voChild.datasetCol;
          if(vsDatasetCol) {
            var voDataProxy = new eXria.controls.DataProxy(voDataSet, vsDataSetId, vsDatasetCol, i);
            if(voChildData.isProxy) voDataProxy.data = voChildData.data;
            else voDataProxy.data = voChildData;
            if(voChildData.nodesetInstanceId && voChildData.nodesetInstancePath) {
              voDataProxy.nodesetInstanceId = voChildData.nodesetInstanceId;
              voDataProxy.nodesetInstancePath = voChildData.nodesetInstancePath;
            }
            voChild.data = voDataProxy;
            vsType = voChild.toString();
  //          if(vsType == "DateInput" || vsType == "EditMask") {
  //            vsValue = voDataProxy.getData();
  //            if(vsValue != null && vsValue != "") {
  //              voChild.maxLength = vsValue.length;
  //            }
  //          }
          }
        }
      }
      this.recursiveCnt = 0;
      this.recursiveMap.clear();
      voMap = null;
      vnMapLength = null;
    }
  }
};

eXria.controls.xhtml.FreeForm.prototype.reloadData = function(poCtrl, poDocument, pbKeepStatus) {
  this.loadData(poDocument, pbKeepStatus);
  var voChild = null;
  var voIterator = this.controls.iterator();
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild.toString() == "ComboBox")  voChild.refresh();
    if(voChild.reloadData) voChild.reloadData();
  }
};

eXria.controls.xhtml.FreeForm.prototype.refreshData = function(poCtrl, poDocument, pbKeepStatus) {
  this.loadData(poDocument, pbKeepStatus);
  var voChild = null;
  var voMap = null;
  var vnMapLength = null;
  var voIterator = this.controls.iterator();
  
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    
    if(voChild.controls != null) {
      this.recursiveControl(voChild);
      voMap = this.recursiveMap;
    }
    
    if(voMap == null) vnMapLength = 1;
    else vnMapLength = voMap.size();
      
    for(var i = 0; i < vnMapLength; i++) {
      if(voMap != null) voChild = voMap.get(i);
      if(voChild.refreshData) voChild.refreshData(poCtrl, poDocument, pbKeepStatus);
    }
    
    this.recursiveCnt = 0;
    this.recursiveMap.clear();
    voMap = null;
    vnMapLength = null;
  }
};

eXria.controls.xhtml.FreeForm.prototype.refresh = function(poDocument, pbKeepStatus) {
  if(poDocument == null) poDocument = this.document;

  if(this.removeUIGeneralDefaults) { this.removeUIGeneralDefaults(this.ctrl, poDocument); };           // 공통 초기값으로 지정된 속성값을 제거
  if(this.removeSpecificDefaults) { this.removeSpecificDefaults(this.ctrl, poDocument); };             // 개별 초기값으로 지정된 속성값을 제거

  if(this.refreshTemplate) { this.refreshTemplate(this.ctrl, poDocument); };
  if(this.refreshMainStyles) { this.refreshMainStyles(this.ctrl, poDocument); };                       // Main Style 새로고침
  if(this.refreshSubStyles) { this.refreshSubStyles(this.ctrl, poDocument); };                         // Composite Child Style 새로고침

  if(this.refreshUIGeneralDefaults) { this.refreshUIGeneralDefaults(this.ctrl, poDocument); };         // 공통 초기값으로 새로고침
  if(this.refreshSpecificDefaults) { this.refreshSpecificDefaults(this.ctrl, poDocument); };           // 개별 초기값으로 새로고침

  if(this.refreshSpecificAttrs) { this.refreshSpecificAttrs(this.ctrl, poDocument); };                 // 개별 속성으로 새로고침

  if(this.refreshSpecificEvents) { this.refreshSpecificEvents(this.ctrl); };                          // 개별 Events로 새로고침

  if(this.reloadData) { this.reloadData(this.ctrl, poDocument, pbKeepStatus); };                                   // Data 새로고침
  if(this.refreshComplete) {this.refreshComplete(this.ctrl, poDocument); };                           // 새로고침 최종 처리
};
/**
 * freeform을 다음 페이지 데이타로 새로고침 합니다.
 */
eXria.controls.xhtml.FreeForm.prototype.moveToNextPage = function() {
  var vnPageCount = this.getPageCount();
  if(this.rowIndex < vnPageCount - 1) {
    this.rowIndex++;
    this.refreshData(null, null, true);
  }
};
/**
 * freeform을 이전 페이지 데이타로 새로고침 합니다.
 */
eXria.controls.xhtml.FreeForm.prototype.moveToPrevPage = function() {
  if(this.rowIndex > 0) {
    this.rowIndex--;
    this.refreshData(null, null, true);
  }
};
/**
 * freeform을 지정된 페이지 데이타로 새로고침 합니다.
 * @param {Number} pnIndex 표시될 page index(0부터 시작)
 */
eXria.controls.xhtml.FreeForm.prototype.moveToPage = function(pnIndex) {
  var vnPageCount = this.getPageCount();
  if(pnIndex >= 0 && pnIndex < vnPageCount) {
//    if(pnIndex == this.rowIndex) return;
    this.rowIndex = pnIndex;
    this.refreshData(null, null, true);
  }
};
/**
 * 데이타 페이지 수를 반환합니다.
 * @return 데이타 페이지 수
 * @type Number
 */
eXria.controls.xhtml.FreeForm.prototype.getPageCount = function() {
  var vnCnt = 0;
  var vsDataSetId = this.datasetId;
  if(vsDataSetId == null) {
    var voData = this.data;
    var vsInstanceId = voData.nodesetInstanceId;
    var vsInstancePath = voData.nodesetInstancePath;
    if(vsInstanceId == null || vsInstancePath == null) return 0;
    var voCollectionNode = voData.getNodesetData2();
    if(voCollectionNode == null) return 0 ;
    vnCnt = voCollectionNode.getLength();

  } else {
    var voDataSet = this.canvas.page.model.getDataSet(vsDataSetId);
    if(voDataSet == null) return 0;
    vnCnt = voDataSet.getRowCnt();
  };
  return vnCnt;
};
/**
 * 프린트 창을 호출합니다.
 * @private
 */
eXria.controls.xhtml.FreeForm.prototype.print = function(){
  this.window.PrintForm = this;
  var voWindow = this.window.open(this.canvas.page.metadata.resourceBaseUrl + "eXria/controls/xhtml/eXria.controls.xhtml.FreeFormPrint.html","FreeFormPrint","",false);
};
/**
 * 프린트 창에 출력될 전체 폼을 디스플레이 합니다.
 * @param {HTMLWindow} voWindow
 * @private
 */
eXria.controls.xhtml.FreeForm.prototype.printForm = function(voWindow) {
  this.setPrintingState(true);
  var voDocument = voWindow.document;
  var voHead = voDocument.getElementsByTagName("head")[0];
  var voLink = null;
  if(this.printObject.css) {
    voLink = voDocument.createElement("link");
    voLink.setAttribute("href", this.printObject.css);
    voLink.setAttribute("type", "text/css");
    voLink.setAttribute("rel", "stylesheet");
    voHead.appendChild(voLink);
  } else {
    var vaStyleSheet = voDocument.styleSheets;
    if(!vaStyleSheet) vaStyleSheet = voDocument.getElementsByTagName("link");
    if(vaStyleSheet) {
      for (var i = 0; i < vaStyleSheet.length; i++) {
        voLink = voDocument.createElement("link");
        voLink.setAttribute("href", vaStyleSheet[i]);
        voLink.setAttribute("type", "text/css");
        voLink.setAttribute("rel", "stylesheet");
        voHead.appendChild(voLink);
      }
    } //end of if(vaStyleSheet)
  } //end of if(this.printCSS)
  this.printObject.create(voDocument);
  this.printObject.repeatForm();
  this.setPrintingState(false);
};
/**
 * 컨트롤의 프린트 출력 상태를 설정합니다.
 * @param {Boolean} pbPrinting 프린팅 여부
 * @private
 */
eXria.controls.xhtml.FreeForm.prototype.setPrintingState = function(pbPrinting) {
  this.printMode = pbPrinting;
  var voIterator = this.controls.iterator();
  var voControl = null;
  var vsId = null;
  while(voIterator.hasNext()) {
    voControl = voIterator.next();
    voControl.printMode = pbPrinting;
  }
};

eXria.controls.xhtml.FreeForm.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.FreeForm[psAttrName];
  if(vsDefaultValue == null) vsDefaultValue = eXria.controls.xhtml.Default.Group[psAttrName];
  if(vsDefaultValue === undefined) {
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "FreeForm"
 * @type String
 */
eXria.controls.xhtml.FreeForm.prototype.toString = function() {
  return "Freeform";
};
/**
 * TableLayout 상속.
 * @private
 */
eXria.controls.xhtml.FreeForm.prototype.inheritTableLayout = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  eXria.controls.xhtml.TableLayout.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  var parentProto = eXria.controls.xhtml.TableLayout.prototype;
  for(psAttr in parentProto) {
    this[psAttr] = parentProto[psAttr];
  }
};
