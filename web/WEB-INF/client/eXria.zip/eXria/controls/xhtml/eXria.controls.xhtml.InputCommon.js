/**
 * @fileoverview
 * Input 컨트롤에 대한 xhtml 공통 클래스
 * @author kim doohwan
 */

/**
 * @class XHTML EditMask, InputBox, SecretBox의 상위클래스입니다.<br />
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.InputCommon 객체
 * @type eXria.controls.xhtml.InputCommon
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */

eXria.controls.xhtml.InputCommon = function(psId, pnLeft, pnTop, pnWidth, pnHeight){

  eXria.controls.xhtml.UIControl.call(this, psId,pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */
  this.data = new eXria.controls.DataRefNode(this);
  ////속성
  /**
   * 컨트롤 설정 값.
   * @type String
   */
  this.value = null;
  /**
   * 입력 가능한 문자열의 최대 길이.
   * @type Number
   */
  this.maxLength = null;
  /**
   * 입력 가능한 문자열의 최소 길이.
   * @type Number
   */
  this.minLength = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 텍스트 세로 정렬 방식.<br>
   * "top" | "middle" | "bottom"
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트에 줄을 넣을때.<br>
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 텍스트의 대소문자를 지정할때.<br>
   * "capitalize" | "uppercase" | "lowercase"
   * @type String
   */
  this.textTransform = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 컨트롤의 안쪽 여백(단위 px).
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤의 안쪽 상단여백(단위 px).
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤의 안쪽 우측여백(단위 px).
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤의 안쪽 하단여백(단위 px).
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 컨트롤의 안쪽 좌측여백(단위 px).
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤이 포커싱 되어 있는지 여부
   * @private
   */
  this.focused = false;
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
  /**
   * 사용자 정의 nullable 속성
   * @type Boolean
   */
  this.nullable = true;
  /**
   * input element ime-mode 설정 속성
   * @type String
   */
  this.imeMode = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.InputCommon);

eXria.controls.xhtml.InputCommon.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  voCtrl["accesskey"] = this.accessKey;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};

eXria.controls.xhtml.InputCommon.prototype.refreshTemplate = null;

eXria.controls.xhtml.InputCommon.prototype.setSpecificEvents = function(poCtrl){
  var voInput = this.subElement.input;
  //@data  TODO: 테스트 필요...
  voInput.control = this;
//  this.eventManager.removeListener(poCtrl, "onmouseover", this.mediateEvent);
//  this.eventManager.removeListener(poCtrl, "onmouseout", this.mediateEvent);
//  this.eventManager.addListener(voInput, "onmouseover", this.mediateEvent);
//  this.eventManager.addListener(voInput, "onmouseout", this.mediateEvent);
//  this.eventManager.addListener(voInput, "onchange", this.mediateEvent);
  this.eventManager.addListener(voInput, "onfocus", this.mediateEvent);
  this.eventManager.addListener(voInput, "onblur", this.mediateEvent);
  this.eventManager.addListener(voInput, "onselect", this.mediateEvent);
};
/**
 * @ignore
 */
eXria.controls.xhtml.InputCommon.prototype.finalkeydown = function(e) {
  this.isEnter = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.InputCommon.prototype.atkeyup = function(e){
  var vnMaxByteLength = this.maxByteLength;
  if(!vnMaxByteLength) return;

  vnMaxByteLength = Number(vnMaxByteLength);
  var voInput = this.subElement.input;
  var vsValue = voInput.value;
  if(eXria.util.StringUtil.getByteLength(vsValue) > vnMaxByteLength){
    this.isEditing = true;
    voInput.disabled = true;
    voInput.disabled = false;
    var vnLength = vsValue.length;
    for(var i = 1; i < vnLength; i++) {
      if(eXria.util.StringUtil.getByteLength(vsValue.substring(0,vnLength - i)) <= vnMaxByteLength) {
        voInput.value = vsValue.substring(0,vnLength - i);
        break;
      }
    }

    var vnPos = voInput.value.length;
    if (voInput.createTextRange) {
      var range = voInput.createTextRange();
      range.collapse(true);
      range.moveEnd('character', vnPos);
      range.moveStart('character', vnPos);
      range.select();
    } else if (voInput.selectionEnd) {
      voInput.selectionStart = vnPos;
      voInput.selectionEnd = vnPos;
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.InputCommon.prototype.doblur = function() {
  var voInput = this.subElement.input;
  var voDocument  = this.document;

  if(this.toString && this.toString() == "DateInput"){
    this.calendarShowed = false;
  };
  try{
    if(voDocument.activeElement == voInput) {
      voInput.blur();
      voInput.disabled = true;
      voInput.disabled = false;
    }
  }catch(err){}
};
/**
 * @ignore
 */
eXria.controls.xhtml.InputCommon.prototype.refreshSpecificEvents = function(poCtrl) {
  this.setSpecificEvents(poCtrl);
};

eXria.controls.xhtml.InputCommon.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  //if(this.data.instanceId == null || this.data.isRelativeRef()) return;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;
  var vsRefData = this.data.getData();
  this.setValue(vsRefData);
};
/**
 * @ignore
 */
eXria.controls.xhtml.InputCommon.prototype.loadComplete = function(poDocument, pbReloadData) {
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  if(this.onchangeInitValue == null) this.onchangeInitValue = voInput.value;

  // todo : yhkim 2009.09.08 실제 이 코드는 사용자 정의 css때문에 정의 된 것인데 inputbox계열 outer는 back-ground color가 있어야 한다
  //var voSubElement = this.getSubCtrl("input", voCtrl, poDocument);
  if(voInput) {
    var vsColor = this.getStyleCurrentValue(voInput, "background-color", "backgroundColor");
    if(vsColor) this.setAttrCtrl("backgroundColor", vsColor, voCtrl);
  }

  this.setInputHeight(voCtrl);
  this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);

  // refreshspecific과 reloadData에서 중복 호출 됨으로써 padding-left가 초기화되는 현상 방지
  if(!pbReloadData) this.setInputWidth(poDocument);
};
/**
 * input element 의 가로 길이 설정 메소드.
 * @private
 */
eXria.controls.xhtml.InputCommon.prototype.setInputWidth = function() {
  var voCtrl = this.ctrl;
  var voSubElement = this.subElement.input;
  var vnPaddingLeft = parseInt(this.getStyleCurrentValue(voSubElement, "padding-left", "paddingLeft"), 10);
  var vnPaddingRight = parseInt(this.getStyleCurrentValue(voSubElement, "padding-right", "paddingRight"), 10);
  var vnBorderLeft = parseInt(this.getStyleCurrentValue(voCtrl, "border-left-width", "borderLeftWidth"), 10);
  var vnBorderRight = parseInt(this.getStyleCurrentValue(voCtrl, "border-right-width", "borderRightWidth"), 10);
  vnPaddingLeft = vnPaddingLeft == null ? 0 : vnPaddingLeft;
  vnPaddingRight = vnPaddingRight == null ? 0 : vnPaddingRight;
  vnBorderLeft = vnBorderLeft == null ? 0 : vnBorderLeft;
  vnBorderRight = vnBorderRight == null ? 0 : vnBorderRight;

  //상위 Dom이 display 가 none 일경우 offsetWidth 를 통해서 제대로된
  //width값이 넘어 오지 안기 때문에
  //voCtrl.offsetWidth 를 this.width 로 변경
  //2011.04.21

  var vnWidth = this.width - vnBorderLeft - vnBorderRight - 1;
  vnWidth = vnWidth - (vnPaddingLeft + vnPaddingRight);
  this.setAttrCtrl("left", vnPaddingLeft, voSubElement);
  this.setAttrCtrl("width", vnWidth, voSubElement);
  this.setAttrCtrl("paddingLeft", "0px", voSubElement);
  this.setAttrCtrl("paddingRight", "1px", voSubElement);
  if(this.subElement.divDate  && this.width > 0 )
    this.setAttrCtrl("left", this.width - vnBorderRight - this.imgAreaWidth - vnPaddingRight, this.subElement.divDate);
  if(this.subElement.divSpin && this.width > 0 )
    this.setAttrCtrl("left", this.width - vnBorderRight - this.spinWidth - vnPaddingRight, this.subElement.divSpin);
};

eXria.controls.xhtml.InputCommon.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
  this.loadComplete(poDocument, true);
};

eXria.controls.xhtml.InputCommon.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
  this.maskLen = null;
};
/**
 * 텍스트 박스의 텍스트 세로 길이 설정 메소드.
 * @param {HTMLDiv} poCtrl
 * @private
 */
eXria.controls.xhtml.InputCommon.prototype.setInputHeight = function(poCtrl){
  var voInput = this.subElement.input;
  var vsText = voInput.value;
  var voSpan = this.subElement.span;
  voSpan.innerHTML = "&nbsp;";

//  var vnHeight = voSpan.offsetHeight;
//  this.setAttrCtrl("height", vnHeight, voInput);

  var vnHeight = voSpan.offsetHeight;

  //TODO : 임시처리
  if(!!vnHeight) this.backupHeight = vnHeight;
  if(!!this.backupHeight) vnHeight = this.backupHeight;

  var voCtrl = this.ctrl;
  var vnPaddingTop = parseInt(this.getStyleCurrentValue(voInput, "padding-top", "paddingTop"), 10);
  var vnPaddingBottom = parseInt(this.getStyleCurrentValue(voInput, "padding-bottom", "paddingBottom"), 10);
  var vnBorderTop = parseInt(this.getStyleCurrentValue(voCtrl, "border-top-width", "borderTopWidth"), 10);
  var vnBorderBottom = parseInt(this.getStyleCurrentValue(voCtrl, "border-bottom-width", "borderBottomWidth"), 10);

  //var vnHeight = this.height - (vnPaddingTop+vnPaddingBottom);
  //vnHeight = vnHeight - (vnBorderTop + vnBorderBottom);

  this.setAttrCtrl("paddingTop", vnPaddingTop+"px", voInput);
  this.setAttrCtrl("paddingBottom", vnPaddingBottom+"px", voInput);
  this.setAttrCtrl("borderTopWidth", vnBorderTop +"px", voInput);
  this.setAttrCtrl("borderBottomWidth", vnBorderBottom+"px", voInput);

  //top의 위치 조정은 setVerticalAlign 에서 담당
  //this.setAttrCtrl("top", (vnPaddingTop+vnPaddingBottom)+(vnBorderTop + vnBorderBottom), voInput);

  this.setAttrCtrl("height", vnHeight, voInput);

};
/**
 * 컨트롤 텍스트 수직정렬을 새로고침 합니다.
 */
eXria.controls.xhtml.InputCommon.prototype.refreshVerticalAlign = function() {
  var voCtrl = this.ctrl;
  if(voCtrl == null) return;
  var voDf = this.df;
  var voInput = this.subElement.input;
  this.setInputHeight();
  this.setVerticalAlign(voInput, voCtrl, this.verticalAlign);
};
/**
 * 컨트롤의 값을 반환합니다.
 * @return 컨트롤에 할당된 값
 * @type String
 */
eXria.controls.xhtml.InputCommon.prototype.getValue = function(){
  return this.value;
};
/**
 * 입력필드에 보여지는 텍스트값을 반환합니다.
 * @return 입력필드에 보여지는값
 * @type String
 */
eXria.controls.xhtml.InputCommon.prototype.getText = function() {
  var voInput = this.subElement.input;
  var vsText = voInput.value;
  return vsText;
};
/**
 * 텍스트를 선택상태로 만듭니다.
 */
eXria.controls.xhtml.InputCommon.prototype.selectText = function() {
  var voCtrl = this.ctrl;
  var voInput = this.subElement.input;
  var vnPos = voInput.value.length;
  if(vnPos == 0) {
    try { voInput.focus(); }catch(err) {}
  }else {
    var vsText = voInput.value;
    if(this.value != vsText && vsText == "NaN") {
      voInput.value = "";
      vnPos = 0;
    }
    if (voInput.createTextRange) {
      var range = voInput.createTextRange();
      range.collapse(true);
      range.moveEnd('character', vnPos);
      range.moveStart('character', 0);
      range.select();
    } else if (voInput.selectionEnd) {
      voInput.selectionStart = 0;
      voInput.selectionEnd = vnPos;
      if(this.focused == false){
        try { voInput.focus(); }catch(err) {}
        this.focused = true;
      }
    }
  }
};
/**
 * 데이트형 입력 값이 mask에 형태와 다르게 숫자만 입력될 경우
 * mask에 숫자 부분에 해당되는 값만을 가져오기 위한 메소드;
 * @param {String} psInputVal input 영역에 입력된 값
 */
eXria.controls.xhtml.InputCommon.prototype.filterDateInput = function(psInputVal){
  var vsRet = psInputVal;
  if(/^\d*$/.test(vsRet) == false || vsRet == "") return vsRet;
  var vsDigitMask = this.mask;
  if(vsDigitMask == null || vsDigitMask == "") return vsRet;
  vsDigitMask = vsDigitMask.replace(/[^YyMDdhms]/g, "");
  if(vsRet.length > vsDigitMask.length) vsRet = vsRet.substring(0, vsDigitMask.length);
  return vsRet;
};
/**
 * 커서 위치를 설정합니다.
 * @param {Number} pnPos 커서 위치 값
 */
eXria.controls.xhtml.InputCommon.prototype.setCursorPosition = function(pnPos) {
  var voInput = this.subElement.input; 
  
  if(this.focused == false) {
    var voBase = this;
    this.afFocusAct = { func : voBase.setCursorPosition,
                      args : [pnPos]};
  }
  if(voInput.selectionEnd) {
    voInput.selectionStart = pnPos;
    voInput.selectionEnd = pnPos;
  } else if (voInput.createTextRange) {
    var voRange = voInput.createTextRange();
    voRange.collapse(true);
    voRange.moveEnd('character', pnPos);
    voRange.moveStart('character', pnPos);
    voRange.select();
  }
};
