/**
 * @fileoverview
 * Abstract TableLayout(UI 컨트롤들을 그룹짓는 클래스)
 * @author 정희수
 */

/**
 * @class TableLayout (추상클래스).<br>
 * UI 컨트롤들을 그룹짓는 클래스.
 * @version 1.0
 * @constructor
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.TableLayout 객체
 * @type eXria.controls.TableLayout
 */
eXria.controls.TableLayout = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  //////////////////////////////////////////////////////////////////
  // 속성
  eXria.controls.Group.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
};

//eXria.controls.xhtml.Util.createInheritance(eXria.controls.Group, eXria.controls.TableLayout);
//////////////////////////////////////////////////////////////////
// 메소드
eXria.controls.TableLayout.prototype.setCellSpan = null;

eXria.controls.TableLayout.prototype.getCellSpan = null;