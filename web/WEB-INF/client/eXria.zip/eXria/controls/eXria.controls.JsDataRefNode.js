/**
 * @fileoverview
 * Node Data Reference class(노드 데이타 레퍼런스 기본 클래스)
 * @author 조동일
 */

/**
 * @class Node Data Reference classs.<br>
 * 노드 데이타 레퍼런스 기본 클래스.
 * @version 1.0
 * @constructor
 * @base eXria.controls.DataRef
 * @param {Object} poControl page의 Instance가 참조 가능한 컨트롤 객체
 * @return 새로운 eXria.controls.JsDataRefNode 객체
 * @type eXria.controls.JsDataRefNode
 */
eXria.controls.JsDataRefNode = function(poControl) {
  eXria.controls.DataRef.call(this);
  /**
   * DataRefNode를 연결할 Control
   * @type Object
   */
  this.control = poControl;
  /**
   * Control에 연결된 Instance의 ID
   * @type String
   */
  this.instanceId;
  /**
   * 해당 Instance에서 Control이 사용하는 Node의 XPath
   * @type String
   */
  this.instancePath;
  /**
   * 한번 가져온 Instance를 보관하기 위한 Map
   * @type eXria.data.Map
   * @private
   */
  this.instanceMap = new eXria.data.Map();
  /**
   * setData 발생 시 상위 노드에 업데이트 플래그를 설정할 지 여부
   * @type Boolean
   * @private
   */
  this.markUpdateAbove = false;
  /**
   * xpath의 경로 요소를 저장하기 위한 배열
   * @type Array(String)
   */
  this.paths = [];
  /**
   * 다른 페이지의 인스턴스 공유 시 해당 인스턴스를 참조하기 위한 속성
   * @type eXria.form.Page;
   * @private
   */
  this.instPage = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.DataRef, eXria.controls.JsDataRefNode);
/**
 * @ignore
 */
eXria.controls.JsDataRefNode.prototype.setPage = function(poPage) {
  this.instPage = poPage;
  if(this.control && this.control.controls) {
    var voCollection = this.control.controls;
    var vcCtl = null;
    var vnSize = voCollection.size();
    for(var i = 0; i < vnSize; i++) {
      vcCtl = voCollection.get(i);
      if(vcCtl.data) {
        vcCtl.data.setPage(poPage);
      }
    }
  }
};
/**
 * @ignore
 */
eXria.controls.JsDataRefNode.prototype.setRef = function(psInstanceId, psPath, psParentPath) {
  this.instanceId = null;
  this.instanceId = psInstanceId;
  if(psPath == null) {
    this.instancePath = null;
    return;
  }
  if(psParentPath) {
    this.instancePath = psParentPath + "/" + psPath;
  } else {
    this.instancePath = psPath;
  }

  var vaPath = this.instancePath.match(/\/[^\/]*/g);
  if(vaPath == null) vaPath = [];
  var vnCnt = vaPath.length;
  var vaRoBrk = null;
  var vaLoBrk = null;
  var vnRoCnt = 0;
  for (var i = 0; i < vnCnt; i++) {
    if (!vaPath[i]) continue;
    vaRoBrk = vaPath[i].match(/\[/g);
    if(vaRoBrk == null) vaRoBrk = [];
    vaLoBrk = vaPath[i].match(/\]/g);
    if(vaLoBrk == null) vaLoBrk = [];
    if(vnRoCnt > 0) {
      vaPath[i] = vaPath[i - 1] + vaPath[i];
      vaPath[i - 1] = "";
    }
    vnRoCnt += vaRoBrk.length;
    vnRoCnt -= vaLoBrk.length;
    if(vnRoCnt > 0) continue;

//    if (/^\/[^\/]*\[([0-9]+)\]/.test(vaPath[i])) {
//      if(page.metadata.useDomPath) {
//        vaPath[i] = eval(RegExp.$1);
//        vaPath[i]--;
//        vaPath[i] = "[" + vaPath[i] + "]";
//      }
//    } else if(/^\/[^\/]*(\[.+\])/.test(vaPath[i])) {
//      var vsQuery = "" + RegExp.$1;
//      if(page.metadata.useDomPath) vaPath[i] = vsQuery;
//    }
  }
  this.paths = [];
  for (var i = 0; i < vnCnt; i++) {
    if (!vaPath[i]) continue;
    this.paths.push(vaPath[i]);
  }
};
/**
 * @ignore
 */
eXria.controls.JsDataRefNode.prototype.getNodeData = function() { /* helper function */
  var viInstance = this.getInstance();
  if(viInstance) {
    var voInstanceNode = viInstance.selectSingleNode(this.instancePath);
    if(voInstanceNode) return new eXria.data.xhtml.ValueNode(voInstanceNode);
    else return null;
  } else {
    return null;
  }
};
/**
 * 설정된 노드의 상위 노드 DOM 객체 리턴.
 * @type Object
 * @private
 */
eXria.controls.JsDataRefNode.prototype.getParentNode = function() { /* helper function */
  var viInstance = this.getInstance();
  var voParent = null;
  if(viInstance) {
    var vsInstancePath = this.instancePath;
    if(vsInstancePath != null && vsInstancePath != "/") {
      vsInstancePath = vsInstancePath.substr(0, vsInstancePath.lastIndexOf("/"));
    }
    voParent = viInstance.selectSingleNode(vsInstancePath);
  }
  return voParent;
};
/**
 * @ignore
 */
eXria.controls.JsDataRefNode.prototype.getInstance = function() {
  var voPage = this.instPage;
  var voNode = null;
  if(voPage) {
    voNode = voPage.getInstance(this.instanceId);
  } else {
    voNode = this.instanceMap.get(this.instanceId);
  }
  if(voNode == null) {
    if(voPage == null) voPage = page;
    voNode = voPage.getInstance(this.instanceId);
    this.instanceMap.put(this.instanceId, voNode);
  }
  return voNode;
};
/**
 * @ignore
 */
eXria.controls.JsDataRefNode.prototype.getData = function() {
  if(this.instancePath == null) return "";
	if(this.paths.length == 0) return "";
  var vaPath = this.paths;
  var voNode = this.getInstance().selectSingleNode(vaPath.join(""));
//  if(voNode == null) voNode = this.getInstance().selectSingleNode(vaPath.join("") + "@es");
  if(voNode) voNode = voNode.node;
  return voNode;
};
/**
 * @ignore
 */
eXria.controls.JsDataRefNode.prototype.setData = function(psData) {
  if(this.instancePath == null) return;
	if(psData === null) psData = "";
  
  var voInst = this.getInstance();
  var voParentNode = voInst.selectSingleNode(this.paths.slice(0, this.paths.length - 1).join(""));
  if(voParentNode == null) return;
  var vsLastPath = this.paths[this.paths.length - 1].replace("/", "");
  var vbChanged = false;
  if(voParentNode.node[vsLastPath] != psData) vbChanged = true;
  voParentNode.node[vsLastPath] = psData;
  if(this.markUpdateAbove) {
    var vsStatus = voParentNode.node["status"];
    if(vsStatus == null) vsStatus = "";
    if(vsStatus.indexOf("U") == -1 && vbChanged) voParentNode.node["status"] = vsStatus + "U"; 
    if(voInst.copyInstObj != null) {
      var vbResult = this.compareRecord(voParentNode.name);
      if(vbResult) voParentNode.node["status"] = "";
    }
  }
};
/**
 * 인스턴스 패스가 절대 패스 인지 여부 리턴.
 * @return 인스턴스 패스가 절대 패스 인지 여부
 * @type Boolean
 */
eXria.controls.JsDataRefNode.prototype.isRelativeRef = function() {
  var vbRelative = false;
  if(this.instancePath.indexOf("/") != 0) vbRelative = true;

  return vbRelative;
};

//수정
/**
 * copyInstance 사용하여 백업된 Instance와 현재 Instance 값을 비교한다.
 * @param {Integer} 해당 컨트롤의 rowIndex(InstIdx)
 * @param {String} 해당 컨트롤의 nodeName
 * @param {String} 해당 컨트롤의 마지막 nodeName
 * @return boolean
 */
eXria.controls.JsDataRefNode.prototype.compareRecord = function(pnIndex) {
  var vbResult = false;
  var vsInstPath = null;
  var voInstance = null;
  var vsControlType = this.control.toString();

  if(vsControlType != "GridEx") {
    vsInstPath = this.paths.slice(0, this.paths.length - 1).join("");
    voInstance = this.getInstance();
  } else {
    vsInstPath = this.nodesetInstancePath;
    voInstance = this.getNodesetInstance();
  }
  
  var vsOriginInst = voInstance.copyInstObj;
  var vsOriginAttr = null;
  var vsJsonData = null;
  var vsOriginData = null;
  
  for(var vsAttr in vsOriginInst) {
    vsOriginAttr = vsAttr;
    break;
  }
  
  if(vsControlType != "GridEx") {
    vsJsonData = voInstance.getJSON(vsInstPath);
    vsOriginData = voInstance.toJSONString(vsOriginInst[vsOriginAttr][pnIndex]);
  } else {
    vsJsonData = voInstance.getJSON(vsInstPath + "["+ pnIndex + "]");
    vsOriginData = voInstance.toJSONString(vsOriginInst[vsOriginAttr][pnIndex]);
  }
  
  var regexpFirst = /{"status\":\s\"[UDRA]+\",\s/g; 
  var regexpMiddle = /,\s"status\":\s\"[UDRA]+\"/g;
  var regexpLast = /,\s"status\":\s\"[UDRA]+\"}/g;
  
  vsJsonData = vsJsonData.replace(regexpFirst, "{");
  vsJsonData = vsJsonData.replace(regexpMiddle, "");
  vsJsonData = vsJsonData.replace(regexpLast, "}");

  if(vsOriginData == vsJsonData) vbResult = true;
  return vbResult;
}