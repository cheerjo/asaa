/**
 * @fileoverview
 * Abstract Data Reference(데이타 레퍼런스 기본 클래스).
 * @author 조동일
 */

/**
 * @class Abstract Data Reference classs<br>
 * 데이타 레퍼런스 기본 클래스
 * @version 2.0
 * @constructor
 * @return 새로운 eXria.controls.DataRef 객체
 * @type eXria.controls.DataRef
 */
eXria.controls.DataRef = function() {
};
/**
 * Control에 Instance의 특정 node를 매핑한다.<br>
 * Studio를 이용하여 개발 할때는 서버 파서에 의해 스크립트 변환과정 중에
 * 자동 호출되고, 동적으로 control을 생성하는 container(repeater, treeview,...)
 * 에서는 자체 컨트롤 구현을 통해 호출되도록 한다.
 * @param {String} psInstanceId Page에서 Unique한 InstanceId
 * @param {String} psPath 해당 Instance에서의 태그명<br>
 *   ex psPath)
 *     실제 노드의 XPath가 /simple_data 일때
 *     psPath는 simple_data
 * @param {String} psParentPath control이 repeater나 tree view등
 *   container control안에 포함되어 있는 경우 container control의
 *   node XPath. container control에 포함되지 않을 경우는
 *   넘기지 않는다.<br>
 *   node의 인덱스가 필요한 경우 index도 포함한다.
 *   ex)
 *     /root/main_list/list[1]
 */
eXria.controls.DataRef.prototype.setRef = function(psInstanceId, psPath, psParentPath) {};
/**
 * page에 접근해서 instance를 찾아서
 * ValueNode로 instance의 데이타를 wrapping하여 리턴.
 * @return ValueNode로 wrapping된 instance의 데이타
 * @type eXria.data.xhtml.ValueNode
 */
eXria.controls.DataRef.prototype.getNodeData = function() {};
/**
 * page에 접근해서 instance를 찾아서 리턴.
 * @return 페이지 instance
 * @type eXria.data.Instance
 */
eXria.controls.DataRef.prototype.getInstance = function() {};
/**
 * Control에 매핑된 Data Instance의 nodeValue를 리턴한다.
 * @return Control에 매핑된 Data Instance의 TextNode의 nodeValue
 * @type String|Array(String)
 */
eXria.controls.DataRef.prototype.getData = function() {};
/**
 * Control에 매핑된 Data Instance에 넘겨진 값을 입력한다.
 * @param {String} psData Data Instance에 입력할 String Value
 */
eXria.controls.DataRef.prototype.setData = function() {};
/**
 * 다른 페이지의 인스턴스 참조 시 해당 페이지 참조 속성을 설정하기 위한 메소드
 * @param {eXria.form.Page} poPage 인스턴스를 참조할 페이지 객체
 */
 eXria.controls.DataRef.prototype.setPage = function() {};