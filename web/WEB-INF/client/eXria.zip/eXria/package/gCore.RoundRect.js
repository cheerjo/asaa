﻿/**
 * gCore.RoundRect
 */
gCore.RoundRect = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pnRound) {
  /**
   * inherit
   */
  gCore.Rectangle.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * round
   * public member
   * 0.0 ~ 1.0
   */
  this.round = pnRound;

};
