﻿/**
 * FillableShape
 */
gCore.FillableShape = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /*
   * inherit
   */
  gCore.Shape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * fill
   * public member
   */
  this.fill = null;

  /**
   * setFill
   * public method
   */
  this.setFill = null;

  /**
   * attachFill
   * private method
   */
  this.attachFill = null;

};
