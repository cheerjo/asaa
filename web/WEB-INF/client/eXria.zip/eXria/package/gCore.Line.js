﻿/**
 * gCore.Line
 */
gCore.Line = function(psId, pnX1, pnY1, pnX2, pnY2) {

  var vnLeft = Math.min(pnX1, pnX2);
  var vnTop = Math.min(pnY1, pnY2);
  var vnWidth = Math.abs(pnX1 - pnX2) + 1;
  var vnHeight = Math.abs(pnY1 - pnY2) + 1;

  /**
   * inherit
   */
  gCore.Shape.call(this, psId, vnLeft, vnTop, vnWidth, vnHeight);

  /**
   * startX
   * public member
   */
  this.startX = pnX1;

  /**
   * startY
   * public member
   */
  this.startY = pnY1;

  /**
   * endX
   * public member
   */
  this.endX = pnX2;

  /**
   * endY
   * public member
   */
  this.endY = pnY2;

};