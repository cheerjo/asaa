﻿/**
 * gCore.Circle
 */
gCore.Circle = function(psId, pnCenterX, pnCenterY, pnRadius) {

  /**
   * init
   */
  var vnLeft = pnCenterX - pnRadius;
  var vnTop = pnCenterY - pnRadius;
  var vnDiameter = pnRadius * 2;

  /**
   * inherit
   */
  gCore.Ellipse.call(this, psId, vnLeft, vnTop, vnDiameter, vnDiameter);

  /**
   * centerX
   * public member
   */
  this.centerX = pnCenterX;

  /**
   * centerY
   * public member
   */
  this.centerY = pnCenterY;

  /**
   * radius
   * public member
   */
  this.radius = pnRadius;

};
