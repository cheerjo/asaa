﻿/**
 * gCore.vml.JoinTypes
 */
gCore.vml.JoinTypes = [
  "miter", // MITER
  "round", // ROUND
  "bevel"  // BEVEL
];
