﻿/**
 * gCore.vml.Ellipse
 */
gCore.vml.Ellipse = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /**
   * inherit
   */
  gCore.vml.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElement("v:oval");
    voCtrl.setAttribute("id", this.id);
    var voStyle = voCtrl.style;
    voStyle.left = this.left;
    voStyle.top = this.top;
    voStyle.width = (this.width < 0 ? 0 : this.width) + "px";
    voStyle.height = (this.height < 0 ? 0 : this.height) + "px";
    voStyle.rotation = this.angle; //
    voStyle.cursor = this.cursor;
    return voCtrl;
  };

};
