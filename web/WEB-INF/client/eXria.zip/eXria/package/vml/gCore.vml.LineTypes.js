﻿/**
 * gCore.vml.LineTypes
 */
gCore.vml.LineTypes = [
  "solid", // solid
  "1 1", // dot
  "2 2" // dash
];
