﻿/**
 * gCore.vml.Line
 */
gCore.vml.Line = function(psId, pnX1, pnY1, pnX2, pnY2) {

  var vnLeft = Math.min(pnX1, pnX2);
  var vnTop = Math.min(pnY1, pnY2);
  var vnWidth = Math.abs(pnX1 - pnX2) + 1;
  var vnHeight = Math.abs(pnY1 - pnY2) + 1;

  /**
   * inherit
   */
  gCore.vml.Shape.call(this, psId, vnLeft, vnTop, vnWidth, vnHeight);

  this.startX = pnX1;
  this.startY = pnY1;
  this.endX = pnX2;
  this.endY = pnY2;

  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElement("v:line");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("from", this.startX + "," + this.startY);
    voCtrl.setAttribute("to", this.endX + "," + this.endY);
    var voStyle = voCtrl.style;
    voStyle.rotation = this.angle; //
    voStyle.cursor = this.cursor;
    return voCtrl;
  };

};