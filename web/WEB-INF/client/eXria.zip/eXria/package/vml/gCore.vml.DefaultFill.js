﻿/**
 * gCore.vml.DefaultFill
 */
gCore.vml.DefaultFill = function() {

  gCore.vml.Fill.call(this, gCore.FillType.DEFAULT, "#F0F0F0", "F0F0F0", 1.0, 0);

};
