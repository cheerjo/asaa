﻿/**
 * gCore.vml.Fill
 */
gCore.vml.Fill = function(psType, psColor, psColor2, pnOpacity, pnAngle) {
  /**
   * inherit
   */
  gCore.Fill.call(this, psType, psColor, psColor2, pnOpacity, pnAngle);

  this.apply = function(poCtrl) {
    var voCtrl = this.shape.pane.document.createElement("v:fill");
    voCtrl.setAttribute("id", this.shape.id + "_fill");
    voCtrl.setAttribute("type", this.type);
    voCtrl.setAttribute("color", this.color);
    voCtrl.setAttribute("color2", this.color2);
    voCtrl.setAttribute("opacity", (this.opacity * 100) + "%");
    if(this.opacity == 0) voCtrl.setAttribute("type", "solid");
    voCtrl.setAttribute("angle", 270 - this.angle);
    voCtrl.setAttribute("on", this.visible && this.type != gCore.FillType.NONE ? true : false);
    poCtrl.appendChild(voCtrl);
    return poCtrl;
  };

  this.getCtrl = function() {
  return this.shape.pane.document.getElementById(this.shape.id + "_fill");
  };

};
