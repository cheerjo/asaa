﻿/**
 * gCore.vml
 */
gCore.vml = {};