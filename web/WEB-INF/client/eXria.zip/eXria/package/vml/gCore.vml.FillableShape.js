﻿/**
 * gCore.vml.FillableShape
 */
gCore.vml.FillableShape = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /*
   * inherit
   */
  gCore.vml.Shape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * fill
   * public member
   */
  this.fill = null;

  /**
   * setFill
   * public method
   */
  this.setFill = function(poFill) {
  this.fill = poFill;
  this.fill.shape = this;
  };

  /**
   * attachFill
   * private method
   */
  this.attachFill = function(poCtrl) {
    this.fill.apply(poCtrl);
    return poCtrl;
  };

  /*
   * init
   */
  this.setFill(new gCore.vml.DefaultFill());

};
