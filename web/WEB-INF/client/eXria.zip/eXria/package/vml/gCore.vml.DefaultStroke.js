﻿/**
 * gCore.vml.DefaultStroke
 */
gCore.vml.DefaultStroke = function() {

  gCore.vml.Stroke.call(this, gCore.LineType.DEFAULT, 1, "#505050", 1.0, gCore.LineCapType.DEFAULT, gCore.JoinType.DEFAULT);

};
