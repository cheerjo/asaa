﻿/**
 * gCore.Text
 */
gCore.Text = function(psId, pnLeft, pnTop, pnWidth, pnHeight, psString, pnPosition) {
  /**
   * inherit
   */
  gCore.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  this.string = psString;

  this.position = pnPosition;

  this.fontFamily = "Dotum";
  this.fontSize = 12;
  this.fontStyle = "normal";
  this.fontWeight = "normal";

};