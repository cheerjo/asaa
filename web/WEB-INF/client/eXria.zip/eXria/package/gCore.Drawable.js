﻿/**
 * gCore.Drawable
 */
gCore.Drawable = function(psId) {

  this.id = psId;

  this.getCtrl = null;

  /**
   * draw
   * public method
   */
  this.draw = null;

};
