﻿/**
 * gCore.TextPosition
 */
gCore.TextPosition = {
  DEFAULT : 0,
  TOPLEFT : 0,
  TOPCENTER : 1,
  TOPRIGHT : 2,
  MIDDLELEFT : 3,
  MIDDLECENTER : 4,
  MIDDLERIGHT : 5,
  BOTTOMLEFT : 6,
  BOTTOMCENTER : 7,
  BOTTOMRIGHT : 8
};