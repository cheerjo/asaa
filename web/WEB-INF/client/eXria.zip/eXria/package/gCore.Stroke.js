﻿/**
 * Stroke
 */
gCore.Stroke = function(pnType, pnWeight, psColor, pnOpacity, pnLineCap, pnJoinType) {

  this.shape = null;
  this.type = pnType;
  this.weight = pnWeight;
  this.color = psColor;
  this.opacity = pnOpacity;
  this.lineCap = pnLineCap;
  this.joinType = pnJoinType;

  this.visible = true;
};