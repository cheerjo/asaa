﻿/**
 * gCore.svg.Text
 */
gCore.svg.Text = function(psId, pnLeft, pnTop, pnWidth, pnHeight, psString, pnPosition) {
  /**
   * inherit
   */
  gCore.svg.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * init
   */
  this.stroke.visible = false;
  this.fill.color = "#000000";

  this.string = psString;

  this.position = pnPosition || gCore.TextPosition.DEFAULT;


  /**
   * fontFamily
   * public member
   * default Dotum
   */
  this.fontFamily = "Dotum";

  /**
   * fontSize
   * public member
   * default 12
   */
  this.fontSize = 12;

  /**
   * fontStyle
   * public member
   * default normal
   */
  this.fontStyle = "normal";

  /**
   * fontWeight
   * public member
   * default normal
   */
  this.fontWeight = "normal";

  /**
   * createCtrl
   * private method
   */
  this.createCtrl = function() {

  var vsTextAnchor = null;
  var vsBaseLine = null;
  var vnX = 0;
  var vnY = 0;

  var vnTopCorrect = 0;
  var vnMiddleCorrect = 0;
  var vnBottomCorrect = 0;

  if (gCore.browser.opera) {
    vnTopCorrect = Math.round(this.fontSize * 0.85);
    vnMiddleCorrect = Math.round(this.fontSize * 0.7 / 2);
    vnBottomCorrect = Math.round(this.fontSize /  10);
    } else if (gCore.browser.webkit) {
    vnTopCorrect -= Math.round(this.fontSize * 0.05);
    vnMiddleCorrect = Math.round(this.fontSize * 0.12);
    vnBottomCorrect = Math.round(this.fontSize * 0.30);
    }

  switch (this.position) {
    case gCore.TextPosition.TOPLEFT :
      vnX = this.left;
      vnY = this.top + vnTopCorrect;
      vsTextAnchor = "start";
      vsBaseLine = "text-before-edge";
      break;
    case gCore.TextPosition.TOPCENTER :
      vnX = this.left + Math.round(this.width / 2);
      vnY = this.top + vnTopCorrect;
      vsTextAnchor = "middle";
      vsBaseLine = "text-before-edge";
      break;
    case gCore.TextPosition.TOPRIGHT :
      vnX = this.left + this.width - 1;
      vnY = this.top + vnTopCorrect;
      vsTextAnchor = "end";
      vsBaseLine = "text-before-edge";
      break;
    case gCore.TextPosition.MIDDLELEFT :
      vnX = this.left;
      vnY = this.top + Math.round(this.height / 2) + vnMiddleCorrect;
      vsTextAnchor = "start";
      vsBaseLine = "middle";
      break;
    case gCore.TextPosition.MIDDLECENTER :
      vnX = this.left + Math.round(this.width / 2);
      vnY = this.top + Math.round(this.height / 2) + vnMiddleCorrect;
      vsTextAnchor = "middle";
      vsBaseLine = "middle";
      break;
    case gCore.TextPosition.MIDDLERIGHT :
      vnX = this.left + this.width - 1;
      vnY = this.top + Math.round(this.height / 2) + vnMiddleCorrect;
      vsTextAnchor = "end";
      vsBaseLine = "middle";
      break;
    case gCore.TextPosition.BOTTOMLEFT :
      vnX = this.left;
      vnY = this.top + this.height - 1 - vnBottomCorrect;
      vsTextAnchor = "start";
      vsBaseLine = "text-after-edge";
      break;
    case gCore.TextPosition.BOTTOMCENTER :
      vnX = this.left + Math.round(this.width / 2);
      vnY = this.top + this.height - 1 - vnBottomCorrect;
      vsTextAnchor = "middle";
      vsBaseLine = "text-after-edge";
      break;
    case gCore.TextPosition.BOTTOMRIGHT :
      vnX = this.left + this.width - 1;
      vnY = this.top + this.height - 1 - vnBottomCorrect;
      vsTextAnchor = "end";
      vsBaseLine = "text-after-edge";
      break;
    }

    var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "text");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("x", vnX);
    voCtrl.setAttribute("y", vnY);

    voCtrl.setAttribute("font-family", "\"" + this.fontFamily + "\"");
    voCtrl.setAttribute("font-size", this.fontSize);
    voCtrl.setAttribute("font-style", this.fontStyle);
    voCtrl.setAttribute("font-weight", this.fontWeight);
    voCtrl.setAttribute("text-anchor", vsTextAnchor);
    voCtrl.setAttribute("dominant-baseline", vsBaseLine);
    voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + vnX + "," + vnY + ")");

    var voText = document.createTextNode(this.string);
    voCtrl.appendChild(voText);
    return voCtrl;
  };

};