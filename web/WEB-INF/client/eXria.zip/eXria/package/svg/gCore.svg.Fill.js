/**
 * gCore.svg.Fill
 */
gCore.svg.Fill = function(psType, psColor, psColor2, pnOpacity, pnAngle) {
  /**
   * inherit
   */
  gCore.Fill.call(this, psType, psColor, psColor2, pnOpacity, pnAngle);

  this.apply = function(poCtrl) {

  // visible false or FillType.NONE
    if (this.visible == false || this.type == gCore.FillType.NONE) {
      poCtrl.setAttribute("fill", "none");
    } else {
    // FillType.SOLID
      if (this.type == gCore.FillType.SOLID) {
        poCtrl.setAttribute("fill", this.color);
      // FillType.GRADIENT
      } else if (this.type == gCore.FillType.GRADIENT) {
        var voDefs = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "defs");

        var voLinearGradient = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "linearGradient");
        var vsId = this.shape.id + "_gradient_fill";
        voLinearGradient.setAttribute("id", vsId);
        voLinearGradient.setAttribute("gradientUnits", "objectBoundingBox");
   //     var vnCx = this.shape.left + Math.round(this.shape.width / 2);
   //     var vnCy = this.shape.top + Math.round(this.shape.height / 2);
        var vnCx = 0;
        var vnCy = 0;
        voLinearGradient.setAttribute("gradientTransform", "rotate(" + this.angle + ", " + vnCx + ", " + vnCy + ")");

        var voStop1 = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "stop");
        voStop1.setAttribute("id", vsId + "_stop1");
        voStop1.setAttribute("offset", "5%");
        voStop1.setAttribute("stop-color", this.color);
        voLinearGradient.appendChild(voStop1);

        var voStop2 = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "stop");
        voStop2.setAttribute("id", vsId + "_stop2");
        voStop2.setAttribute("offset", "95%");
        voStop2.setAttribute("stop-color", this.color2);
        voLinearGradient.appendChild(voStop2);

        poCtrl.parentNode.appendChild(voDefs);
        voDefs.appendChild(voLinearGradient);

        poCtrl.setAttribute("fill", "url(#" + vsId + ")");
      } else if (this.type == gCore.FillType.GRADIENTRADIAL) {
        var voDefs = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "defs");

        var voRadialGradient = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "radialGradient");
        var vsId = this.shape.id + "_gradientradial_fill";
        voRadialGradient.setAttribute("id", vsId);
        var vsCx = "0";
        var vsCy = "0";
        var vsR = "100%";
        var vsFx = "0";
        var vsFy = "0";
        voRadialGradient.setAttribute("cx", vsCx);
        voRadialGradient.setAttribute("cy", vsCy);
        voRadialGradient.setAttribute("r", vsR);
        voRadialGradient.setAttribute("fx", vsFx);
        voRadialGradient.setAttribute("fy", vsFy);
        
        var voStop1 = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "stop");
        voStop1.setAttribute("id", vsId + "_stop1");
        voStop1.setAttribute("offset", "5%");
        voStop1.setAttribute("stop-color", this.color);
        voRadialGradient.appendChild(voStop1);

        var voStop2 = this.shape.pane.document.createElementNS("http://www.w3.org/2000/svg", "stop");
        voStop2.setAttribute("id", vsId + "_stop2");
        voStop2.setAttribute("offset", "95%");
        voStop2.setAttribute("stop-color", this.color2);
        voRadialGradient.appendChild(voStop2);

        poCtrl.parentNode.appendChild(voDefs);
        voDefs.appendChild(voRadialGradient);

        poCtrl.setAttribute("fill", "url(#" + vsId + ")");
      }
      poCtrl.setAttribute("fill-opacity", this.opacity);
    }
    return poCtrl;
  };

};
