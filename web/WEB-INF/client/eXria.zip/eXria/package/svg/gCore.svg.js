﻿/**
 * gCore.svg
 */
gCore.svg = {};