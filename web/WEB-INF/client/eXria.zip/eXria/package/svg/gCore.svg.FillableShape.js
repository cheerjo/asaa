﻿/**
 * gCore.svg.FillableShape
 */
gCore.svg.FillableShape = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /*
   * inherit
   */
  gCore.svg.Shape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * fill
   * public member
   */
  this.fill = null;

  /**
   * setFill
   * public method
   */
  this.setFill = function(poFill) {
  this.fill = poFill;
  this.fill.shape = this;
  };

  /**
   * attachFill
   * private method
   */
  this.attachFill = function(poCtrl) {
    this.fill.apply(poCtrl);
    return poCtrl;
  };

  /*
   * init
   */
  this.setFill(new gCore.svg.DefaultFill());

};
