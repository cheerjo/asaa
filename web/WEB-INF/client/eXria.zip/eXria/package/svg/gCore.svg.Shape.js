﻿/**
 * gCore.svg.Shape
 */
gCore.svg.Shape = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /*
   * inherit
   */
  gCore.Shape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * @inherited
   */
  this.draw = function(poParent) {
    var voCtrl = this.createCtrl();
    poParent.appendChild(voCtrl);
    if (this.attachStroke) { this.attachStroke(voCtrl); }
    if (this.attachFill) { this.attachFill(voCtrl); }

    return voCtrl;
  };

  /**
   * @inherited
   */
  this.setStroke = function(poStroke) {
  this.stroke = poStroke;
  this.stroke.shape = this;
  };

  /**
   * @inherited
   */
  this.attachStroke = function(poCtrl) {
    this.stroke.apply(poCtrl);
    return poCtrl;
  };

  /*
   * init
   */
  this.setStroke(new gCore.svg.DefaultStroke());

};
