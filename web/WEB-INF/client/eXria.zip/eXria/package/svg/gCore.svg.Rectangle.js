﻿/**
 * gCore.svg.Rectangle
 */
gCore.svg.Rectangle = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /**
   * inherit
   */
  gCore.svg.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "rect");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("x", this.left);
    voCtrl.setAttribute("y", this.top );
    voCtrl.setAttribute("width", this.width);
    voCtrl.setAttribute("height", this.height);

    var vnCx = this.left + this.width/2;
    var vnCy = this.top + this.height/2;
    voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + vnCx + "," + vnCy + ")");
    var voStyle = voCtrl.style;
    voStyle.cursor = this.cursor;
    return voCtrl;
  };

};
