﻿/**
 * gCore.Polyline
 */
gCore.Polyline = function(psId) {
  /**
   * inherit
   */
  gCore.FillableShape.call(this, psId, null, null, null, null);

  /**
   * points
   * public member
   * array
   */
  this.points = null;

  /**
   * addPoint
   * public method
   */
  this.addPoint = null;

  this.minX = null;
  this.minY = null;
  this.maxX = null;
  this.maxY = null;

};
