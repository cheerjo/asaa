﻿/**
 * gCore.FillType
 */
gCore.FillType = {
  DEFAULT : "solid",
  NONE : "none",
  SOLID : "solid",
  GRADIENT : "gradient",
  GRADIENTRADIAL : "gradientradial" // reserved
};
