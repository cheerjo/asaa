/**
 * @fileoverview
 * FileDownLoadUtil
 */
/**
 * FileDownLoadUtil
 * 파일 다운로드를 위한 유틸
 * @constructor
 */
eXria.util.FileDownloadUtil = function(poPage) {
  /**
   * page
   * @type {eXria.form.Page} poPage
   * @see eXria.form.Page
   * @ignore
   */
  this.page = poPage;
  /**
   * downLoadForm
   * @ignore
   */
  this.downLoadForm = null;
  /**
   *  파라미터 추가
   *  @param {eXria.form.Page} poPage page 객체
   *  @param {String} psKey 파라미터의 Id
   *  @param {String} psValue 파라미터의 value
   *  @return void
   *  @type void
   */
  this.addParam = function(poPage, psKey, psValue) {
	var voInputElement = poPage.window.document.createElement("input");
	voInputElement.setAttribute("type", "hidden");
	voInputElement.setAttribute("id", psKey);
	voInputElement.setAttribute("name", psKey);
	voInputElement.setAttribute("value", psValue);
	this.downLoadForm.appendChild(voInputElement);
  };
  /**
   *  action URL 설정
   *  @param {String} psAction action url
   *  @return void
   *  @type void
   */
  this.setURL = function(psAction) {
	var vsRegAction;
	var vsTmpAction = psAction;
	var vsRegAction = null;

	if(this.page.metadata.submitBaseUrl == null || this.page.metadata.submitBaseUrl == "") {
	  if(eXria.util.StringUtil.startsWith(vsTmpAction, "/")) {
		vsRegAction = "." + psAction;
	  } else {
		vsRegAction = psAction;
	  }
	} else if(vsTmpAction.length > 4 && eXria.util.StringUtil.startsWith(vsTmpAction.toUpperCase(), "HTTP")) {
	  vsRegAction = psAction;
	} else {
	  if(eXria.util.StringUtil.startsWith(vsTmpAction, "/")) {
		if(eXria.util.StringUtil.endsWith(this.page.metadata.submitBaseUrl, "/")) {
		  vsTmpAction = psAction.substring(1);
		}
		vsRegAction = this.page.metadata.submitBaseUrl + vsTmpAction;
	  } else {
		if(eXria.util.StringUtil.endsWith(this.page.metadata.submitBaseUrl, "/")) {
		  vsRegAction = this.page.metadata.submitBaseUrl + psAction;
		} else {
		  vsRegAction = this.page.metadata.submitBaseUrl + "/" + psAction;
		}
	  }
	}
	this.downLoadForm.setAttribute("action", vsRegAction);
  };
  /**
   * 파일을 다운로드 하는 메서드
   * @return void
   * @type void
   */
  this.fileDown = function() {
    this.bindErrMsg();
    
    this.downLoadForm.submit();
    this.downLoadForm.reset();
    this.downLoadForm.parentNode.removeChild(this.downLoadForm);
    this.downLoadForm = null;
  };
  /**
   *  initialize, iFrame은 MultipartBuilder의 것을 사용
   *  @param {eXria.form.Page} poPage
   *  @return void
   *  @type void
   *  @ignore
   */
  this.init = function(poPage) {
	var voPageDocument = poPage.window.document;
  var vnBrowserVer = poPage.metadata.browser.ie;
  
	// IE
	if(vnBrowserVer > 0) {
	  var voDiv = voPageDocument.getElementById("hiddenFormDiv");

	  if(voDiv == null || voDiv == undefined) {
  		var voFrameDiv = voPageDocument.createElement("DIV");
  		voFrameDiv.setAttribute("id", "hiddenFormDiv");
  		voFrameDiv.setAttribute("name", "hiddenFormDiv");
          		
  		voFrameDiv.innerHTML = "<iframe id='fileUpHiddenFrm' name='fileUpHiddenFrm' style='display:none'></iframe>";
      
      if(vnBrowserVer >= 8) {
        voPageDocument.body.appendChild(voFrameDiv);
      } else {
        voPageDocument.appendChild(voFrameDiv); 
      }
	  }
	} else {	// non IE
	  var voHiddenFrm = voPageDocument.getElementById("fileUpHiddenFrm");

	  if(voHiddenFrm == null || voHiddenFrm == undefined) {
		var voHiddenFrame = voPageDocument.createElement("iframe");
		voHiddenFrame.setAttribute("id", "fileUpHiddenFrm");
		voHiddenFrame.setAttribute("name", "fileUpHiddenFrm");
		voHiddenFrame.style.display = "none";
		voPageDocument.body.appendChild(voHiddenFrame);	
	  }
	}
	this.downLoadForm = voPageDocument.createElement("form");
	this.downLoadForm.setAttribute("method", "POST");
	this.downLoadForm.setAttribute("target", "fileUpHiddenFrm");
	voPageDocument.body.appendChild(this.downLoadForm);
  };
  /**
   *  iframe body의 에러메세지 처리
   *  @return void
   *  @type void
   *  @ignore
   */
  this.bindErrMsg = function(){
    var voPage = this.page;
    var voPageDocument = voPage.window.document;
    
    var fileDownLoadComplete = function() {
      var vsResult = null;
      var voReadyState = voPageDocument.getElementById("fileUpHiddenFrm").readyState;

      // iframe body의 error msg 가져오기
      if(voReadyState && voReadyState == "complete") { //IE
        vsResult = voPageDocument.frames["fileUpHiddenFrm"].document.body;
        if(vsResult != null) vsResult = vsResult.innerText;
      } else { // IE외
        try {
          vsResult = voPageDocument.getElementById("fileUpHiddenFrm").contentWindow.document.body.firstChild.firstChild.nodeValue;
        } catch(e) {
        }
      }
      
      // error msg를 instance에 bind
      if(vsResult != null) {
        try {
          vsResult =eval("(" + vsResult + ")");
          var voDefInst = voPage.model.getInstance(voPage.model.defaultInstanceId);
          var voErr = voDefInst.selectSingleNode("/root/EXRIAERRMSG");
          if(voErr.hasChildNodes()) {
            voErr.parentNode["EXRIAERRMSG"] = "";
          }
          if(!vsResult) return;
          if(!vsResult.root.EXRIAERRMSG) return;
      
          var voResErr = null;
          voResErr = new eXria.data.json.Node(vsResult.root.EXRIAERRMSG);
          var voResErrNode = voResErr.getChildNodes();
          var vnErrLen = voResErrNode.getLength();
          for(var i = 0 ; i < vnErrLen ; i++) {  
            voErr.appendChild((voResErrNode.item(i)).cloneNode(true));
          }
        } catch(err) {
        }
      }
    };

    if (voPage.metadata.browser.ie > 0) {
      voPageDocument.getElementById("fileUpHiddenFrm").onreadystatechange = function() {
        fileDownLoadComplete();
      };
    } else {
      voPageDocument.getElementById("fileUpHiddenFrm").onload = function() {
        fileDownLoadComplete();
      };
    }
  };
  /**
   * @ignore
   */
  this.init(poPage);
};