/**
 * @fileoverview
 * eXria.util.NumberUtil
 */
/**
 * eXria.util.NumberUtil
 * @author Choe, hyeon jong.
 * @constructor
 */
eXria.util.NumberUtil = {
  /**
   * Number 속성 데이터에 대한 null값 체크를 한다.</br>
   * @param {Object} puValue null체크를 할 데이터
   * @param {Number} pnFix 첫번째 파라미터가 null일 경우 대체할 데이터
   * @return 첫번째로 넘어온 데이터가 Number 혹은 String 타입의 Number일 경우</br>해당 값을 리턴하며,</br>null이거나 undefined일 경우 두번째로 넘어온</br>데이터가 리턴된다.
   * @type Number 
   */
  fixNull : function(puValue, pnFix) {
	if(typeof(pnFix) != "number" || pnFix instanceof Number)
	  throw new Error("Parameter is not a number.");
	
	if(!puValue) {
		return pnFix;
	} else if(typeof(puValue) == "number" || puValue instanceof Number) {
        return puValue;
    } else {
		var vnNum =  Number(puValue);
		return isNaN(vnNum) ? pnFix : vnNum;
	}
  }
};