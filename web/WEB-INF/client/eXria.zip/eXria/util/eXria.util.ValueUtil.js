/**
 * @fileoverview
 * ValueUtil
 * Value 체크 및 형 변환
 */
 
/**
 * ValueUtil
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.util.ValueUtil = {
    /**
     * Null 여부 체크
     * @param {Object} puValue null 체크를 할 객체
     * @return null 이라면 true, 아니라면 false
     * @type Boolean
     */
    isNull : function (puValue) {
        return (eXria.util.StringUtil.fixNull(puValue) == "");
    },
    /**
     * Number형 value인지 체크 : ex) ValueUtil.isNumber("1234.56") == true
     * @param {String} psValue 체크할 문자열
     * @return 숫자라면 true, 아니라면 false
     * @type Boolean
     */
    isNumber : function (psValue) {
        var vnNum = Number(psValue);
        return isNaN(vnNum) == false;
    },

    /**
     * null이거나 정의되지 않은경우 ""로 반환
     * @param {Object} puValue 체크할 객체
     * @return null이라면 공백, null이 아니라면 해당 문자열 리턴
     * @type String
     */
    fixNull : function (puValue) {
        var vsType = typeof(puValue);
        if(vsType == "string" || (vsType == "object" && puValue instanceof String)) {
        	puValue = eXria.util.StringUtil.trim(puValue);
        }
        return (puValue == null || puValue == "null" || puValue == "undefined") ? "" : String(puValue);
    },

    /**
     * Boolean형으로 반환
     * @param {Object} puValue Boolean으로 반환할 객체
     * @return 파라미터가 boolean 데이터일 경우 그대로 리턴.</br>Number일 경우 0이 아니면 true, 0이면 false.</br>String일경우 TRUE면 true, 아니면 false리턴
     * @type Boolean
     */
    fixBoolean : function (puValue) {
        if (typeof(puValue) == "boolean" || puValue instanceof Boolean) {
            return puValue;
        }
        if (typeof(puValue) == "number" || puValue instanceof Number) {
            return puValue != 0;
        }
        return (eXria.util.StringUtil.fixNull(puValue).toUpperCase() == "TRUE");
    },

    /**
     * Number형으로 반환
     * @param {Object} puValue Number형으로 반환할 객체
     * @return 파라미터가 Number일 경우 그대로 리턴.</br>아닐 경우 파라미터를 숫자로 변경 후 리턴</br>파라미터가 null 혹은 정의되지 않았을 경우 0 리턴
     * @type Number
     */
    fixNumber : function (puValue) {
        if (typeof(puValue) == "number" || puValue instanceof Number) {
            return puValue;
        }
        var vnNum = Number(eXria.util.StringUtil.fixNull(puValue));
        return isNaN(vnNum) ? 0 : vnNum;
    }

};