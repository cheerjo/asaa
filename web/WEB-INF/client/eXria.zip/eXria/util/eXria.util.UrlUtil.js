﻿/**
 * @fileoverview
 * UrlUtil
 */
 
/**
 * UrlUtil
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.util.UrlUtil = {
  parse : function(puValue, psDefault) {
    //TODO
  },
  /**
   * 파라미터로 넘어온 url을 절대 주소로 변경하여 리턴하는 메소드
   * @param {String} psUrl
   * @type String
   * @return 절대주소로 변경된 String
   */
  getAbsoluteUrl : function(psUrl) {
	var vsUrl = null;
	if(psUrl.toUpperCase().indexOf("HTTP") == 0) {
		vsUrl = psUrl;
	} else if(psUrl.indexOf("../") == 0 || psUrl.indexOf("./") == 0) {
	  var vsUrl = page.metadata.url;
	  var vsDocPath = vsUrl.substring(0, vsUrl.lastIndexOf("/") + 1);
	  vsUrl = vsDocPath + psUrl;
	} else if(psUrl.indexOf("/") == 0) {
	  var voLocation = page.window.location;
	  vsUrl = voLocation.protocol + "//" + voLocation.host + page.metadata.resourceBaseUrl + psUrl.substring(1, psUrl.length);
	} else if(psUrl.indexOf("/") == -1) {
	  var vsUrl = page.metadata.url;
	  vsUrl = vsUrl.substring(0, vsUrl.lastIndexOf("/")) + "/" + psUrl;
	} else if(psUrl.indexOf("/") > 0) {
	  var voLocation = page.window.location;
	  vsUrl = voLocation.protocol + "//" + voLocation.host + page.metadata.resourceBaseUrl + psUrl;
	}
	return vsUrl;
  }
}; 