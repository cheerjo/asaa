/**
 * @fileoverview
 * BooleanUtil
 */
 
/**
 * BooleanUtil
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.util.BooleanUtil = {

  /**
   * fix</br>
   * default : null, undefined, NaN -> false</br>
   * boolean, Boolean -> boolean</br>
   * null, undefined, NaN -> default</br>
   * Math.NEGATIVE_INFINITY -> false</br>
   * Math.POSITIVE_INFINITY -> true</br>
   * string, String -> equals true ?</br>
   * number, Number -> > 0 ?</br>
   * @return 변경된 Boolean 데이터
   * @type Boolean
   */
  fix : function(puValue, pbDefault) {
    var vbDefault = pbDefault || false;

    // boolean, Boolean
    var vsType = typeof(puValue);
    if (vsType == "boolean" || (vsType == "Object" && puValue instanceof Boolean)) {
      return puValue == true;

    // null, undefined, NaN
    } else if (puValue == null || puValue == undefined || puValue == NaN) {
      return vbDefault;

    // NEGATIVE_INFINITY
    } else if (puValue == Math.NEGATIVE_INFINITY) {
      return false;

    // POSITIVE_INFINITY
    } else if (puValue == Math.POSITIVE_INFINITY) {
      return true;
    }

    // string, String
    var vsValue = new String(puValue);
    if (eXria.util.StringUtil.equals(vsValue, "true")) {
      return true;

    // number, Number
    } else if (new Number(vsValue) > 0) {
      return true;
    } 

    return vbDefault;
  },

  /**
   * 파라미터로 넘어온 2개의 데이터가 같은 데이터인지 비교한다.
   * @return 같다면 true, 틀리다면 false
   * @type Boolean
   */
  equals : function(puValue1, puValue2) {
    return this.fix(puValue1, false) == this.fix(puValue2, false);
  }

};
