/**
 * @fileoverview
 * DomUtil
 */

/**
 * DomUtil
 * 
 * @version 1.0
 * @constructor
 */
eXria.util.DomUtil = {
  /**
   * 파라미터로 넘어온 XMLNode를 기존의 Dom에 추가
   * @param {XMLNode} poDom 넘어온 XMLNode를 추가할 Dom
   * @param {XMLNode} poXML 기존의 Dom에 추가시킬 XMLNode
   * @param {Boolean} pbMode 넘어온 XMLNode를 기존의 Dom에 추가시 false,</br>기존의 Dom을 초기화 후 추가시 true.
   * @return void
   * @type void
   */
  load : function(poDom, poXML, pbMode) {
    var voOriNode = new eXria.data.xhtml.CollectionNode(poDom);

    if (pbMode) { //replace 
      voOriNode.clear();
    }

    //    var voNodes = poXML.childNodes;
    // var vnLength = voNodes.length;
    var voNodes = poXML.getChildNodes();
    var vnLength = voNodes.getLength();

    for ( var i = 0; i < vnLength; i++) {
      voOriNode.add(voNodes.item(i).cloneNode(true));
    }
  },

  /**
   * 넘겨 받은 parentNode에 append 될 Node를 생성 후 추가(IE8과 관련하여 Document가 틀린 Node가 붙지 않는 문제)
   * @param {XMLNode} poParentNode 넘어온 node를 추가할 Node
   * @param {XMLNode} poAppendNode 추가 될 Node
   * @return void
   * @type void
   * @private
   */
  appendNodeElement : function(poParentNode, poAppendNode, poDocument) {
    var voWhiteSpace = /\S/;
    var voNode = null;
    var voCreateNode = null;

    if (poAppendNode.nodeType == 1) {
      var voFirstChild = poAppendNode.firstChild;

      if (voFirstChild == null) {
        voCreateNode = poDocument.createNode(poAppendNode.nodeName);
        poParentNode.appendChild(voCreateNode);
      } else {
        if (!voWhiteSpace.test(voFirstChild.nodeValue)) {
          voFirstChild = voFirstChild.nextSibling;
        }

        if (voFirstChild.nodeType == 1) {
          voCreateNode = poDocument.createNode(poAppendNode.nodeName);
          poParentNode.appendChild(voCreateNode);
          poParentNode = voCreateNode;
        }
      }
    }

    var voChilds = poAppendNode.childNodes;
    var vnChildLen = voChilds.length;

    if (vnChildLen == 0)
      return null;

    for ( var i = 0; i < vnChildLen; i++) {
      if (!voWhiteSpace.test(voChilds[i].nodeValue))
        continue;

      if (!voChilds[i].firstChild) {
        voCreateNode = poDocument.createNode(voChilds[i].nodeName);

        poParentNode.appendChild(voCreateNode);
      } else if (voChilds[i].firstChild.nodeType == 3
          || voChilds[i].firstChild.nodeType == 4) {
        voCreateNode = poDocument.createNode(voChilds[i].nodeName);

        var voValue = voCreateNode.firstChild;
        if (voValue != null) {
          voValue.nodeValue = voChilds[i].firstChild.nodeValue;
        } else {
          voCreateNode.appendChild(voCreateNode.ownerDocument
              .createTextNode(voChilds[i].firstChild.nodeValue));
        }
        poParentNode.appendChild(voCreateNode);
      } else {
        if (voChilds[i].nodeType == 1) {
          if (voChilds[i].firstChild.nodeType == 1) {
            eXria.util.DomUtil.appendNodeElement(poParentNode, voChilds[i],
                poDocument);
          }
        }
      }
    }
  }
};